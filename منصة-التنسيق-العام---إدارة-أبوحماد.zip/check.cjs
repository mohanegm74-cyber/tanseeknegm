const fs = require('fs');
const content = fs.readFileSync('src/components/CoordinationAdminPortal.tsx', 'utf8');
const lines = content.split('\n');
let startLine = 1593;
let endLine = 3790;

console.log("Analyzing JSX Tags on lines " + startLine + " to " + endLine);
let tags = [];
const tagRegex = /<\/?[a-zA-Z0-9_\-]+(?:\s+[^>]*?)?>/g;

for (let i = startLine - 1; i < endLine; i++) {
  const line = lines[i];
  let match;
  while ((match = tagRegex.exec(line)) !== null) {
    const fullTag = match[0];
    const isClosing = fullTag.startsWith('</');
    const isSelfClosing = fullTag.endsWith('/>');
    
    // Extract tag name
    let nameMatch = fullTag.match(/<\/?([a-zA-Z0-9_\-]+)/);
    if (!nameMatch) continue;
    const tagName = nameMatch[1];
    
    // Ignore self-closing tags
    if (isSelfClosing) continue;
    
    if (isClosing) {
      if (tags.length === 0) {
        console.log("Unmatched closing tag: " + fullTag + " on line " + (i + 1));
      } else {
        const last = tags.pop();
        if (last.name !== tagName) {
          console.log(`Mismatched tag: opened <${last.name}> on line ${last.line}, closed with </${tagName}> on line ${i + 1}`);
        }
      }
    } else {
      tags.push({ name: tagName, line: i + 1, full: fullTag });
    }
  }
}

console.log("Open tags remaining: " + tags.length);
tags.forEach(t => {
  console.log(`Unclosed <${t.name}> opened on line ${t.line}`);
});
