import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "15mb" }));

// Initialize the Gemini client utility
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API routes FIRST
app.post("/api/ai-report", async (req, res) => {
  try {
    const { analytics, schoolsData, materialsData } = req.body;

    const systemInstruction = 
      "أنت خبير ومستشار تخطيط تربوي وتنسيق تعليمي في وزارة التربية والتعليم بمصر. " +
      "مهمتك هي كتابة تقرير تحليل علمي وعملي ملخص ومفيد جداً ومباشر باللغة العربية الفصحى وبصيغة رسمية واضحة. " +
      "التقرير يجب أن يشرح تلخيصاً شاملاً ومفيداً لحالة العجز والزيادة بالمدارس ومعدلات تغطية الحصص والأنصبة استناداً إلى الأرقام والبيانات المرسلة إليك دون إسهاب أو إطالة غير مفيدة. " +
      "يجب أن تتضمن هيكلية التقرير الأقسام التالية بوضوح وبشكل موجز وعملي:\n" +
      "1. مقدمة موجزة ورسمية للارتقاء بالعملية التعليمية بالشرقية وإدارة أبوحماد.\n" +
      "2. تحليل رقمي سريع لحالة العجز والزيادة (تحديد أعلى المدارس والمواد عجزاً، وأكثرها وفرة، وتفسير الملاحظات الرئيسية باختصار وتحليل كفاءة التوزيع).\n" +
      "3. التداعيات التعليمية والتربوية الأساسية (الأثر على جودة اليوم الدراسي، ومستويات التحصيل للطلاب).\n" +
      "4. أهم الإيجابيات الحالية المكتشفة من واقع رصد قوى المدارس.\n" +
      "5. السلبيات والتحديات القائمة التي تستوجب التدخل العاجل.\n" +
      "6. توصيات وخطوات عملية استراتيجية وبدائل مبتكرة وقابلة للتطبيق الفوري (مثل الندب الجزئي، تدوير الأنصبة، الاستعانة بالمعلمين بالحصة، دمج فصول محددة، تفعيل الفصول الذكية).\n" +
      "7. خاتمة بليغة وموجزة تلهم متخذي القرار وتدعم ريادة إدارة أبو حماد التعليمية.\n" +
      "فضلاً ركّز على الاختصار الهادف وتقديم نقاط مباشرة ومفيدة مع استخدام لغة مهنية غنية ومصطلحات تخطيطية قوية (مثل: الاستثمار الأمثل للموارد البشرية، الفجوة التنسيقية، كفاءة التشغيل، الخطة الداعمة).";

    const prompt = `الرجاء كتابة التقرير التلخيصي الشامل المفيد والمباشر (تحليل ذكاء اصطناعي مكثف وبناء) بناءً على البيانات الواقعية المحدثة التالية لإدارة أبوحماد التعليمية:

أولاً: إحصائيات عامة جملة بالإدارة:
- عدد المدارس المقيدة: ${analytics.totalSchools} مدرسة.
- إجمالي عدد المعلمين المقيدين الفعلي (تخصصات أساسية): ${analytics.totalTeachers || "غير محدد"}.
- إجمالي القيادات المدرسية والوكلاء: ${analytics.totalLeadership || "غير محدد"} قيادي.
- إجمالي الإخصائيين بالمدارس: ${analytics.totalSpecialists || "غير محدد"} أخصائي.
- إجمالي الإداريين ومشرفي الأنشطة: ${analytics.totalAdmins || "غير محدد"} موظف.
- إجمالي العمال والخدمات المعاونة والحراسة: ${analytics.totalLabor || "غير محدد"} عامل.
- نسبة الحضور الطلابية العامة التقريبية: ${analytics.studentAttendanceRate || "100"}%.
- معدل تغطية الحصص والأنصبة الكلية بالإدارة: ${analytics.generalCoveragePercentage || "100"}%.
- الرقم الإجمالي المكتشف للعجز (بالمعلمين): ${analytics.totalDeficit || "0"} معلم.
- الرقم الإجمالي المكتشف للزيادة الوفرة (بالمعلمين): ${analytics.totalSurplus || "0"} معلم.

ثانياً: تفاصيل المدارس والتبعية في هذه اللحظة:
${JSON.stringify(schoolsData)}

ثالثاً: ملخص المواد الدراسية ومستويات التغطية والعجز والزيادة بالإدارة:
${JSON.stringify(materialsData)}

الرجاء إنشاء تحليل منهجي مكثف ومفيد للغاية وملخص وبليغ ومنسق باستخدام صيغة Markdown متميزة (عناوين عريضة، نقاط واضحة، تفصيل مباشر) دون الحاجة لأي كلمات أو جمل تمهيدية باللغات الأجنبية.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.75,
      }
    });

    const text = response.text;
    res.json({ success: true, report: text });
  } catch (error: any) {
    console.error("Gemini AI API Error:", error);
    res.status(500).json({ success: false, error: error.message || "فشل الاتصال بنظام الذكاء الاصطناعي لتوليد التقرير." });
  }
});

// Vite middleware for development
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT} under NODE_ENV=${process.env.NODE_ENV}`);
  });
}

setupVite();
