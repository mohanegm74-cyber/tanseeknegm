/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type SchoolStage = 'primary' | 'prep' | 'sec' | 'basic' | 'languages' | 'vocational' | 'nursery';

export const STAGE_LABELS: Record<SchoolStage, string> = {
  nursery: 'رياض أطفال',
  primary: 'ابتدائي',
  prep: 'إعدادي',
  basic: 'تعليم أساسي',
  sec: 'ثانوي عام',
  vocational: 'ثانوي فني',
  languages: 'رسمي لغات'
};

export interface School {
  id: string;
  name: string;
  address: string;
  year: string;
  stage: SchoolStage;
  classroomsCount: number;
  password?: string;
  createdAt?: any;
  boysCount?: number;
  girlsCount?: number;
  totalStudentsCount?: number;
}

export interface Material {
  id: string;
  name: string;
  stage: 'primary' | 'prep' | 'sec';
  quota: number; // default quota (e.g. 20, 18, 18) but can be set per material/subject (نصاب المادة)
  teacherQuota?: number; // نصاب المعلم (حصص/أسبوع)
}

export interface MaterialCount {
  schoolId: string;
  materialId: string;
  super_senior: number; // كبير معلمين
  expert: number; // خبير
  first_a: number; // معلم أول أ
  first: number; // معلم أول
  teacher: number; // معلم
  assistant: number; // معلم مساعد
  delegated: number; // منتدب
  by_class: number; // بالحصة
  classroomsCount?: number; // عدد فصول المادة للمرحلة الثانوية
  updatedAt?: string;
}

export interface Directorship {
  id: string;
  schoolId: string;
  name: string;
  nationalId: string;
  role: 'principal' | 'vice_principal';
  specialty: string;
  decisionNumber: string;
  decisionDate: string;
  address: string;
  schoolYearsCount: number;
  qualification: string;
  qualificationDate: string;
  birthDate: string;
  code: string;
  phone: string;
}

export interface StaffMember {
  id: string;
  schoolId: string;
  name: string;
  nationalId: string;
  role: 'teacher' | 'specialist' | 'admin' | 'activity_supervisor' | 'worker';
  phone: string;
  address: string;
  specialty: string;
  qualification: string;
  appointmentDate: string;
  type: 'original' | 'delegated';
  birthDate: string;
  code: string;
  assignedJob?: string;
}

export interface StudentAbsenceRecord {
  grade: string;       // e.g. "الصف الأول"
  registered: number;  // المقيد
  present: number;     // الحاضر
  absent: number;      // الغائب
}

export interface StudentAbsence {
  id: string;
  schoolId: string;
  date: string; // YYYY-MM-DD
  records: StudentAbsenceRecord[];
}

export interface TeacherAbsence {
  id: string;
  schoolId: string;
  date: string; // YYYY-MM-DD
  registered: number;   // المقيد
  delegated: number;    // الندب
  mission: number;      // مأمورية
  regularLeave: number; // اعتيادي
  sickLeave: number;    // مرضي
  present: number;      // الحاضر
  absent: number;       // الغائب
  monthKey?: string;    // YYYY-MM
}

export interface VisitorLog {
  id: string;
  schoolId: string;
  schoolName: string;
  visitorName: string;
  jobTitle: string;
  date: string;
  day: string;
  arrivalTime: string;
  attachmentData?: string; // base64 payload representing file since we are building offline-first PWA
  attachmentType?: string; // PDF, JPG, PNG
  attachmentName?: string;
}

export interface NutritionRecord {
  id: string;
  schoolId: string;
  academicYear: string;
  distributionDays: number;
  beneficiariesCount: number;
}

export interface SystemSettings {
  id: string;
  coordinationAdminUsername: string;
  coordinationAdminPass: string;
  quota_primary: number;
  quota_prep: number;
  quota_sec: number;
  administrationName?: string;
  departmentName?: string;
  undersecretariesNames?: string;
  settingsVersion?: number;
  settingsUpdatedAt?: number;
}

export interface TrashItem {
  id: string;
  originalId: string;
  type: 'school' | 'material';
  name: string;
  deletedAt: number;
  data: any;
}

export interface NominationDocument {
  id: string;
  name: string;
  type: string;
  dataUrl: string; // Can store raw base64 or storage url
}

export interface ExamNomination {
  id: string;
  schoolId: string;
  schoolName: string;
  year: string;
  name: string;
  nationalId: string;
  code: string;
  jobTitle: string;
  subject: string;
  appointmentDate: string;
  phone: string;
  address: string;
  birthDate?: string;
  obstacleId: string; // e.g. 'none', 'relative', 'investigation', 'other'
  obstacleText?: string; // custom reason text
  documents: NominationDocument[];
  status: 'draft' | 'submitted' | 'approved' | 'rejected' | 'pending';
  rejectionReason?: string;
  rejectionFeedback?: string;
  qualificationStatus: 'eligible' | 'needs_review' | 'disqualified'; // 🟢 | 🟡 | 🔴
  qualificationReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ExamObstacle {
  id: string;
  name: string;
  requiresDocument: boolean;
}

export interface ExamExcuse {
  id: string;
  schoolId: string;
  schoolName: string;
  name: string;
  nationalId: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  approvalDate?: string;
  decisionDate?: string;
  auditor?: string;
  documents?: NominationDocument[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  details: string;
  schoolId?: string;
  oldData?: string;
  newData?: string;
}

export interface ArchivedReport {
  id: string;
  title: string;
  subtitle: string;
  reportType: string;
  exportedAt: string; // ISO date string
  exportedBy: string; // e.g. 'مدير التنسيق'
  filterSchoolId?: string;
  filterMaterialId?: string;
  htmlSnapshot?: string; // Optional HTML string or content state to display or print again
  stats?: {
    totalSchools?: number;
    totalTeachers?: number;
    totalDeficit?: number;
    totalSurplus?: number;
    coveragePercentage?: number;
  };
}

