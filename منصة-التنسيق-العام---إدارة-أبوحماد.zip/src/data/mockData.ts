/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { School, Material, SystemSettings, MaterialCount, StaffMember, Directorship, StudentAbsence, TeacherAbsence, VisitorLog, NutritionRecord } from '../types';

export const INITIAL_SETTINGS: SystemSettings = {
  id: 'system_settings',
  coordinationAdminUsername: 'admin',
  coordinationAdminPass: '1234',
  quota_primary: 20,
  quota_prep: 18,
  quota_sec: 18
};

export const INITIAL_SCHOOLS: School[] = [
  {
    id: 'school_1',
    name: 'مدرسة أبو حماد الثانوية العسكرية بنين',
    address: 'شارع الجيش، أبو حماد، الشرقية',
    year: '2025/2026',
    stage: 'sec',
    classroomsCount: 15,
    password: '101'
  },
  {
    id: 'school_2',
    name: 'مدرسة أبو حماد الإعدادية بنات الجديدة',
    address: 'بجوار مجلس المدينة، أبو حماد',
    year: '2025/2026',
    stage: 'prep',
    classroomsCount: 18,
    password: '102'
  },
  {
    id: 'school_3',
    name: 'مدرسة السنجق الابتدائية',
    address: 'قرية السنجق، أبو حماد',
    year: '2025/2026',
    stage: 'primary',
    classroomsCount: 12,
    password: '103'
  },
  {
    id: 'school_4',
    name: 'مدرسة الشيخ جبيل للتعليم الأساسي',
    address: 'قرية الشيخ جبيل، أبو حماد',
    year: '2025/2026',
    stage: 'basic',
    classroomsCount: 22,
    password: '104'
  },
  {
    id: 'school_5',
    name: 'مدرسة الشهيد أحمد صبحي الرسمية للغات',
    address: 'منشية السلام، أبو حماد',
    year: '2025/2026',
    stage: 'languages',
    classroomsCount: 14,
    password: '105'
  },
  {
    id: 'school_6',
    name: 'مدرسة الصوة الابتدائية المشتركة',
    address: 'قرية الصوة، أبو حماد',
    year: '2025/2026',
    stage: 'primary',
    classroomsCount: 10,
    password: '106'
  },
  {
    id: 'school_7',
    name: 'مدرسة العباسة الثانوية المشتركة',
    address: 'قرية العباسة، أبو حماد',
    year: '2025/2026',
    stage: 'sec',
    classroomsCount: 9,
    password: '107'
  },
  {
    id: 'school_8',
    name: 'مدرسة أبو حماد الثانوية الفنية للبنات',
    address: 'طريق الزقازيق - أبو حماد الرئيسي',
    year: '2025/2026',
    stage: 'vocational',
    classroomsCount: 24,
    password: '108'
  }
];

export const INITIAL_MATERIALS: Material[] = [
  // Primary materials
  { id: 'mat_ar_pri', name: 'اللغة العربية', stage: 'primary', quota: 20 },
  { id: 'mat_en_pri', name: 'اللغة الإنجليزية', stage: 'primary', quota: 20 },
  { id: 'mat_math_pri', name: 'الرياضيات', stage: 'primary', quota: 20 },
  { id: 'mat_sci_pri', name: 'العلوم', stage: 'primary', quota: 20 },
  { id: 'mat_ss_pri', name: 'الدراسات الاجتماعية', stage: 'primary', quota: 20 },
  { id: 'mat_art_pri', name: 'التربية الفنية', stage: 'primary', quota: 20 },
  { id: 'mat_music_pri', name: 'التربية الموسيقية', stage: 'primary', quota: 20 },
  { id: 'mat_rel_pri', name: 'التربية الدينية', stage: 'primary', quota: 20 },

  // Prep materials
  { id: 'mat_ar_pre', name: 'اللغة العربية', stage: 'prep', quota: 18 },
  { id: 'mat_en_pre', name: 'اللغة الإنجليزية', stage: 'prep', quota: 18 },
  { id: 'mat_math_pre', name: 'الرياضيات', stage: 'prep', quota: 18 },
  { id: 'mat_sci_pre', name: 'العلوم', stage: 'prep', quota: 18 },
  { id: 'mat_ss_pre', name: 'الدراسات الاجتماعية', stage: 'prep', quota: 18 },
  { id: 'mat_comp_pre', name: 'الحاسب الآلي', stage: 'prep', quota: 18 },
  { id: 'mat_art_pre', name: 'التربية الفنية', stage: 'prep', quota: 18 },

  // Secondary materials
  { id: 'mat_ar_sec', name: 'اللغة العربية', stage: 'sec', quota: 18 },
  { id: 'mat_en_sec', name: 'اللغة الإنجليزية', stage: 'sec', quota: 18 },
  { id: 'mat_math_sec', name: 'الرياضيات الفنية/البحتة', stage: 'sec', quota: 18 },
  { id: 'mat_physics_sec', name: 'الفيزياء', stage: 'sec', quota: 18 },
  { id: 'mat_chemistry_sec', name: 'الكيمياء', stage: 'sec', quota: 18 },
  { id: 'mat_biology_sec', name: 'الأحياء', stage: 'sec', quota: 18 },
  { id: 'mat_history_sec', name: 'التاريخ', stage: 'sec', quota: 18 },
  { id: 'mat_geography_sec', name: 'الجغرافيا', stage: 'sec', quota: 18 },
  { id: 'mat_philosophy_sec', name: 'الفلسفة والمنطق', stage: 'sec', quota: 18 }
];

export const INITIAL_MATERIAL_COUNTS: MaterialCount[] = [
  // material allocations for School_1 (Secondary)
  {
    schoolId: 'school_1',
    materialId: 'mat_ar_sec',
    super_senior: 1,
    expert: 2,
    first_a: 2,
    first: 4,
    teacher: 3,
    assistant: 1,
    delegated: 0,
    by_class: 0.5
  },
  {
    schoolId: 'school_1',
    materialId: 'mat_en_sec',
    super_senior: 0,
    expert: 1,
    first_a: 3,
    first: 2,
    teacher: 4,
    assistant: 1,
    delegated: 1,
    by_class: 0
  },
  {
    schoolId: 'school_1',
    materialId: 'mat_math_sec',
    super_senior: 1,
    expert: 2,
    first_a: 1,
    first: 3,
    teacher: 3,
    assistant: 0,
    delegated: 0,
    by_class: 1
  },
  // Allocations for School_2 (Prep)
  {
    schoolId: 'school_2',
    materialId: 'mat_ar_pre',
    super_senior: 0,
    expert: 3,
    first_a: 2,
    first: 5,
    teacher: 4,
    assistant: 0,
    delegated: 1,
    by_class: 0
  },
  {
    schoolId: 'school_2',
    materialId: 'mat_math_pre',
    super_senior: 1,
    expert: 1,
    first_a: 2,
    first: 3,
    teacher: 5,
    assistant: 1,
    delegated: 0,
    by_class: 0
  },
  // Allocations for School_3 (Primary)
  {
    schoolId: 'school_3',
    materialId: 'mat_ar_pri',
    super_senior: 1,
    expert: 1,
    first_a: 1,
    first: 2,
    teacher: 3,
    assistant: 1,
    delegated: 1,
    by_class: 0.5
  }
];

export const INITIAL_LEADERSHIP: Directorship[] = [
  {
    id: 'lead_1',
    schoolId: 'school_1',
    name: 'جمال عبد الحميد السيد سليمان',
    nationalId: '27210151800293',
    role: 'principal',
    specialty: 'لغة عربية',
    decisionNumber: 'ق_2024_412',
    decisionDate: '2024-03-12',
    address: 'بندر أبو حماد، الشرقية',
    schoolYearsCount: 2,
    qualification: 'بكالوريوس تربية لغة عربية',
    qualificationDate: '1995-05-15',
    birthDate: '1972-10-15',
    code: '901241',
    phone: '01098241517'
  },
  {
    id: 'lead_2',
    schoolId: 'school_1',
    name: 'ممدوح سعد محمود عامر',
    nationalId: '27708221800539',
    role: 'vice_principal',
    specialty: 'رياضيات',
    decisionNumber: 'ق_2025_110',
    decisionDate: '2025-01-20',
    address: 'العباسة، أبو حماد، الشرقية',
    schoolYearsCount: 1,
    qualification: 'بكالوريوس علوم وتربية رياضيات',
    qualificationDate: '1999-05-22',
    birthDate: '1977-08-22',
    code: '954203',
    phone: '01124156689'
  },
  {
    id: 'lead_3',
    schoolId: 'school_2',
    name: 'سلوى أحمد فؤاد عيسى',
    nationalId: '27011031800234',
    role: 'principal',
    specialty: 'رياضيات',
    decisionNumber: 'ق_2023_890',
    decisionDate: '2023-09-01',
    address: 'شارع المحطة، أبو حماد',
    schoolYearsCount: 3,
    qualification: 'ليسانس وبكالوريوس تربية',
    qualificationDate: '1992-06-12',
    birthDate: '1970-11-03',
    code: '881142',
    phone: '01061448821'
  }
];

export const INITIAL_STAFF: StaffMember[] = [
  // Teachers (school_1)
  {
    id: 'staff_1',
    schoolId: 'school_1',
    name: 'أحمد محمود يوسف السعدني',
    nationalId: '28212101802931',
    role: 'teacher',
    phone: '01021451515',
    address: 'بندر أبو حماد',
    specialty: 'لغة عربية',
    qualification: 'ليسانس آداب وتربية لغة عربية',
    appointmentDate: '2005-09-10',
    type: 'original',
    birthDate: '1982-12-10',
    code: '150124'
  },
  {
    id: 'staff_2',
    schoolId: 'school_1',
    name: 'محمد صابر علي سلامة',
    nationalId: '28605051801229',
    role: 'teacher',
    phone: '01224151617',
    address: 'العباسة، أبو حماد',
    specialty: 'لغة إنجليزية',
    qualification: 'ليسانس آداب وتربية إنجليزي',
    appointmentDate: '2009-10-01',
    type: 'original',
    birthDate: '1986-05-05',
    code: '234512'
  },
  {
    id: 'staff_3',
    schoolId: 'school_1',
    name: 'علاء عبداللطيف مصطفى',
    nationalId: '29007251801452',
    role: 'teacher',
    phone: '01002541893',
    address: 'قرية الصوة، أبو حماد',
    specialty: 'الرياضيات الفنية/البحتة',
    qualification: 'بكالوريوس علوم وتربية رياضيات',
    appointmentDate: '2013-03-05',
    type: 'delegated',
    birthDate: '1990-07-25',
    code: '589632'
  },

  // Specialists (school_1)
  {
    id: 'staff_4',
    schoolId: 'school_1',
    name: 'هبة الله علي السيد منصور',
    nationalId: '28804121800241',
    role: 'specialist',
    phone: '01025114402',
    address: 'مساكن مجلس المدينة، أبو حماد',
    specialty: 'أخصائي اجتماعي',
    qualification: 'بكالوريوس خدمة اجتماعية',
    appointmentDate: '2010-10-15',
    type: 'original',
    birthDate: '1988-04-12',
    code: '302144'
  },

  // Admins (school_1)
  {
    id: 'staff_5',
    schoolId: 'school_1',
    name: 'حمدي صابر عثمان جودة',
    nationalId: '27503111802314',
    role: 'admin',
    phone: '01511245632',
    address: 'شارع الحرس الوطني، أبو حماد',
    specialty: 'مسؤول شؤون طلاب',
    qualification: 'دبلوم تجارة',
    appointmentDate: '1998-10-01',
    type: 'original',
    birthDate: '1975-03-11',
    code: '102563'
  },

  // Workers (school_1)
  {
    id: 'staff_6',
    schoolId: 'school_1',
    name: 'عطية فتحي محمود متولي',
    nationalId: '27806141804153',
    role: 'worker',
    phone: '01004125893',
    address: 'الحي الأوسط، أبو حماد',
    specialty: 'خدمات معاونة',
    qualification: 'محو أمية',
    appointmentDate: '2001-05-15',
    type: 'original',
    birthDate: '1978-06-14',
    code: '45893'
  }
];

export const INITIAL_STUDENT_ABSENCE: StudentAbsence[] = [
  {
    id: 'stu_abs_1',
    schoolId: 'school_1',
    date: new Date().toISOString().split('T')[0],
    records: [
      { grade: 'الصف الأول الثانوي', registered: 240, present: 228, absent: 12 },
      { grade: 'الصف الثاني الثانوي', registered: 210, present: 198, absent: 12 },
      { grade: 'الصف الثالث الثانوي', registered: 195, present: 180, absent: 15 }
    ]
  },
  {
    id: 'stu_abs_2',
    schoolId: 'school_2',
    date: new Date().toISOString().split('T')[0],
    records: [
      { grade: 'الصف الأول الإعدادي', registered: 300, present: 285, absent: 15 },
      { grade: 'الصف الثاني الإعدادي', registered: 280, present: 260, absent: 20 },
      { grade: 'الصف الثالث الإعدادي', registered: 265, present: 245, absent: 20 }
    ]
  }
];

export const INITIAL_TEACHER_ABSENCE: TeacherAbsence[] = [
  {
    id: 'teach_abs_1',
    schoolId: 'school_1',
    date: new Date().toISOString().split('T')[0],
    registered: 45,
    delegated: 3,
    mission: 1,
    regularLeave: 2,
    sickLeave: 1,
    present: 38,
    absent: 7, 
    monthKey: new Date().toISOString().substring(0, 7)
  }
];

export const INITIAL_VISITORS: VisitorLog[] = [
  {
    id: 'visit_1',
    schoolId: 'school_1',
    schoolName: 'مدرسة أبو حماد الثانوية العسكرية بنين',
    visitorName: 'أ. فوزي عبد الله',
    jobTitle: 'موجه لغة عربية بالإدارة',
    date: new Date().toISOString().split('T')[0],
    day: 'الثلاثاء',
    arrivalTime: '09:15',
    attachmentName: 'تقرير_موجه_لغة_عربية.pdf'
  }
];

export const INITIAL_NUTRITION: NutritionRecord[] = [
  {
    id: 'nut_1',
    schoolId: 'school_1',
    academicYear: '2025/2026',
    distributionDays: 45,
    beneficiariesCount: 645
  },
  {
    id: 'nut_2',
    schoolId: 'school_2',
    academicYear: '2025/2026',
    distributionDays: 60,
    beneficiariesCount: 845
  }
];
