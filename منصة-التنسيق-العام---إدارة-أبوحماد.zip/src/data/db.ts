/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { School, Material, MaterialCount, Directorship, StaffMember, StudentAbsence, TeacherAbsence, VisitorLog, NutritionRecord, SystemSettings, ExamNomination, ExamObstacle, ExamExcuse, AuditLog, ArchivedReport, TrashItem } from '../types';
import { INITIAL_SCHOOLS, INITIAL_MATERIALS, INITIAL_MATERIAL_COUNTS, INITIAL_LEADERSHIP, INITIAL_STAFF, INITIAL_STUDENT_ABSENCE, INITIAL_TEACHER_ABSENCE, INITIAL_VISITORS, INITIAL_NUTRITION, INITIAL_SETTINGS } from './mockData';
import { db, handleFirestoreError } from '../lib/firebase';
import { collection, setDoc, doc, deleteDoc, getDocs, query, limit, where, writeBatch } from 'firebase/firestore';

const DEFAULT_OBSTACLES: ExamObstacle[] = [
  { id: 'relatives', name: 'وجود أقارب حتى الدرجة الرابعة يؤدون الامتحان في نفس اللجنة', requiresDocument: true },
  { id: 'investigation', name: 'قيد التحقيق القانوني أو الإحالة للمحكمة التأديبية', requiresDocument: true },
  { id: 'sanction', name: 'موقع عليه جزاء تأديبي يزيد عن خمسة أيام', requiresDocument: true },
  { id: 'health', name: 'مانع صحي بموجب قرار من اللجنة الطبية المتخصصة', requiresDocument: true },
  { id: 'sick_leave', name: 'حاصل على إجازة مرضية معتمدة رسمياً', requiresDocument: true },
  { id: 'unpaid_leave', name: 'حاصل على إجازة بدون مرتب', requiresDocument: true },
  { id: 'pregnancy', name: 'إجازة رعاية طفل أو وضع ومثبتة رسمياً', requiresDocument: true },
  { id: 'seconded', name: 'منتدب كلياً أو جزئياً لجهة خارج الإدارة', requiresDocument: true },
  { id: 'other', name: 'موانع وقرارات أخرى (يلزم توضيح وإرفاق مستند)', requiresDocument: true }
];

const COLLECTION_MAP: Record<string, string> = {
  schools: 'coordination_schools',
  materials: 'coordination_materials',
  material_counts: 'coordination_material_counts',
  staff: 'coordination_staff',
  leadership: 'coordination_leadership',
  student_absences: 'coordination_student_absences',
  teacher_absences: 'coordination_teacher_absences',
  visitors: 'coordination_visitors',
  nutrition: 'coordination_nutrition',
  exam_nominations: 'coordination_exam_nominations',
  exam_obstacles: 'coordination_exam_obstacles',
  exam_excuses: 'coordination_exam_excuses',
  exam_audits: 'coordination_exam_audits',
  archived_reports: 'coordination_archived_reports',
  settings: 'coordination_settings',
  trash_items: 'coordination_trash_items'
};

// Class to manage our local State, Firestore Real-time synchronization and sync gracefully with localStorage
class LocalCoordinationDB {
  private listeners: (() => void)[] = [];
  private activeWritesCount = 0;
  private loadedSchoolsData: Record<string, boolean> = {};

  private checkIfQuotaExceeded(e: any): boolean {
    const msg = e instanceof Error ? e.message : String(e);
    if (
      msg.includes('Quota limit exceeded') ||
      msg.includes('Resource exhausted') ||
      msg.includes('Quota exceeded') ||
      msg.includes('quota') ||
      msg.includes('exhausted')
    ) {
      this.setQuotaExceeded(true);
      return true;
    }
    return false;
  }

  private isQuotaExceededCached(): boolean {
    return localStorage.getItem('firestore_quota_exceeded') === 'true';
  }

  public setQuotaExceeded(exceeded: boolean) {
    localStorage.setItem('firestore_quota_exceeded', exceeded ? 'true' : 'false');
    if (typeof window !== 'undefined') {
      (window as any).firestoreQuotaExceeded = exceeded;
      if (exceeded) {
        window.dispatchEvent(new CustomEvent('firestore-quota-exceeded'));
      }
    }
  }

  constructor() {
    this.initDatabase();
    this.seedFirestoreIfEmpty();
    this.setupFirestoreListeners();
    this.loadGlobalData().catch(err => console.warn('Background global data load failed:', err));
  }

  private initDatabase() {
    if (!localStorage.getItem('coordination_settings')) {
      localStorage.setItem('coordination_settings', JSON.stringify(INITIAL_SETTINGS));
    }
    if (!localStorage.getItem('coordination_schools')) {
      localStorage.setItem('coordination_schools', JSON.stringify(INITIAL_SCHOOLS));
    }
    if (!localStorage.getItem('coordination_materials')) {
      localStorage.setItem('coordination_materials', JSON.stringify(INITIAL_MATERIALS));
    }
    if (!localStorage.getItem('coordination_material_counts')) {
      localStorage.setItem('coordination_material_counts', JSON.stringify(INITIAL_MATERIAL_COUNTS));
    }
    if (!localStorage.getItem('coordination_leadership')) {
      localStorage.setItem('coordination_leadership', JSON.stringify(INITIAL_LEADERSHIP));
    }
    if (!localStorage.getItem('coordination_staff')) {
      localStorage.setItem('coordination_staff', JSON.stringify(INITIAL_STAFF));
    }
    if (!localStorage.getItem('coordination_student_absences')) {
      localStorage.setItem('coordination_student_absences', JSON.stringify(INITIAL_STUDENT_ABSENCE));
    }
    if (!localStorage.getItem('coordination_teacher_absences')) {
      localStorage.setItem('coordination_teacher_absences', JSON.stringify(INITIAL_TEACHER_ABSENCE));
    }
    if (!localStorage.getItem('coordination_visitors')) {
      localStorage.setItem('coordination_visitors', JSON.stringify(INITIAL_VISITORS));
    }
    if (!localStorage.getItem('coordination_nutrition')) {
      localStorage.setItem('coordination_nutrition', JSON.stringify(INITIAL_NUTRITION));
    }
    if (!localStorage.getItem('coordination_exam_nominations')) {
      localStorage.setItem('coordination_exam_nominations', JSON.stringify([]));
    }
    if (!localStorage.getItem('coordination_exam_obstacles')) {
      localStorage.setItem('coordination_exam_obstacles', JSON.stringify(DEFAULT_OBSTACLES));
    }
    if (!localStorage.getItem('coordination_exam_excuses')) {
      localStorage.setItem('coordination_exam_excuses', JSON.stringify([]));
    }
    if (!localStorage.getItem('coordination_exam_audits')) {
      localStorage.setItem('coordination_exam_audits', JSON.stringify([]));
    }
    if (!localStorage.getItem('coordination_archived_reports')) {
      localStorage.setItem('coordination_archived_reports', JSON.stringify([]));
    }
  }

  // --- FIRESTORE ADVANCED SYNC ENGINGE ---

  private async seedFirestoreIfEmpty() {
    if (this.isQuotaExceededCached()) {
      console.log('Skipping Firestore seeding because quota is exceeded.');
      return;
    }
    try {
      const tempQuery = query(collection(db, 'schools'), limit(1));
      const snaps = await getDocs(tempQuery);
      if (snaps.empty) {
        console.log('Firestore is empty. Seeding initial Abu Hammad school board data...');
        
        // Seed schools
        for (const item of INITIAL_SCHOOLS) {
          await setDoc(doc(db, 'schools', item.id), item);
        }
        // Seed materials
        for (const item of INITIAL_MATERIALS) {
          await setDoc(doc(db, 'materials', item.id), item);
        }
        // Seed material counts
        for (const item of INITIAL_MATERIAL_COUNTS) {
          await setDoc(doc(db, 'material_counts', `${item.schoolId}_${item.materialId}`), item);
        }
        // Seed leadership
        for (const item of INITIAL_LEADERSHIP) {
          await setDoc(doc(db, 'leadership', item.id), item);
        }
        // Seed staff
        for (const item of INITIAL_STAFF) {
          await setDoc(doc(db, 'staff', item.id), item);
        }
        // Seed student absences
        for (const item of INITIAL_STUDENT_ABSENCE) {
          await setDoc(doc(db, 'student_absences', item.id), item);
        }
        // Seed teacher absences
        for (const item of INITIAL_TEACHER_ABSENCE) {
          await setDoc(doc(db, 'teacher_absences', item.id), item);
        }
        // Seed visitors
        for (const item of INITIAL_VISITORS) {
          await setDoc(doc(db, 'visitors', item.id), item);
        }
        // Seed nutrition
        for (const item of INITIAL_NUTRITION) {
          await setDoc(doc(db, 'nutrition', item.id), item);
        }
        // Seed settings
        await setDoc(doc(db, 'settings', 'system_settings'), INITIAL_SETTINGS);

        // Seed obstacles
        for (const item of DEFAULT_OBSTACLES) {
          await setDoc(doc(db, 'exam_obstacles', item.id), item);
        }

        console.log('Firestore seeding completed successfully.');
      }
    } catch (e) {
      if (this.checkIfQuotaExceeded(e)) {
        console.warn('Firestore seeding skipped: Quota limit exceeded. Running in offline/cached local mode.');
      } else {
        console.error('Error seeding Firestore database instance:', e);
      }
    }
  }

  private registerDeletion(colName: string, id: string) {
    const key = `coordination_deleted_${colName}`;
    const deletedIds = JSON.parse(localStorage.getItem(key) || '[]');
    if (!deletedIds.includes(id)) {
      deletedIds.push(id);
      localStorage.setItem(key, JSON.stringify(deletedIds));
    }
  }

  private isDeleted(colName: string, id: string): boolean {
    const key = `coordination_deleted_${colName}`;
    const deletedIds = JSON.parse(localStorage.getItem(key) || '[]');
    return deletedIds.includes(id);
  }

  private setupFirestoreListeners() {
    // Disabled to prevent massive reads and respect getDocs on-demand / manual refresh architecture.
  }

  private compressData(data: any): any {
    if (!data || typeof data !== 'object') return data;
    const cleaned = { ...data };
    Object.keys(cleaned).forEach(key => {
      const val = cleaned[key];
      if (val === null || val === undefined || val === '') {
        delete cleaned[key];
      } else if (Array.isArray(val)) {
        cleaned[key] = val.map(item => this.compressData(item));
      } else if (typeof val === 'object') {
        cleaned[key] = this.compressData(val);
      }
    });
    return cleaned;
  }

  private async saveToFirestore(colName: string, docId: string, data: any): Promise<boolean> {
    const isGlobal = ['schools', 'materials', 'settings', 'exam_obstacles', 'archived_reports', 'trash_items', 'exam_audits'].includes(colName);
    if (!isGlobal) {
      console.log(`Skipping auto-sync to Firestore for school-specific collection: ${colName}`);
      return true;
    }

    if (this.isQuotaExceededCached()) {
      console.log(`Skipping saveToFirestore for ${colName}/${docId} because quota is exceeded.`);
      return true;
    }

    this.activeWritesCount++;
    try {
      const compressed = this.compressData(data);
      await setDoc(doc(db, colName, docId), compressed);
      const localKey = COLLECTION_MAP[colName];
      if (localKey) {
        localStorage.setItem(localKey + '_syncedAt', Date.now().toString());
      }
      return true;
    } catch (e) {
      if (this.checkIfQuotaExceeded(e)) {
        console.warn(`saveToFirestore failed: Quota limit exceeded. Preserving local changes.`);
      } else {
        handleFirestoreError(e, 'write' as any, `${colName}/${docId}`);
      }
      return false;
    } finally {
      this.activeWritesCount = Math.max(0, this.activeWritesCount - 1);
    }
  }

  private async deleteFromFirestore(colName: string, docId: string): Promise<boolean> {
    const isGlobal = ['schools', 'materials', 'settings', 'exam_obstacles', 'archived_reports', 'trash_items', 'exam_audits'].includes(colName);
    if (!isGlobal) {
      console.log(`Skipping auto-delete from Firestore for school-specific collection: ${colName}`);
      return true;
    }

    if (this.isQuotaExceededCached()) {
      console.log(`Skipping deleteFromFirestore for ${colName}/${docId} because quota is exceeded.`);
      return true;
    }

    this.activeWritesCount++;
    try {
      await deleteDoc(doc(db, colName, docId));
      const localKey = COLLECTION_MAP[colName];
      if (localKey) {
        localStorage.setItem(localKey + '_syncedAt', Date.now().toString());
      }
      return true;
    } catch (e) {
      if (this.checkIfQuotaExceeded(e)) {
        console.warn(`deleteFromFirestore failed: Quota limit exceeded. Preserving local changes.`);
      } else {
        handleFirestoreError(e, 'delete' as any, `${colName}/${docId}`);
      }
      return false;
    } finally {
      this.activeWritesCount = Math.max(0, this.activeWritesCount - 1);
    }
  }

  // Loaded cache helper
  public async loadGlobalData() {
    if (this.isQuotaExceededCached()) {
      console.log('Skipping loadGlobalData because quota is exceeded.');
      return;
    }
    try {
      // 1. Schools
      const schoolsSnap = await getDocs(collection(db, 'schools'));
      const schoolsList: any[] = [];
      schoolsSnap.forEach(docSnap => {
        schoolsList.push(docSnap.data());
      });
      if (schoolsList.length > 0) {
        localStorage.setItem('coordination_schools', JSON.stringify(schoolsList));
        localStorage.setItem('coordination_schools_updatedAt', Date.now().toString());
        localStorage.setItem('coordination_schools_syncedAt', Date.now().toString());
      }

      // 2. Materials
      const materialsSnap = await getDocs(collection(db, 'materials'));
      const materialsList: any[] = [];
      materialsSnap.forEach(docSnap => {
        materialsList.push(docSnap.data());
      });
      if (materialsList.length > 0) {
        localStorage.setItem('coordination_materials', JSON.stringify(materialsList));
        localStorage.setItem('coordination_materials_updatedAt', Date.now().toString());
        localStorage.setItem('coordination_materials_syncedAt', Date.now().toString());
      }

      // 3. Settings
      const settingsSnap = await getDocs(collection(db, 'settings'));
      settingsSnap.forEach(docSnap => {
        if (docSnap.id === 'system_settings') {
          localStorage.setItem('coordination_settings', JSON.stringify(docSnap.data()));
          localStorage.setItem('coordination_settings_updatedAt', Date.now().toString());
          localStorage.setItem('coordination_settings_syncedAt', Date.now().toString());
        }
      });

      // 4. Obstacles
      const obstaclesSnap = await getDocs(collection(db, 'exam_obstacles'));
      const obstaclesList: any[] = [];
      obstaclesSnap.forEach(docSnap => {
        obstaclesList.push(docSnap.data());
      });
      if (obstaclesList.length > 0) {
        localStorage.setItem('coordination_exam_obstacles', JSON.stringify(obstaclesList));
        localStorage.setItem('coordination_exam_obstacles_updatedAt', Date.now().toString());
        localStorage.setItem('coordination_exam_obstacles_syncedAt', Date.now().toString());
      }

      // 5. Archived Reports
      const reportsSnap = await getDocs(collection(db, 'archived_reports'));
      const reportsList: any[] = [];
      reportsSnap.forEach(docSnap => {
        reportsList.push(docSnap.data());
      });
      if (reportsList.length > 0) {
        localStorage.setItem('coordination_archived_reports', JSON.stringify(reportsList));
        localStorage.setItem('coordination_archived_reports_updatedAt', Date.now().toString());
        localStorage.setItem('coordination_archived_reports_syncedAt', Date.now().toString());
      }

      // 6. Trash Items
      try {
        const trashSnap = await getDocs(collection(db, 'trash_items'));
        const trashList: any[] = [];
        trashSnap.forEach(docSnap => {
          trashList.push(docSnap.data());
        });
        localStorage.setItem('coordination_trash_items', JSON.stringify(trashList));
        localStorage.setItem('coordination_trash_items_updatedAt', Date.now().toString());
        localStorage.setItem('coordination_trash_items_syncedAt', Date.now().toString());
      } catch (e) {
        console.warn('Could not load trash items on startup:', e);
      }

      // 7. Exam Audits
      try {
        const auditsSnap = await getDocs(collection(db, 'exam_audits'));
        const auditsList: any[] = [];
        auditsSnap.forEach(docSnap => {
          auditsList.push(docSnap.data());
        });
        localStorage.setItem('coordination_exam_audits', JSON.stringify(auditsList));
        localStorage.setItem('coordination_exam_audits_updatedAt', Date.now().toString());
        localStorage.setItem('coordination_exam_audits_syncedAt', Date.now().toString());
      } catch (e) {
        console.warn('Could not load exam audits on startup:', e);
      }

      this.notify();
    } catch (e) {
      if (this.checkIfQuotaExceeded(e)) {
        console.warn('loadGlobalData skipped: Quota limit exceeded. Running in offline/cached local mode.');
      } else {
        console.error('Error loading global data:', e);
      }
    }
  }

  public async loadSchoolDataFromServer(schoolId: string, force = false): Promise<void> {
    if (force) {
      this.setQuotaExceeded(false); // Reset quota exceeded flag on user manual action
    }

    if (this.loadedSchoolsData[schoolId] && !force) {
      console.log(`Data for school ${schoolId} already loaded or cached.`);
      return;
    }

    if (this.isQuotaExceededCached() && !force) {
      console.log(`Skipping loadSchoolDataFromServer for ${schoolId} because quota is exceeded.`);
      return;
    }

    console.log(`Fetching Firestore data on-demand for school: ${schoolId}`);

    const collectionsToSync = [
      { firestoreName: 'material_counts', localStorageKey: 'coordination_material_counts' },
      { firestoreName: 'staff', localStorageKey: 'coordination_staff' },
      { firestoreName: 'leadership', localStorageKey: 'coordination_leadership' },
      { firestoreName: 'student_absences', localStorageKey: 'coordination_student_absences' },
      { firestoreName: 'teacher_absences', localStorageKey: 'coordination_teacher_absences' },
      { firestoreName: 'visitors', localStorageKey: 'coordination_visitors' },
      { firestoreName: 'nutrition', localStorageKey: 'coordination_nutrition' },
      { firestoreName: 'exam_nominations', localStorageKey: 'coordination_exam_nominations' },
      { firestoreName: 'exam_excuses', localStorageKey: 'coordination_exam_excuses' }
    ];

    try {
      for (const col of collectionsToSync) {
        const q = query(collection(db, col.firestoreName), where('schoolId', '==', schoolId));
        const snap = await getDocs(q);
        const fetchedDocs: any[] = [];
        snap.forEach(docSnap => {
          fetchedDocs.push({ ...docSnap.data() });
        });

        // Soft delete filtering
        const filteredDocs = fetchedDocs.filter(item => {
          const itemId = col.firestoreName === 'material_counts'
            ? `${item.schoolId}_${item.materialId}`
            : (item.id || '');
          return !this.isDeleted(col.firestoreName, itemId);
        });

        // Merge this school's data into localStorage
        const existingLocal = this.getData<any>(col.localStorageKey);
        const otherSchoolsData = existingLocal.filter((item: any) => item.schoolId !== schoolId);
        const merged = [...otherSchoolsData, ...filteredDocs];

        localStorage.setItem(col.localStorageKey, JSON.stringify(merged));
        const now = Date.now().toString();
        localStorage.setItem(col.localStorageKey + '_updatedAt', now);
        localStorage.setItem(col.localStorageKey + '_syncedAt', now);
      }
      this.loadedSchoolsData[schoolId] = true;
      this.notify();
    } catch (e) {
      if (this.checkIfQuotaExceeded(e)) {
        console.warn(`loadSchoolDataFromServer failed: Quota limit exceeded for school ${schoolId}.`);
      } else {
        console.error(`Error loading data for school ${schoolId}:`, e);
      }
    }
  }

  public hasUnsyncedChanges(schoolId?: string): boolean {
    const collectionsToSync = [
      { key: 'coordination_schools', isSchoolSpecific: false },
      { key: 'coordination_material_counts', isSchoolSpecific: true },
      { key: 'coordination_staff', isSchoolSpecific: true },
      { key: 'coordination_leadership', isSchoolSpecific: true },
      { key: 'coordination_student_absences', isSchoolSpecific: true },
      { key: 'coordination_teacher_absences', isSchoolSpecific: true },
      { key: 'coordination_visitors', isSchoolSpecific: true },
      { key: 'coordination_nutrition', isSchoolSpecific: true },
      { key: 'coordination_exam_nominations', isSchoolSpecific: true },
      { key: 'coordination_exam_excuses', isSchoolSpecific: true },
      { key: 'coordination_archived_reports', isSchoolSpecific: false }
    ];

    for (const col of collectionsToSync) {
      const updatedAt = Number(localStorage.getItem(col.key + '_updatedAt') || '0');
      const syncedAt = Number(localStorage.getItem(col.key + '_syncedAt') || '0');
      if (updatedAt > syncedAt) {
        if (schoolId && col.isSchoolSpecific) {
          const localData = this.getData<any>(col.key);
          const hasUnsyncedSchoolItems = localData.some(item => item.schoolId === schoolId);
          if (hasUnsyncedSchoolItems) {
            return true;
          }
        } else {
          return true;
        }
      }
    }
    return false;
  }

  public async syncAllUnsyncedToFirestore(): Promise<void> {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.log('Skipping syncAllUnsyncedToFirestore because device is offline.');
      return;
    }
    if (this.isQuotaExceededCached()) {
      console.log('Skipping syncAllUnsyncedToFirestore because quota is exceeded.');
      return;
    }
    console.log("Triggering auto-sync of all unsynced changes to Firestore...");
    
    try {
      // 1. Schools
      const schoolsUpdatedAt = Number(localStorage.getItem('coordination_schools_updatedAt') || '0');
      const schoolsSyncedAt = Number(localStorage.getItem('coordination_schools_syncedAt') || '0');
      if (schoolsUpdatedAt > schoolsSyncedAt) {
        const schools = this.getSchools();
        for (const s of schools) {
          await setDoc(doc(db, 'schools', s.id), this.compressData(s));
        }
        localStorage.setItem('coordination_schools_syncedAt', Date.now().toString());
      }

      // 2. Materials
      const materialsUpdatedAt = Number(localStorage.getItem('coordination_materials_updatedAt') || '0');
      const materialsSyncedAt = Number(localStorage.getItem('coordination_materials_syncedAt') || '0');
      if (materialsUpdatedAt > materialsSyncedAt) {
        const materials = this.getMaterials();
        for (const m of materials) {
          await setDoc(doc(db, 'materials', m.id), this.compressData(m));
        }
        localStorage.setItem('coordination_materials_syncedAt', Date.now().toString());
      }

      // 3. Settings
      const settingsUpdatedAt = Number(localStorage.getItem('coordination_settings_updatedAt') || '0');
      const settingsSyncedAt = Number(localStorage.getItem('coordination_settings_syncedAt') || '0');
      if (settingsUpdatedAt > settingsSyncedAt) {
        const settings = this.getSettings();
        await setDoc(doc(db, 'settings', 'system_settings'), this.compressData(settings));
        localStorage.setItem('coordination_settings_syncedAt', Date.now().toString());
      }

      // 4. Trash Items
      const trashUpdatedAt = Number(localStorage.getItem('coordination_trash_items_updatedAt') || '0');
      const trashSyncedAt = Number(localStorage.getItem('coordination_trash_items_syncedAt') || '0');
      if (trashUpdatedAt > trashSyncedAt) {
        const trash = this.getTrashItems();
        for (const t of trash) {
          await setDoc(doc(db, 'trash_items', t.id), this.compressData(t));
        }
        localStorage.setItem('coordination_trash_items_syncedAt', Date.now().toString());
      }

      // 5. Exam Audits / Logs
      const auditsUpdatedAt = Number(localStorage.getItem('coordination_exam_audits_updatedAt') || '0');
      const auditsSyncedAt = Number(localStorage.getItem('coordination_exam_audits_syncedAt') || '0');
      if (auditsUpdatedAt > auditsSyncedAt) {
        const audits = this.getAuditLogs();
        for (const a of audits) {
          await setDoc(doc(db, 'exam_audits', a.id), this.compressData(a));
        }
        localStorage.setItem('coordination_exam_audits_syncedAt', Date.now().toString());
      }

      // Clean deleted globals
      const deletedSchools: string[] = JSON.parse(localStorage.getItem('coordination_deleted_schools') || '[]');
      for (const id of deletedSchools) {
        await deleteDoc(doc(db, 'schools', id));
      }
      localStorage.setItem('coordination_deleted_schools', '[]');

      const deletedMaterials: string[] = JSON.parse(localStorage.getItem('coordination_deleted_materials') || '[]');
      for (const id of deletedMaterials) {
        await deleteDoc(doc(db, 'materials', id));
      }
      localStorage.setItem('coordination_deleted_materials', '[]');

      const deletedTrash: string[] = JSON.parse(localStorage.getItem('coordination_deleted_trash_items') || '[]');
      for (const id of deletedTrash) {
        await deleteDoc(doc(db, 'trash_items', id));
      }
      localStorage.setItem('coordination_deleted_trash_items', '[]');

      this.notify();
    } catch (e) {
      console.error("Auto-sync of unsynced changes to Firestore failed:", e);
    }
  }

  public async syncSchoolToFirestore(schoolId: string): Promise<boolean> {
    this.setQuotaExceeded(false); // Reset quota status on user manual sync attempt
    const batch = writeBatch(db);
    let countOps = 0;

    // Helper to safely write documents
    const addWrite = (colName: string, docId: string, data: any) => {
      const compressed = this.compressData(data);
      const docRef = doc(db, colName, docId);
      batch.set(docRef, compressed);
      countOps++;
    };

    const addDelete = (colName: string, docId: string) => {
      const docRef = doc(db, colName, docId);
      batch.delete(docRef);
      countOps++;
    };

    // 1. Schools
    const schools = this.getSchools().filter(s => s.id === schoolId);
    schools.forEach(s => addWrite('schools', s.id, s));

    // 2. Material Counts
    const materialCounts = this.getMaterialCounts().filter(mc => mc.schoolId === schoolId);
    materialCounts.forEach(mc => addWrite('material_counts', `${mc.schoolId}_${mc.materialId}`, mc));

    // 3. Staff
    const staff = this.getStaff().filter(s => s.schoolId === schoolId);
    staff.forEach(s => addWrite('staff', s.id, s));

    // 4. Leadership
    const leadership = this.getLeadership().filter(l => l.schoolId === schoolId);
    leadership.forEach(l => addWrite('leadership', l.id, l));

    // 5. Student Absences
    const studentAbs = this.getStudentAbsences().filter(sa => sa.schoolId === schoolId);
    studentAbs.forEach(sa => addWrite('student_absences', sa.id, sa));

    // 6. Teacher Absences
    const teacherAbs = this.getTeacherAbsences().filter(ta => ta.schoolId === schoolId);
    teacherAbs.forEach(ta => addWrite('teacher_absences', ta.id, ta));

    // 7. Visitors
    const visitors = this.getVisitors().filter(v => v.schoolId === schoolId);
    visitors.forEach(v => addWrite('visitors', v.id, v));

    // 8. Nutrition
    const nutrition = this.getNutritionRecords().filter(n => n.schoolId === schoolId);
    nutrition.forEach(n => addWrite('nutrition', n.id, n));

    // 9. Exam nominations
    const examNominations = this.getExamNominations().filter(en => en.schoolId === schoolId);
    examNominations.forEach(en => addWrite('exam_nominations', en.id, en));

    // 10. Exam excuses
    const examExcuses = this.getExamExcuses().filter(ee => ee.schoolId === schoolId);
    examExcuses.forEach(ee => addWrite('exam_excuses', ee.id, ee));

    // Deletions
    const colsToClean = [
      'schools', 'material_counts', 'staff', 'leadership',
      'student_absences', 'teacher_absences', 'visitors', 'nutrition',
      'exam_nominations', 'exam_excuses'
    ];

    colsToClean.forEach(colName => {
      const key = `coordination_deleted_${colName}`;
      const deletedIds: string[] = JSON.parse(localStorage.getItem(key) || '[]');
      deletedIds.forEach(id => {
        let belongs = false;
        if (colName === 'material_counts') {
          belongs = id.startsWith(`${schoolId}_`);
        } else {
          belongs = true; 
        }
        if (belongs) {
          addDelete(colName, id);
        }
      });
    });

    if (countOps === 0) {
      console.log('No operations to sync for school: ', schoolId);
      return true;
    }

    this.activeWritesCount++;
    try {
      await batch.commit();

      // Clear deleted lists in local storage after successful commit
      colsToClean.forEach(colName => {
        const key = `coordination_deleted_${colName}`;
        const deletedIds: string[] = JSON.parse(localStorage.getItem(key) || '[]');
        const remaining = deletedIds.filter(id => {
          if (colName === 'material_counts') {
            return !id.startsWith(`${schoolId}_`);
          }
          return false; 
        });
        localStorage.setItem(key, JSON.stringify(remaining));
      });

      // Update _syncedAt keys
      const collectionsToSync = [
        { firestoreName: 'schools', localStorageKey: 'coordination_schools' },
        { firestoreName: 'material_counts', localStorageKey: 'coordination_material_counts' },
        { firestoreName: 'staff', localStorageKey: 'coordination_staff' },
        { firestoreName: 'leadership', localStorageKey: 'coordination_leadership' },
        { firestoreName: 'student_absences', localStorageKey: 'coordination_student_absences' },
        { firestoreName: 'teacher_absences', localStorageKey: 'coordination_teacher_absences' },
        { firestoreName: 'visitors', localStorageKey: 'coordination_visitors' },
        { firestoreName: 'nutrition', localStorageKey: 'coordination_nutrition' },
        { firestoreName: 'exam_nominations', localStorageKey: 'coordination_exam_nominations' },
        { firestoreName: 'exam_excuses', localStorageKey: 'coordination_exam_excuses' }
      ];

      const now = Date.now().toString();
      collectionsToSync.forEach(col => {
        localStorage.setItem(col.localStorageKey + '_syncedAt', now);
        localStorage.setItem(col.localStorageKey + '_updatedAt', now);
      });

      this.notify();
      return true;
    } catch (e) {
      if (this.checkIfQuotaExceeded(e)) {
        console.warn('Batch sync failed: Quota limit exceeded.');
      } else {
        handleFirestoreError(e, 'write' as any, `batch_sync_school_${schoolId}`);
      }
      return false;
    } finally {
      this.activeWritesCount = Math.max(0, this.activeWritesCount - 1);
    }
  }

  // Subscribe to changes in DB
  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(listener => {
      try {
        listener();
      } catch (e) {
        console.error('Error in listener', e);
      }
    });
  }

  // Generic Storage Helpers
  private getData<T>(key: string): T[] {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  }

  private saveData<T>(key: string, data: T[]) {
    localStorage.setItem(key, JSON.stringify(data));
    localStorage.setItem(key + '_updatedAt', Date.now().toString());
    this.notify();
  }

  // System Settings
  public getSettings(): SystemSettings {
    const data = localStorage.getItem('coordination_settings');
    return data ? JSON.parse(data) : INITIAL_SETTINGS;
  }

  public saveSettings(settings: SystemSettings, incrementVersion = true) {
    if (incrementVersion) {
      settings.settingsVersion = (settings.settingsVersion || 1) + 1;
      settings.settingsUpdatedAt = Date.now();
    }
    localStorage.setItem('coordination_settings', JSON.stringify(settings));
    localStorage.setItem('coordination_settings_updatedAt', Date.now().toString());
    this.saveToFirestore('settings', 'system_settings', settings);
    this.notify();
  }

  public autoUpdateSettingsVersion() {
    const settings = this.getSettings();
    this.saveSettings(settings, true);
  }

  // Schools
  public getSchools(): School[] {
    return this.getData<School>('coordination_schools');
  }

  public saveSchool(school: School) {
    const schools = this.getSchools();
    const index = schools.findIndex(s => s.id === school.id);
    if (index >= 0) {
      schools[index] = { ...schools[index], ...school };
    } else {
      schools.push(school);
    }
    this.saveData('coordination_schools', schools);
    this.saveToFirestore('schools', school.id, school);
    this.autoUpdateSettingsVersion();
  }

  public deleteSchool(id: string) {
    this.registerDeletion('schools', id);
    const schools = this.getSchools().filter(s => s.id !== id);
    this.saveData('coordination_schools', schools);
    this.deleteFromFirestore('schools', id);

    // clean up related records locally and on Firestore
    const countsFiltered = this.getMaterialCounts().filter(m => m.schoolId !== id);
    this.saveData('coordination_material_counts', countsFiltered);
    this.getMaterialCounts().filter(m => m.schoolId === id).forEach(m => {
      this.deleteFromFirestore('material_counts', `${m.schoolId}_${m.materialId}`);
    });

    const staffFiltered = this.getStaff().filter(s => s.schoolId !== id);
    this.saveData('coordination_staff', staffFiltered);
    this.getStaff().filter(m => m.schoolId === id).forEach(m => {
      this.deleteFromFirestore('staff', m.id);
    });

    const leadershipFiltered = this.getLeadership().filter(l => l.schoolId !== id);
    this.saveData('coordination_leadership', leadershipFiltered);
    this.getLeadership().filter(m => m.schoolId === id).forEach(m => {
      this.deleteFromFirestore('leadership', m.id);
    });

    const studentAbsFiltered = this.getStudentAbsences().filter(a => a.schoolId !== id);
    this.saveData('coordination_student_absences', studentAbsFiltered);
    this.getStudentAbsences().filter(m => m.schoolId === id).forEach(m => {
      this.deleteFromFirestore('student_absences', m.id);
    });

    const teacherAbsFiltered = this.getTeacherAbsences().filter(a => a.schoolId !== id);
    this.saveData('coordination_teacher_absences', teacherAbsFiltered);
    this.getTeacherAbsences().filter(m => m.schoolId === id).forEach(m => {
      this.deleteFromFirestore('teacher_absences', m.id);
    });

    const visitorsFiltered = this.getVisitors().filter(v => v.schoolId !== id);
    this.saveData('coordination_visitors', visitorsFiltered);
    this.getVisitors().filter(m => m.schoolId === id).forEach(m => {
      this.deleteFromFirestore('visitors', m.id);
    });

    const nutritionFiltered = this.getNutritionRecords().filter(n => n.schoolId !== id);
    this.saveData('coordination_nutrition', nutritionFiltered);
    this.getNutritionRecords().filter(m => m.schoolId === id).forEach(m => {
      this.deleteFromFirestore('nutrition', m.id);
    });

    this.autoUpdateSettingsVersion();
  }

  // Materials
  public getMaterials(): Material[] {
    return this.getData<Material>('coordination_materials');
  }

  public saveMaterial(material: Material) {
    const materials = this.getMaterials();
    const index = materials.findIndex(m => m.id === material.id);
    if (index >= 0) {
      materials[index] = { ...materials[index], ...material };
    } else {
      materials.push(material);
    }
    this.saveData('coordination_materials', materials);
    this.saveToFirestore('materials', material.id, material);
    this.autoUpdateSettingsVersion();
  }

  public deleteMaterial(id: string) {
    this.registerDeletion('materials', id);
    const materials = this.getMaterials().filter(m => m.id !== id);
    this.saveData('coordination_materials', materials);
    this.deleteFromFirestore('materials', id);

    // clean counts
    const cleanCounts = this.getMaterialCounts().filter(c => c.materialId !== id);
    this.saveData('coordination_material_counts', cleanCounts);
    this.getMaterialCounts().filter(c => c.materialId === id).forEach(c => {
      this.deleteFromFirestore('material_counts', `${c.schoolId}_${c.materialId}`);
    });
    this.autoUpdateSettingsVersion();
  }

  // Material Counts per school
  public getMaterialCounts(): MaterialCount[] {
    return this.getData<MaterialCount>('coordination_material_counts');
  }

  public saveMaterialCount(count: MaterialCount) {
    const counts = this.getMaterialCounts();
    const index = counts.findIndex(c => c.schoolId === count.schoolId && c.materialId === count.materialId);
    if (index >= 0) {
      counts[index] = { ...counts[index], ...count };
    } else {
      counts.push(count);
    }
    this.saveData('coordination_material_counts', counts);
    this.saveToFirestore('material_counts', `${count.schoolId}_${count.materialId}`, count);
  }

  public saveBulkMaterialCounts(schoolId: string, list: MaterialCount[]) {
    let counts = this.getMaterialCounts().filter(c => c.schoolId !== schoolId);
    counts = [...counts, ...list];
    this.saveData('coordination_material_counts', counts);
    list.forEach(item => {
      this.saveToFirestore('material_counts', `${item.schoolId}_${item.materialId}`, item);
    });
  }

  // School Leadership
  public getLeadership(): Directorship[] {
    return this.getData<Directorship>('coordination_leadership');
  }

  public saveLeadership(member: Directorship) {
    const list = this.getLeadership();
    const index = list.findIndex(l => l.id === member.id);
    if (index >= 0) {
      list[index] = { ...list[index], ...member };
    } else {
      list.push(member);
    }
    this.saveData('coordination_leadership', list);
    this.saveToFirestore('leadership', member.id, member);
  }

  public deleteLeadership(id: string) {
    this.registerDeletion('leadership', id);
    const list = this.getLeadership().filter(l => l.id !== id);
    this.saveData('coordination_leadership', list);
    this.deleteFromFirestore('leadership', id);
  }

  // Staff (Teachers, Specialists, Admins, Workers)
  public getStaff(): StaffMember[] {
    return this.getData<StaffMember>('coordination_staff');
  }

  public saveStaff(member: StaffMember) {
    const staff = this.getStaff();
    const index = staff.findIndex(s => s.id === member.id);
    if (index >= 0) {
      staff[index] = { ...staff[index], ...member };
    } else {
      staff.push(member);
    }
    this.saveData('coordination_staff', staff);
    this.saveToFirestore('staff', member.id, member);
  }

  public deleteStaff(id: string) {
    this.registerDeletion('staff', id);
    const staff = this.getStaff().filter(s => s.id !== id);
    this.saveData('coordination_staff', staff);
    this.deleteFromFirestore('staff', id);
  }

  public saveBulkStaff(schoolId: string, role: 'teacher' | 'specialist' | 'admin' | 'worker', list: StaffMember[]) {
    let staff = this.getStaff().filter(s => !(s.schoolId === schoolId && s.role === role));
    staff = [...staff, ...list];
    this.saveData('coordination_staff', staff);
    list.forEach(item => {
      this.saveToFirestore('staff', item.id, item);
    });
  }

  // Student Absences
  public getStudentAbsences(): StudentAbsence[] {
    return this.getData<StudentAbsence>('coordination_student_absences');
  }

  public saveStudentAbsence(absence: StudentAbsence) {
    const list = this.getStudentAbsences();
    const index = list.findIndex(a => a.schoolId === absence.schoolId && a.date === absence.date);
    if (index >= 0) {
      list[index] = { ...list[index], ...absence };
    } else {
      list.push(absence);
    }
    this.saveData('coordination_student_absences', list);
    this.saveToFirestore('student_absences', absence.id, absence);
  }

  // Teacher Absences
  public getTeacherAbsences(): TeacherAbsence[] {
    return this.getData<TeacherAbsence>('coordination_teacher_absences');
  }

  public saveTeacherAbsence(absence: TeacherAbsence) {
    const list = this.getTeacherAbsences();
    const index = list.findIndex(a => a.schoolId === absence.schoolId && a.date === absence.date);
    if (index >= 0) {
      list[index] = { ...list[index], ...absence };
    } else {
      list.push(absence);
    }
    this.saveData('coordination_teacher_absences', list);
    this.saveToFirestore('teacher_absences', absence.id, absence);
  }

  // Visitor Logs
  public getVisitors(): VisitorLog[] {
    return this.getData<VisitorLog>('coordination_visitors');
  }

  public saveVisitor(visitor: VisitorLog) {
    const list = this.getVisitors();
    const index = list.findIndex(v => v.id === visitor.id);
    if (index >= 0) {
      list[index] = { ...list[index], ...visitor };
    } else {
      list.push(visitor);
    }
    this.saveData('coordination_visitors', list);
    this.saveToFirestore('visitors', visitor.id, visitor);
  }

  public deleteVisitor(id: string) {
    this.registerDeletion('visitors', id);
    const list = this.getVisitors().filter(v => v.id !== id);
    this.saveData('coordination_visitors', list);
    this.deleteFromFirestore('visitors', id);
  }

  // Nutrition
  public getNutritionRecords(): NutritionRecord[] {
    return this.getData<NutritionRecord>('coordination_nutrition');
  }

  public saveNutritionRecord(rec: NutritionRecord) {
    const list = this.getNutritionRecords();
    const index = list.findIndex(n => n.id === rec.id);
    if (index >= 0) {
      list[index] = { ...list[index], ...rec };
    } else {
      list.push(rec);
    }
    this.saveData('coordination_nutrition', list);
    this.saveToFirestore('nutrition', rec.id, rec);
  }

  public deleteNutritionRecord(id: string) {
    this.registerDeletion('nutrition', id);
    const list = this.getNutritionRecords().filter(n => n.id !== id);
    this.saveData('coordination_nutrition', list);
    this.deleteFromFirestore('nutrition', id);
  }

  // --- EXAM NOMINATIONS (1 SECRET) AND EXCLUSIONS ---

  public getExamNominations(): ExamNomination[] {
    return this.getData<ExamNomination>('coordination_exam_nominations');
  }

  public saveExamNomination(nom: ExamNomination) {
    const list = this.getExamNominations();
    const index = list.findIndex(n => n.id === nom.id);
    if (index >= 0) {
      list[index] = { ...list[index], ...nom };
    } else {
      list.push(nom);
    }
    this.saveData('coordination_exam_nominations', list);
    this.saveToFirestore('exam_nominations', nom.id, nom);
  }

  public deleteExamNomination(id: string) {
    this.registerDeletion('exam_nominations', id);
    const list = this.getExamNominations().filter(n => n.id !== id);
    this.saveData('coordination_exam_nominations', list);
    this.deleteFromFirestore('exam_nominations', id);
  }

  // Obstacles
  public getExamObstacles(): ExamObstacle[] {
    return this.getData<ExamObstacle>('coordination_exam_obstacles');
  }

  public saveExamObstacle(obs: ExamObstacle) {
    const list = this.getExamObstacles();
    const index = list.findIndex(o => o.id === obs.id);
    if (index >= 0) {
      list[index] = { ...list[index], ...obs };
    } else {
      list.push(obs);
    }
    this.saveData('coordination_exam_obstacles', list);
    this.saveToFirestore('exam_obstacles', obs.id, obs);
  }

  public deleteExamObstacle(id: string) {
    this.registerDeletion('exam_obstacles', id);
    const list = this.getExamObstacles().filter(o => o.id !== id);
    this.saveData('coordination_exam_obstacles', list);
    this.deleteFromFirestore('exam_obstacles', id);
  }

  // Excuses
  public getExamExcuses(): ExamExcuse[] {
    return this.getData<ExamExcuse>('coordination_exam_excuses');
  }

  public saveExamExcuse(exc: ExamExcuse) {
    const list = this.getExamExcuses();
    const index = list.findIndex(e => e.id === exc.id);
    if (index >= 0) {
      list[index] = { ...list[index], ...exc };
    } else {
      list.push(exc);
    }
    this.saveData('coordination_exam_excuses', list);
    this.saveToFirestore('exam_excuses', exc.id, exc);
  }

  public deleteExamExcuse(id: string) {
    this.registerDeletion('exam_excuses', id);
    const list = this.getExamExcuses().filter(e => e.id !== id);
    this.saveData('coordination_exam_excuses', list);
    this.deleteFromFirestore('exam_excuses', id);
  }

  // Audit Logs
  public getAuditLogs(): AuditLog[] {
    return this.getData<AuditLog>('coordination_exam_audits');
  }

  public saveAuditLog(log: AuditLog) {
    const list = this.getAuditLogs();
    list.unshift(log); // newest first
    this.saveData('coordination_exam_audits', list);
    this.saveToFirestore('exam_audits', log.id, log);
  }

  public addAuditLog(user: string, action: string, details: string, oldData?: any, newData?: any) {
    const log: AuditLog = {
      id: 'audit_' + Date.now() + '_' + Math.floor(Math.random() * 100000),
      timestamp: new Date().toISOString(),
      user,
      action,
      details,
      oldData: oldData ? JSON.stringify(oldData, null, 2) : undefined,
      newData: newData ? JSON.stringify(newData, null, 2) : undefined,
    };
    this.saveAuditLog(log);
  }

  // Trash Items / Recycle Bin
  public getTrashItems(): TrashItem[] {
    return this.getData<TrashItem>('coordination_trash_items');
  }

  public saveTrashItem(item: TrashItem) {
    const list = this.getTrashItems();
    const index = list.findIndex(i => i.id === item.id);
    if (index >= 0) {
      list[index] = item;
    } else {
      list.push(item);
    }
    this.saveData('coordination_trash_items', list);
    this.saveToFirestore('trash_items', item.id, item);
  }

  public deleteTrashItem(id: string) {
    const list = this.getTrashItems().filter(i => i.id !== id);
    this.saveData('coordination_trash_items', list);
    this.deleteFromFirestore('trash_items', id);
  }

  // Archived Reports
  public getArchivedReports(): ArchivedReport[] {
    return this.getData<ArchivedReport>('coordination_archived_reports');
  }

  public saveArchivedReport(report: ArchivedReport) {
    const list = this.getArchivedReports();
    const index = list.findIndex(r => r.id === report.id);
    if (index >= 0) {
      list[index] = { ...list[index], ...report };
    } else {
      list.unshift(report); // newest first
    }
    this.saveData('coordination_archived_reports', list);
    this.saveToFirestore('archived_reports', report.id, report);
  }

  public deleteArchivedReport(id: string) {
    this.registerDeletion('archived_reports', id);
    const list = this.getArchivedReports().filter(r => r.id !== id);
    this.saveData('coordination_archived_reports', list);
    this.deleteFromFirestore('archived_reports', id);
  }

  // Database Reset to defaults helper (for backup or initial look)
  public async resetToDefaults() {
    localStorage.removeItem('coordination_settings');
    localStorage.removeItem('coordination_schools');
    localStorage.removeItem('coordination_materials');
    localStorage.removeItem('coordination_material_counts');
    localStorage.removeItem('coordination_leadership');
    localStorage.removeItem('coordination_staff');
    localStorage.removeItem('coordination_student_absences');
    localStorage.removeItem('coordination_teacher_absences');
    localStorage.removeItem('coordination_visitors');
    localStorage.removeItem('coordination_nutrition');
    
    // Clear soft deleted lists
    const cols = [
      'schools', 'materials', 'material_counts', 'staff', 'leadership',
      'student_absences', 'teacher_absences', 'visitors', 'nutrition',
      'exam_nominations', 'exam_obstacles', 'exam_excuses', 'exam_audits',
      'archived_reports'
    ];
    cols.forEach(col => {
      localStorage.removeItem(`coordination_deleted_${col}`);
    });

    this.initDatabase();

    // Reset Firestore collections
    try {
      // Re-seed directly
      for (const item of INITIAL_SCHOOLS) {
        await setDoc(doc(db, 'schools', item.id), item);
      }
      for (const item of INITIAL_MATERIALS) {
        await setDoc(doc(db, 'materials', item.id), item);
      }
      for (const item of INITIAL_MATERIAL_COUNTS) {
        await setDoc(doc(db, 'material_counts', `${item.schoolId}_${item.materialId}`), item);
      }
      for (const item of INITIAL_LEADERSHIP) {
        await setDoc(doc(db, 'leadership', item.id), item);
      }
      for (const item of INITIAL_STAFF) {
        await setDoc(doc(db, 'staff', item.id), item);
      }
      for (const item of INITIAL_STUDENT_ABSENCE) {
        await setDoc(doc(db, 'student_absences', item.id), item);
      }
      for (const item of INITIAL_TEACHER_ABSENCE) {
        await setDoc(doc(db, 'teacher_absences', item.id), item);
      }
      for (const item of INITIAL_VISITORS) {
        await setDoc(doc(db, 'visitors', item.id), item);
      }
      for (const item of INITIAL_NUTRITION) {
        await setDoc(doc(db, 'nutrition', item.id), item);
      }
      await setDoc(doc(db, 'settings', 'system_settings'), INITIAL_SETTINGS);
    } catch (e) {
      if (this.checkIfQuotaExceeded(e)) {
        console.warn('Firestore reset skipped: Quota limit exceeded. Running in offline/cached local mode.');
      } else {
        console.error('Error resetting Firestore collections:', e);
      }
    }

    this.notify();
  }

  // --- AUTOMATIC CALCULATIONS & METRICS ---

  /**
   * Helper function to match a school's stage to a material's stage
   * This is critical to guarantee that the primary materials only evaluate
   * in schools with elementary stages.
   */
  public isMaterialApplicableToSchool(schoolStage: string, materialStage: 'primary' | 'prep' | 'sec'): boolean {
    if (schoolStage === 'basic') {
      // Basic educational schools can have both primary and preparatory materials
      return materialStage === 'primary' || materialStage === 'prep';
    }
    if (schoolStage === 'languages') {
      // Languages offer primary, prep, and sec
      return true;
    }
    if (schoolStage === 'primary' || schoolStage === 'nursery') {
      return materialStage === 'primary';
    }
    if (schoolStage === 'prep') {
      return materialStage === 'prep';
    }
    if (schoolStage === 'sec' || schoolStage === 'vocational') {
      return materialStage === 'sec';
    }
    return false;
  }

  public calculateMaterialMetrics(school: School, material: Material, count?: MaterialCount) {
    const applicable = this.isMaterialApplicableToSchool(school.stage, material.stage);
    if (!applicable) {
      return {
        applicable: false,
        needed: 0,
        present: 0,
        deficit: 0,
        surplus: 0,
        percentage: 0,
        totalLessons: 0,
        coveredLessons: 0,
        periodDeficit: 0,
        periodSurplus: 0,
        refQuota: 0
      };
    }

    // Get the system settings for teaching quotas by stage or use the material's teacherQuota
    const settings = this.getSettings();
    let refQuota = material.teacherQuota && material.teacherQuota > 0 ? material.teacherQuota : 0;
    
    if (refQuota <= 0) {
      if (material.stage === 'primary') {
        refQuota = settings.quota_primary || 20;
      } else if (material.stage === 'prep') {
        refQuota = settings.quota_prep || 18;
      } else if (material.stage === 'sec') {
        refQuota = settings.quota_sec || 18;
      } else {
        if (school.stage === 'primary' || school.stage === 'nursery') {
          refQuota = settings.quota_primary || 20;
        } else if (school.stage === 'prep') {
          refQuota = settings.quota_prep || 18;
        } else {
          refQuota = settings.quota_sec || 18;
        }
      }
    }

    // Total required lessons = classrooms * material quota
    let materialClassrooms = school.classroomsCount || 0;
    if ((school.stage === 'sec' || school.stage === 'primary') && count && typeof count.classroomsCount === 'number') {
      materialClassrooms = count.classroomsCount;
    }
    const totalLessons = materialClassrooms * (material.quota || 0);
    // Needed teachers = total lessons needed / reference quota per teacher
    const needed = Number((totalLessons / refQuota).toFixed(2));

    // Sum teachers in the count details
    let present = 0;
    if (count) {
      present = 
        (count.super_senior || 0) +
        (count.expert || 0) +
        (count.first_a || 0) +
        (count.first || 0) +
        (count.teacher || 0) +
        (count.assistant || 0) +
        (count.delegated || 0) +
        (count.by_class || 0);
    }

    const diff = present - needed;
    const deficit = diff < 0 ? Number(Math.abs(diff).toFixed(2)) : 0;
    const surplus = diff > 0 ? Number(diff.toFixed(2)) : 0;

    // Calculate lesson-based metrics using the refQuota (teacher weekly workload)
    const coveredLessons = Number((present * refQuota).toFixed(2));
    const periodDiff = coveredLessons - totalLessons;
    const periodDeficit = periodDiff < 0 ? Number(Math.abs(periodDiff).toFixed(2)) : 0;
    const periodSurplus = periodDiff > 0 ? Number(periodDiff.toFixed(2)) : 0;

    // Coverage percentage based on lessons
    const percentage = totalLessons > 0 ? (coveredLessons / totalLessons) * 100 : 100;

    return {
      applicable: true,
      needed,
      present,
      deficit,
      surplus,
      percentage: Number(percentage.toFixed(1)),
      totalLessons,
      coveredLessons,
      periodDeficit,
      periodSurplus,
      refQuota
    };
  }

  // Calculate character-based DJB2-like checksum to verify file integrity
  public calculateChecksum(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(16);
  }

  // Import school data package and update database safely without duplicates or losing other schools data
  public importSchoolData(parsedData: any): { success: boolean; message: string; details?: any } {
    if (!parsedData || !parsedData.metadata || !parsedData.payload) {
      return { success: false, message: 'صيغة الملف غير صالحة ولا تحتوي على البيانات الأساسية.' };
    }

    const { metadata, payload: payloadStr, checksum } = parsedData;
    const { schoolId, schoolName, fileId, exportDateTime } = metadata;

    // Verify Checksum
    const calculated = this.calculateChecksum(payloadStr);
    if (calculated !== checksum) {
      return { success: false, message: 'فشل التحقق من سلامة الملف؛ الرمز التعريفي لا يطابق المحتوى (مما يشير لتعديل أو تلف الملف).' };
    }

    // Parse payload
    let payloadObj: any;
    try {
      payloadObj = JSON.parse(payloadStr);
    } catch (e) {
      return { success: false, message: 'فشل قراءة محتوى الملف الداخلي.' };
    }

    // Check duplicate file or older file
    const lastImports = JSON.parse(localStorage.getItem('coordination_last_imported_files') || '{}');
    const existingImport = lastImports[schoolId];
    if (existingImport) {
      if (existingImport.fileId === fileId) {
        return { success: false, message: `⚠️ هذا الملف تم استيراده بالفعل مسبقاً لهذه المدرسة (معرف الملف: ${fileId}).` };
      }
      if (new Date(exportDateTime).getTime() <= new Date(existingImport.exportedAt).getTime()) {
        return { success: false, message: `⚠️ يوجد ملف استيراد أحدث أو مساوي في التوقيت تم استيراده بالفعل لمدرسة "${schoolName}"؛ يرجى التأكد من استيراد الملف الصحيح الأحدث.` };
      }
    }

    // Proceed to update
    // 1. School details
    if (payloadObj.school) {
      this.saveSchool(payloadObj.school);
    }

    // 2. Leadership
    if (Array.isArray(payloadObj.leadership)) {
      let list = this.getLeadership().filter(l => l.schoolId !== schoolId);
      list = [...list, ...payloadObj.leadership];
      this.saveData('coordination_leadership', list);
      payloadObj.leadership.forEach((item: any) => {
        this.saveToFirestore('leadership', item.id, item);
      });
    }

    // 3. Staff
    if (Array.isArray(payloadObj.staff)) {
      let list = this.getStaff().filter(s => s.schoolId !== schoolId);
      list = [...list, ...payloadObj.staff];
      this.saveData('coordination_staff', list);
      payloadObj.staff.forEach((item: any) => {
        this.saveToFirestore('staff', item.id, item);
      });
    }

    // 4. Material Counts
    if (Array.isArray(payloadObj.materialCounts)) {
      let list = this.getMaterialCounts().filter(mc => mc.schoolId !== schoolId);
      list = [...list, ...payloadObj.materialCounts];
      this.saveData('coordination_material_counts', list);
      payloadObj.materialCounts.forEach((item: any) => {
        this.saveToFirestore('material_counts', `${item.schoolId}_${item.materialId}`, item);
      });
    }

    // 5. Student Absences
    if (Array.isArray(payloadObj.studentAbsences)) {
      let list = this.getStudentAbsences().filter(sa => sa.schoolId !== schoolId);
      list = [...list, ...payloadObj.studentAbsences];
      this.saveData('coordination_student_absences', list);
      payloadObj.studentAbsences.forEach((item: any) => {
        this.saveToFirestore('student_absences', item.id, item);
      });
    }

    // 6. Teacher Absences
    if (Array.isArray(payloadObj.teacherAbsences)) {
      let list = this.getTeacherAbsences().filter(ta => ta.schoolId !== schoolId);
      list = [...list, ...payloadObj.teacherAbsences];
      this.saveData('coordination_teacher_absences', list);
      payloadObj.teacherAbsences.forEach((item: any) => {
        this.saveToFirestore('teacher_absences', item.id, item);
      });
    }

    // 7. Visitors
    if (Array.isArray(payloadObj.visitors)) {
      let list = this.getVisitors().filter(v => v.schoolId !== schoolId);
      list = [...list, ...payloadObj.visitors];
      this.saveData('coordination_visitors', list);
      payloadObj.visitors.forEach((item: any) => {
        this.saveToFirestore('visitors', item.id, item);
      });
    }

    // 8. Nutrition
    if (Array.isArray(payloadObj.nutrition)) {
      let list = this.getNutritionRecords().filter(n => n.schoolId !== schoolId);
      list = [...list, ...payloadObj.nutrition];
      this.saveData('coordination_nutrition', list);
      payloadObj.nutrition.forEach((item: any) => {
        this.saveToFirestore('nutrition', item.id, item);
      });
    }

    // 9. Exam nominations
    if (Array.isArray(payloadObj.examNominations)) {
      let list = this.getExamNominations().filter(en => en.schoolId !== schoolId);
      list = [...list, ...payloadObj.examNominations];
      this.saveData('coordination_exam_nominations', list);
      payloadObj.examNominations.forEach((item: any) => {
        this.saveToFirestore('exam_nominations', item.id, item);
      });
    }

    // 10. Exam excuses
    if (Array.isArray(payloadObj.examExcuses)) {
      let list = this.getExamExcuses().filter(ee => ee.schoolId !== schoolId);
      list = [...list, ...payloadObj.examExcuses];
      this.saveData('coordination_exam_excuses', list);
      payloadObj.examExcuses.forEach((item: any) => {
        this.saveToFirestore('exam_excuses', item.id, item);
      });
    }

    // Save this file as the last imported file for this school
    lastImports[schoolId] = {
      fileId,
      exportedAt: exportDateTime,
      importedAt: new Date().toISOString()
    };
    localStorage.setItem('coordination_last_imported_files', JSON.stringify(lastImports));

    // Calculate total imported records
    const recordsCount = (payloadObj.leadership?.length || 0) + 
                         (payloadObj.staff?.length || 0) + 
                         (payloadObj.materialCounts?.length || 0) + 
                         (payloadObj.studentAbsences?.length || 0) + 
                         (payloadObj.teacherAbsences?.length || 0) + 
                         (payloadObj.visitors?.length || 0) + 
                         (payloadObj.nutrition?.length || 0) + 
                         (payloadObj.examNominations?.length || 0) + 
                         (payloadObj.examExcuses?.length || 0);

    // Save logs
    const operationLogs = JSON.parse(localStorage.getItem('coordination_import_export_logs') || '[]');
    operationLogs.unshift({
      id: fileId,
      schoolId,
      schoolName,
      fileName: `School_${schoolName}.abhm`,
      exportedAt: exportDateTime,
      importedAt: new Date().toISOString(),
      status: 'success',
      recordsCount
    });
    localStorage.setItem('coordination_import_export_logs', JSON.stringify(operationLogs));

    this.notify();

    return {
      success: true,
      message: 'تم استيراد الملف وتحديث قاعدة البيانات بنجاح.',
      details: {
        schoolName,
        recordsCount
      }
    };
  }

  // Get aggregated calculations across the system optionally filtered by stage or material
  public getAggregatedAnalytics() {
    const schools = this.getSchools();
    const materials = this.getMaterials();
    const counts = this.getMaterialCounts();
    const staff = this.getStaff();

    const totalSchools = schools.length;
    const totalTeachers = staff.filter(s => s.role === 'teacher').length;
    const totalAdmins = staff.filter(s => s.role === 'admin').length;
    const totalLabor = staff.filter(s => s.role === 'worker').length;
    const totalSpecialists = staff.filter(s => s.role === 'specialist').length;

    // Student Absences percentage calculations
    const absences = this.getStudentAbsences();
    let totalRegisteredStudents = 0;
    let totalPresentStudents = 0;
    let totalAbsentStudents = 0;

    absences.forEach(abs => {
      abs.records.forEach(rec => {
        totalRegisteredStudents += (Number(rec.registered) || 0);
        totalPresentStudents += (Number(rec.present) || 0);
        totalAbsentStudents += (Number(rec.absent) || 0);
      });
    });

    const studentAbsenceRate = totalRegisteredStudents > 0 
      ? Number(((totalAbsentStudents / totalRegisteredStudents) * 100).toFixed(1)) 
      : 0;

    const studentAttendanceRate = totalRegisteredStudents > 0 
      ? Number(((totalPresentStudents / totalRegisteredStudents) * 100).toFixed(1)) 
      : 0;

    // System-wide materials report aggregation
    let totalNeeded = 0;
    let totalPresent = 0;
    let totalDeficit = 0;
    let totalSurplus = 0;

    schools.forEach(school => {
      materials.forEach(material => {
        const count = counts.find(c => c.schoolId === school.id && c.materialId === material.id);
        const metr = this.calculateMaterialMetrics(school, material, count);
        if (metr.applicable) {
          totalNeeded += metr.needed;
          totalPresent += metr.present;
          totalDeficit += metr.deficit;
          totalSurplus += metr.surplus;
        }
      });
    });

    const generalCoveragePercentage = totalNeeded > 0 
      ? Number(((totalPresent / totalNeeded) * 100).toFixed(1)) 
      : 100;

    return {
      totalSchools,
      totalTeachers,
      totalAdmins,
      totalLabor,
      totalSpecialists,
      studentAbsenceRate,
      studentAttendanceRate,
      totalNeeded,
      totalPresent,
      totalDeficit,
      totalSurplus,
      generalCoveragePercentage
    };
  }
}

export const dbInstance = new LocalCoordinationDB();
