import React, { useState, useEffect } from 'react';
import { School, ExamNomination, ExamObstacle, ExamExcuse, NominationDocument, AuditLog } from '../types';
import { dbInstance } from '../data/db';
import { 
  FileText, Check, X, ShieldAlert, CheckCircle, 
  Trash2, Plus, Edit2, Download, Eye, FileDown, 
  Printer, Search, Sliders, Info, AlertCircle, AlertTriangle, 
  CheckCircle2, RefreshCw, Layers, ClipboardList, HelpCircle
} from 'lucide-react';
import PrintableReport from './ReportTemplate';

interface AdminExamNominationTabProps {
  schools: School[];
  dbTick: number;
}

export default function AdminExamNominationTab({ schools, dbTick }: AdminExamNominationTabProps) {
  const [nominations, setNominations] = useState<ExamNomination[]>([]);
  const [obstacles, setObstacles] = useState<ExamObstacle[]>([]);
  const [excuses, setExcuses] = useState<ExamExcuse[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // Search, Group & Filter State
  const [searchSchool, setSearchSchool] = useState('');
  const [searchTeacher, setSearchTeacher] = useState('');
  const [searchNationalId, setSearchNationalId] = useState('');
  const [filterJob, setFilterJob] = useState('all');
  const [filterSubject, setFilterSubject] = useState('all');
  const [filterObstacle, setFilterObstacle] = useState('all');
  const [filterReviewStatus, setFilterReviewStatus] = useState('all');

  // Custom Obstacle Management State
  const [showObstacleManager, setShowObstacleManager] = useState(false);
  const [newObstacleName, setNewObstacleName] = useState('');
  const [newObstacleRequiresDoc, setNewObstacleRequiresDoc] = useState(true);
  const [editingObstacleId, setEditingObstacleId] = useState<string | null>(null);

  // In-line reject dialog state
  const [rejectionNomId, setRejectionNomId] = useState<string | null>(null);
  const [rejectionReasonText, setRejectionReasonText] = useState('');

  // Excuse Inline decision dialog state
  const [excuseDecisionId, setExcuseDecisionId] = useState<string | null>(null);
  const [excuseDecisionNotes, setExcuseDecisionNotes] = useState('');

  // Custom excuse dialog
  const [excuseDecisionDialog, setExcuseDecisionDialog] = useState<{
    isOpen: boolean;
    nomination: ExamNomination | null;
    decision: 'approved' | 'rejected' | null;
    notes: string;
  }>({
    isOpen: false,
    nomination: null,
    decision: null,
    notes: ''
  });

  // Print preview state
  const [printReportType, setPrintReportType] = useState<'fit' | 'excuses' | 'all_schools_approved' | null>(null);

  // Custom Confirm Dialog State
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  const [toast, setToast] = useState<{
    message: string;
    type: 'success' | 'error' | 'info';
  } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Report view modes
  const [activeReportMode, setActiveReportMode] = useState<'all' | 'accepted' | 'rejected' | 'excused' | 'obstacles' | 'incomplete'>('all');

  // Document modal preview
  const [previewDoc, setPreviewDoc] = useState<NominationDocument | null>(null);

  const loadData = () => {
    setNominations(dbInstance.getExamNominations());
    setObstacles(dbInstance.getExamObstacles());
    setExcuses(dbInstance.getExamExcuses());
    setAuditLogs(dbInstance.getAuditLogs());
  };

  useEffect(() => {
    loadData();
    const unsubscribe = dbInstance.subscribe(() => {
      loadData();
    });
    return unsubscribe;
  }, [dbTick]);

  // Handle Nomination Decision (قبول الترشيح)
  const handleApproveNomination = (nom: ExamNomination) => {
    const updated: ExamNomination = {
      ...nom,
      status: 'approved',
      rejectionReason: undefined,
      rejectionFeedback: 'تمت مراجعة الاستمارة رسمياً والموافقة على الترشيح لتوافق الشروط',
      updatedAt: new Date().toISOString()
    };

    dbInstance.saveExamNomination(updated);

    dbInstance.saveAuditLog({
      id: `audit_${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: 'مدير التنسيق العام',
      action: 'اعتماد ترشيح مرشح',
      details: `تمت الموافقة على ترشيح المعلم: ${nom.name} من مدرسة: ${nom.schoolName}`,
      schoolId: nom.schoolId
    });

    showToast(`تم قبول واعتماد ترشيح المعلم: ${nom.name} بنجاح.`, 'success');
  };

  // Handle Open Rejection Dialog
  const handleOpenRejection = (nomId: string) => {
    setRejectionNomId(nomId);
    setRejectionReasonText('');
  };

  // Submit Rejection (رفض الترشيح)
  const handleRejectNominationSubmit = () => {
    if (!rejectionNomId || !rejectionReasonText.trim()) {
      showToast('الرجاء كتابة سبب الرفض الإداري.', 'error');
      return;
    }

    const nom = nominations.find(n => n.id === rejectionNomId);
    if (!nom) return;

    const updated: ExamNomination = {
      ...nom,
      status: 'rejected',
      rejectionReason: rejectionReasonText,
      rejectionFeedback: rejectionReasonText,
      updatedAt: new Date().toISOString()
    };

    dbInstance.saveExamNomination(updated);

    dbInstance.saveAuditLog({
      id: `audit_${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: 'مدير التنسيق العام',
      action: 'رفض ترشيح مرشح',
      details: `تم رفض ترشيح المعلم: ${nom.name} من مدرسة: ${nom.schoolName} لسبب: ${rejectionReasonText}`,
      schoolId: nom.schoolId
    });

    setRejectionNomId(null);
    setRejectionReasonText('');
    showToast(`تم تسجيل الرفض وإخطار مدرسة: ${nom.schoolName} فورياً.`, 'success');
  };

  // --- EXCUSE DECISION LOGIC (نظام الاعتذارات ضمن الكشف) ---
  const handleExcuseDecision = (nom: ExamNomination, decision: 'approved' | 'rejected', notes: string) => {
    const uniqueExcuseId = `exc_${nom.id}`;
    
    // Create/update related excuse
    const relatedExcuse: ExamExcuse = {
      id: uniqueExcuseId,
      schoolId: nom.schoolId,
      schoolName: nom.schoolName,
      name: nom.name,
      nationalId: nom.nationalId,
      reason: nom.obstacleText || obstacles.find(o => o.id === nom.obstacleId)?.name || 'اعتذار رسمي',
      status: decision,
      approvalDate: new Date().toLocaleDateString('ar-EG'),
      decisionDate: new Date().toISOString(),
      auditor: 'مدير التنسيق العام',
      documents: nom.documents
    };
    dbInstance.saveExamExcuse(relatedExcuse);

    // Update nomination status in-sync with excuse choice
    const updatedNom: ExamNomination = {
      ...nom,
      status: decision === 'approved' ? 'rejected' : 'approved',
      rejectionFeedback: decision === 'approved' 
        ? `✅ تم قبول العذر والاعتذار رسمياً بالإدارة: ${notes}` 
        : `❌ تم رفض العذر والاعتذار بالإدارة: ${notes}`,
      updatedAt: new Date().toISOString()
    };
    dbInstance.saveExamNomination(updatedNom);

    dbInstance.saveAuditLog({
      id: `audit_${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: 'مدير التنسيق العام',
      action: decision === 'approved' ? 'قبول عذر / اعتذار' : 'رفض عذر / اعتذار',
      details: `تم البت في طلب اعتذار المعلم: ${nom.name} بالـ (${decision === 'approved' ? 'قبول' : 'الرفض'}) بملاحظات: ${notes}`,
      schoolId: nom.schoolId
    });

    setExcuseDecisionDialog({
      isOpen: false,
      nomination: null,
      decision: null,
      notes: ''
    });
    
    showToast('تم تقييد قرار الاعتذار وتحديث استمارات المدرسة التبادلية في نفس اللحظة.', 'success');
  };

  const handleDeleteNominationAdmin = (nom: ExamNomination) => {
    setConfirmDialog({
      isOpen: true,
      title: 'تأكيد الحذف النهائي للمرشح',
      message: `هل أنت متأكد من حذف الترشيح بالكامل للمعلم: ${nom.name} من مدرسة: ${nom.schoolName} نهائياً؟ ستتم إزالته من كشوفات المدرسة والإدارة.`,
      onConfirm: () => {
        dbInstance.deleteExamNomination(nom.id);
        
        dbInstance.saveAuditLog({
          id: `audit_${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: 'مدير التنسيق العام',
          action: 'حذف استمارة مرشح',
          details: `تم إزالة سجل الترشيح بالكامل للمرشح: ${nom.name} من مدرسة: ${nom.schoolName}`,
          schoolId: nom.schoolId
        });

        setConfirmDialog(null);
        showToast('تم حذف السجل بالكامل وتحديث قواعد بيانات التنسيق فورياً.', 'success');
      }
    });
  };

  // --- OBSTACLE DYNAMIC MANAGEMENT (إدارة الموانع الفورية بلا تحديث) ---
  const handleSaveObstacle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newObstacleName.trim()) {
      showToast('الرجاء إدخال اسم المانع القانوني أولاً', 'error');
      return;
    }

    const item: ExamObstacle = {
      id: editingObstacleId || `obs_${Date.now()}`,
      name: newObstacleName.trim(),
      requiresDocument: newObstacleRequiresDoc
    };

    dbInstance.saveExamObstacle(item);
    
    dbInstance.saveAuditLog({
      id: `audit_${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: 'مدير التنسيق العام',
      action: editingObstacleId ? 'تعديل بند مانع اشتراك' : 'إضافة بند مانع اشتراك جديد',
      details: `تم ${editingObstacleId ? 'تحديث' : 'تعريف'} عقبة ومانع امتحانات باسم: ${newObstacleName}`,
    });

    setNewObstacleName('');
    setNewObstacleRequiresDoc(true);
    setEditingObstacleId(null);
    showToast('تم حفظ وتحديث المانع بنظام الاستمارات الإلكترونية فورياً.', 'success');
  };

  const handleDeleteObstacle = (id: string, name: string) => {
    if (id === 'other' || id === 'none') {
      showToast('الأعذار الأساسية للسيستم غير قابلة للحذف.', 'error');
      return;
    }

    setConfirmDialog({
      isOpen: true,
      title: 'تأكيد إزالة مانع الامتحانات',
      message: `هل تريد بالتأكيد إزالة خيار المانع: (${name})؟ لن يؤثر على الملفات القديمة المعتمدة ولكن سيتم إزالته من قائمة الخيارات المتاحة للمدارس فوراً.`,
      onConfirm: () => {
        dbInstance.deleteExamObstacle(id);
        dbInstance.saveAuditLog({
          id: `audit_${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: 'مدير التنسيق العام',
          action: 'إزالة مانع امتحانات',
          details: `تم حذف خيار عقبة الامتحانات: ${name}`,
        });
        setConfirmDialog(null);
        showToast('تم حذف البند وتحديث القائمة فورياً للمدارس والإدارة.', 'success');
      }
    });
  };

  // Smart check routine for color highlighting & analysis (الفحص الذكي)
  const runDiagnostics = (nom: ExamNomination): { status: 'eligible' | 'needs_review' | 'disqualified', reason: string } => {
    const name = nom.name?.trim() || '';
    const nationalId = nom.nationalId?.trim() || '';
    const jobTitle = nom.jobTitle?.trim() || '';
    const subject = nom.subject?.trim() || '';
    const phone = nom.phone?.trim() || '';
    const address = nom.address?.trim() || '';
    const obstacleId = nom.obstacleId || 'none';
    const documents = nom.documents || [];

    // Checked incompleteness
    if (!name || nationalId.length !== 14 || !jobTitle || !subject || phone.length !== 11 || !address) {
      return { 
        status: 'disqualified', 
        reason: 'نقص جوهري في البيانات الأساسية (الاسم، الرقم القومي، الهاتف، أو السكن)' 
      };
    }

    // Check duplicates
    const sameNationals = nominations.filter(n => n.nationalId === nationalId);
    if (sameNationals.length > 1) {
      return { 
        status: 'disqualified', 
        reason: 'تكرار رقمي: يوجد معلم مسجل بنفس القومي على مدرستين أو تكرر ترشيحه' 
      };
    }

    // Check with document limits
    if (obstacleId !== 'none') {
      const parentObstacle = obstacles.find(o => o.id === obstacleId);
      if (parentObstacle && parentObstacle.requiresDocument && documents.length === 0) {
        return {
          status: 'needs_review',
          reason: `مستثنى بمانع: (${parentObstacle.name}) لكن المدرسة لم تقم بضم المستندات المؤيدة`
        };
      }
      return { 
        status: 'needs_review', 
        reason: `لديه مانع رسمي مسجل: (${parentObstacle?.name || 'مانع عائلي/صحي'}). يستوجب فحص الإدارة` 
      };
    }

    return { status: 'eligible', reason: 'مكتمل ومؤهل للمشاركة بأعمال الكشوف العامة' };
  };

  // General CSV download (تصدير Excel)
  const handleExportCSV = () => {
    if (filteredRows.length === 0) {
      alert('لا توجد بيانات لتصديرها.');
      return;
    }

    let csvContent = '\ufeff'; // UTF-8 BOM
    csvContent += 'المدرسة,الاسم رباعي,الوظيفة الحالية,التخصص والمادة,العنوان,الرقم القومي,تاريخ الميلاد,رقم الهاتف,مانع الاشتراك,الفحص الذكي,الحالة الإدارية\n';

    filteredRows.forEach(row => {
      const obst = row.obstacleId === 'none' ? 'لا يوجد' : (obstacles.find(o => o.id === row.obstacleId)?.name || 'أخرى');
      const diag = runDiagnostics(row);
      const diagStr = diag.status === 'eligible' ? 'صالح' : diag.status === 'needs_review' ? 'يحتاج مراجعة' : 'غير صالح';
      const statusStr = row.status === 'draft' ? 'مسودة' : row.status === 'approved' ? 'مقبول' : row.status === 'rejected' ? 'مرفوض' : 'قيد الفرز';
      
      csvContent += `"${row.schoolName}","${row.name}","${row.jobTitle}","${row.subject}","${row.address}","${row.nationalId}","${row.birthDate || ''}","${row.phone}","${obst}","${diagStr}","${statusStr}"\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `كشف_استمارة_1_سري_المجمعة_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Advanced Filtering logic combining search inputs and report presets
  const filteredRows = nominations.filter(nom => {
    const matchesSchool = nom.schoolName.toLowerCase().includes(searchSchool.toLowerCase());
    const matchesTeacher = nom.name.toLowerCase().includes(searchTeacher.toLowerCase());
    const matchesNationalId = nom.nationalId.includes(searchNationalId);
    
    const matchesJob = filterJob === 'all' || nom.jobTitle.toLowerCase().includes(filterJob.toLowerCase());
    const matchesSubject = filterSubject === 'all' || nom.subject.toLowerCase().includes(filterSubject.toLowerCase());
    const matchesObstacle = filterObstacle === 'all' || 
                            (filterObstacle === 'has' && nom.obstacleId !== 'none') || 
                            (filterObstacle === 'none' && nom.obstacleId === 'none');
                            
    const matchesReview = filterReviewStatus === 'all' ||
                          (filterReviewStatus === 'pending' && (nom.status === 'submitted' || nom.status === 'pending')) ||
                          (filterReviewStatus === 'approved' && nom.status === 'approved') ||
                          (filterReviewStatus === 'rejected' && nom.status === 'rejected');

    if (!matchesSchool || !matchesTeacher || !matchesNationalId || !matchesJob || !matchesSubject || !matchesObstacle || !matchesReview) {
      return false;
    }

    // Apply report presets
    const diag = runDiagnostics(nom);
    if (activeReportMode === 'accepted') return nom.status === 'approved';
    if (activeReportMode === 'rejected') return nom.status === 'rejected' && nom.rejectionReason && !nom.rejectionReason.includes('عذر');
    if (activeReportMode === 'excused') return excuseDecisionId !== null || excuses.some(e => e.nationalId === nom.nationalId && e.status === 'approved');
    if (activeReportMode === 'obstacles') return nom.obstacleId !== 'none';
    if (activeReportMode === 'incomplete') return diag.status === 'disqualified';

    return true;
  });

  return (
    <div className="space-y-6 text-slate-800 font-sans" dir="rtl">
      {/* Quick Summary Panels */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Banner */}
        <div className="md:col-span-2 bg-gradient-to-l from-slate-900 to-slate-850 p-6 rounded-2xl text-white flex flex-col justify-between shadow">
          <div>
            <h2 className="text-lg font-black flex items-center gap-2">
              <ClipboardList className="text-rose-400" size={20} />
              مركز المراجعة والاعتماد لاستمارة (1 سري) المجمعة
            </h2>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              تصلك استمارات المعلمين الرقمية فور ملئها من المدارس. يرجى المراجعة والتحقق من المفرزات وصحة المستندات الداعمة لموانع التنسيق لاعتمادها أو رفضها محلياً وسحابياً.
            </p>
          </div>
          <div className="flex gap-2 mt-4 flex-wrap">
            <button
              onClick={() => setShowObstacleManager(!showObstacleManager)}
              className="bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 rounded-lg text-[11px] font-black cursor-pointer flex items-center gap-1 shadow"
            >
              <Sliders size={13} />
              {showObstacleManager ? 'إغلاق نافذة التحكم' : 'إدارة بنود الموانع والأعذار'}
            </button>
          </div>
        </div>

        {/* Total stats */}
        <div className="bg-white border rounded-2xl p-5 flex flex-col justify-between shadow-xs">
          <p className="text-[11px] text-slate-400 font-extrabold">إجمالي استمارات المعلمين المسجلة</p>
          <div className="flex justify-between items-baseline my-2">
            <span className="text-3xl font-black text-rose-700">{nominations.length}</span>
            <span className="text-[10px] text-slate-400 font-bold">بين مسودة وقيد فرز</span>
          </div>
          <div className="text-[10px] bg-slate-50 p-2 rounded-lg text-slate-500 font-medium leading-normal">
            ⏳ قيد المراجعة: <span className="font-bold text-slate-900">{nominations.filter(n => n.status === 'submitted' || n.status === 'pending').length}</span>
          </div>
        </div>

        {/* Integrity Stats */}
        <div className="bg-white border rounded-2xl p-5 flex flex-col justify-between shadow-xs">
          <p className="text-[11px] text-slate-400 font-extrabold">تدقيق الفحص الذكي والقرابات</p>
          <div className="flex gap-4 justify-around my-2 text-center">
            <div>
              <p className="text-[10px] text-emerald-600 font-black">🟢 صالح</p>
              <p className="text-xl font-black text-emerald-700">
                {nominations.filter(n => runDiagnostics(n).status === 'eligible').length}
              </p>
            </div>
            <div className="border-r border-slate-100 pr-4">
              <p className="text-[10px] text-amber-500 font-black">🟡 عذر/مانع</p>
              <p className="text-xl font-black text-amber-600">
                {nominations.filter(n => runDiagnostics(n).status === 'needs_review').length}
              </p>
            </div>
            <div className="border-r border-slate-100 pr-4">
              <p className="text-[10px] text-rose-600 font-black">🔴 غير مكتمل</p>
              <p className="text-xl font-black text-rose-700">
                {nominations.filter(n => runDiagnostics(n).status === 'disqualified').length}
              </p>
            </div>
          </div>
          <div className="text-[10px] bg-rose-50/40 p-2 border border-rose-100 rounded-lg text-rose-800 font-bold truncate">
            ⚠️ موانع لم يرفق لها مستندات: {nominations.filter(n => n.obstacleId !== 'none' && n.documents.length === 0).length}
          </div>
        </div>
      </div>

      {/* Embedded Dynamic Obstacle Manager (إدارة موانع الامتحانات) */}
      {showObstacleManager && (
        <div className="bg-[#FFF8F8] border border-rose-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex justify-between items-center border-b border-rose-100 pb-2">
            <h3 className="font-extrabold text-rose-900 text-xs flex items-center gap-1.5">
              <Sliders size={15} className="text-rose-500" />
              تكوين قائمة موانع الاشتراك (تحديث موجه للمدارس بلا تحديث كود التطبيق)
            </h3>
            <span className="text-[9px] bg-rose-100 px-2 py-0.5 rounded text-rose-800 font-bold">بوابة التحكم الحيوية</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Form */}
            <form onSubmit={handleSaveObstacle} className="bg-white p-4 border border-rose-100 rounded-xl space-y-3.5">
              <h4 className="text-xs font-black text-slate-700">{editingObstacleId ? 'تعديل بند عقبة' : 'إضافة بند مانع استبعاد جديد'}</h4>
              
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-500">اسم المانع وعقبة الاشتراك الفعلي *</label>
                <input
                  type="text"
                  value={newObstacleName}
                  onChange={(e) => setNewObstacleName(e.target.value)}
                  placeholder="مثال: جزاء تأديبي يزيد عن 5 أيام، إعارة، درجة قرابة..."
                  className="w-full text-xs p-2.5 border rounded-lg focus:outline-none focus:border-rose-450 font-semibold"
                />
              </div>

              <label className="flex items-center gap-2 select-none cursor-pointer">
                <input
                  type="checkbox"
                  checked={newObstacleRequiresDoc}
                  onChange={(e) => setNewObstacleRequiresDoc(e.target.checked)}
                  className="rounded text-rose-600 focus:ring-rose-500"
                />
                <span className="text-[11px] font-bold text-slate-600">يتطلب هذا البند إلزامياً رفع مستند مؤيد وصور داعمة من المدرسة</span>
              </label>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-rose-600 text-white hover:bg-rose-700 font-black rounded-lg text-xs cursor-pointer"
                >
                  حفظ البند بالبوابة
                </button>
                {editingObstacleId && (
                  <button
                    type="button"
                    onClick={() => {
                      setNewObstacleName('');
                      setEditingObstacleId(null);
                      setNewObstacleRequiresDoc(true);
                    }}
                    className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-semibold"
                  >
                    إلغاء التعديل
                  </button>
                )}
              </div>
            </form>

            {/* List of current config live */}
            <div className="bg-white p-4 border border-rose-100 rounded-xl space-y-2 max-h-[220px] overflow-y-auto">
              <h4 className="text-xs font-black text-slate-700 border-b pb-1.5 mb-2">البنود الحالية النشطة بالسيستم ({obstacles.length})</h4>
              {obstacles.map(obs => (
                <div key={obs.id} className="p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100 flex justify-between items-center text-xs">
                  <div>
                    <p className="font-extrabold text-slate-800">{obs.name}</p>
                    <p className="text-[9px] text-slate-450 font-semibold">
                      {obs.requiresDocument ? '📎 إلزامي المرفق' : 'لا يشترط مستند'} | كود: {obs.id}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => {
                        setEditingObstacleId(obs.id);
                        setNewObstacleName(obs.name);
                        setNewObstacleRequiresDoc(obs.requiresDocument);
                      }}
                      className="p-1 hover:bg-slate-200 text-slate-600 rounded"
                      title="تعديل هذا البند"
                    >
                      <Edit2 size={11} />
                    </button>
                    <button
                      onClick={() => handleDeleteObstacle(obs.id, obs.name)}
                      className="p-1 hover:bg-red-50 text-red-600 rounded"
                      title="مسح هذا البند من الخيارات"
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Filters Toolbar & Report Mode Toggles */}
      <div className="bg-white border rounded-2xl p-5 shadow-xs space-y-4">
        <h3 className="text-xs font-black text-[#0D47A1] border-b pb-2 flex items-center gap-1.5">
          <Sliders size={15} />
          أدوات التصفية والفرز الذكي والتقارير المحددة
        </h3>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400">التصفية باسم المدرسة</span>
            <input
              type="text"
              placeholder="اكتب اسم المدرسة للفلترة..."
              value={searchSchool}
              onChange={(e) => setSearchSchool(e.target.value)}
              className="w-full p-2 border rounded-lg text-xs focus:outline-none font-semibold bg-slate-50/50"
            />
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400">التصفية باسم المعلم المرشح</span>
            <input
              type="text"
              placeholder="اكتب اسم المعلم للفلترة..."
              value={searchTeacher}
              onChange={(e) => setSearchTeacher(e.target.value)}
              className="w-full p-2 border rounded-lg text-xs focus:outline-none font-semibold bg-slate-50/50"
            />
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400">الرقم القومي (14 رقماً)</span>
            <input
              type="text"
              maxLength={14}
              placeholder="أدخل الرقم القومي كاملاً..."
              value={searchNationalId}
              onChange={(e) => setSearchNationalId(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg text-xs focus:outline-none font-bold bg-slate-50/50 font-mono"
            />
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400">حالة المراجعة الإدارية</span>
            <select
              value={filterReviewStatus}
              onChange={(e) => setFilterReviewStatus(e.target.value)}
              className="w-full p-2 border rounded-lg text-xs focus:outline-none font-bold bg-slate-50 cursor-pointer text-slate-650"
            >
              <option value="all">كل حالات المراجعة</option>
              <option value="pending">⏳ قيد الفرز والدراسة</option>
              <option value="approved">✅ المعتمدين والمقبولين</option>
              <option value="rejected">❌ المستبعدين والمرفوضين</option>
            </select>
          </div>
        </div>

            {/* Report Presets Row */}
            <div className="border-t border-slate-100 pt-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <span className="text-[11px] font-black text-rose-900">التقارير السريعة وعرض الشرائح:</span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { mode: 'all', label: '📊 الاستمارات الكاملة' },
                  { mode: 'accepted', label: '🟢 تقرير المقبولين للترشيح' },
                  { mode: 'rejected', label: '🔴 تقرير المستبعدين والمرفوضين' },
                  { mode: 'excused', label: '🔵 تقرير المعتذرين رسمياً' },
                  { mode: 'obstacles', label: '⚠️ تقرير أصحاب الموانع والعراقيل' },
                  { mode: 'incomplete', label: '📋 تقرير المستندات والبيانات الناقصة' }
                ].map((btn) => (
                  <button
                    key={btn.mode}
                    onClick={() => setActiveReportMode(btn.mode as any)}
                    className={`px-3 py-1.5 rounded-lg text-[10px] font-black cursor-pointer transition active:scale-95 border ${
                      activeReportMode === btn.mode
                        ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {btn.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Printable Official Reports Trigger */}
            <div className="border-t border-dashed border-rose-100 pt-3.5 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50 p-3 rounded-xl border border-slate-150 mt-1">
              <div className="flex items-center gap-1.5 font-extrabold text-[11px] text-slate-800">
                <Printer size={14} className="text-rose-600 animate-pulse" />
                <span>التقارير الإدارية المعتمدة المستخرجة للطباعة والبت:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setPrintReportType('fit')}
                  className="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1.5 rounded-lg text-[10px] font-black cursor-pointer flex items-center gap-1.5 shadow-sm transition active:scale-95 font-sans"
                >
                  <FileText size={12} />
                  🖨️ طباعة تقرير المرشحين الصالحين (صالح)
                </button>
                <button
                  onClick={() => setPrintReportType('excuses')}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-[10px] font-black cursor-pointer flex items-center gap-1.5 shadow-sm transition active:scale-95 font-sans"
                >
                  <FileText size={12} />
                  🖨️ طباعة تقرير نتائج الاعتذارات (مقبول / مرفوض)
                </button>
                <button
                  onClick={() => setPrintReportType('all_schools_approved')}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg text-[10px] font-black cursor-pointer flex items-center gap-1.5 shadow-sm transition active:scale-95 font-sans animate-soft-pulse"
                >
                  <Printer size={12} />
                  🖨️ طباعة تقارير المدارس المجمعة (المقبولين لـ ١ سري)
                </button>
              </div>
            </div>
      </div>

      {/* Main Core Candidates Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-right text-xs">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-200 font-extrabold text-slate-700">
                <th className="p-3">المدرسة</th>
                <th className="p-3">اسم المعلم المرشح</th>
                <th className="p-3">الوظيفة المادية والفعلية</th>
                <th className="p-3 text-center">الرقم القومي والاتصال</th>
                <th className="p-3">العقبات المسجلة</th>
                <th className="p-3 text-center">الفحص الآلي الذكي</th>
                <th className="p-3 text-center">المستندات المرفقة</th>
                <th className="p-3 text-center">القرار وحالة المراجعة</th>
                <th className="p-3 text-center">إجراءات المراجعة والاعتذارات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-12 text-center text-slate-450 font-bold">
                    <div className="space-y-2">
                      <HelpCircle size={36} className="mx-auto text-slate-300" />
                      <p className="text-sm">لا توجد سجلات ترشيحات موجهة تناسب معايير البحث والتقارير المحددة حالياً.</p>
                      <p className="text-[11px] text-slate-400">تصلك السجلات والخيارات فوريًا بمجرد إدراجها من قبل إدارات المدارس المعتمدة.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRows.map((row) => {
                  const diag = runDiagnostics(row);
                  return (
                    <tr key={row.id} className="hover:bg-slate-50/50 transition duration-150">
                      {/* School Name */}
                      <td className="p-3 font-extrabold text-blue-900 border-l border-slate-100 max-w-[120px] truncate" title={row.schoolName}>
                        {row.schoolName}
                      </td>

                      {/* Name & Address */}
                      <td className="p-3">
                        <div className="font-extrabold text-slate-900 text-sm">{row.name}</div>
                        <div className="text-[10px] text-slate-400 font-semibold mt-0.5">{row.address}</div>
                      </td>

                      {/* Job & subject */}
                      <td className="p-3">
                        <div className="font-bold text-slate-850">{row.jobTitle}</div>
                        <div className="text-[10px] text-slate-500 font-semibold mt-0.5">مادة: {row.subject}</div>
                      </td>

                      {/* National ID & Phone */}
                      <td className="p-3 text-center font-mono font-bold text-slate-700">
                        <div>{row.nationalId}</div>
                        <div className="text-[9px] text-slate-400 mt-0.5">هاتف: {row.phone}</div>
                      </td>

                      {/* Impediments/Obstacles */}
                      <td className="p-3 text-right">
                        {row.obstacleId !== 'none' ? (
                          <div className="space-y-0.5 bg-rose-50/60 p-2 rounded-lg border border-rose-100 max-w-[180px]">
                            <span className="text-[10px] font-black text-rose-800">
                              ⚠️ {obstacles.find(o => o.id === row.obstacleId)?.name || 'عائق مسجل'}
                            </span>
                            {row.obstacleText && (
                              <p className="text-[9px] text-slate-600 line-clamp-2 mt-1" title={row.obstacleText}>
                                توضيح: {row.obstacleText}
                              </p>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[10px] font-bold">لا يوجد مانع مسجل</span>
                        )}
                      </td>

                      {/* Smart check results */}
                      <td className="p-3 text-center">
                        {diag.status === 'eligible' ? (
                          <div className="inline-flex flex-col items-center">
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 text-emerald-805 border border-emerald-250">
                              🟢 صالح ومستوفى
                            </span>
                          </div>
                        ) : diag.status === 'needs_review' ? (
                          <div className="inline-flex flex-col items-center gap-0.5 max-w-[130px]">
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-amber-100 text-amber-805 border border-amber-250 animate-pulse">
                              🟡 يستحق مراجعة
                            </span>
                            <span className="text-[8px] text-slate-450 leading-normal" title={diag.reason}>
                              {diag.reason}
                            </span>
                          </div>
                        ) : (
                          <div className="inline-flex flex-col items-center gap-0.5 max-w-[130px]">
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-rose-100 text-rose-805 border border-rose-250">
                              🔴 غير صالح
                            </span>
                            <span className="text-[8px] text-rose-600 font-extrabold leading-normal" title={diag.reason}>
                              {diag.reason}
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Attached Documents list with Preview */}
                      <td className="p-3 text-center">
                        {row.documents && row.documents.length > 0 ? (
                          <div className="flex flex-col gap-1 items-center">
                            <span className="text-[10px] font-black text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-205">
                              📎 المرفقات ({row.documents.length})
                            </span>
                            <div className="flex justify-center gap-1 mt-0.5">
                              {row.documents.map((doc, idx) => (
                                <button
                                  key={doc.id}
                                  onClick={() => setPreviewDoc(doc)}
                                  className="p-1 hover:bg-slate-100 text-blue-700 rounded-lg transition"
                                  title={`معاينة المرفق (${idx + 1}): ${doc.name}`}
                                >
                                  <Eye size={12} />
                                </button>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-medium">لا توجد</span>
                        )}
                      </td>

                      {/* Current Status and decisions details */}
                      <td className="p-3 text-center font-bold">
                        {row.status === 'draft' ? (
                          <span className="px-2 bg-slate-100 text-slate-600 rounded border">لم يسلم بعد</span>
                        ) : row.status === 'submitted' || row.status === 'pending' ? (
                          <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-md border border-amber-250">
                            ⏳ بانتظار البت
                          </span>
                        ) : row.status === 'approved' ? (
                          <div className="space-y-0.5">
                            <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-md border border-emerald-250 text-[10px] font-black">
                              🟢 معتمد ومقبول
                            </span>
                            {row.rejectionFeedback && (
                              <p className="text-[9px] text-slate-450 block truncate max-w-[120px] mx-auto" title={row.rejectionFeedback}>
                                {row.rejectionFeedback}
                              </p>
                            )}
                          </div>
                        ) : (
                          <div className="space-y-0.5">
                            <span className="px-1.5 py-0.5 bg-rose-100 text-rose-800 rounded-md border border-rose-250 text-[10px] font-black">
                              🔴 مستبعد ومرفوض
                            </span>
                            {row.rejectionFeedback && (
                              <p className="text-[9px] text-red-650 bg-rose-50/50 p-1 rounded font-black max-w-[120px] mx-auto truncate" title={row.rejectionFeedback}>
                                السبب: {row.rejectionFeedback}
                              </p>
                            )}
                          </div>
                        )}
                      </td>

                      {/* Action buttons (الاعتمادات ثنائية الاتجاه ونظام الأعذار) */}
                      <td className="p-3 text-center">
                        <div className="flex flex-col items-center gap-1.5">
                          {/* Approve and reject actions for Candidate */}
                          {(row.status === 'submitted' || row.status === 'pending') && (
                            <div className="flex gap-1">
                              <button
                                onClick={() => handleApproveNomination(row)}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black px-2 py-1 rounded shadow-xs cursor-pointer transition active:scale-95"
                                title="الموافقة على ترشيحه للجنة الامتحانات"
                              >
                                ✅ موافقة
                              </button>
                              <button
                                onClick={() => handleOpenRejection(row.id)}
                                className="bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-black px-2 py-1 rounded shadow-xs cursor-pointer transition active:scale-95"
                                title="استبعاد الترشيح مع إرفاق تعليق"
                              >
                                ❌ رفض
                              </button>
                            </div>
                          )}

                          {/* Excuse Decisions actions (قبول ورفض الاعتذار) for candidates with obstacles */}
                          {row.obstacleId !== 'none' && (
                            <div className="bg-blue-50/45 p-1 rounded border border-blue-200 text-center space-y-1 w-full max-w-[140px]">
                              <p className="text-[9px] font-black text-[#0D47A1]">عقد قرار الالتماس/العذر:</p>
                              <div className="flex gap-1 justify-center">
                                <button
                                  onClick={() => {
                                    setExcuseDecisionDialog({
                                      isOpen: true,
                                      nomination: row,
                                      decision: 'approved',
                                      notes: 'مستند طبي داعم صحيح وموثق للجنة'
                                    });
                                  }}
                                  className="bg-blue-600 hover:bg-blue-700 text-white text-[8px] font-black px-1.5 py-0.5 rounded cursor-pointer"
                                  title="قبول والاعتراف بالعذر للاعتذار"
                                >
                                  قبول العذر
                                </button>
                                <button
                                  onClick={() => {
                                    setExcuseDecisionDialog({
                                      isOpen: true,
                                      nomination: row,
                                      decision: 'rejected',
                                      notes: 'لا يتطابق السجل أو التقرير المرفق مع الاشتراطات واللوائح الطبية الممنوحة'
                                    });
                                  }}
                                  className="bg-amber-600 hover:bg-amber-700 text-white text-[8px] font-black px-1.5 py-0.5 rounded cursor-pointer"
                                  title="رفض عذر المعلم وعودته لأعمال الفرز والامتحان"
                                >
                                  رفض العذر
                                </button>
                              </div>
                            </div>
                          )}

                          {/* Reset state to study */}
                          {(row.status === 'approved' || row.status === 'rejected') && (
                            <button
                              onClick={() => {
                                setConfirmDialog({
                                  isOpen: true,
                                  title: 'إعادة الترشيح للدراسة',
                                  message: `هل أنت متأكد من إعادة فحص استمارة الموظف: ${row.name} وإعادتها لمرحلة قيد الدراسة والفرز؟`,
                                  onConfirm: () => {
                                    const updated = { ...row, status: 'submitted', rejectionReason: undefined, rejectionFeedback: undefined } as any;
                                    dbInstance.saveExamNomination(updated);
                                    setConfirmDialog(null);
                                    showToast('تمت إعادة الاستمارة لوضع قيد الدراسة والمراجعة.', 'success');
                                  }
                                });
                              }}
                              className="text-[9px] text-slate-500 font-bold hover:underline"
                            >
                              إعادة دراسة الاستمارة
                            </button>
                          )}

                          {/* Coordination Admin Deletion Button */}
                          <button
                            onClick={() => handleDeleteNominationAdmin(row)}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 p-1 rounded-md text-[9px] font-black flex items-center justify-center gap-1 transition-all mt-1 w-full max-w-[120px] cursor-pointer"
                            title="إلغاء الترشيح وحذف الاستمارة تماماً وسائباً"
                          >
                            <Trash2 size={10} />
                            حذف استمارة
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Rejection comment text prompt box popup */}
      {rejectionNomId && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-xl space-y-4 text-right">
            <h4 className="font-sans font-black text-sm text-rose-700 flex items-center gap-1.5">
              <AlertCircle size={18} />
              تسجيل سبب الرفض والاستبعاد الإداري للمرشح
            </h4>
            <p className="text-xs text-slate-500">سوف يعود هذا السبب فورياً كإخطار وتغذية راجعة على واجهة مدير المدرسة في نفس اللحظة:</p>
            <textarea
              rows={3}
              value={rejectionReasonText}
              onChange={(e) => setRejectionReasonText(e.target.value)}
              placeholder="اكتب تفاصيل الرفض وملاحظات الإرجاع بدقة هنا..."
              className="w-full text-xs p-3 border rounded-xl bg-slate-5 font-semibold focus:outline-none focus:border-rose-500"
            />
            <div className="flex gap-2 justify-end pt-2">
              <button
                onClick={() => {
                  setRejectionNomId(null);
                  setRejectionReasonText('');
                }}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                إلغاء الأمر
              </button>
              <button
                onClick={handleRejectNominationSubmit}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow cursor-pointer"
              >
                حفظ وإرجاع للمدرسة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Document modal preview */}
      {previewDoc && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl overflow-hidden text-right">
            <div className="bg-slate-100 p-4 border-b border-slate-200 flex justify-between items-center">
              <button 
                onClick={() => setPreviewDoc(null)}
                className="p-1 hover:bg-slate-200 rounded-full transition text-slate-500 cursor-pointer"
              >
                <X size={18} />
              </button>
              <h4 className="font-sans font-black text-xs text-[#0D47A1] truncate pl-4">
                معاينة المرفق المستندي: {previewDoc.name}
              </h4>
            </div>
            <div className="p-4 flex items-center justify-center min-h-[320px] bg-slate-55">
              {previewDoc.type === 'pdf' ? (
                <div className="text-center space-y-3 p-10">
                  <FileText size={48} className="text-rose-500 mx-auto" />
                  <p className="text-xs font-black text-slate-600">هذا المستند ملف PDF رسمي</p>
                  <a
                    href={previewDoc.dataUrl}
                    download={previewDoc.name}
                    referrerPolicy="no-referrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-650 hover:bg-rose-700 text-white rounded-lg text-xs font-bold shadow transition cursor-pointer"
                  >
                    <Download size={14} />
                    تنزيل ملف الـ PDF لفحصه
                  </a>
                </div>
              ) : (
                <img
                  src={previewDoc.dataUrl}
                  alt={previewDoc.name}
                  referrerPolicy="no-referrer"
                  className="max-h-[65vh] rounded-lg max-w-full object-contain border shadow-xs"
                />
              )}
            </div>
            <div className="bg-slate-50 p-3 border-t border-slate-200 flex justify-end gap-2 text-xs">
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-1.5 bg-rose-600 text-white hover:bg-rose-700 rounded-lg font-black transition cursor-pointer"
              >
                إغلاق المعاينة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Excuse Decision Dialog Modal */}
      {excuseDecisionDialog.isOpen && excuseDecisionDialog.nomination && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-xl space-y-4 text-right border border-blue-100" dir="rtl">
            <h4 className="font-sans font-black text-sm text-blue-805 flex items-center gap-1.5 border-b pb-2">
              <ClipboardList size={22} className="text-blue-600" />
              عقد قرار عذر والتماس المعلم: {excuseDecisionDialog.nomination.name}
            </h4>
            <div className="bg-slate-50 p-3 rounded-xl space-y-2 text-xs">
              <p><strong>المدرسة:</strong> {excuseDecisionDialog.nomination.schoolName}</p>
              <p><strong>الوظيفة والتخصص:</strong> {excuseDecisionDialog.nomination.jobTitle} - {excuseDecisionDialog.nomination.subject}</p>
              <p><strong>المانع المسجل:</strong> {obstacles.find(o => o.id === excuseDecisionDialog.nomination?.obstacleId)?.name || 'أخرى'}</p>
              {excuseDecisionDialog.nomination.obstacleText && (
                <p><strong>تفاصيل العذر:</strong> {excuseDecisionDialog.nomination.obstacleText}</p>
              )}
            </div>

            <div className="space-y-1">
              <label className="block text-[11px] font-bold text-slate-500">حالة قرار البت النهائي بالإدارة:</label>
              <div className="flex flex-col gap-2 p-1 border rounded-lg bg-slate-50/50">
                <label className="flex items-center gap-2 cursor-pointer font-black text-xs text-emerald-700">
                  <input
                    type="radio"
                    name="excuseDecisionRadio"
                    checked={excuseDecisionDialog.decision === 'approved'}
                    onChange={() => setExcuseDecisionDialog(prev => ({ ...prev, decision: 'approved' }))}
                    className="text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>✅ قبول العذر والاستبعاد من أعمال اللجنة (مقبول عذره ومستبعد)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer font-black text-xs text-amber-700">
                  <input
                    type="radio"
                    name="excuseDecisionRadio"
                    checked={excuseDecisionDialog.decision === 'rejected'}
                    onChange={() => setExcuseDecisionDialog(prev => ({ ...prev, decision: 'rejected' }))}
                    className="text-amber-600 focus:ring-amber-500"
                  />
                  <span>❌ رفض العذر واستدعاؤه للجنة (مرفوض عذره وملزم بالندب)</span>
                </label>
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-[11px] font-bold text-slate-500">المسوغات والملاحظات الإدارية للبت *</label>
              <textarea
                rows={3}
                value={excuseDecisionDialog.notes}
                onChange={(e) => setExcuseDecisionDialog(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="مثال: تم قبول العذر لوجود تقرير طبي معتمد من التأمين الصحي، إلخ..."
                className="w-full text-xs p-3 border rounded-xl bg-slate-5 font-semibold focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex gap-2 justify-end pt-2 border-t border-slate-100">
              <button
                onClick={() => setExcuseDecisionDialog({ isOpen: false, nomination: null, decision: null, notes: '' })}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                رجوع وإلغاء
              </button>
              <button
                onClick={() => {
                  if (!excuseDecisionDialog.decision) {
                    showToast('يرجى تحديد قرار البت (قبول أو رفض) أولاً.', 'error');
                    return;
                  }
                  if (!excuseDecisionDialog.notes.trim()) {
                    showToast('يرجى إدخال ملاحظات البت ومسوغاته لحفظ القرار.', 'error');
                    return;
                  }
                  handleExcuseDecision(excuseDecisionDialog.nomination!, excuseDecisionDialog.decision, excuseDecisionDialog.notes);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow cursor-pointer"
              >
                اعتماد وحفظ القرار الفوري
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Confirm Dialog Overlay */}
      {confirmDialog && confirmDialog.isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-xl space-y-4 text-right border border-slate-100" dir="rtl">
            <h4 className="font-sans font-black text-sm text-rose-700 flex items-center gap-1.5">
              ⚠️ {confirmDialog.title}
            </h4>
            <p className="text-xs text-slate-650 font-bold leading-relaxed">{confirmDialog.message}</p>
            <div className="flex gap-2 justify-end pt-2">
              <button
                onClick={() => setConfirmDialog(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                رجوع وإلغاء
              </button>
              <button
                onClick={confirmDialog.onConfirm}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow cursor-pointer"
              >
                تأكيد ومتابعة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-bounce">
          <div className={`p-4 rounded-xl shadow-lg border text-xs font-black flex items-center gap-2 ${
            toast.type === 'success' ? 'bg-emerald-55 border-emerald-200 text-emerald-850' :
            toast.type === 'error' ? 'bg-rose-55 border-rose-200 text-rose-850' :
            'bg-slate-55 border-slate-250 text-slate-850'
          }`}>
            <span>{toast.type === 'success' ? '✅' : toast.type === 'error' ? '❌' : 'ℹ️'}</span>
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Fit (صالح) Candidates Printable Report Sheet */}
      {printReportType === 'fit' && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden text-right flex flex-col my-8">
            <div className="bg-slate-100 px-6 py-4 border-b border-slate-200 flex justify-between items-center shrink-0">
              <div className="flex gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-1.5 bg-rose-600 text-white hover:bg-rose-700 rounded-lg text-xs font-black shadow transition flex items-center gap-1 cursor-pointer"
                >
                  <Printer size={13} strokeWidth={2.5} />
                  إرسال لأمر الطباعة (Ctrl+P)
                </button>
                <button
                  onClick={() => setPrintReportType(null)}
                  className="px-4 py-1.5 bg-slate-200 text-slate-700 hover:bg-slate-3 rounded-lg text-xs font-black transition cursor-pointer"
                >
                  إغلاق نافذة المعاينة
                </button>
              </div>
              <h4 className="font-sans font-black text-xs text-[#0D47A1]">
                معاينة مسودة التقرير الرسمي للمرشحين الصالحين (صالح)
              </h4>
            </div>

            <div id="printable-report-area" className="p-6 overflow-y-auto flex-grow max-h-[75vh] bg-slate-50/50">
              <PrintableReport
                title="الـكـشـف الـجـمـاعـي الـمـعـتـمـد لـلـمـرشـحـيـن الـصـالـحـيـن (١ سري)"
                subtitle={`كشف مجمع حصر المعلمين المستوفين وصالحي الاشتراك في نظام أعمال الامتحانات الرسمية بمدارس الإدارة لعام ${new Date().getFullYear()}`}
              >
                <div className="space-y-4">
                  {/* Summary grid */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <div className="bg-emerald-50 border border-emerald-100 p-3 rounded-lg text-center">
                      <p className="text-[10px] text-emerald-800 font-extrabold">عدد المرشحين الصالحين</p>
                      <p className="text-xl font-bold text-emerald-900">
                        {nominations.filter(n => runDiagnostics(n).status === 'eligible').length} معلم
                      </p>
                    </div>
                    <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg text-center">
                      <p className="text-[10px] text-slate-500 font-semibold">نسبة الاستيفاء المكتملة</p>
                      <p className="text-xl font-bold text-slate-850">
                        {nominations.length > 0 
                          ? Math.round((nominations.filter(n => runDiagnostics(n).status === 'eligible').length / nominations.length) * 100) 
                          : 0}%
                      </p>
                    </div>
                    <div className="bg-blue-50 border border-blue-100 p-3 rounded-lg text-center">
                      <p className="text-[10px] text-blue-800 font-extrabold font-sans">قيد الفرز والتدقيق</p>
                      <p className="text-xl font-bold text-blue-900">
                        {nominations.filter(n => n.status === 'submitted' || n.status === 'pending').length} استمارة
                      </p>
                    </div>
                    <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg text-center">
                      <p className="text-[10px] text-slate-500 font-semibold">تاريخ التوثيق الفعلي</p>
                      <p className="text-xs font-bold text-slate-800 my-2">{new Date().toLocaleDateString('ar-EG')}</p>
                    </div>
                  </div>

                  {/* Table */}
                  <div className="border border-slate-300 rounded-lg overflow-hidden">
                    <table className="w-full text-right border-collapse text-[10px] leading-relaxed">
                      <thead>
                        <tr className="bg-slate-100 border-b border-slate-300 font-extrabold text-slate-900">
                          <th className="p-2 border-l border-slate-300 text-center">م</th>
                          <th className="p-2 border-l border-slate-300">الاسم رباعي</th>
                          <th className="p-2 border-l border-slate-300">المدرسة والتبعية</th>
                          <th className="p-2 border-l border-slate-300">الوظيفة والتخصص</th>
                          <th className="p-2 border-l border-slate-300 text-center font-mono">الرقم القومي (١٤ رقماً)</th>
                          <th className="p-2 border-l border-slate-300 text-center font-mono">رقم الهاتف</th>
                          <th className="p-2 text-center">بصمة / توقيع المستلم</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-300">
                        {nominations.filter(n => runDiagnostics(n).status === 'eligible').length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-6 text-center text-slate-400 font-bold">
                              لا يوجد مرشحون صالحون مستوفون في الكشوف المجمعة حالياً.
                            </td>
                          </tr>
                        ) : (
                          nominations.filter(n => runDiagnostics(n).status === 'eligible').map((nom, idx) => (
                            <tr key={nom.id} className="hover:bg-slate-50">
                              <td className="p-2 border-l border-slate-300 text-center font-bold font-mono">{idx + 1}</td>
                              <td className="p-2 border-l border-slate-300 font-black text-slate-900">{nom.name}</td>
                              <td className="p-2 border-l border-slate-300 font-bold text-slate-800">{nom.schoolName}</td>
                              <td className="p-2 border-l border-slate-300">
                                <span className="font-bold text-slate-850">{nom.jobTitle}</span> | مادة: {nom.subject}
                              </td>
                              <td className="p-2 border-l border-slate-300 text-center font-mono font-bold text-slate-800">{nom.nationalId}</td>
                              <td className="p-2 border-l border-slate-300 text-center font-mono font-semibold">{nom.phone}</td>
                              <td className="p-2 text-center text-slate-300 select-none">.................................</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </PrintableReport>
            </div>
          </div>
        </div>
      )}

      {/* Excuse Decisions (مقبول / مرفوض) Printable Report Sheet */}
      {printReportType === 'excuses' && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden text-right flex flex-col my-8">
            <div className="bg-slate-100 px-6 py-4 border-b border-slate-200 flex justify-between items-center shrink-0">
              <div className="flex gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-1.5 bg-rose-600 text-white hover:bg-rose-700 rounded-lg text-xs font-black shadow transition flex items-center gap-1 cursor-pointer"
                >
                  <Printer size={13} strokeWidth={2.5} />
                  إرسال لأمر الطباعة (Ctrl+P)
                </button>
                <button
                  onClick={() => setPrintReportType(null)}
                  className="px-4 py-1.5 bg-slate-200 text-slate-700 hover:bg-slate-3 rounded-lg text-xs font-black transition cursor-pointer"
                >
                  إغلاق نافذة المعاينة
                </button>
              </div>
              <h4 className="font-sans font-black text-xs text-[#0D47A1]">
                معاينة مسودة التقرير الرسمي لنتائج البت في اعتذارات الامتحانات
              </h4>
            </div>

            <div id="printable-report-area" className="p-6 overflow-y-auto flex-grow max-h-[75vh] bg-slate-50/50">
              <PrintableReport
                title="تـقـريـر نـتـائـج الـبـت فـي اعـتـذارات والـتـمـاسـات الـمـعـلـمـيـن (١ سري)"
                subtitle={`الكشف القانوني المجمع لقرارات لجنة التنسيق العام بشأن الأعذار وموانع الاشتراك لعام ${new Date().getFullYear()}`}
              >
                <div className="space-y-4">
                  {/* Summary cards row */}
                  <div className="grid grid-cols-3 gap-4 mb-6 text-center">
                    <div className="bg-blue-50 border border-blue-100 p-3 rounded-lg">
                      <p className="text-[10px] text-blue-800 font-extrabold">إجمالي التماسات الأعذار</p>
                      <p className="text-lg font-bold text-blue-950">
                        {nominations.filter(n => n.obstacleId !== 'none').length} طلب
                      </p>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-100 p-3 rounded-lg">
                      <p className="text-[10px] text-emerald-800 font-extrabold">أعذار مقبولة (استبعاد تام)</p>
                      <p className="text-lg font-bold text-emerald-950">
                        {excuses.filter(e => e.status === 'approved').length} مقبول
                      </p>
                    </div>
                    <div className="bg-rose-50 border border-rose-100 p-3 rounded-lg">
                      <p className="text-[10px] text-rose-850 font-extrabold">أعذار مرفوضة (ملزم بالاشتراك)</p>
                      <p className="text-lg font-bold text-rose-955">
                        {excuses.filter(e => e.status === 'rejected').length} مرفوض
                      </p>
                    </div>
                  </div>

                  {/* Table */}
                  <div className="border border-slate-300 rounded-lg overflow-hidden">
                    <table className="w-full text-right border-collapse text-[10px] leading-relaxed">
                      <thead>
                        <tr className="bg-slate-100 border-b border-slate-300 font-extrabold text-slate-900">
                          <th className="p-2 border-l border-slate-300 text-center">م</th>
                          <th className="p-2 border-l border-slate-300">المرشح الملتّمس</th>
                          <th className="p-2 border-l border-slate-300">المدرسة والتبعية</th>
                          <th className="p-2 border-l border-slate-300">المانع القانوني المسجل</th>
                          <th className="p-2 border-l border-slate-300 text-center">المرفقات المستندية</th>
                          <th className="p-2 border-l border-slate-300 text-center">قرار اللجنة المعتمد</th>
                          <th className="p-2 text-right">أسباب ومسوغات قرار اللجنة الرسمي</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-300">
                        {nominations.filter(n => n.obstacleId !== 'none').length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-6 text-center text-slate-400 font-bold">
                              لا توجد طلبات التماسات أو أعذار قانونية مقدمة حالياً بمؤسسات الإدارة.
                            </td>
                          </tr>
                        ) : (
                          nominations.filter(n => n.obstacleId !== 'none').map((nom, idx) => {
                            const relatedExcuse = excuses.find(e => e.id === `exc_${nom.id}`);
                            return (
                              <tr key={nom.id} className="hover:bg-slate-50">
                                <td className="p-2 border-l border-slate-300 text-center font-bold font-mono">{idx + 1}</td>
                                <td className="p-2 border-l border-slate-300">
                                  <div className="font-bold text-slate-900">{nom.name}</div>
                                  <div className="text-[8px] text-slate-500 font-mono mt-0.5">{nom.nationalId}</div>
                                </td>
                                <td className="p-2 border-l border-slate-300 font-bold text-slate-800">{nom.schoolName}</td>
                                <td className="p-2 border-l border-slate-300 text-slate-800 font-bold">
                                  {obstacles.find(o => o.id === nom.obstacleId)?.name || 'عائق قانوني'}
                                  {nom.obstacleText && (
                                    <span className="block text-[8px] text-slate-500 font-semibold font-sans mt-0.5">توضيح: {nom.obstacleText}</span>
                                  )}
                                </td>
                                <td className="p-2 border-l border-slate-300 text-center font-bold text-slate-700">
                                  {nom.documents && nom.documents.length > 0 ? `📎 مستند مؤيد (${nom.documents.length})` : '⚠️ غير مرفق'}
                                </td>
                                <td className="p-2 border-l border-slate-300 text-center font-bold">
                                  {relatedExcuse?.status === 'approved' ? (
                                    <span className="p-1 rounded bg-emerald-100 text-emerald-800 border border-emerald-200 text-[8px]">
                                      مــقــبــول (مستبعد)
                                    </span>
                                  ) : relatedExcuse?.status === 'rejected' ? (
                                    <span className="p-1 rounded bg-rose-100 text-rose-800 border border-rose-200 text-[8px]">
                                      مــرفــوض (ملتزم بالندب)
                                    </span>
                                  ) : (
                                    <span className="p-1 rounded bg-slate-100 text-slate-500 border text-[8px]">
                                      قـيـد الـدراسة
                                    </span>
                                  )}
                                </td>
                                <td className="p-2 text-slate-700 leading-normal font-semibold max-w-[200px] text-[9px]">
                                  {relatedExcuse?.status === 'approved' && nom.rejectionFeedback?.replace('✅ تم قبول العذر والاعتذار رسمياً بالإدارة: ', '')}
                                  {relatedExcuse?.status === 'rejected' && nom.rejectionFeedback?.replace('❌ تم رفض العذر والاعتذار بالإدارة: ', '')}
                                  {!relatedExcuse?.status && 'لم يتخذ قرار بت مجمع حتى تاريخه'}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </PrintableReport>
            </div>
          </div>
        </div>
      )}

      {/* Comprehensive All Approved Schools Grouped Report Sheet */}
      {printReportType === 'all_schools_approved' && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden text-right flex flex-col my-8">
            <div className="bg-slate-100 px-6 py-4 border-b border-slate-200 flex justify-between items-center shrink-0">
              <div className="flex gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-1.5 bg-emerald-600 text-white hover:bg-emerald-700 rounded-lg text-xs font-black shadow transition flex items-center gap-1 cursor-pointer font-sans"
                >
                  <Printer size={13} strokeWidth={2.5} />
                  طباعة الكشوف المجمعة (Ctrl+P)
                </button>
                <button
                  onClick={() => setPrintReportType(null)}
                  className="px-4 py-1.5 bg-slate-200 text-slate-700 hover:bg-slate-3 rounded-lg text-xs font-black transition cursor-pointer font-sans"
                >
                  إغلاق نافذة المعاينة
                </button>
              </div>
              <h4 className="font-sans font-black text-xs text-emerald-800">
                معاينة تقارير المدارس الكلية لـ ١ سري المقبولين (استخراج جماعي مسبق لكل مدرسة في صفحة منفصلة)
              </h4>
            </div>

            <div id="printable-report-area" className="p-6 overflow-y-auto flex-grow max-h-[75vh] bg-slate-50/50 space-y-12">
              {(() => {
                const schoolsWithApproved = schools.filter(school => 
                  nominations.some(n => n.schoolId === school.id && n.status === 'approved')
                );

                if (schoolsWithApproved.length === 0) {
                  return (
                    <div className="bg-white p-12 rounded-xl text-center border border-slate-200 shadow-sm col-span-full">
                      <AlertTriangle className="mx-auto text-amber-500 mb-2" size={32} />
                      <p className="text-sm font-black text-slate-850">لا توجد مدارس معتمدة في كشوف المقبولين حالياً.</p>
                      <p className="text-xs text-slate-500 mt-1 leading-normal font-medium font-sans">تأكد من قيامك كمدير تنسيق بقبول/اعتماد بعض المرشحين أولاً ثم اطلب طباعة التقرير المجمع.</p>
                    </div>
                  );
                }

                return schoolsWithApproved.map((school, schoolIdx) => {
                  const schoolNoms = nominations.filter(
                    n => n.schoolId === school.id && n.status === 'approved'
                  );
                  return (
                    <div 
                      key={school.id} 
                      className={`${schoolIdx > 0 ? "print-page-break pt-12 border-t-4 border-double border-slate-400" : "pt-4"}`}
                    >
                      <PrintableReport
                        title={`كـشـف مـرشـحـي الـمـدرسـة الـمـعـتـمـديـن (١ سري) - مـدرسـة: ${school.name}`}
                        subtitle={`البيان الرسمي لأعضاء الهيئة التعليمية المقبولين للمشاركة بنظام أعمال سير الامتحانات العامة لعام ${new Date().getFullYear()}`}
                      >
                        <div className="space-y-4 text-right" dir="rtl">
                          {/* Info card for print alignment */}
                          <div className="flex justify-between items-center bg-emerald-50 border border-emerald-100 p-3 rounded-lg text-xs font-bold leading-relaxed">
                            <div>
                               <span className="text-slate-500">اسم المؤسسة التعليمية: </span>
                               <span className="text-emerald-990 font-black text-slate-950 font-sans">{school.name}</span>
                            </div>
                            <div>
                              <span className="text-slate-500">عدد المرشحين المقبولين: </span>
                              <span className="bg-emerald-200 text-emerald-900 border border-emerald-300 px-2 py-0.5 rounded font-black font-mono">
                                {schoolNoms.length} معلم
                              </span>
                            </div>
                          </div>

                          {/* Table */}
                          <div className="border border-slate-300 rounded-lg overflow-hidden">
                            <table className="w-full text-right border-collapse text-[10px] leading-relaxed">
                              <thead>
                                <tr className="bg-slate-100 border-b border-slate-300 font-extrabold text-slate-900">
                                  <th className="p-2 border-l border-slate-300 text-center">م</th>
                                  <th className="p-2 border-l border-slate-300">الاسم رباعي</th>
                                  <th className="p-2 border-l border-slate-300">الوظيفة المالية والتعليمية</th>
                                  <th className="p-2 border-l border-slate-300">التخصص والمادة</th>
                                  <th className="p-2 border-l border-slate-300 text-center font-mono">الرقم القومي (١٤ رقماً)</th>
                                  <th className="p-2 border-l border-slate-300 text-center font-mono">الهاتف والجوال</th>
                                  <th className="p-2 text-center">توقيع وبصمة المستلم بالتبليغ الرسمي للمدرسة</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-300">
                                {schoolNoms.map((nom, idx) => (
                                  <tr key={nom.id} className="hover:bg-slate-50">
                                    <td className="p-2 border-l border-slate-300 text-center font-bold font-mono text-slate-950">{idx + 1}</td>
                                    <td className="p-2 border-l border-slate-300 font-black text-slate-950">{nom.name}</td>
                                    <td className="p-2 border-l border-slate-300 font-black text-slate-800">{nom.jobTitle}</td>
                                    <td className="p-2 border-l border-slate-300 text-slate-900 font-medium">{nom.subject}</td>
                                    <td className="p-2 border-l border-slate-300 text-center font-mono font-bold text-slate-900">{nom.nationalId}</td>
                                    <td className="p-2 border-l border-slate-300 text-center font-mono font-semibold text-slate-800">{nom.phone}</td>
                                    <td className="p-2 text-center text-slate-300 select-none">.................................</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </PrintableReport>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
