/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { StaffMember } from '../types';
import { Plus, Search, Trash2, Edit, Save, X, ArrowUpDown, FileDown, FileUp, Sparkles, ChevronUp, ChevronDown } from 'lucide-react';
import { dbInstance } from '../data/db';

function SortIndicator({ field, currentField, direction }: { field: string; currentField: string | null; direction: 'asc' | 'desc' }) {
  if (currentField !== field) {
    return <ArrowUpDown size={11} className="text-white/40 group-hover:text-white/80 transition-colors shrink-0 mr-1.5" />;
  }
  return direction === 'asc' 
    ? <ChevronUp size={11} className="text-amber-300 shrink-0 mr-1.5 font-bold" />
    : <ChevronDown size={11} className="text-amber-300 shrink-0 mr-1.5 font-bold" />;
}

interface StaffRegistryTableProps {
  schoolId: string;
  role: 'teacher' | 'specialist' | 'admin' | 'worker' | 'all';
  title: string;
}

export const ROLE_LABELS: Record<string, string> = {
  teacher: 'معلم',
  specialist: 'أخصائي',
  admin: 'إداري',
  activity_supervisor: 'مشرف نشاط',
  worker: 'عامل'
};

export default function StaffRegistryTable({ schoolId, role, title }: StaffRegistryTableProps) {
  const [staffList, setStaffList] = useState<StaffMember[]>(() => {
    return dbInstance.getStaff().filter(s => s.schoolId === schoolId && (role === 'all' || s.role === role));
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'original' | 'delegated'>('all');
  const [filterSpecialty, setFilterSpecialty] = useState<string>('all');
  const [filterRole, setFilterRole] = useState<'all' | 'teacher' | 'specialist' | 'admin' | 'activity_supervisor' | 'worker'>('all');
  const [sortField, setSortField] = useState<keyof StaffMember | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // unique specialties for filter dropdown list
  const uniqueSpecialties = useMemo(() => {
    const s = new Set<string>();
    staffList.forEach(item => {
      if (item.specialty && item.specialty.trim() !== '') {
        s.add(item.specialty.trim());
      }
    });
    return Array.from(s);
  }, [staffList]);

  // Edit / Add status
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isCategorySelected, setIsCategorySelected] = useState(false);

  // Sync state if schoolId or role changes
  React.useEffect(() => {
    reloadData();
  }, [schoolId, role]);

  // Specialties Lists and Options Selection
  const teacherMaterials = useMemo(() => {
    try {
      const materials = dbInstance.getMaterials();
      const names = Array.from(new Set(materials.map(m => m.name.trim())));
      if (names.length === 0) {
        return [
          'اللغة العربية',
          'اللغة الإنجليزية',
          'الرياضيات',
          'العلوم',
          'الدراسات الاجتماعية',
          'التربية الفنية',
          'التربية الموسيقية',
          'التربية الدينية',
          'الحاسب الآلي',
          'التربية الرياضية'
        ];
      }
      return names;
    } catch (e) {
      return [
        'اللغة العربية',
        'اللغة الإنجليزية',
        'الرياضيات',
        'العلوم',
        'الدراسات الاجتماعية',
        'التربية الفنية',
        'التربية الموسيقية',
        'التربية الدينية',
        'الحاسب الآلي',
        'التربية الرياضية'
      ];
    }
  }, []);

  const specialistSpecialties = useMemo(() => [
    'أخصائي اجتماعي',
    'أخصائي نفسي',
    'أخصائي صحافة وإعلام',
    'أخصائي مكتبات',
    'أخصائي تكنولوجيا / تطوير',
    'أخصائي مسرح',
    'أخصائي وسائط تعليمية'
  ], []);

  const adminSpecialties = useMemo(() => [
    'إداري',
    'مشرف نشاط',
    'مسؤول شؤون طلاب',
    'مسؤول شؤون عاملين',
    'أمين مخزن',
    'أمين معمل',
    'كاتب'
  ], []);

  const workerSpecialties = useMemo(() => [
    'خدمات معاونة',
    'عامل خدمات',
    'عامل حراسة / أمن',
    'سائق',
    'عامل صيانة'
  ], []);

  const [isOtherSelected, setIsOtherSelected] = useState(false);

  // Form Fields
  const [formData, setFormData] = useState<Partial<StaffMember>>({
    name: '',
    nationalId: '',
    phone: '',
    address: '',
    specialty: '',
    qualification: '',
    appointmentDate: '',
    type: 'original',
    birthDate: '',
    code: '',
    assignedJob: '',
    role: role === 'all' ? 'teacher' : role
  });

  const currentOptions = useMemo(() => {
    const activeRole = formData.role || (role === 'all' ? 'teacher' : role);
    if (activeRole === 'teacher') return teacherMaterials;
    if (activeRole === 'specialist') return specialistSpecialties;
    if (activeRole === 'admin') return adminSpecialties;
    if (activeRole === 'activity_supervisor') return ['مشرف نشاط', 'أخصائي نشاط رياضى', 'أخصائي نشاط فنى', 'أخصائي نشاط ثقافى', 'أخصائي نشاط اجتماعى'];
    return workerSpecialties;
  }, [formData.role, role, teacherMaterials, specialistSpecialties, adminSpecialties, workerSpecialties]);

  const isCustomSpecialty = useMemo(() => {
    if (isOtherSelected) return true;
    if (!formData.specialty) return false;
    return !currentOptions.includes(formData.specialty);
  }, [formData.specialty, currentOptions, isOtherSelected]);

  // Re-fetch data helper
  const reloadData = () => {
    const list = dbInstance.getStaff().filter(s => s.schoolId === schoolId && (role === 'all' || s.role === role));
    setStaffList(list);
  };

  // Sorting Handler
  const handleSort = (field: keyof StaffMember) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Filter & Search Logic
  const processedStaffList = useMemo(() => {
    let list = [...staffList];

    // Filter by type
    if (filterType !== 'all') {
      list = list.filter(item => item.type === filterType);
    }

    // Filter by role (if in 'all' mode)
    if (role === 'all' && filterRole !== 'all') {
      list = list.filter(item => item.role === filterRole);
    }

    // Filter by specialty dropdown
    if (filterSpecialty !== 'all') {
      list = list.filter(item => item.specialty === filterSpecialty);
    }

    // Search query
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        item =>
          item.name.toLowerCase().includes(q) ||
          item.specialty.toLowerCase().includes(q) ||
          item.nationalId.includes(q) ||
          item.code.includes(q)
      );
    }

    // Sorting
    if (sortField) {
      list.sort((a, b) => {
        const valA = String(a[sortField] || '').toLowerCase();
        const valB = String(b[sortField] || '').toLowerCase();
        
        if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
        if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return list;
  }, [staffList, filterType, filterSpecialty, filterRole, searchQuery, sortField, sortDirection]);

  // Handle Input Changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Delete Action
  const handleDelete = (id: string) => {
    dbInstance.deleteStaff(id);
    reloadData();
  };

  // Add Mode Trigger
  const startAdd = () => {
    const defaultSpecialty = role === 'admin' ? 'إداري' : role === 'teacher' ? (teacherMaterials[0] || 'اللغة العربية') : role === 'specialist' ? 'أخصائي اجتماعي' : 'خدمات معاونة';
    setFormData({
      name: '',
      nationalId: '',
      phone: '',
      address: '',
      specialty: defaultSpecialty,
      qualification: '',
      appointmentDate: '',
      type: 'original',
      birthDate: '',
      code: '',
      assignedJob: '',
      role: role === 'all' ? 'teacher' : role
    });
    setIsOtherSelected(false);
    setIsCategorySelected(false); // select category first
    setIsAdding(true);
    setEditingId(null);
  };

  // Edit Mode Trigger
  const startEdit = (item: StaffMember) => {
    setFormData(item);
    setEditingId(item.id);
    setIsAdding(false);
    setIsCategorySelected(true); // edit mode has role already
    const isCustom = item.specialty && !currentOptions.includes(item.specialty);
    setIsOtherSelected(!!isCustom);
  };

  // Cancel edit
  const cancelForm = () => {
    setIsAdding(false);
    setEditingId(null);
    setIsCategorySelected(false);
  };

  // Form Submit
  const handleSaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.nationalId) {
      alert('الرجاء إدخال اسم الموظف والرقم القومي بالكامل');
      return;
    }

    if (formData.nationalId.length !== 14) {
      alert('الرقم القومي يجب أن يتكون من 14 رقماً بالضبط');
      return;
    }

    const payload: StaffMember = {
      id: editingId || 'staff_' + Date.now(),
      schoolId,
      role: formData.role || role,
      name: formData.name,
      nationalId: formData.nationalId,
      phone: formData.phone || '',
      address: formData.address || '',
      specialty: formData.specialty || '',
      qualification: formData.qualification || '',
      appointmentDate: formData.appointmentDate || '',
      type: (formData.type as 'original' | 'delegated') || 'original',
      birthDate: formData.birthDate || '',
      code: formData.code || '',
      assignedJob: formData.assignedJob || ''
    };

    dbInstance.saveStaff(payload);
    cancelForm();
    reloadData();
  };

  // CSV Export
  const exportToCSV = () => {
    const headers = [
      'الاسم',
      'الرقم القومي',
      'التخصص/الوظيفة',
      'العمل المكلف به بالمدرسة',
      'الهاتف',
      'العنوان',
      'المؤهل',
      'تاريخ التعيين',
      'التبعية',
      'تاريخ الميلاد',
      'الكود'
    ];

    const rows = staffList.map(item => [
      item.name,
      item.nationalId,
      item.specialty,
      item.assignedJob || '---',
      item.phone,
      item.address,
      item.qualification,
      item.appointmentDate,
      item.type === 'original' ? 'أصلي' : 'منتدب',
      item.birthDate,
      item.code
    ]);

    const csvContent = 
      '\uFEFF' + // UTF-8 BOM for Excel Arabic layout
      [headers.join(','), ...rows.map(e => e.map(val => `"${val}"`).join(','))].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `سجل_${title}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Excel/CSV Simulated Import
  const handleCSVImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n');
      const importedRecords: StaffMember[] = [];

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // Simple parse logic
        const cells = line.split(',').map(c => c.replace(/^"/, '').replace(/"$/, '').trim());
        if (cells.length >= 2 && cells[0]) {
          importedRecords.push({
            id: 'staff_' + Date.now() + '_' + i,
            schoolId,
            role: role === 'all' ? 'teacher' : role,
            name: cells[0],
            nationalId: cells[1] || '---',
            specialty: cells[2] || 'عام',
            assignedJob: cells[3] || '---',
            phone: cells[4] || '',
            address: cells[5] || '',
            qualification: cells[6] || '',
            appointmentDate: cells[7] || '',
            type: cells[8] === 'منتدب' ? 'delegated' : 'original',
            birthDate: cells[9] || '',
            code: cells[10] || ''
          });
        }
      }

      if (importedRecords.length > 0) {
        importedRecords.forEach(rec => dbInstance.saveStaff(rec));
        alert(`تم استيراد عدد (${importedRecords.length}) من السجلات بنجاح إلى قاعدة البيانات السحابية.`);
        reloadData();
      } else {
        alert('الملف فارغ أو غير مطابق للتنسيق الصحيح للملف المصدر.');
      }
    };
    reader.readAsText(file, 'utf-8');
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-6">
      
      {/* Top action layout */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span className="w-2.5 h-6 rounded bg-blue-600 block"></span>
            {title}
          </h2>
          <p className="text-xs text-slate-500 mt-1">تحديث لحظي وسعة غير محدودة للتخزين السحابي</p>
        </div>

        <div className="flex flex-wrap items-center gap-2 print:hidden">
          <button 
            type="button"
            onClick={startAdd} 
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-l from-[#1565C0] to-[#1E88E5] hover:brightness-110 active:scale-95 text-white rounded-lg text-sm font-extrabold shadow-md transition-all cursor-pointer"
          >
            <Plus size={16} />
            إضافة جديد
          </button>
        </div>
      </div>

      {/* Filter & Search Dashboard bar */}
      <div className={`grid grid-cols-1 ${role === 'all' ? 'md:grid-cols-5' : 'md:grid-cols-4'} gap-3 print:hidden`}>
        {/* Search Field */}
        <div>
          <div className="relative">
            <span className="absolute right-3 top-2.5 text-slate-400">
              <Search size={18} />
            </span>
            <input
              type="text"
              placeholder="ابحث بالاسم، التخصص، الرقم القومي..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-4 pr-10 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 transition-colors text-slate-900 bg-white"
            />
          </div>
        </div>

        {/* Tab state select */}
        <div>
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value as any)}
            className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white text-black font-black focus:outline-none focus:border-blue-500 transition-colors text-right shadow-xs"
          >
            <option value="all">الكل (أصلي ومنتدب)</option>
            <option value="original">أصلي بالمدرسة</option>
            <option value="delegated">منتدب إلى المدرسة</option>
          </select>
        </div>

        {/* Filter by role (if in 'all' mode) */}
        {role === 'all' && (
          <div>
            <select
              value={filterRole}
              onChange={e => {
                setFilterRole(e.target.value as any);
                setFilterSpecialty('all'); // Reset specialty filter on role change
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white text-black font-black focus:outline-none focus:border-blue-500 transition-colors text-right shadow-xs"
            >
              <option value="all">كل الفئات (معلم/أخصائي/إداري/مشرف/عامل)</option>
              <option value="teacher">معلم</option>
              <option value="specialist">أخصائي</option>
              <option value="admin">إداري</option>
              <option value="activity_supervisor">مشرف نشاط</option>
              <option value="worker">عامل</option>
            </select>
          </div>
        )}

        {/* Specialty selection dropdown */}
        <div>
          <select
            value={filterSpecialty}
            onChange={e => setFilterSpecialty(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white text-black font-black focus:outline-none focus:border-blue-500 transition-colors text-right shadow-xs"
          >
            <option value="all">كل التخصصات / الوظائف</option>
            {uniqueSpecialties.map(spec => (
              <option key={spec} value={spec}>{spec}</option>
            ))}
          </select>
        </div>

        <div className="text-left text-xs text-slate-400 font-mono self-center">
          الإجمالي المتاح: {processedStaffList.length} موظفاً
        </div>
      </div>

      {/* Input or Edit Form overlay */}
      {(isAdding || editingId) && (
        <div className="bg-slate-50 border border-slate-150 rounded-lg p-5 space-y-4 animate-fade-in print:hidden">
          <h3 className="text-sm font-bold text-slate-800 pb-2 border-b border-slate-200">
            {editingId ? 'تعديل البيانات' : 'إضافة موظف جديد'}
          </h3>

          {!isCategorySelected ? (
            <div className="space-y-4 py-2 font-sans">
              {/* Canceled Excel Import Notice Banner */}
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-900 text-xs font-semibold leading-relaxed">
                📢 <strong>تنبيه إداري هام:</strong> تم إلغاء ميزة الاستيراد التلقائي من ملفات الإكسيل (Excel) بناءً على التعليمات التنظيمية، والاكتفاء حصرياً بنموذج الإضافة الفردي المباشر أدناه لضمان دقة رصد الكوادر والبيانات التعليمية بالمدرسة.
              </div>

              <label className="block text-xs font-black text-slate-800">
                يرجى اختيار الوظيفة أو التخصص أولاً للبدء في تسجيل استمارة التفاصيل الفردية:
              </label>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const defSpecialty = teacherMaterials[0] || 'اللغة العربية';
                    setFormData(prev => ({ ...prev, role: 'teacher', specialty: defSpecialty }));
                    setIsCategorySelected(true);
                  }}
                  className="p-4 border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 rounded-lg text-center font-bold text-sm text-slate-700 transition cursor-pointer flex flex-col items-center justify-center gap-2 bg-white"
                >
                  <span className="text-2xl">👨‍🏫</span>
                  <span>معلم</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFormData(prev => ({ ...prev, role: 'specialist', specialty: 'أخصائي اجتماعي' }));
                    setIsCategorySelected(true);
                  }}
                  className="p-4 border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 rounded-lg text-center font-bold text-sm text-slate-700 transition cursor-pointer flex flex-col items-center justify-center gap-2 bg-white"
                >
                  <span className="text-2xl">📑</span>
                  <span>أخصائي</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFormData(prev => ({ ...prev, role: 'admin', specialty: 'إداري' }));
                    setIsCategorySelected(true);
                  }}
                  className="p-4 border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 rounded-lg text-center font-bold text-sm text-slate-700 transition cursor-pointer flex flex-col items-center justify-center gap-2 bg-white"
                >
                  <span className="text-2xl">💼</span>
                  <span>إداري</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFormData(prev => ({ ...prev, role: 'admin', specialty: 'مشرف نشاط' }));
                    setIsCategorySelected(true);
                  }}
                  className="p-4 border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 rounded-lg text-center font-bold text-sm text-slate-700 transition cursor-pointer flex flex-col items-center justify-center gap-2 bg-white"
                >
                  <span className="text-2xl">🏆</span>
                  <span>مشرف نشاط</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFormData(prev => ({ ...prev, role: 'worker', specialty: 'خدمات معاونة' }));
                    setIsCategorySelected(true);
                  }}
                  className="p-4 border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 rounded-lg text-center font-bold text-sm text-slate-700 transition cursor-pointer flex flex-col items-center justify-center gap-2 bg-white"
                >
                  <span className="text-2xl">🔧</span>
                  <span>عامل</span>
                </button>
              </div>
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={cancelForm}
                  className="px-4 py-1.5 bg-slate-200 text-slate-700 rounded hover:bg-slate-300 text-xs font-medium transition cursor-pointer"
                >
                  إلغاء الأمر
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSaveSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">اسم المدرسة المنسوب إليها السجل</label>
                  <input
                    type="text"
                    readOnly
                    disabled
                    value={dbInstance.getSchools().find(s => s.id === schoolId)?.name || ''}
                    className="w-full px-3 py-1.5 text-sm border border-slate-300 rounded bg-slate-100 font-sans font-bold text-slate-600 text-right shadow-xs cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">اسم الموظف رباعياً *</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 bg-white text-black font-black shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">الرقم القومي (14 رقم) *</label>
                  <input
                    type="text"
                    name="nationalId"
                    maxLength={14}
                    value={formData.nationalId || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-mono bg-white text-black font-black shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">
                    {(formData.role || role) === 'teacher' ? 'التخصص الدراسي (المادة) *' : (formData.role || role) === 'specialist' ? 'التخصص الوظيفي *' : 'الوظيفة المحددة *'}
                  </label>
                  <select
                    name="specialty_select"
                    value={isOtherSelected ? '__other__' : (formData.specialty || '')}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '__other__') {
                        setIsOtherSelected(true);
                        setFormData(prev => ({ ...prev, specialty: '' }));
                      } else {
                        setIsOtherSelected(false);
                        setFormData(prev => ({ ...prev, specialty: val }));
                      }
                    }}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 bg-white text-black font-black shadow-xs cursor-pointer"
                  >
                    <option value="" disabled>-- اختر من القائمة المتاحة --</option>
                    {currentOptions.map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                    <option value="__other__">✨ أخرى / كتابة تخصص مخصص يدويًا</option>
                  </select>
                  {isOtherSelected && (
                    <div className="mt-2 animate-fadeIn">
                      <input
                        type="text"
                        name="specialty"
                        placeholder="اكتب التخصص مخصصًا هنا بالتفصيل..."
                        value={formData.specialty || ''}
                        onChange={handleInputChange}
                        className="w-full px-3 py-1.5 text-sm border border-amber-400 rounded text-right focus:outline-none focus:border-amber-600 focus:ring-1 focus:ring-amber-600 bg-white text-black font-black shadow-sm"
                      />
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">الكود المالي</label>
                  <input
                    type="text"
                    name="code"
                    value={formData.code || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-mono bg-white text-black font-black shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">رقم الهاتف</label>
                  <input
                    type="text"
                    name="phone"
                    value={formData.phone || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-mono bg-white text-black font-black shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">العنوان بالتفصيل</label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 bg-white text-black font-black shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">المؤهل الدراسي وتاريخه</label>
                  <input
                    type="text"
                    name="qualification"
                    placeholder="جامعة الزقازيق تربية ١٩٩٨"
                    value={formData.qualification || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 bg-white text-black font-black shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">تاريخ الميلاد</label>
                  <input
                    type="date"
                    name="birthDate"
                    value={formData.birthDate || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-mono bg-white text-black font-black shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">تاريخ التعيين</label>
                  <input
                    type="date"
                    name="appointmentDate"
                    value={formData.appointmentDate || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-mono bg-white text-black font-black shadow-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-800 mb-1">التبعية المدرسية</label>
                  <select
                    name="type"
                    value={formData.type || 'original'}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-slate-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 bg-white text-black font-black shadow-xs"
                  >
                    <option value="original">أصلي بالمدرسة</option>
                    <option value="delegated">منتدب للمدرسة</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-black text-[#0D47A1] mb-1">العمل المكلف به بالمدرسة *</label>
                  <input
                    type="text"
                    name="assignedJob"
                    placeholder="مثال: ريادة فصل، إشراف طابور، كنترول، إلخ"
                    value={formData.assignedJob || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-1.5 text-sm border border-blue-400 rounded text-right focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 bg-white text-black font-black shadow-xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-gradient-to-l from-green-700 to-emerald-600 hover:brightness-110 active:scale-95 text-white rounded text-xs font-black shadow-md transition-all cursor-pointer"
                >
                  حفظ وتأكيد
                </button>
                <button
                  type="button"
                  onClick={cancelForm}
                  className="px-4 py-1.5 bg-slate-200 text-slate-700 rounded hover:bg-slate-300 text-xs font-medium transition cursor-pointer"
                >
                  إلغاء الأمر
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Zebra styled responsive table layout */}
      <div className="overflow-x-auto border border-slate-300 rounded-xl shadow-xs transition-all duration-300">
        <table className="w-full text-right text-sm border-collapse border border-slate-300">
          <thead>
            <tr className="bg-black text-white font-bold text-xs uppercase tracking-wider border-b-2 border-slate-400">
              <th className="p-3 text-center border border-slate-600">#</th>
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('name')}>
                <div className="flex items-center gap-1 justify-start">
                  <span>الاسم رباعياً</span>
                  <SortIndicator field="name" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              {role === 'all' && (
                <th className="p-3 border border-slate-600 text-center">الفئة</th>
              )}
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('nationalId')}>
                <div className="flex items-center gap-1 justify-start">
                  <span>الرقم القومي</span>
                  <SortIndicator field="nationalId" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('specialty')}>
                <div className="flex items-center gap-1 justify-start">
                  <span>التخصص/الوظيفة</span>
                  <SortIndicator field="specialty" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('assignedJob')}>
                <div className="flex items-center gap-1 justify-start">
                  <span>العمل المكلف به بالمدرسة</span>
                  <SortIndicator field="assignedJob" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('phone')}>
                <div className="flex items-center gap-1 justify-start">
                  <span>الهاتف</span>
                  <SortIndicator field="phone" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('address')}>
                <div className="flex items-center gap-1 justify-start">
                  <span>العنوان</span>
                  <SortIndicator field="address" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('type')}>
                <div className="flex items-center gap-1 justify-center">
                  <span>التبعية</span>
                  <SortIndicator field="type" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('appointmentDate')}>
                <div className="flex items-center gap-1 justify-center">
                  <span>تاريخ التعيين</span>
                  <SortIndicator field="appointmentDate" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              <th className="p-3 border border-slate-600 cursor-pointer select-none hover:bg-slate-800 transition-colors group" onClick={() => handleSort('code')}>
                <div className="flex items-center gap-1 justify-center">
                  <span>الكود</span>
                  <SortIndicator field="code" currentField={sortField} direction={sortDirection} />
                </div>
              </th>
              <th className="p-3 text-center border border-slate-600 print:hidden">الخيارات</th>
            </tr>
          </thead>
          <tbody>
            {processedStaffList.length === 0 ? (
              <tr>
                <td colSpan={role === 'all' ? 12 : 11} className="text-center p-8 text-slate-400 bg-slate-50">
                  لا توجد سجلات مضافة مطابقة للبحث أو الفلترة حالياً
                </td>
              </tr>
            ) : (
              processedStaffList.map((item, index) => (
                <tr 
                  key={item.id} 
                  className="even:bg-slate-100 hover:bg-slate-200/60 transition-all duration-300 ease-out border-b border-slate-300 text-slate-800 [&_td]:p-3 hover:translate-x-[-2px]"
                >
                  <td className="text-center font-mono font-medium text-slate-400 border border-slate-300">{index + 1}</td>
                  <td className="font-semibold text-slate-900 border border-slate-300">{item.name}</td>
                  {role === 'all' && (
                    <td className="text-center border border-slate-300 font-bold text-xs text-slate-800">
                      <span className="bg-slate-100 border border-slate-300 px-2 py-0.5 rounded">
                        {ROLE_LABELS[item.role] || item.role}
                      </span>
                    </td>
                  )}
                  <td className="font-mono text-xs text-slate-600 border border-slate-300">{item.nationalId}</td>
                  <td className="font-medium text-blue-800 border border-slate-300">
                    <span className="bg-blue-50 px-2 py-0.5 rounded text-xs border border-blue-100">
                      {item.specialty || 'عام'}
                    </span>
                  </td>
                  <td className="font-semibold text-indigo-700 border border-slate-300">
                    <span className="bg-indigo-50 px-2.5 py-0.5 rounded text-xs border border-indigo-100">
                      {item.assignedJob || '---'}
                    </span>
                  </td>
                  <td className="font-mono text-xs border border-slate-300">{item.phone || '---'}</td>
                  <td className="text-xs text-slate-500 border border-slate-300 truncate max-w-[120px]" title={item.address}>{item.address || '---'}</td>
                  <td className="text-center border border-slate-300">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${item.type === 'original' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-amber-50 text-amber-700 border border-amber-100'}`}>
                      {item.type === 'original' ? 'أصلي' : 'منتدب'}
                    </span>
                  </td>
                  <td className="font-mono text-center text-xs text-slate-500 border border-slate-300">{item.appointmentDate || '---'}</td>
                  <td className="font-mono text-center text-xs text-slate-600 font-bold border border-slate-300">{item.code || '---'}</td>
                  <td className="text-center border border-slate-300 print:hidden space-x-1 space-x-reverse">
                    <button 
                      type="button"
                      onClick={() => startEdit(item)}
                      className="p-1 px-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded transition inline-flex items-center gap-0.5 text-xs cursor-pointer"
                      title="تعديل السجل"
                    >
                      <Edit size={12} />
                      تعديل
                    </button>
                    {confirmDeleteId === item.id ? (
                      <div className="inline-flex items-center gap-1 bg-rose-50 border border-rose-200 rounded p-0.5 animate-pulse">
                        <button
                          type="button"
                          onClick={() => {
                            handleDelete(item.id);
                            setConfirmDeleteId(null);
                          }}
                          className="px-1.5 py-0.5 bg-rose-600 text-white font-extrabold rounded text-[9px] cursor-pointer"
                        >
                          تأكيد
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(null)}
                          className="px-1.5 py-0.5 border border-slate-300 text-slate-600 font-extrabold rounded text-[9px] cursor-pointer bg-white"
                        >
                          إلغاء
                        </button>
                      </div>
                    ) : (
                      <button 
                        type="button"
                        onClick={() => setConfirmDeleteId(item.id)}
                        className="p-1 px-1.5 text-red-600 hover:text-red-800 hover:bg-red-50 rounded transition inline-flex items-center gap-0.5 text-xs cursor-pointer"
                        title="حذف السجل"
                      >
                        <Trash2 size={12} />
                        حذف
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
}
