/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { dbInstance } from '../data/db';
import { SystemSettings } from '../types';

interface FooterProps {
  showCredits?: boolean;
}

export default function Footer({ showCredits = true }: FooterProps) {
  const [settings, setSettings] = useState<SystemSettings>(dbInstance.getSettings());

  useEffect(() => {
    return dbInstance.subscribe(() => {
      setSettings(dbInstance.getSettings());
    });
  }, []);

  const adminName = settings.administrationName || 'إدارة أبو حماد التعليمية';
  const depName = settings.departmentName || 'قسم التنسيق العام';
  const undersecretaries = settings.undersecretariesNames || 'الأستاذ علاء المرجل / الأستاذ عبد المنعم شعلان';

  return (
    <footer className="w-full mt-12 mb-8 border-t border-slate-200 pt-8 px-4 select-none print:hidden">
      <div className="max-w-7xl mx-auto text-center space-y-5">
        
        {/* Designer & Programmers section - Put each on separate lines with customized colors and small font */}
        {showCredits && (
          <div className="flex flex-col items-center justify-center gap-2 py-4 bg-slate-50 border border-slate-200/80 rounded-2xl max-w-3xl mx-auto shadow-xs px-6">
            
            {/* Row 1: Programmer & Developer Specialist */}
            <div className="text-slate-800 font-extrabold text-[10px] md:text-xs tracking-wide leading-relaxed">
              <span className="text-[#0D47A1] bg-blue-50 border border-blue-150 px-2 py-0.5 rounded-lg font-black mr-1">
                💻 مبرمج المنصة والمطور تصميم:
              </span>
              <span className="text-blue-900 font-black text-xs md:text-sm mr-1.5">
                الأستاذ محمد نجم
              </span>
              <span className="text-slate-400 font-bold mr-1.5">– مدير التنسيق العام ( الإعدادي والثانوي )</span>
            </div>
            
            {/* Row 2: Primary Coordination */}
            <div className="text-slate-800 font-extrabold text-[10px] md:text-xs tracking-wide leading-relaxed">
              <span className="text-emerald-950 font-black text-xs md:text-sm mr-1.5">
                الأستاذ عصمت عميرة
              </span>
              <span className="text-slate-400 font-bold mr-1.5">– مدير التنسيق الابتدائي</span>
            </div>

            {/* Row 3: Services & Activities Coordination */}
            <div className="text-slate-800 font-extrabold text-[10px] md:text-xs tracking-wide leading-relaxed">
              <span className="text-purple-950 font-black text-xs md:text-sm mr-1.5">
                الدكتور وحيد درويش
              </span>
              <span className="text-slate-400 font-bold mr-1.5">– مدير تنسيق الخدمات والأنشطة</span>
            </div>

            {/* Row 4: Workers & Administrators Coordination */}
            <div className="text-slate-800 font-extrabold text-[10px] md:text-xs tracking-wide leading-relaxed">
              <span className="text-amber-950 font-black text-xs md:text-sm mr-1.5">
                الأستاذ عبداللطيف بكيرة
              </span>
              <span className="text-slate-400 font-bold mr-1.5">– مدير تنسيق العمال والإداريين</span>
            </div>

          </div>
        )}
        
        {/* Dynamic educational leaders */}
        {showCredits && (
          <div className="flex flex-wrap justify-center items-center text-xs md:text-sm text-slate-600 gap-y-2 gap-x-6">
            <span className="flex items-center bg-white shadow-xs border border-slate-100 rounded-lg px-3 py-1 text-slate-800 font-extrabold">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 ml-2 animate-pulse"></span>
              الأستاذ محمد منصور العباسي – مدير عام الإدارة
            </span>
            <span className="flex items-center bg-white shadow-xs border border-slate-100 rounded-lg px-3 py-1 text-slate-800 font-extrabold">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ml-2"></span>
              وكلاء الإدارة المعتمدون: {undersecretaries}
            </span>
          </div>
        )}

        {/* Beautiful, colored, pulsing launch banner for undersecretary of the ministry as requested */}
        <div className="block mt-4">
          <div className="animate-soft-pulse bg-gradient-to-r from-[#0D47A1] via-[#1976D2] to-[#0D47A1] border-2 border-[#D4AF37] rounded-2xl p-5 md:p-6 inline-block max-w-3xl mx-auto shadow-xl text-center">
            <p className="text-sm md:text-base font-black text-white leading-relaxed">
              ✨ <span className="text-yellow-300 font-black text-base md:text-lg">تم التدشين</span> في عهد السيد <span className="text-yellow-200 font-black text-base md:text-lg underline underline-offset-4 decoration-yellow-400">الأستاذ محمد رمضان</span> – <span className="text-emerald-300 font-black text-base md:text-lg">وكيل أول وزارة التربية والتعليم بالشرقية</span> سنة ٢٠٢٦ ✨
            </p>
            <p className="text-slate-100 text-[11px] mt-2.5 font-bold leading-snug">
              {showCredits ? (
                <>المطور والمبرمج التقني المسؤول: الأستاذ محمد نجم (٠١٠١٥١٧٤٠٨٤) | </>
              ) : null}جميع الحقوق محفوظة لوزارة التربية والتعليم © ٢٠٢٦
            </p>
          </div>
        </div>

      </div>
    </footer>
  );
}
