import React, { useState, useEffect, useRef } from 'react';
import { School, ExamNomination, ExamObstacle, ExamExcuse, NominationDocument, AuditLog } from '../types';
import { dbInstance } from '../data/db';
import { uploadNominationFile } from '../lib/storageUtils';
import { 
  FileText, Plus, Trash2, Edit2, Check, Send, 
  Printer, ArrowRight, UploadCloud, AlertTriangle, 
  CheckCircle2, RefreshCw, X, Eye, Download, Info,
  Search, ShieldAlert, FileIcon, FileCheck, CheckCircle
} from 'lucide-react';

interface ExamNominationTabProps {
  school: School;
  dbTick: number;
}

export default function ExamNominationTab({ school, dbTick }: ExamNominationTabProps) {
  const [nominations, setNominations] = useState<ExamNomination[]>([]);
  const [obstacles, setObstacles] = useState<ExamObstacle[]>([]);
  const [excuses, setExcuses] = useState<ExamExcuse[]>([]);
  const [view, setView] = useState<'list' | 'form' | 'print'>('list');
  const [selectedNomination, setSelectedNomination] = useState<ExamNomination | null>(null);

  // Custom dialog and notification state
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  const [toast, setToast] = useState<{
    message: string;
    type: 'success' | 'error' | 'info';
  } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Form Fields
  const [formName, setFormName] = useState('');
  const [formJobTitle, setFormJobTitle] = useState('');
  const [formSubject, setFormSubject] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formAppointmentDate, setFormAppointmentDate] = useState('');
  const [formNationalId, setFormNationalId] = useState('');
  const [formBirthDate, setFormBirthDate] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formObstacleId, setFormObstacleId] = useState('none');
  const [formObstacleText, setFormObstacleText] = useState('');
  const [formDocuments, setFormDocuments] = useState<NominationDocument[]>([]);

  // Search and Filter State for School View
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // File states
  const [fileUploading, setFileUploading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'failed'>('idle');
  const [previewDoc, setPreviewDoc] = useState<NominationDocument | null>(null);

  // Load and subscribe
  const loadData = () => {
    const allNoms = dbInstance.getExamNominations().filter(n => n.schoolId === school.id);
    const allObstacles = dbInstance.getExamObstacles();
    const allExcuses = dbInstance.getExamExcuses().filter(e => e.schoolId === school.id);
    
    setNominations(allNoms);
    setObstacles(allObstacles);
    setExcuses(allExcuses);
  };

  useEffect(() => {
    loadData();
    const unsubscribe = dbInstance.subscribe(() => {
      loadData();
    });
    return unsubscribe;
  }, [school.id, dbTick]);

  // Parse National ID to Birthdate automatically
  useEffect(() => {
    if (formNationalId.length === 14 && /^[0-9]+$/.test(formNationalId)) {
      try {
        const centuryDigit = parseInt(formNationalId[0]);
        const yearDigits = formNationalId.substring(1, 3);
        const monthDigits = formNationalId.substring(3, 5);
        const dayDigits = formNationalId.substring(5, 7);
        
        let prefix = '19';
        if (centuryDigit === 3) prefix = '20';
        else if (centuryDigit === 4) prefix = '21';
        
        const birthDateStr = `${prefix}${yearDigits}-${monthDigits}-${dayDigits}`;
        if (!formBirthDate) {
          setFormBirthDate(birthDateStr);
        }
      } catch (err) {
        console.warn('Could not auto-parse birthdate from National ID', err);
      }
    }
  }, [formNationalId]);

  // Debounced auto-save
  const autoSaveTimeout = useRef<NodeJS.Timeout | null>(null);

  const triggerAutoSave = (updatedFields: Partial<ExamNomination>) => {
    if (!selectedNomination) return;

    setAutoSaveStatus('saving');
    if (autoSaveTimeout.current) {
      clearTimeout(autoSaveTimeout.current);
    }

    autoSaveTimeout.current = setTimeout(() => {
      const draftRecord: ExamNomination = {
        ...selectedNomination,
        ...updatedFields,
        schoolName: school.name,
        updatedAt: new Date().toISOString()
      };

      // Perform Smart Check inside auto save
      const checkResult = runSmartCheck(draftRecord);
      draftRecord.qualificationStatus = checkResult.status;
      draftRecord.qualificationReason = checkResult.reason;

      try {
        dbInstance.saveExamNomination(draftRecord);
        setAutoSaveStatus('saved');
        setTimeout(() => setAutoSaveStatus('idle'), 2000);
      } catch (err) {
        console.error('AutoSave failed:', err);
        setAutoSaveStatus('failed');
      }
    }, 1000);
  };

  // Run Smart Check (الفحص الذكي)
  const runSmartCheck = (nom: Partial<ExamNomination>): { status: 'eligible' | 'needs_review' | 'disqualified', reason: string } => {
    const name = nom.name?.trim() || '';
    const nationalId = nom.nationalId?.trim() || '';
    const jobTitle = nom.jobTitle?.trim() || '';
    const subject = nom.subject?.trim() || '';
    const phone = nom.phone?.trim() || '';
    const address = nom.address?.trim() || '';
    const obstacleId = nom.obstacleId || 'none';
    const documents = nom.documents || [];

    // Check completeness
    const missingFields: string[] = [];
    if (!name) missingFields.push('الاسم (رباعي)');
    if (nationalId.length !== 14) missingFields.push('الرقم القومي (14 رقم)');
    if (!jobTitle) missingFields.push('الوظيفة');
    if (!subject) missingFields.push('التخصص والمادة');
    if (phone.length !== 11) missingFields.push('الهاتف (11 رقم)');
    if (!address) missingFields.push('العنوان المكتوب');

    if (missingFields.length > 0) {
      return { 
        status: 'disqualified', 
        reason: `البيانات غير مكتملة، نقص في: ${missingFields.join('، ')}` 
      };
    }

    // Check for duplicates in local store
    const localDups = nominations.filter(n => n.nationalId === nationalId && n.id !== nom.id);
    if (localDups.length > 0) {
      return { 
        status: 'disqualified', 
        reason: 'تم تكرار الرقم القومي المسجل لهذا المعلم في الاستمارات الحالية مسبقاً' 
      };
    }

    // Check for impediment requiring document
    const selectedObstacle = obstacles.find(o => o.id === obstacleId);
    if (selectedObstacle && selectedObstacle.id !== 'none') {
      if (selectedObstacle.requiresDocument && documents.length === 0) {
        return {
          status: 'needs_review',
          reason: `مسجل مانع اشتراك: (${selectedObstacle.name}) بدون إرفاق مستندات المرفق الداعمة المطلوبة`
        };
      }
      return {
        status: 'needs_review',
        reason: `مستبعد بمانع اشتراك رسمي: ${selectedObstacle.name}. بانتظار البت في العذر من الإدارة`
      };
    }

    return { status: 'eligible', reason: 'مكتمل والبيانات صحيحة ومؤهل لأعمال الامتحانات' };
  };

  const handleOpenForm = (nom: ExamNomination | null) => {
    if (nom) {
      setSelectedNomination(nom);
      setFormName(nom.name);
      setFormJobTitle(nom.jobTitle);
      setFormSubject(nom.subject);
      setFormAddress(nom.address);
      setFormAppointmentDate(nom.appointmentDate || '');
      setFormNationalId(nom.nationalId);
      setFormBirthDate(nom.birthDate || '');
      setFormPhone(nom.phone);
      setFormCode(nom.code || '');
      setFormObstacleId(nom.obstacleId);
      setFormObstacleText(nom.obstacleText || '');
      setFormDocuments(nom.documents || []);
    } else {
      const newDummy: ExamNomination = {
        id: `nom_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        schoolId: school.id,
        schoolName: school.name,
        year: new Date().getFullYear().toString(),
        name: '',
        nationalId: '',
        code: '',
        jobTitle: '',
        subject: '',
        appointmentDate: '',
        phone: '',
        address: '',
        obstacleId: 'none',
        obstacleText: '',
        documents: [],
        status: 'draft',
        qualificationStatus: 'disqualified',
        qualificationReason: 'استمارة جديدة فارغة قيد التحرير',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      setSelectedNomination(newDummy);
      setFormName('');
      setFormJobTitle('');
      setFormSubject('');
      setFormAddress('');
      setFormAppointmentDate('');
      setFormNationalId('');
      setFormBirthDate('');
      setFormPhone('');
      setFormCode('');
      setFormObstacleId('none');
      setFormObstacleText('');
      setFormDocuments([]);
    }
    setView('form');
    setErrorMsg('');
  };

  const handleFormInputChange = (fieldName: string, value: any) => {
    if (!selectedNomination) return;

    switch (fieldName) {
      case 'name': setFormName(value); break;
      case 'jobTitle': setFormJobTitle(value); break;
      case 'subject': setFormSubject(value); break;
      case 'address': setFormAddress(value); break;
      case 'appointmentDate': setFormAppointmentDate(value); break;
      case 'nationalId': setFormNationalId(value); break;
      case 'birthDate': setFormBirthDate(value); break;
      case 'phone': setFormPhone(value); break;
      case 'code': setFormCode(value); break;
      case 'obstacleId': setFormObstacleId(value); break;
      case 'obstacleText': setFormObstacleText(value); break;
    }

    // Capture immediately
    const updated = {
      ...selectedNomination,
      name: fieldName === 'name' ? value : formName,
      jobTitle: fieldName === 'jobTitle' ? value : formJobTitle,
      subject: fieldName === 'subject' ? value : formSubject,
      address: fieldName === 'address' ? value : formAddress,
      appointmentDate: fieldName === 'appointmentDate' ? value : formAppointmentDate,
      nationalId: fieldName === 'nationalId' ? value : formNationalId,
      birthDate: fieldName === 'birthDate' ? value : formBirthDate,
      phone: fieldName === 'phone' ? value : formPhone,
      code: fieldName === 'code' ? value : formCode,
      obstacleId: fieldName === 'obstacleId' ? value : formObstacleId,
      obstacleText: fieldName === 'obstacleText' ? value : formObstacleText,
      documents: formDocuments
    };

    setSelectedNomination(updated);
    triggerAutoSave(updated);
  };

  // Upload handlers
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setFileUploading(true);
    setErrorMsg('');
    try {
      const uploadedDocs: NominationDocument[] = [];
      const fileList = Array.from(files) as File[];
      
      for (const file of fileList) {
        const uploadResult = await uploadNominationFile(file, school.id, formName || 'attachment');
        const newDoc: NominationDocument = {
          id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          name: file.name,
          type: file.type.includes('pdf') ? 'pdf' : 'image',
          dataUrl: uploadResult.url
        };
        uploadedDocs.push(newDoc);
      }

      const updatedDocs = [...formDocuments, ...uploadedDocs];
      setFormDocuments(updatedDocs);
      
      if (selectedNomination) {
        const updatedNom = { ...selectedNomination, documents: updatedDocs };
        setSelectedNomination(updatedNom);
        triggerAutoSave(updatedNom);
      }
    } catch (err) {
      console.error(err);
      setErrorMsg('فشل في رفع الملف، يرجى المحاولة مرة أخرى.');
    } finally {
      setFileUploading(false);
    }
  };

  // Remove uploaded document
  const handleDeleteDoc = (docId: string) => {
    const updatedDocs = formDocuments.filter(d => d.id !== docId);
    setFormDocuments(updatedDocs);
    if (selectedNomination) {
      const updatedNom = { ...selectedNomination, documents: updatedDocs };
      setSelectedNomination(updatedNom);
      triggerAutoSave(updatedNom);
    }
  };

  // Replace file
  const handleReplaceFile = async (docId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setFileUploading(true);
    setErrorMsg('');
    try {
      const file = files[0];
      const uploadResult = await uploadNominationFile(file, school.id, formName || 'replaced');
      
      const updatedDocs = formDocuments.map(d => {
        if (d.id === docId) {
          return {
            ...d,
            name: file.name,
            type: file.type.includes('pdf') ? 'pdf' : 'image',
            dataUrl: uploadResult.url
          };
        }
        return d;
      });

      setFormDocuments(updatedDocs);
      if (selectedNomination) {
        const updatedNom = { ...selectedNomination, documents: updatedDocs };
        setSelectedNomination(updatedNom);
        triggerAutoSave(updatedNom);
      }
    } catch (err) {
      console.error(err);
      setErrorMsg('فشل استبدال المستند. يرجى المحاولة لاحقاً');
    } finally {
      setFileUploading(false);
    }
  };

  // Final manual Save button
  const handleFinalSave = () => {
    if (!selectedNomination) return;

    if (!formName.trim()) {
      setErrorMsg('الاسم رباعي مطلوب إدخاله لحفظ الاستمارة');
      return;
    }

    if (formNationalId.length !== 14 || !/^\d+$/.test(formNationalId)) {
      setErrorMsg('الرقم القومي يتألف من 14 رقماً مصرياً صحيحاً');
      return;
    }

    if (formPhone.length !== 11 || !/^\d+$/.test(formPhone)) {
      setErrorMsg('رقم الهاتف يتألف من 11 رقماً مصرياً صحيحاً');
      return;
    }

    const record: ExamNomination = {
      ...selectedNomination,
      name: formName,
      jobTitle: formJobTitle,
      subject: formSubject,
      address: formAddress,
      appointmentDate: formAppointmentDate,
      nationalId: formNationalId,
      birthDate: formBirthDate,
      phone: formPhone,
      code: formCode,
      obstacleId: formObstacleId,
      obstacleText: formObstacleText,
      documents: formDocuments,
      updatedAt: new Date().toISOString()
    };

    // Calculate intelligent qualification status
    const smartCheckResult = runSmartCheck(record);
    record.qualificationStatus = smartCheckResult.status;
    record.qualificationReason = smartCheckResult.reason;

    dbInstance.saveExamNomination(record);

    // Audit Log
    dbInstance.saveAuditLog({
      id: `audit_${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: `مدير مدرسة ${school.name}`,
      action: 'حفظ مسودة استمارة 1 سري',
      details: `تم تعديل/حفظ الاستمارة الخاصة بالمرشح: ${formName}`,
      schoolId: school.id
    });

    setView('list');
  };

  // Submit all drafted forms to admin
  const handleSubmitAllToAdmin = () => {
    const drafts = nominations.filter(n => n.status === 'draft');
    if (drafts.length === 0) {
      showToast('لا توجد استمارات جديدة في وضع المسودة لإرسالها.', 'info');
      return;
    }

    setConfirmDialog({
      isOpen: true,
      title: 'تأكيد إرسال الكشوفات للإدارة',
      message: `هل أنت متأكد من تسليم وإرسال عدد (${drafts.length}) استمارات لأعمال الامتحانات إلى قسم التنسيق العام بالإدارة؟`,
      onConfirm: () => {
        drafts.forEach(nom => {
          const updated: ExamNomination = {
            ...nom,
            status: 'submitted',
            updatedAt: new Date().toISOString()
          };
          dbInstance.saveExamNomination(updated);
        });

        dbInstance.saveAuditLog({
          id: `audit_${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: `مدير مدرسة ${school.name}`,
          action: 'إرسال الاستمارات وتأكيدها للإدارة',
          details: `تم تأكيد وتسليم عدد (${drafts.length}) للجنة التنسيق بالإدارة بنجاح`,
          schoolId: school.id
        });

        setConfirmDialog(null);
        showToast('تم تسليم وإرسال الكشوف والاستمارات بنجاح بشكل رسمي إلى لجنة التنسيق بالإدارة.', 'success');
      }
    });
  };

  const handleDeleteNomination = (id: string, name: string) => {
    setConfirmDialog({
      isOpen: true,
      title: 'تأكيد الحذف نهائياً',
      message: `هل تريد حذف استمارة المرشح: ${name} نهائياً وحذف ملفاته المرتبطة بها؟`,
      onConfirm: () => {
        dbInstance.deleteExamNomination(id);

        dbInstance.saveAuditLog({
          id: `audit_${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: `مدير مدرسة ${school.name}`,
          action: 'حذف استمارة مرشح',
          details: `تم إزالة سجل الترشيح بالكامل للمرشح: ${name}`,
          schoolId: school.id
        });

        setConfirmDialog(null);
        showToast(`تم حذف استمارة المرشح: ${name} بنجاح.`, 'success');
      }
    });
  };

  // Direct print layouts
  const handlePrintNomination = (nom: ExamNomination) => {
    setSelectedNomination(nom);
    setView('print');
    setTimeout(() => {
      window.print();
    }, 500);
  };

  // Filtering Logic
  const filteredNominations = nominations.filter(nom => {
    const matchesSearch = 
      nom.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      nom.nationalId.includes(searchTerm) ||
      (nom.code && nom.code.includes(searchTerm)) ||
      nom.jobTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      nom.subject.toLowerCase().includes(searchTerm.toLowerCase());

    if (filterStatus === 'all') return matchesSearch;
    if (filterStatus === 'draft') return matchesSearch && nom.status === 'draft';
    if (filterStatus === 'submitted') return matchesSearch && (nom.status === 'submitted' || nom.status === 'pending');
    if (filterStatus === 'approved') return matchesSearch && nom.status === 'approved';
    if (filterStatus === 'rejected') return matchesSearch && nom.status === 'rejected';
    
    // Check specific obstacle status
    if (filterStatus === 'obstacle') return matchesSearch && nom.obstacleId !== 'none';
    if (filterStatus === 'incomplete') return matchesSearch && nom.qualificationStatus === 'disqualified';

    return matchesSearch;
  });

  return (
    <div className="space-y-6 text-slate-800" dir="rtl">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-red-800 via-rose-700 to-red-900 text-white rounded-2xl shadow-md p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-10 -mt-10 blur-xl"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-1.5">
            <h2 className="text-xl font-black font-sans flex items-center gap-2">
              <FileCheck size={24} className="text-rose-100" />
              النظام الإلكتروني لاستمارة (1 سري) للترشيح لأعمال الامتحانات العامة
            </h2>
            <p className="text-xs text-rose-100/90 leading-relaxed font-semibold">
              مدرسة: <span className="font-bold underline text-white">{school.name}</span> | فرز الترشيحات المباشرة، التماس العقبات، رفع المستندات الداعمة وسجلات موانع الاشتراك التبادلية مع لجنة التنسيق.
            </p>
          </div>
          {view === 'list' && (
            <div className="flex gap-2.5">
              <button
                onClick={() => handleOpenForm(null)}
                className="bg-white text-rose-800 px-4 py-2 text-xs font-black rounded-xl hover:bg-slate-50 transition shadow active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                <Plus size={16} />
                إضافة مرشح جديد
              </button>
              <button
                onClick={handleSubmitAllToAdmin}
                className="bg-emerald-600 border border-emerald-500 hover:bg-emerald-700 text-white px-4 py-2 text-xs font-black rounded-xl transition shadow active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                <Send size={15} />
                إرسال الكشوفات للإدارة
              </button>
            </div>
          )}
        </div>
      </div>

      {/* View 1: List View */}
      {view === 'list' && (
        <div className="space-y-4">
          {/* Filters & Information Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-white p-4 rounded-xl border border-rose-100 shadow-xs">
            {/* Search Input */}
            <div className="relative md:col-span-2">
              <span className="absolute inset-y-0 right-3 flex items-center text-slate-400">
                <Search size={15} />
              </span>
              <input
                type="text"
                placeholder="ابحث بالاسم، الرقم القومي، الكود، الوظيفة أو التخصص..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-9 pl-3 py-2 border border-slate-205 rounded-xl text-xs text-slate-700 bg-slate-50/50 focus:outline-none focus:border-rose-450 focus:bg-white font-semibold"
              />
            </div>

            {/* Filter Dropdown */}
            <div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full px-3 py-2 border border-slate-205 rounded-xl text-xs text-slate-700 bg-slate-50 focus:outline-none focus:border-rose-450 font-semibold cursor-pointer"
              >
                <option value="all">كل الاستمارات المسجلة</option>
                <option value="draft">📁 مسودة (تعديل وحفظ تلقائي)</option>
                <option value="submitted">⏳ قيد المراجعة والاعتماد</option>
                <option value="approved">✅ المقبولين للترشيح</option>
                <option value="rejected">❌ المرفوضين من الإدارة</option>
                <option value="obstacle">⚠️ أصحاب الموانع والمكفوفين</option>
                <option value="incomplete">🔴 بيانات ناقصة / غير صالحة</option>
              </select>
            </div>

            {/* Live Stats summary block */}
            <div className="flex items-center justify-around text-center border-r border-slate-100 pr-2">
              <div className="px-2">
                <p className="text-[10px] text-slate-400 font-bold">الإجمالي</p>
                <p className="text-sm font-black text-slate-800">{nominations.length}</p>
              </div>
              <div className="px-2 border-r border-slate-100">
                <p className="text-[10px] text-slate-400 font-bold">صالح 🟢</p>
                <p className="text-sm font-black text-emerald-600">
                  {nominations.filter(n => n.qualificationStatus === 'eligible').length}
                </p>
              </div>
              <div className="px-2 border-r border-slate-100">
                <p className="text-[10px] text-slate-400 font-bold">قيد الدراسة</p>
                <p className="text-sm font-black text-amber-500">
                  {nominations.filter(n => n.status === 'submitted' || n.status === 'pending').length}
                </p>
              </div>
            </div>
          </div>

          {/* List Table Container */}
          <div className="bg-white rounded-2xl border border-slate-201 shadow-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-right text-xs">
                <thead>
                  <tr className="bg-gradient-to-b from-slate-100 to-slate-200 border-b border-slate-200 font-black text-slate-700">
                    <th className="p-3">اسم المعلم المرشح</th>
                    <th className="p-3">الوظيفة الحالية</th>
                    <th className="p-3">التخصص المالي</th>
                    <th className="p-3 text-center">الرقم القومي</th>
                    <th className="p-3 text-center">الكود / الموانع</th>
                    <th className="p-3 text-center">الفحص الذكي</th>
                    <th className="p-3 text-center">المستندات</th>
                    <th className="p-3 text-center">الحالة النهائية بالإدارة</th>
                    <th className="p-3 text-center">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredNominations.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-10 text-center text-slate-450 font-bold">
                        {searchTerm || filterStatus !== 'all' ? (
                          <div className="space-y-1.5">
                            <ShieldAlert className="mx-auto text-amber-500" size={32} />
                            <p>لا توجد نتائج تطابق خيارات التصفية والبحث الحالية.</p>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <FileText className="mx-auto text-slate-350" size={36} />
                            <p>لم يتم تسجيل أي مرشحين لاستمارة 1 سري لهذه المدرسة حتى الآن.</p>
                            <button
                              onClick={() => handleOpenForm(null)}
                              className="mt-2 bg-rose-600 hover:bg-rose-700 text-white px-4 py-1.5 text-xs font-black rounded-lg cursor-pointer"
                            >
                              سجل أول استمارة للمدرسة الآن
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ) : (
                    filteredNominations.map((nom) => (
                      <tr key={nom.id} className="hover:bg-slate-50/50 transition">
                        <td className="p-3">
                          <div className="font-extrabold text-slate-900 text-sm">{nom.name}</div>
                          <div className="text-[10px] text-slate-400 font-medium mt-0.5">{nom.phone} | {nom.address}</div>
                        </td>
                        <td className="p-3 font-semibold text-slate-700">{nom.jobTitle}</td>
                        <td className="p-3 font-semibold text-slate-700">{nom.subject}</td>
                        <td className="p-3 font-mono text-center text-sm font-bold text-slate-600">{nom.nationalId}</td>
                        <td className="p-3 text-center">
                          <div className="font-mono text-[10px] text-slate-500 font-bold mb-0.5">الكود: {nom.code || 'لا يوجد'}</div>
                          {nom.obstacleId !== 'none' ? (
                            <span className="inline-block px-2 py-0.5 rounded bg-rose-50 border border-rose-150 text-[10px] font-black text-rose-700" title={nom.obstacleText}>
                              ⚠️ لديه مانع
                            </span>
                          ) : (
                            <span className="text-[10px] text-slate-400 font-bold">لا توجد موانع</span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          {nom.qualificationStatus === 'eligible' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-250">
                              🟢 صالح تماماً
                            </span>
                          ) : nom.qualificationStatus === 'needs_review' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-800 border border-amber-250" title={nom.qualificationReason}>
                              🟡 يحتاج مراجعة
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-800 border border-rose-250" title={nom.qualificationReason}>
                              🔴 غير صالح
                            </span>
                          )}
                          <div className="text-[9px] text-slate-400 max-w-[120px] truncate mx-auto mt-1" title={nom.qualificationReason}>
                            {nom.qualificationReason}
                          </div>
                        </td>
                        <td className="p-3 text-center">
                          {nom.documents && nom.documents.length > 0 ? (
                            <div className="flex flex-col items-center gap-1">
                              <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-md">
                                📎 عدد ({nom.documents.length}) مرفقات
                              </span>
                              <div className="flex gap-1">
                                {nom.documents.slice(0, 3).map((d) => (
                                  <button
                                    key={d.id}
                                    onClick={() => setPreviewDoc(d)}
                                    className="p-1 hover:bg-slate-100 rounded text-sky-700 transition"
                                    title={`معاينة: ${d.name}`}
                                  >
                                    <Eye size={11} />
                                  </button>
                                ))}
                              </div>
                            </div>
                          ) : (
                            <span className="text-slate-400 font-medium">لا توجد مرفقات</span>
                          )}
                        </td>
                        <td className="p-3 text-center font-bold">
                          {(() => {
                            const relatedExcuse = excuses.find(
                              (e) => e.id === `exc_${nom.id}` || e.nationalId === nom.nationalId
                            );

                            if (nom.status === 'draft') {
                              return (
                                <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md border border-slate-200">
                                  مسودة
                                </span>
                              );
                            }

                            if (nom.status === 'submitted' || nom.status === 'pending') {
                              return (
                                <div className="space-y-0.5">
                                  <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-md border border-amber-200">
                                    ⏳ قيد المراجعة والاعتماد
                                  </span>
                                  <div className="text-[9px] text-slate-400 mt-1">بانتظار قرار لجنة الإدارة</div>
                                </div>
                              );
                            }

                            if (nom.status === 'approved') {
                              // If there is a rejected excuse, make it extremely explicit
                              if (relatedExcuse?.status === 'rejected') {
                                return (
                                  <div className="space-y-1">
                                    <span className="px-2 py-1 bg-emerald-100 text-emerald-800 rounded-md border border-emerald-250 block text-[10px] text-center font-black">
                                      ✅ مقبول ومرشح أعمال الامتحانات
                                    </span>
                                    <span className="px-1.5 py-0.5 bg-rose-50 text-rose-700 rounded-md border border-rose-200 block text-[9.5px] font-black text-center mt-1">
                                      ⚠️ مرفوض الأعذار من التنسيق (ملزم بالندب)
                                    </span>
                                    {nom.rejectionFeedback && (
                                      <p className="text-[9px] text-slate-500 font-bold mt-1 max-w-[145px]" title={nom.rejectionFeedback}>
                                        القرار: {nom.rejectionFeedback}
                                      </p>
                                    )}
                                  </div>
                                );
                              }

                              return (
                                <div className="space-y-0.5">
                                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md border border-emerald-250">
                                    ✅ تم قبول الترشيح (مرشح مقبول)
                                  </span>
                                  {nom.rejectionFeedback && (
                                    <p className="text-[9px] text-emerald-600 font-bold mt-1 max-w-[140px] truncate" title={nom.rejectionFeedback}>
                                      ملاحظة: {nom.rejectionFeedback}
                                    </p>
                                  )}
                                </div>
                              );
                            }

                            // If status is 'rejected' or others but with an approved excuse from AdminCoordination
                            if (relatedExcuse?.status === 'approved') {
                              return (
                                <div className="space-y-1">
                                  <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-md border border-blue-200 block text-[10px] text-center font-black">
                                    ✅ مقبول العذر ومستبعد (موانع معتمد)
                                  </span>
                                  <span className="px-1.5 py-0.5 bg-emerald-50 text-emerald-800 rounded-md border border-emerald-200 block text-[9.5px] font-bold text-center mt-1">
                                    مقبول الأعذار في المدرسة والتنسيق
                                  </span>
                                  {nom.rejectionFeedback && (
                                    <p className="text-[9px] text-slate-500 font-bold mt-1 max-w-[145px]" title={nom.rejectionFeedback}>
                                      ملاحظة: {nom.rejectionFeedback}
                                    </p>
                                  )}
                                </div>
                              );
                            }

                            return (
                              <div className="space-y-0.5">
                                <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded-md border border-rose-250">
                                  ❌ تم استبعاد / رفض الترشيح
                                </span>
                                {nom.rejectionFeedback && (
                                  <p className="text-[9px] text-rose-650 font-black mt-1 bg-rose-50 p-1 border border-rose-150 rounded" title={nom.rejectionFeedback}>
                                    السبب: {nom.rejectionFeedback}
                                  </p>
                                )}
                              </div>
                            );
                          })()}
                        </td>
                        <td className="p-3 text-center">
                          <div className="flex justify-center items-center gap-1.5 flex-wrap">
                            <button
                              onClick={() => handleOpenForm(nom)}
                              className="p-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 rounded-lg transition-all"
                              title="تعديل الاستمارة"
                            >
                              <Edit2 size={13} />
                            </button>
                            <button
                              onClick={() => handlePrintNomination(nom)}
                              className="p-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-600 rounded-lg transition-all"
                              title="طباعة الاستمارة الرسمية واجهة (1 سري)"
                            >
                              <Printer size={13} />
                            </button>
                            <button
                              onClick={() => handleDeleteNomination(nom.id, nom.name)}
                              className="p-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-600 rounded-lg transition-all"
                              title="مسح وتحرير السجل"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            {/* General instructions foot of table */}
            <div className="p-3 bg-slate-50 border-t border-slate-100 text-[10px] text-slate-450 leading-relaxed font-semibold flex items-center gap-1.5 justify-between">
              <span className="flex items-center gap-1">
                <Info size={13} className="text-blue-500" />
                تتم مزامنة جميع الإدخالات والخيارات فوريًا مع الإدارة. تذكر إرسال المسودات رسميًا للحصول على موافقة وتصنيف اللجنة الإدارية.
              </span>
              <span className="text-slate-400">آخر تحديث من السيرفر: {new Date().toLocaleTimeString('ar-EG')}</span>
            </div>
          </div>
        </div>
      )}

      {/* View 2: Form Tabbing / Creator View */}
      {view === 'form' && selectedNomination && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setView('list')}
                className="p-1.5 px-3 bg-slate-50 hover:bg-slate-100 rounded-lg text-slate-600 transition flex items-center gap-1 cursor-pointer font-bold text-xs"
              >
                <ArrowRight size={14} />
                رجوع للكشوف
              </button>
              <div className="h-5 w-[1px] bg-slate-200 mx-2"></div>
              <h3 className="font-sans font-black text-rose-600 text-sm flex items-center gap-2">
                <FileText size={18} />
                تحرير واستيفاء استمارة (1 سري) المعتمدة للمرشح
              </h3>
            </div>

            {/* Offline Auto Save Status indicator */}
            <div className="flex items-center gap-1 text-[10px] font-bold">
              {autoSaveStatus === 'saving' && (
                <span className="text-amber-600 flex items-center gap-1">
                  <RefreshCw size={12} className="animate-spin" />
                  جاري الحفظ التلقائي...
                </span>
              )}
              {autoSaveStatus === 'saved' && (
                <span className="text-emerald-600 flex items-center gap-1">
                  <Check size={12} />
                  تم الحفظ تلقائياً بسحابة Firestore
                </span>
              )}
              {autoSaveStatus === 'failed' && (
                <span className="text-rose-600 flex items-center gap-1">
                  ❌ فشل الحفظ، تحقق من الإنترنت (حفظ محلي مؤقتاً)
                </span>
              )}
              {autoSaveStatus === 'idle' && (
                <span className="text-slate-400">
                  حفظ تلقائي مفعل ومؤمّن
                </span>
              )}
            </div>
          </div>

          {/* Validation Alert details banner */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 font-bold text-xs flex items-center gap-2">
              <AlertTriangle size={15} />
              {errorMsg}
            </div>
          )}

          {/* Core Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Name */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">1. اسم المعلم المرشح رباعي (مكافأة أعمال الامتحانات) *</label>
              <input
                type="text"
                value={formName}
                onChange={(e) => handleFormInputChange('name', e.target.value)}
                placeholder="أدخل الاسم الرباعي صحيحاً"
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-semibold"
              />
            </div>

            {/* Current Job (الوظيفة الحالية) */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">2. الوظيفة الحالية بالمدرسة *</label>
              <input
                type="text"
                value={formJobTitle}
                onChange={(e) => handleFormInputChange('jobTitle', e.target.value)}
                placeholder="مثال: معلم خبير / معلم أول أ / أخصائي..."
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-semibold"
              />
            </div>

            {/* Specialization */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">3. تخصص ومادة التدريس الفعلية بالمدرسة *</label>
              <input
                type="text"
                value={formSubject}
                onChange={(e) => handleFormInputChange('subject', e.target.value)}
                placeholder="مثال: لغة عربية / رياضيات / دراسات..."
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-semibold"
              />
            </div>

            {/* Address */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">4. مسكن وعنوان الموظف بالتفصيل *</label>
              <input
                type="text"
                value={formAddress}
                onChange={(e) => handleFormInputChange('address', e.target.value)}
                placeholder="العنوان الكامل للمراسلات والبريد"
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-semibold"
              />
            </div>

            {/* Appointment Date */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">5. تاريخ التعيين بالوزارة</label>
              <input
                type="date"
                value={formAppointmentDate}
                onChange={(e) => handleFormInputChange('appointmentDate', e.target.value)}
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-semibold"
              />
            </div>

            {/* National ID */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">6. الرقم القومي (14 رقماً مصرياً) *</label>
              <input
                type="text"
                maxLength={14}
                value={formNationalId}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9]/g, '');
                  handleFormInputChange('nationalId', val);
                }}
                placeholder="أدخل الـ 14 رقماً لتقوم المنصة بحساب تاريخ الميلاد تلقائياً"
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-bold font-mono"
              />
            </div>

            {/* Birthdate */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">7. تاريخ الميلاد (يتم استخراجه تلقائياً)</label>
              <input
                type="date"
                value={formBirthDate}
                onChange={(e) => handleFormInputChange('birthDate', e.target.value)}
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-semibold"
              />
            </div>

            {/* Phone */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">8. رقم الهاتف الجوال (11 رقماً للتواصل) *</label>
              <input
                type="text"
                maxLength={11}
                value={formPhone}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9]/g, '');
                  handleFormInputChange('phone', val);
                }}
                placeholder="مثال: 01012345678"
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-bold font-mono"
              />
            </div>

            {/* Code */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-700">9. كود المعلم الوظيفي (إن وجد)</label>
              <input
                type="text"
                value={formCode}
                onChange={(e) => handleFormInputChange('code', e.target.value)}
                placeholder="كود الموظف بنظام شؤون العاملين"
                className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:outline-none focus:border-rose-500 font-bold font-mono"
              />
            </div>
          </div>

          {/* Dynamic Obstacles (موانع الاشتراك) */}
          <div className="border-t border-slate-100 pt-5 space-y-4">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div>
                <label className="block text-xs font-black text-slate-700">10. مانع الاشتراك في أعمال الامتحانات (قائمة الموانع المعتمدة بالإدارة) *</label>
                <p className="text-[10px] text-slate-400 mt-1">يجرى التحكم بالمرئيات والموانع من قبل التنسيق المركزي ملقماً عبر الـ Cloud</p>
              </div>
              <div className="w-full md:w-80">
                <select
                  value={formObstacleId}
                  onChange={(e) => handleFormInputChange('obstacleId', e.target.value)}
                  className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50 text-slate-800 font-bold focus:outline-none focus:border-rose-500 cursor-pointer"
                >
                  <option value="none">لا يوجد مانع (مستوفي لكافة الشروط)</option>
                  {obstacles.map(obs => (
                    <option key={obs.id} value={obs.id}>{obs.name}</option>
                  ))}
                  <option value="other">أخرى (موانع شخصية أو صحية إضافية)</option>
                </select>
              </div>
            </div>

            {/* Other option customized reason */}
            {formObstacleId === 'other' && (
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-700">شرح وتفصيل سبب استبعاد أو مانع المرشح *</label>
                <textarea
                  rows={2}
                  value={formObstacleText}
                  onChange={(e) => handleFormInputChange('obstacleText', e.target.value)}
                  placeholder="يرجى كتابة سبب التفصيل بدقة كمرجع إداري للإدارة في التقييم والفرز الموجه..."
                  className="w-full text-xs p-3 border border-slate-300 rounded-xl bg-slate-50/50 text-slate-800 focus:outline-none focus:border-rose-500"
                />
              </div>
            )}
          </div>

          {/* Live Document management with replacement options */}
          <div className="border-t border-slate-100 pt-5 space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h4 className="text-xs font-black text-rose-800 flex items-center gap-1.5">
                  <UploadCloud size={15} />
                  11. مراجعة ورفع المستندات الرسمية الداعمة للمرشح (مجموعة الصور والـ PDF)
                </h4>
                <p className="text-[10px] text-slate-400 mt-1">يلزم إرفاق مستند رسمي في حالة اختيار الموانع لتأمين الطلب من الإلغاء</p>
              </div>
              <span className="text-[10px] text-slate-450 font-bold">بوابة المستندات المؤمّنة (شؤون الطلبة والامتحانات)</span>
            </div>

            <div className="flex flex-col md:flex-row gap-5 items-start">
              {/* Drag Area */}
              <label 
                className={`flex-shrink-0 w-full md:w-64 h-36 border-2 border-dashed rounded-xl transition flex flex-col items-center justify-center cursor-pointer p-4 select-none ${
                  fileUploading 
                    ? 'border-rose-300 bg-rose-50/20' 
                    : 'border-slate-300 hover:border-rose-500 bg-slate-50 hover:bg-slate-100/50'
                }`}
              >
                {fileUploading ? (
                  <>
                    <RefreshCw size={28} className="text-rose-600 animate-spin" />
                    <span className="text-[11px] font-black text-rose-700 mt-2">جاري الرفع لـ Cloud Storage...</span>
                  </>
                ) : (
                  <>
                    <UploadCloud size={30} className="text-slate-400" />
                    <span className="text-[11px] font-black text-slate-700 mt-2">اسحب هنا أو انقر للاختيار</span>
                    <span className="text-[9px] text-slate-400 mt-0.5">يدعم صور الامتحانات و PDF</span>
                  </>
                )}
                <input
                  type="file"
                  onChange={handleFileUpload}
                  multiple
                  accept=".pdf,image/*"
                  className="hidden"
                  disabled={fileUploading}
                />
              </label>

              {/* Grid of uploaded files with preview, download, and replace */}
              <div className="flex-grow w-full space-y-2">
                {formDocuments.length === 0 ? (
                  <div className="p-10 border border-dashed border-slate-200 rounded-xl text-center text-slate-400 font-bold text-xs bg-slate-50/20">
                    لا توجد مستندات داعمة مرفوعة حالياً. يمكنك رفع ملف إثبات الموانع، الإعفاء، أو تقرير الحالة المرضية/العائلية للموظف.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {formDocuments.map((doc) => (
                      <div key={doc.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex justify-between items-center text-xs">
                        <div className="flex items-center gap-2 truncate">
                          <span className="p-1 px-1.5 text-[9px] font-black bg-rose-100 text-rose-700 rounded-md">
                            {doc.type.toUpperCase()}
                          </span>
                          <span className="font-semibold text-slate-700 truncate max-w-[140px]" title={doc.name}>
                            {doc.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          {/* Preview option */}
                          <button
                            type="button"
                            onClick={() => setPreviewDoc(doc)}
                            className="p-1 text-slate-600 hover:bg-white border hover:border-slate-200 rounded-md transition"
                            title="معاينة المرفق"
                          >
                            <Eye size={12} />
                          </button>
                          {/* Download option */}
                          <a
                            href={doc.dataUrl}
                            download={doc.name}
                            referrerPolicy="no-referrer"
                            className="p-1 text-slate-600 hover:bg-white border hover:border-slate-200 rounded-md transition"
                            title="تسجيل وتحميل"
                          >
                            <Download size={12} />
                          </a>
                          {/* Replace option with file selector */}
                          <label className="p-1 text-blue-600 hover:bg-blue-50 border border-transparent hover:border-blue-150 rounded-md cursor-pointer transition" title="استبدال الملف">
                            <RefreshCw size={12} />
                            <input
                              type="file"
                              accept=".pdf,image/*"
                              onChange={(e) => handleReplaceFile(doc.id, e)}
                              className="hidden"
                              disabled={fileUploading}
                            />
                          </label>
                          {/* Delete option */}
                          <button
                            type="button"
                            onClick={() => handleDeleteDoc(doc.id)}
                            className="p-1 text-red-600 hover:bg-red-50 border border-transparent hover:border-red-150 rounded-md transition"
                            title="حذف المستند"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Form Decision Actions footer */}
          <div className="border-t border-slate-100 pt-5 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setView('list')}
              className="px-5 py-2.5 bg-slate-150 hover:bg-slate-200 border border-slate-300 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              إلغاء التعديلات والرجوع
            </button>
            <button
              type="button"
              onClick={handleFinalSave}
              disabled={fileUploading}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow-md active:scale-95 transition cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
            >
              <CheckCircle size={14} />
              حفظ وتأكيد الاستمارة بالكشف
            </button>
          </div>
        </div>
      )}

      {/* View 3: Printable Official Layout */}
      {view === 'print' && selectedNomination && (
        <div className="bg-slate-500/20 p-4 rounded-2xl flex flex-col items-center space-y-4">
          <div className="flex gap-2">
            <button
              onClick={() => window.print()}
              className="bg-sky-600 text-white px-5 py-2 rounded-lg font-black text-xs flex items-center gap-1.5 hover:bg-sky-700 cursor-pointer shadow"
            >
              <Printer size={15} />
              ابدأ عملية الطباعة الفورية
            </button>
            <button
              onClick={() => setView('list')}
              className="bg-white border text-slate-700 px-5 py-2 rounded-lg font-bold text-xs hover:bg-slate-100 cursor-pointer shadow"
            >
              الرجوع لكشوف المدرسة
            </button>
          </div>

          <div className="bg-white text-black size-a4 font-serif p-10 shadow-xl border-4 border-double border-slate-800 leading-relaxed max-w-[800px] w-full" id="printable-area">
            {/* Republic Header */}
            <div className="flex justify-between items-start text-xs border-b-2 border-black pb-4 mb-6">
              <div className="space-y-1">
                <p className="font-bold">جمهورية مصر العربية</p>
                <p>وزارة التربية والتعليم والتعليم الفني</p>
                <p>مديرية التربية والتعليم بالشرقية</p>
                <p>إدارة أبو حماد التعليمية</p>
                <p className="font-extrabold text-blue-900">لجنة التنسيق العام والامتحانات</p>
              </div>
              <div className="text-center">
                <div className="border border-black p-2 font-bold text-sm bg-slate-50 rounded-lg">
                  استمارة (1 سري) المعتمدة
                </div>
                <p className="text-[10px] text-slate-500 font-mono mt-2">لسنة: {new Date().getFullYear()} م</p>
              </div>
            </div>

            {/* Main title */}
            <div className="text-center space-y-2 mb-8">
              <h1 className="text-lg font-black underline my-2">بينات استمارة موظف مرشح للمشاركة بأعمال الامتحانات العامة والشهادات</h1>
              <p className="text-xs">المقدمة من مدرسة: <span className="font-extrabold">{school.name}</span> بالترشيح الرقمي التفاعلي السحابي</p>
            </div>

            {/* Fields grid table */}
            <div className="border-2 border-black grid grid-cols-2 divide-x-2 divide-y-2 divide-black text-xs mb-8">
              <div className="p-3 bg-slate-100 font-bold">اسم الموظف المرشح رباعي:</div>
              <div className="p-3 font-extrabold text-sm">{selectedNomination.name}</div>

              <div className="p-3 bg-slate-100 font-bold">الوظيفة الحالية بالمدرسة:</div>
              <div className="p-3 font-semibold">{selectedNomination.jobTitle}</div>

              <div className="p-3 bg-slate-100 font-bold">التخصص المالي ومادة التدريس:</div>
              <div className="p-3 font-semibold">{selectedNomination.subject}</div>

              <div className="p-3 bg-slate-100 font-bold">الرقم القومي (14 رقماً مصنعياً):</div>
              <div className="p-3 font-mono font-bold">{selectedNomination.nationalId}</div>

              <div className="p-3 bg-slate-100 font-bold">تاريخ الميلاد والتعيين:</div>
              <div className="p-3">{selectedNomination.birthDate || 'غير مسجل'} | تعيين: {selectedNomination.appointmentDate || 'غير مسجل'}</div>

              <div className="p-3 bg-slate-100 font-bold">موارد التواصل والاتصال (جوال):</div>
              <div className="p-3 font-mono font-bold">{selectedNomination.phone}</div>

              <div className="p-3 bg-slate-100 font-bold">مسكن المرشح وعنوانه الفعلي:</div>
              <div className="p-3">{selectedNomination.address}</div>

              <div className="p-3 bg-slate-100 font-bold">كود المعلم الرقمي:</div>
              <div className="p-3 font-bold font-mono">{selectedNomination.code || 'لا يوجد'}</div>

              <div className="p-3 bg-slate-100 font-bold">نتيجة الفرز والمانع المصرح به:</div>
              <div className="p-3">
                {selectedNomination.obstacleId === 'none' ? 'مستوفى للشروط، وخالي من أي موانع قرابة أو تحقيقية' : `مسجل مانع قرابة/قانوني: ${obstacles.find(o => o.id === selectedNomination.obstacleId)?.name || 'أخرى'}`}
                {selectedNomination.obstacleText && <p className="text-red-700 text-[11px] mt-1 font-bold">توضيح: {selectedNomination.obstacleText}</p>}
              </div>
            </div>

            {/* Smart Check outcome */}
            <div className="p-4 border border-slate-350 bg-slate-50/50 rounded-xl space-y-1 mb-8 text-xs text-right">
              <span className="font-bold underline text-slate-800 text-[11px]">تقرير الفحص التلقائي بالـ Cloud:</span>
              <p className="font-extrabold text-slate-700">
                الحالة: {selectedNomination.qualificationStatus === 'eligible' ? '🟢 مستوفي وصالح تماماً' : '🟡 يحتاج مراجعة المستندات بالإدارة'}
              </p>
              <p className="text-slate-500 font-semibold">{selectedNomination.qualificationReason}</p>
            </div>

            {/* Signatures */}
            <div className="grid grid-cols-3 text-center my-6 text-xs gap-4 mt-12 pb-6">
              <div className="space-y-8">
                <p className="underline font-bold">معد الاستمارة (شؤون العاملين)</p>
                <p className="font-semibold text-slate-400">..............................</p>
              </div>
              <div className="space-y-8">
                <p className="underline font-bold">رئيس اللجنة الطبية / الفرز</p>
                <p className="font-semibold text-slate-400">..............................</p>
              </div>
              <div className="space-y-8">
                <p className="underline font-bold">مدير المدرسة (خاتم شعار الجمهورية)</p>
                <p className="font-semibold text-slate-400">..............................</p>
              </div>
            </div>

            {/* System print stamp */}
            <div className="text-center text-[10px] text-slate-400 border-t border-black/10 pt-4 mt-6">
              تم إنشاء وطباعة هذه الاستمارة الكترونياً من خلال المنصة التنسيقية الذكية لإدارة أبوحماد التعليمية
              <p className="font-mono mt-1 text-slate-350">تاريخ الطباعة: {new Date().toLocaleString('ar-EG')} - ID: {selectedNomination.id}</p>
            </div>
          </div>
        </div>
      )}

      {/* Preview Document Overlay Modal */}
      {previewDoc && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl overflow-hidden text-right">
            <div className="bg-slate-100 p-4 border-b border-slate-200 flex justify-between items-center">
              <button 
                onClick={() => setPreviewDoc(null)}
                className="p-1 hover:bg-slate-200 rounded-full transition text-slate-500 cursor-pointer"
              >
                <X size={18} />
              </button>
              <h4 className="font-sans font-black text-xs text-[#0D47A1] truncate pl-4">
                معاينة مستند: {previewDoc.name}
              </h4>
            </div>
            <div className="p-4 flex items-center justify-center min-h-[320px] bg-slate-50">
              {previewDoc.type === 'pdf' ? (
                <div className="text-center space-y-3 p-10">
                  <FileIcon size={48} className="text-rose-500 mx-auto" />
                  <p className="text-xs font-black text-slate-600">هذا المستند ملف PDF رسمي</p>
                  <a
                    href={previewDoc.dataUrl}
                    download={previewDoc.name}
                    referrerPolicy="no-referrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold shadow transition active:scale-95 cursor-pointer"
                  >
                    <Download size={14} />
                    تحميل وتنزيل ملف الـ PDF كاملاً
                  </a>
                </div>
              ) : (
                <img
                  src={previewDoc.dataUrl}
                  alt={previewDoc.name}
                  referrerPolicy="no-referrer"
                  className="max-h-[70vh] rounded-lg max-w-full object-contain border shadow"
                />
              )}
            </div>
            <div className="bg-slate-50 p-3 border-t border-slate-200 flex justify-end gap-2 text-xs">
              <a
                href={previewDoc.dataUrl}
                download={previewDoc.name}
                referrerPolicy="no-referrer"
                className="px-4 py-1.5 bg-slate-200 text-slate-700 hover:bg-slate-350 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <Download size={12} />
                تنزيل الملف
              </a>
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-1.5 bg-rose-600 text-white hover:bg-rose-700 rounded-lg font-black transition cursor-pointer"
              >
                إغلاق المعاينة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Confirm Dialog Overlay */}
      {confirmDialog && confirmDialog.isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-xl space-y-4 text-right border border-slate-100" dir="rtl">
            <h4 className="font-sans font-black text-sm text-rose-700 flex items-center gap-1.5">
              ⚠️ {confirmDialog.title}
            </h4>
            <p className="text-xs text-slate-650 font-bold leading-relaxed">{confirmDialog.message}</p>
            <div className="flex gap-2 justify-end pt-2">
              <button
                onClick={() => setConfirmDialog(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-705 font-bold text-xs rounded-xl cursor-pointer"
              >
                رجوع وإلغاء
              </button>
              <button
                onClick={confirmDialog.onConfirm}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow cursor-pointer"
              >
                تأكيد ومتابعة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-bounce">
          <div className={`p-4 rounded-xl shadow-lg border text-xs font-black flex items-center gap-2 ${
            toast.type === 'success' ? 'bg-emerald-55 border-emerald-200 text-emerald-850' :
            toast.type === 'error' ? 'bg-rose-55 border-rose-200 text-rose-850' :
            'bg-slate-55 border-slate-250 text-slate-850'
          }`}>
            <span>{toast.type === 'success' ? '✅' : toast.type === 'error' ? '❌' : 'ℹ️'}</span>
            <span>{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
}
