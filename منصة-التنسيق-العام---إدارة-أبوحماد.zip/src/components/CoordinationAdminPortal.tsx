/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { School, Material, MaterialCount, StaffMember, Directorship, VisitorLog, NutritionRecord, StudentAbsence, TeacherAbsence, SystemSettings, ArchivedReport, STAGE_LABELS, TrashItem } from '../types';
import { dbInstance } from '../data/db';
import AdminExamNominationTab from './AdminExamNominationTab';
import { CustomPieChart, CustomDoughnutChart, CustomBarChart, CustomLineChart, DoubleGroupedBarChart } from './DashboardCharts';
import { 
  ResponsiveContainer, 
  BarChart as RechartsBarChart, 
  Bar as RechartsBar, 
  XAxis as RechartsXAxis, 
  YAxis as RechartsYAxis, 
  CartesianGrid as RechartsCartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend as RechartsLegend,
  ReferenceLine as RechartsReferenceLine
} from 'recharts';
import PrintableReport, { PrintHeader, PrintFooter } from './ReportTemplate';
import { EducationalLogo } from './EducationalLogo';
import { 
  Building2, 
  BookOpen, 
  Users, 
  SlidersHorizontal, 
  TrendingUp, 
  Printer, 
  Plus, 
  Trash2, 
  Edit, 
  Save, 
  RefreshCw, 
  CheckCircle,
  FileSpreadsheet,
  AlertTriangle,
  Lock,
  ChevronDown,
  LogOut,
  Search,
  Copy,
  History,
  Download,
  Upload,
  Send,
  FileText,
  Sparkles,
  Brain,
  Archive,
  Eye,
  FileCheck,
  CloudLightning,
  Clock,
  Calendar,
  Apple,
  Activity,
  ShieldCheck,
  UserX
} from 'lucide-react';

export const withOklchBypass = async <T,>(fn: () => Promise<T>): Promise<T> => {
  if (typeof document !== 'undefined' && (document as any).fonts) {
    try {
      await (document as any).fonts.ready;
    } catch (e) {
      console.warn('Fonts ready wait failed or timed out:', e);
    }
  }

  const originalGetComputedStyle = window.getComputedStyle;
  
  const oklabToRgb = (L: number, a: number, b: number): [number, number, number] => {
    // OKLab to LMS
    const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
    const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
    const s_ = L - 0.0894841775 * a - 1.291485548 * b;
    
    // LMS to XYZ (approximate/linear)
    const l3 = l_ * l_ * l_;
    const m3 = m_ * m_ * m_;
    const s3 = s_ * s_ * s_;
    
    // Linear sRGB from LMS
    const rL = +4.0767416621 * l3 - 3.3077115913 * m3 + 0.2309699292 * s3;
    const gL = -1.2684380046 * l3 + 2.6097574011 * m3 - 0.3413193965 * s3;
    const bL = -0.0041960863 * l3 - 0.7034186147 * m3 + 1.707614701 * s3;
    
    // Gamma correction to sRGB
    const clampAndGamma = (v: number) => {
      const clamped = Math.max(0, Math.min(1, v));
      return clamped <= 0.0031308
        ? Math.round(clamped * 12.92 * 255)
        : Math.round((1.055 * Math.pow(clamped, 1 / 2.4) - 0.055) * 255);
    };
    
    return [clampAndGamma(rL), clampAndGamma(gL), clampAndGamma(bL)];
  };

  const oklchToRgb = (l: number, c: number, h: number): [number, number, number] => {
    const hRad = (h * Math.PI) / 180;
    const L = l;
    const a = c * Math.cos(hRad);
    const b = c * Math.sin(hRad);
    return oklabToRgb(L, a, b);
  };

  const replaceColors = (val: string): string => {
    if (typeof val !== 'string') return val;
    if (!val.includes('oklch') && !val.includes('oklab')) return val;
    
    let result = val;
    
    if (result.includes('oklch')) {
      result = result.replace(/oklch\(([^)]+)\)/g, (match, p1) => {
        const parts = p1.trim().split(/[\s,/]+/);
        if (parts.length === 0) return match;
        
        const l = parseFloat(parts[0]);
        const c = parts.length > 1 ? parseFloat(parts[1]) : 0;
        const h = parts.length > 2 ? parseFloat(parts[2]) : 0;
        const opacity = parts.length > 3 ? parseFloat(parts[3]) : 1;
        
        if (isNaN(l)) return match;
        const [rVal, gVal, bVal] = oklchToRgb(l, isNaN(c) ? 0 : c, isNaN(h) ? 0 : h);
        
        if (!isNaN(opacity) && opacity < 1) {
          return `rgba(${rVal}, ${gVal}, ${bVal}, ${opacity})`;
        }
        return `rgb(${rVal}, ${gVal}, ${bVal})`;
      });
    }
    
    if (result.includes('oklab')) {
      result = result.replace(/oklab\(([^)]+)\)/g, (match, p1) => {
        const parts = p1.trim().split(/[\s,/]+/);
        if (parts.length === 0) return match;
        
        const L = parseFloat(parts[0]);
        const a = parts.length > 1 ? parseFloat(parts[1]) : 0;
        const b = parts.length > 2 ? parseFloat(parts[2]) : 0;
        const opacity = parts.length > 3 ? parseFloat(parts[3]) : 1;
        
        if (isNaN(L)) return match;
        const [rVal, gVal, bVal] = oklabToRgb(L, isNaN(a) ? 0 : a, isNaN(b) ? 0 : b);
        
        if (!isNaN(opacity) && opacity < 1) {
          return `rgba(${rVal}, ${gVal}, ${bVal}, ${opacity})`;
        }
        return `rgb(${rVal}, ${gVal}, ${bVal})`;
      });
    }
    
    return result;
  };

  window.getComputedStyle = function (elt, pseudoElt) {
    const style = originalGetComputedStyle(elt, pseudoElt);
    return new Proxy(style, {
      get(target, prop, receiver) {
        if (prop === 'getPropertyValue') {
          return function(propertyName: string) {
            const val = target.getPropertyValue(propertyName);
            return typeof val === 'string' ? replaceColors(val) : val;
          };
        }
        try {
          const val = (target as any)[prop];
          if (typeof val === 'function') {
            return val.bind(target);
          }
          return typeof val === 'string' ? replaceColors(val) : val;
        } catch (e) {
          return undefined;
        }
      }
    });
  };

  try {
    return await fn();
  } finally {
    window.getComputedStyle = originalGetComputedStyle;
  }
};

interface CoordinationAdminPortalProps {
  onLogout: () => void;
}

export default function CoordinationAdminPortal({ onLogout }: CoordinationAdminPortalProps) {
  const [activeTab, setActiveTab] = useState<string>('stats');
  const [dbTick, setDbTick] = useState(0);

  // States fetched dynamically
  const [schools, setSchools] = useState<School[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [materialCounts, setMaterialCounts] = useState<MaterialCount[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [leadership, setLeadership] = useState<Directorship[]>([]);
  const [visitors, setVisitors] = useState<VisitorLog[]>([]);
  const [nutrition, setNutrition] = useState<NutritionRecord[]>([]);
  const [studentAbsences, setStudentAbsences] = useState<StudentAbsence[]>([]);
  const [teacherAbsences, setTeacherAbsences] = useState<TeacherAbsence[]>([]);
  const [settings, setSettings] = useState(dbInstance.getSettings());

  // Reload handler from database
  const loadData = () => {
    setSchools(dbInstance.getSchools());
    setMaterials(dbInstance.getMaterials());
    setMaterialCounts(dbInstance.getMaterialCounts());
    setStaff(dbInstance.getStaff());
    setLeadership(dbInstance.getLeadership());
    setVisitors(dbInstance.getVisitors());
    setNutrition(dbInstance.getNutritionRecords());
    setStudentAbsences(dbInstance.getStudentAbsences());
    setTeacherAbsences(dbInstance.getTeacherAbsences());
    setSettings(dbInstance.getSettings());
  };

  useEffect(() => {
    loadData();
    return dbInstance.subscribe(() => {
      loadData();
      setDbTick(prev => prev + 1);
    });
  }, []);

  const aggregatedAnalytics = useMemo(() => {
    return dbInstance.getAggregatedAnalytics();
  }, [dbTick]);

  const activeTabLabel = useMemo(() => {
    switch (activeTab) {
      case 'stats': return 'الإحصائيات والتحليلات البيانية';
      case 'settings': return 'الإعدادات الأمنية';
      case 'schools': return 'إعدادات المواد والمدارس';
      case 'staff_leadership': return 'تقرير القيادة المدرسية والوكلاء';
      case 'staff_teachers': return 'تقرير المعلمين التفصيلي';
      case 'staff_specialists': return 'تقرير الأخصائيين بالتفصيل';
      case 'staff_admins': return 'تقرير الإداريين بالتفصيل';
      case 'staff_activity_supervisors': return 'تقرير مشرفي الأنشطة بالتفصيل';
      case 'staff_workers': return 'تقرير العمال والخدمات المعاونة';
      case 'deficit_reports': return 'تقارير العجز والزيادة والبحث المتقدم';
      case 'reports_absences_students': return 'تقرير غياب الطلاب اليومي';
      case 'reports_absences_teachers': return 'تقرير حضور وغياب الكوادر';
      case 'reports_visitors': return 'سجل الزوار والموجهين بالمدارس';
      case 'reports_nutrition': return 'تقرير التغذية المدرسية الكلي';
      case 'exam_nomination': return 'استمارات المرشحين (1 سري)';
      case 'ai_deficit_report': return 'التقرير الشامل لعجز وزيادة المدارس بالذكاء الاصطناعي';
      default: return 'بوابة مدير التنسيق';
    }
  }, [activeTab]);

  return (
    <div className="w-full bg-[#F5F7FA] min-h-screen text-[#212121] flex flex-col gap-6 p-4 md:p-6 print:p-0" dir="rtl">
      
      {/* 1. Header with Logo & Title */}
      <header className="bg-white rounded-2xl border border-slate-200 p-5 shadow-lg flex flex-col lg:flex-row justify-between items-center gap-4 print:hidden">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-[#0D47A1] rounded-xl text-white shadow-md">
            <EducationalLogo size="sm" glowing={true} />
          </div>
          <div>
            <h1 className="text-xl font-black text-[#0D47A1] font-sans tracking-wide">التنسيق العام</h1>
            <p className="text-xs text-slate-600 mt-0.5 font-bold">نظام الربط الإلكتروني وحصر العجز والزيادة بالإدارة التعليمية بأبو حماد</p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full lg:w-auto justify-end flex-wrap">
          {/* 4 Control Buttons */}
          <button
            type="button"
            onClick={() => {
              dbInstance.saveSettings(settings);
              alert('💾 تم حفظ كافة التعديلات والبيانات التنسيقية الحالية بنجاح.');
            }}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
          >
            <Save size={13} />
            <span>حفظ 💾</span>
          </button>

          <button
            type="button"
            onClick={() => {
              loadData();
              alert('🔄 تم تحديث وجلب أحدث السجلات والبيانات من قاعدة البيانات بنجاح.');
            }}
            className="px-3.5 py-2 bg-[#1565C0] hover:bg-blue-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw size={13} />
            <span>تحديث 🔄</span>
          </button>

          <button
            type="button"
            onClick={() => {
              alert(`📤 تم إرسال واعتماد الصفحة الحالية ("${activeTabLabel}") بنجاح إلى قاعدة بيانات الإدارة والمديرية.`);
            }}
            className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
          >
            <Send size={13} />
            <span>إرسال الصفحة الحالية 📤</span>
          </button>

          <button
            type="button"
            onClick={() => {
              alert('🚀 تم ترحيل وإرسال كافة بيانات الكوادر والمدارس والأنصبة والغياب سحابياً بنسبة 100% بنجاح إلى مديرية التربية والتعليم بالشرقية.');
            }}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
          >
            <CloudLightning size={13} />
            <span>إرسال جميع البيانات 🚀</span>
          </button>

          <button
            type="button"
            onClick={onLogout}
            className="px-3.5 py-2 hover:bg-slate-100 border border-slate-300 text-slate-800 font-black text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5 active:scale-95 bg-slate-50 shadow-xs"
          >
            <LogOut size={13} className="text-[#D32F2F]" />
            <span>خروج وعودة</span>
          </button>
        </div>
      </header>

      {/* 3. DUAL-ROW MODERN CONTROL TOOLBAR */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-lg print:hidden space-y-3.5">
        
        {/* Row 1: Primary Controls & Staff Reports */}
        <div className="space-y-1.5">
          <span className="block text-[10px] font-black text-slate-400 select-none">التحكم الأساسي وإدارة الكوادر والتنسيق:</span>
          <div className="flex flex-wrap gap-2 justify-start">
            
            <button
              type="button"
              onClick={() => setActiveTab('stats')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'stats'
                  ? 'bg-emerald-600 text-white border-emerald-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <TrendingUp size={14} className={activeTab === 'stats' ? 'text-white' : 'text-emerald-500'} />
              <span>الاحصائيات البيانية</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-slate-800 text-white border-slate-900 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <SlidersHorizontal size={14} className={activeTab === 'settings' ? 'text-white' : 'text-slate-500'} />
              <span>الاعدادات الأمنية</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('schools')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'schools'
                  ? 'bg-amber-600 text-white border-amber-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Building2 size={14} className={activeTab === 'schools' ? 'text-white' : 'text-amber-500'} />
              <span>إعدادات المواد والمدارس</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('staff_leadership')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'staff_leadership'
                  ? 'bg-indigo-600 text-white border-indigo-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <ShieldCheck size={14} className={activeTab === 'staff_leadership' ? 'text-white' : 'text-indigo-500'} />
              <span>القيادة المدرسية</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('staff_teachers')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'staff_teachers'
                  ? 'bg-blue-600 text-white border-blue-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Users size={14} className={activeTab === 'staff_teachers' ? 'text-white' : 'text-blue-500'} />
              <span>تقرير المعلمين</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('staff_specialists')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'staff_specialists'
                  ? 'bg-teal-600 text-white border-teal-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Users size={14} className={activeTab === 'staff_specialists' ? 'text-white' : 'text-teal-500'} />
              <span>تقرير الاخصائيين</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('staff_admins')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'staff_admins'
                  ? 'bg-violet-600 text-white border-violet-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <FileCheck size={14} className={activeTab === 'staff_admins' ? 'text-white' : 'text-violet-500'} />
              <span>تقرير الاداريين</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('staff_activity_supervisors')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'staff_activity_supervisors'
                  ? 'bg-purple-600 text-white border-purple-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Activity size={14} className={activeTab === 'staff_activity_supervisors' ? 'text-white' : 'text-purple-500'} />
              <span>تقرير مشرفي النشاط</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('staff_workers')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'staff_workers'
                  ? 'bg-pink-600 text-white border-pink-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Users size={14} className={activeTab === 'staff_workers' ? 'text-white' : 'text-pink-500'} />
              <span>تقرير العمال</span>
            </button>

          </div>
        </div>

        {/* Row 2: Advanced Reports & Auxiliary Services */}
        <div className="space-y-1.5 pt-1.5 border-t border-slate-150">
          <span className="block text-[10px] font-black text-slate-400 select-none">التقارير المتقدمة والخدمات المكملة للمنظومة:</span>
          <div className="flex flex-wrap gap-2 justify-start">

            <button
              type="button"
              onClick={() => setActiveTab('deficit_reports')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'deficit_reports'
                  ? 'bg-rose-700 text-white border-rose-800 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <AlertTriangle size={14} className={activeTab === 'deficit_reports' ? 'text-white' : 'text-rose-500'} />
              <span>تقارير العجز والزيادة والبحث</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('reports_absences_students')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'reports_absences_students'
                  ? 'bg-sky-600 text-white border-sky-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Calendar size={14} className={activeTab === 'reports_absences_students' ? 'text-white' : 'text-sky-500'} />
              <span>غياب الطلبة</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('reports_absences_teachers')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'reports_absences_teachers'
                  ? 'bg-red-600 text-white border-red-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <UserX size={14} className={activeTab === 'reports_absences_teachers' ? 'text-white' : 'text-red-500'} />
              <span>غياب العاملين</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('reports_visitors')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'reports_visitors'
                  ? 'bg-amber-750 text-white border-amber-850 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Clock size={14} className={activeTab === 'reports_visitors' ? 'text-white' : 'text-amber-600'} />
              <span>سجل الزوار والموجهين</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('reports_nutrition')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'reports_nutrition'
                  ? 'bg-emerald-700 text-white border-emerald-800 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Apple size={14} className={activeTab === 'reports_nutrition' ? 'text-white' : 'text-emerald-500'} />
              <span>التغذية المدرسية</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('exam_nomination')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'exam_nomination'
                  ? 'bg-rose-600 text-white border-rose-700 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <FileText size={14} className={activeTab === 'exam_nomination' ? 'text-white' : 'text-rose-500'} />
              <span>استمارات (1 سري)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('ai_deficit_report')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-black rounded-xl transition duration-150 border cursor-pointer ${
                activeTab === 'ai_deficit_report'
                  ? 'bg-indigo-700 text-white border-indigo-800 shadow-md scale-[1.02]'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200 shadow-2xs'
              }`}
            >
              <Sparkles size={14} className={activeTab === 'ai_deficit_report' ? 'text-white' : 'text-indigo-500'} />
              <span>التقرير الشامل بالذكاء الاصطناعي ✦</span>
            </button>

          </div>
        </div>

      </div>

      {/* 2. PERSISTENT CORE STATS DASHBOARD (Visible Only in Tab 0: Overview/Statistics) */}
      {activeTab === 0 && (
        <div className="bg-slate-900/70 backdrop-blur-md rounded-2xl border border-blue-900/30 p-5 shadow-md print:hidden space-y-4 animate-fade-in text-slate-200">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            
            {/* Total Schools Card */}
            <div className="bg-slate-850/90 rounded-xl border border-blue-950 p-4 shadow-sm flex justify-between items-center hover:border-blue-700/50 transition-all duration-300">
              <div>
                <span className="block text-slate-400 text-[10px] font-extrabold tracking-wide">المدارس المقيدة بالإدارة</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl font-black font-mono text-blue-400">{aggregatedAnalytics.totalSchools}</span>
                  <span className="text-[10px] font-bold text-slate-400">منشأة</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-blue-950/80 text-blue-400">
                <Building2 size={20} />
              </div>
            </div>

            {/* Total Teachers Card */}
            <div className="bg-slate-850/90 rounded-xl border border-blue-950 p-4 shadow-sm flex justify-between items-center hover:border-emerald-600/50 transition-all duration-300">
              <div>
                <span className="block text-slate-400 text-[10px] font-extrabold tracking-wide">إجمالي الكوادر التدريسية</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl font-black font-mono text-emerald-400">{aggregatedAnalytics.totalTeachers}</span>
                  <span className="text-[10px] font-bold text-emerald-500">معلم ومعلمة</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-emerald-950/80 text-emerald-400">
                <Users size={20} />
              </div>
            </div>

            {/* Core Coverage Percentage */}
            <div className="bg-slate-850/90 rounded-xl border border-blue-950 p-4 shadow-sm flex justify-between items-center hover:border-amber-600/50 transition-all duration-300">
              <div>
                <span className="block text-slate-400 text-[10px] font-extrabold tracking-wide">معدل التغطية والتوازن العام</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl font-black font-mono text-amber-400">{aggregatedAnalytics.generalCoveragePercentage}%</span>
                  <span className="text-[10px] font-bold text-amber-500">توازن الأنصبة</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-amber-950/80 text-amber-450">
                <TrendingUp size={20} />
              </div>
            </div>

            {/* Deficits vs Surpluses Summary */}
            <div className="bg-slate-850/90 rounded-xl border border-blue-950 p-4 shadow-sm flex justify-between items-center hover:border-indigo-600/50 transition-all duration-300">
              <div>
                <span className="block text-slate-400 text-[10px] font-extrabold tracking-wide">رصيد العجز / الوفرة الإجمالي</span>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span className="text-[11px] font-black text-rose-400 bg-rose-950/65 px-2 py-0.5 rounded font-mono">عجز: {aggregatedAnalytics.totalDeficit}</span>
                  <span className="text-[11px] font-black text-emerald-400 bg-emerald-950/65 px-2 py-0.5 rounded font-mono">فائض: {aggregatedAnalytics.totalSurplus}</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-indigo-950/80 text-indigo-400">
                <SlidersHorizontal size={20} />
              </div>
            </div>

          </div>

          {/* Supporting stats footer info */}
          <div className="flex flex-wrap gap-4 items-center justify-between text-[11px] text-slate-300 font-medium bg-slate-850 border border-blue-950/40 rounded-xl p-2.5 px-4">
            <div className="flex flex-wrap items-center gap-3">
              <span className="font-extrabold text-blue-400">مستخرجات كادر معاون إضافي:</span>
              <span>القيادات والوكلاء: <strong className="font-mono text-slate-100 font-extrabold">{leadership.length}</strong></span>
              <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
              <span>إداريون ومشرفون: <strong className="font-mono text-slate-100 font-extrabold">{aggregatedAnalytics.totalAdmins}</strong></span>
              <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
              <span>أخصائيون اجتماعيون ونفسيون: <strong className="font-mono text-slate-100 font-extrabold">{aggregatedAnalytics.totalSpecialists}</strong></span>
              <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
              <span>عمال وخدمات: <strong className="font-mono text-slate-100 font-extrabold">{aggregatedAnalytics.totalLabor}</strong></span>
            </div>

            <div className="text-[10px] text-slate-500 hidden sm:block">نظام المراقبة والتحليل الرقمي للإدارة التعليمية ✓</div>
          </div>
        </div>
      )}

      {/* 4. DYNAMIC TAB SUB-VIEW RENDER */}
      <div className="w-full font-sans text-slate-800">
        {activeTab === 'stats' && (
          <OverviewTab 
            analytics={aggregatedAnalytics} 
            schools={schools} 
            materials={materials} 
            materialCounts={materialCounts} 
            staff={staff} 
            visitors={visitors}
          />
        )}
        {activeTab === 'settings' && (
          <SystemSecuritySettingsTab 
            settings={settings}
            dbTick={dbTick}
          />
        )}
        {activeTab === 'schools' && (
          <SchoolMaterialsAndQuotasTab 
            schools={schools}
            materials={materials}
            materialCounts={materialCounts}
            settings={settings}
            dbTick={dbTick}
          />
        )}
        {activeTab === 'exam_nomination' && (
          <AdminExamNominationTab 
            schools={schools}
            dbTick={dbTick}
          />
        )}
        {activeTab === 'ai_deficit_report' && (
          <AIComprehensiveAnalysisTab 
            schools={schools}
            materials={materials}
            materialCounts={materialCounts}
            aggregatedAnalytics={aggregatedAnalytics}
          />
        )}
        {/* Reports tabs */}
        {['staff_leadership', 'staff_teachers', 'staff_specialists', 'staff_admins', 'staff_activity_supervisors', 'staff_workers', 'deficit_reports', 'reports_absences_students', 'reports_absences_teachers', 'reports_visitors', 'reports_nutrition'].includes(activeTab) && (
          <ReportsPrintingTab 
            schools={schools} 
            materials={materials} 
            materialCounts={materialCounts} 
            staff={staff} 
            visitors={visitors} 
            nutrition={nutrition}
            leadership={leadership}
            studentAbsences={studentAbsences}
            teacherAbsences={teacherAbsences}
            activeReportType={
              activeTab === 'staff_leadership' ? 'leadership' :
              activeTab === 'staff_teachers' ? 'teachers' :
              activeTab === 'staff_specialists' ? 'specialists' :
              activeTab === 'staff_admins' ? 'admins' :
              activeTab === 'staff_activity_supervisors' ? 'activity_supervisors' :
              activeTab === 'staff_workers' ? 'workers' :
              activeTab === 'deficit_reports' ? 'comprehensive' :
              activeTab === 'reports_absences_students' ? 'students_absences' :
              activeTab === 'reports_absences_teachers' ? 'teachers_absences' :
              activeTab === 'reports_visitors' ? 'visitors' :
              activeTab === 'reports_nutrition' ? 'nutrition' : 'school'
            }
          />
        )}
      </div>

    </div>
  );
}

// ----------------------------------------------------
// CUSTOM SCHOOL STAFF GAP TOOLTIP (For Interactive Recharts)
// ----------------------------------------------------
const SchoolGapTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const netGap = data.netGap;
    return (
      <div className="bg-[#111827]/95 border border-amber-500/35 text-white rounded-2xl p-4 shadow-2xl text-xs text-right font-medium font-sans min-w-[240px] backdrop-blur-xs">
        <p className="font-extrabold border-b border-white/10 pb-2 mb-2 text-amber-100 text-sm leading-tight">{data.name}</p>
        <div className="space-y-2">
          <div className="flex items-center gap-3 justify-between">
            <span className="font-mono font-black text-rose-450 bg-rose-500/10 px-2 py-0.5 rounded text-[11px]">
              {data.deficit} معلم
            </span>
            <span className="text-slate-300">إجمالي العجز:</span>
          </div>
          <div className="flex items-center gap-3 justify-between">
            <span className="font-mono font-black text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded text-[11px]">
              {data.surplus} معلم
            </span>
            <span className="text-slate-300">إجمالي الزيادة:</span>
          </div>
          
          <div className="border-t border-white/10 pt-2 mt-2 flex items-center gap-3 justify-between">
            {netGap < 0 ? (
              <span className="font-mono font-black text-rose-350 bg-red-500/15 px-2 py-0.5 rounded text-[11px]">
                عجز بقيمة {Math.abs(netGap)} معلم
              </span>
            ) : netGap > 0 ? (
              <span className="font-mono font-black text-emerald-300 bg-emerald-500/15 px-2 py-0.5 rounded text-[11px]">
                زيادة بقيمة {netGap} معلم
              </span>
            ) : (
              <span className="font-bold text-slate-300 font-mono">متوازن ومستقر 🤝</span>
            )}
            <span className="text-slate-250 font-bold">الرصيد الصافي الفعلي:</span>
          </div>
          
          <div className="text-[10px] text-slate-400 pt-1 flex justify-between items-center bg-white/5 px-2 py-1 rounded">
            <span className="font-bold text-slate-300">
              {data.stage === 'primary' ? 'ابتدائي' : data.stage === 'prep' ? 'إعدادي' : 'ثانوي'}
            </span>
            <span>مرحلة المدرسة:</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

// ----------------------------------------------------
// TAB 0: OVERVIEW/ANALYTICS DASHBOARD
// ----------------------------------------------------
function OverviewTab({ 
  analytics, 
  schools, 
  materials, 
  materialCounts, 
  staff, 
  visitors 
}: { 
  analytics: any; 
  schools: School[]; 
  materials: Material[]; 
  materialCounts: MaterialCount[]; 
  staff: StaffMember[]; 
  visitors: VisitorLog[];
}) {
  const [selectedDashboardStage, setSelectedDashboardStage] = useState<'all' | 'primary' | 'prep' | 'sec'>('all');

  // Interactive configurations for the school gaps distribution chart
  const [selectedSchoolStage, setSelectedSchoolStage] = useState<'all' | 'primary' | 'prep' | 'sec'>('all');
  const [analyticsViewType, setAnalyticsViewType] = useState<'all' | 'deficit' | 'surplus'>('deficit');
  const [schoolsLimit, setSchoolsLimit] = useState<number>(10);
  const [schoolSearchQuery, setSchoolSearchQuery] = useState<string>('');

  // Computes deficit and surplus for each individual school
  const schoolGapData = useMemo(() => {
    const rawData = schools.map(school => {
      let totalDeficit = 0;
      let totalSurplus = 0;

      materials.forEach(material => {
        const count = materialCounts.find(c => c.schoolId === school.id && c.materialId === material.id);
        const metrics = dbInstance.calculateMaterialMetrics(school, material, count);
        if (metrics.applicable) {
          totalDeficit += (metrics.deficit || 0);
          totalSurplus += (metrics.surplus || 0);
        }
      });

      return {
        id: school.id,
        name: school.name,
        stage: school.stage,
        deficit: Number(totalDeficit.toFixed(1)),
        surplus: Number(totalSurplus.toFixed(1)),
        netGap: Number((totalSurplus - totalDeficit).toFixed(1)),
        totalGaps: Number((totalDeficit + totalSurplus).toFixed(1))
      };
    });

    // Filter by stage
    let filtered = rawData;
    if (selectedSchoolStage !== 'all') {
      filtered = filtered.filter(item => item.stage === selectedSchoolStage);
    }

    // Filter by search query
    if (schoolSearchQuery.trim()) {
      const q = schoolSearchQuery.toLowerCase();
      filtered = filtered.filter(item => item.name.toLowerCase().includes(q));
    }

    // Sort according to user preference
    if (analyticsViewType === 'deficit') {
      filtered.sort((a, b) => b.deficit - a.deficit);
    } else if (analyticsViewType === 'surplus') {
      filtered.sort((a, b) => b.surplus - a.surplus);
    } else {
      filtered.sort((a, b) => b.totalGaps - a.totalGaps);
    }

    // Slice to the chosen limit
    return filtered.slice(0, schoolsLimit);
  }, [schools, materials, materialCounts, selectedSchoolStage, analyticsViewType, schoolsLimit, schoolSearchQuery]);

  // Compute percentages of deficit and surplus for each material
  const materialPercentageAnalytics = useMemo(() => {
    return materials.map(m => {
      let totalNeeded = 0;
      let totalDeficit = 0;
      let totalSurplus = 0;
      let totalPresent = 0;

      schools.forEach(school => {
        const count = materialCounts.find(c => c.schoolId === school.id && c.materialId === m.id);
        const metrics = dbInstance.calculateMaterialMetrics(school, m, count);
        if (metrics.applicable) {
          totalNeeded += (metrics.needed || 0);
          totalDeficit += (metrics.deficit || 0);
          totalSurplus += (metrics.surplus || 0);
          totalPresent += (metrics.present || 0);
        }
      });

      const deficitRate = totalNeeded > 0 ? Number(((totalDeficit / totalNeeded) * 100).toFixed(1)) : 0;
      const surplusRate = totalNeeded > 0 ? Number(((totalSurplus / totalNeeded) * 100).toFixed(1)) : 0;
      const coverageRate = totalNeeded > 0 ? Number(((totalPresent / totalNeeded) * 100).toFixed(1)) : 100;

      return {
        id: m.id,
        name: m.name,
        stage: m.stage,
        needed: Number(totalNeeded.toFixed(1)),
        present: Number(totalPresent.toFixed(1)),
        deficit: Number(totalDeficit.toFixed(1)),
        surplus: Number(totalSurplus.toFixed(1)),
        deficitRate,
        surplusRate,
        coverageRate
      };
    }).filter(item => {
      if (item.needed <= 0) return false;
      if (selectedDashboardStage === 'all') return true;
      return item.stage === selectedDashboardStage;
    });
  }, [schools, materials, materialCounts, selectedDashboardStage]);

  // 1. Deficit & Surplus by Stage
  const stageAnalytics = useMemo(() => {
    const stages: Record<'primary' | 'prep' | 'sec', { name: string; deficit: number; surplus: number }> = {
      primary: { name: 'ابتدائي', deficit: 0, surplus: 0 },
      prep: { name: 'إعدادي', deficit: 0, surplus: 0 },
      sec: { name: 'ثانوي', deficit: 0, surplus: 0 },
    };

    schools.forEach(school => {
      materials.forEach(material => {
        const count = materialCounts.find(c => c.schoolId === school.id && c.materialId === material.id);
        const metrics = dbInstance.calculateMaterialMetrics(school, material, count);
        if (metrics.applicable) {
          const stage = material.stage; // 'primary' | 'prep' | 'sec'
          if (stages[stage]) {
            stages[stage].deficit += metrics.deficit;
            stages[stage].surplus += metrics.surplus;
          }
        }
      });
    });

    return Object.values(stages);
  }, [schools, materials, materialCounts]);

  // 2. Deficit & Surplus by Material / Subject (Top subjects with deficits/surplus)
  const materialAnalytics = useMemo(() => {
    const map: Record<string, { name: string; deficit: number; surplus: number }> = {};
    
    materials.forEach(m => {
      map[m.id] = { name: m.name, deficit: 0, surplus: 0 };
    });

    schools.forEach(school => {
      materials.forEach(material => {
        const count = materialCounts.find(c => c.schoolId === school.id && c.materialId === material.id);
        const metrics = dbInstance.calculateMaterialMetrics(school, material, count);
        if (metrics.applicable) {
          if (map[material.id]) {
            map[material.id].deficit += metrics.deficit;
            map[material.id].surplus += metrics.surplus;
          }
        }
      });
    });

    return Object.values(map)
      .filter(item => item.deficit > 0 || item.surplus > 0)
      .sort((a, b) => (b.deficit + b.surplus) - (a.deficit + a.surplus))
      .slice(0, 6);
  }, [schools, materials, materialCounts]);

  // 3. Top 5 schools with highest student absence rates
  const schoolAbsenceAnalytics = useMemo(() => {
    const absences = dbInstance.getStudentAbsences();
    const list = schools.map(school => {
      const schoolAbs = absences.filter(a => a.schoolId === school.id);
      let totalReg = 0;
      let totalAbs = 0;

      schoolAbs.forEach(abs => {
        abs.records.forEach(rec => {
          totalReg += (Number(rec.registered) || 0);
          totalAbs += (Number(rec.absent) || 0);
        });
      });

      const rate = totalReg > 0 ? Number(((totalAbs / totalReg) * 100).toFixed(1)) : 0;
      return { name: school.name, rate };
    })
    .filter(item => item.rate > 0)
    .sort((a, b) => b.rate - a.rate)
    .slice(0, 5);

    return list;
  }, [schools]);

  return (
    <div className="space-y-6">
      {/* Analytics charts panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* FULL SUBJECTS DEFICIT AND SURPLUS % DASHBOARD (RECHARTS) */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-150 p-6 space-y-5 lg:col-span-2 animate-fade-in">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-4">
            <div>
              <h4 className="text-xs font-black text-rose-500 uppercase tracking-wider flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block animate-pulse"></span>
                مؤشر عافية الأنصبة بالتخصصات
              </h4>
              <h3 className="text-sm font-extrabold text-[#0D47A1] mt-1">
                لوحة بيانات نسب العجز والزيادة بالتخصص والمرحلة الميدانية
              </h3>
            </div>
            
            {/* Interactive stage filter tabs */}
            <div className="flex bg-slate-100 p-1 rounded-xl border gap-1">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'primary', label: 'ابتدائي' },
                { id: 'prep', label: 'إعدادي' },
                { id: 'sec', label: 'ثانوي' }
              ].map(tab => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setSelectedDashboardStage(tab.id as any)}
                  className={`px-3 py-1.5 text-[11px] font-black rounded-lg transition-all cursor-pointer ${
                    selectedDashboardStage === tab.id
                      ? 'bg-[#1565C0] text-white shadow-xs'
                      : 'text-slate-600 hover:text-black hover:bg-slate-200/50'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            
            {/* The Main Recharts Double Grouped Bar Chart */}
            <div className="lg:col-span-2 space-y-3">
              <div className="flex justify-between items-center text-xs text-slate-500 font-bold px-1">
                <span>نمط الرسم البياني: عجز مئوي للمواد المحددة مقارنة بالأنصبة</span>
                <span className="bg-rose-50 text-rose-700 px-2.5 py-0.5 rounded text-[10px]">تعديل تلقائي</span>
              </div>
              <DoubleGroupedBarChart 
                data={materialPercentageAnalytics}
                xKey="name"
                bar1Key="deficitRate"
                bar1Name="نسبة العجز للمادة (%)"
                bar2Key="surplusRate"
                bar2Name="نسبة الزيادة للمادة (%)"
                bar1Color="#EF5350"
                bar2Color="#10B981"
                height={280}
              />
            </div>

            {/* Side summary list of detailed metrics */}
            <div className="space-y-4">
              <h4 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider border-b pb-1.5">تحليل احتياجات الكادر بالتفصيل</h4>
              <div className="overflow-y-auto max-h-[280px] pr-1 space-y-2.5">
                {materialPercentageAnalytics.map(item => (
                  <div key={item.id} className="p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-100 transition duration-150 text-xs flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold text-slate-900">{item.name}</span>
                      <span className="bg-blue-50 text-[#0D47A1] px-2 py-0.5 rounded-md text-[9px] font-black">
                        {item.stage === 'primary' ? 'ابتدائي' : item.stage === 'prep' ? 'إعدادي' : 'ثانوي'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-1 text-[10px] text-slate-500 font-semibold border-b border-dashed pb-1.5">
                      <div>المطلوب: <span className="font-mono text-slate-900 font-bold">{item.needed}</span></div>
                      <div>الموجود فعلياً: <span className="font-mono text-slate-900 font-bold">{item.present}</span></div>
                    </div>

                    <div className="flex justify-between items-center text-[10px]">
                      <div className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 inline-block"></span>
                        <span className="text-rose-700 font-black">العجز: {item.deficit} ({item.deficitRate}%)</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
                        <span className="text-emerald-700 font-black">الزيادة: {item.surplus} ({item.surplusRate}%)</span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px] font-bold text-slate-400">
                        <span>معدل الكفاية:</span>
                        <span className={`${item.coverageRate < 75 ? 'text-red-650' : item.coverageRate < 100 ? 'text-amber-600' : 'text-emerald-700'}`}>{item.coverageRate}%</span>
                      </div>
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ${
                            item.coverageRate < 75 ? 'bg-rose-500' : item.coverageRate < 100 ? 'bg-amber-500' : 'bg-emerald-500'
                          }`} 
                          style={{ width: `${Math.min(item.coverageRate, 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
        
        {/* Absence Student logs */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-3">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">مؤشر الانضباط العام وعافية الحضور</h4>
          <h3 className="text-sm font-extrabold text-[#1565C0] border-b border-slate-100 pb-2">
            متوسط حضور وغياب التلاميذ بالإدارة اليومي
          </h3>
          <CustomDoughnutChart 
            data={[
              { name: 'إجمالي الحضور التلاميذ', value: analytics.studentAttendanceRate || 92 },
              { name: 'إجمالي الغياب بالمدارس', value: analytics.studentAbsenceRate || 8 }
            ]}
          />
        </div>

        {/* Top 5 schools by student absences */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-3">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">سجل الإنذار المبكر المدرسي</h4>
          <h3 className="text-sm font-extrabold text-red-650 border-b border-slate-100 pb-2">
            المدارس الخمسة الأكثر غياباً للتلاميذ اليوم (%)
          </h3>
          {schoolAbsenceAnalytics.length === 0 ? (
            <div className="flex items-center justify-center h-56 text-slate-400 text-xs font-semibold">
              لا توجد حالات غياب تتخطى النسب الطبيعية اليوم بالمدارس
            </div>
          ) : (
            <CustomBarChart 
              data={schoolAbsenceAnalytics}
              xKey="name"
              yKey="rate"
              color="#EF5350"
              height={220}
            />
          )}
        </div>

        {/* Deficits and surpluses breakdown by school stage */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-3">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">التوزيع الهيكلي التناظري</h4>
          <h3 className="text-sm font-extrabold text-amber-600 border-b border-slate-100 pb-2">
            مؤشر العجز والزيادة حسب المراحل الدراسية الثلاث
          </h3>
          <DoubleGroupedBarChart 
            data={stageAnalytics}
            xKey="name"
            bar1Key="deficit"
            bar1Name="العجز الكلي بالحصص"
            bar2Key="surplus"
            bar2Name="الزيادة الكلية بالحصص"
            bar1Color="#F43F5E"
            bar2Color="#10B981"
            height={220}
          />
        </div>

        {/* Deficits and surpluses breakdown by subject/material */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-3">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">مؤشر الاحتياج التخصصي التراكمي</h4>
          <h3 className="text-sm font-extrabold text-indigo-700 border-b border-slate-100 pb-2">
            تحليل العجز والزيادة لأهم التخصصات والمواد الدراسية
          </h3>
          <DoubleGroupedBarChart 
            data={materialAnalytics}
            xKey="name"
            bar1Key="deficit"
            bar1Name="العجز الفعلي للكوادر"
            bar2Key="surplus"
            bar2Name="الفائض التخصصي الكلي"
            bar1Color="#E11D48"
            bar2Color="#059669"
            height={220}
          />
        </div>

        {/* INTERACTIVE COMPREHENSIVE SCHOOL STAFF GAP DISTRIBUTION (NEW RECHARTS COMPONENT) */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-150 p-6 space-y-6 lg:col-span-2 animate-fade-in">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-4">
            <div>
              <h4 className="text-xs font-black text-indigo-500 uppercase tracking-wider flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 inline-block animate-pulse"></span>
                خريطة توزيع الفجوات والأنصبة بالمدارس
              </h4>
              <h3 className="text-sm font-extrabold text-[#0D47A1] mt-1">
                التحليل التفاعلي لتوزيع عجز وزيادة الكوادر في مدارس أبو حماد
              </h3>
            </div>

            {/* Stage filter tabs */}
            <div className="flex bg-slate-100 p-1 rounded-xl border gap-1 self-stretch md:self-auto justify-center">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'primary', label: 'ابتدائي' },
                { id: 'prep', label: 'إعدادي' },
                { id: 'sec', label: 'ثانوي' }
              ].map(tab => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setSelectedSchoolStage(tab.id as any)}
                  className={`px-3 py-1.5 text-[11px] font-black rounded-lg transition-all cursor-pointer ${
                    selectedSchoolStage === tab.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-black hover:bg-slate-200/50'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Controls Bar for interactive queries */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-50/75 rounded-xl border border-slate-100">
            {/* Search Input */}
            <div className="relative min-w-[240px] flex-1 max-w-sm">
              <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                <Search size={14} />
              </span>
              <input
                type="text"
                placeholder="ابحث عن مدرسة بالتحديد..."
                value={schoolSearchQuery}
                onChange={(e) => setSchoolSearchQuery(e.target.value)}
                className="w-full pr-9 pl-3 py-2 bg-white text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold"
              />
            </div>

            {/* Visual sorting filter */}
            <div className="flex flex-wrap gap-2 items-center text-xs">
              <span className="text-slate-550 font-black">ترتيب حسب:</span>
              <div className="flex bg-white p-0.5 rounded-lg border">
                {[
                  { id: 'deficit', label: 'الأكثر عجزاً 🔴' },
                  { id: 'surplus', label: 'الأكثر زيادة 🟢' },
                  { id: 'all', label: 'الحجم الكلي للفجوة 📊' }
                ].map(opt => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setAnalyticsViewType(opt.id as any)}
                    className={`px-3 py-1.5 text-[10px] font-black rounded-md transition ${
                      analyticsViewType === opt.id
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* School Limit Selection slider */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-550 font-black">عرض حد أقصى:</span>
              <select
                value={schoolsLimit}
                onChange={(e) => setSchoolsLimit(Number(e.target.value))}
                className="bg-white border rounded-lg px-2.5 py-1.5 font-bold text-slate-750 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
              >
                <option value={5}>خمسة مدارس</option>
                <option value={10}>10 مدارس</option>
                <option value={20}>20 مدرسة</option>
                <option value={50}>كل المدارس</option>
              </select>
            </div>
          </div>

          {/* Interactive Chart Area */}
          <div className="w-full h-80">
            {schoolGapData.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full border border-dashed border-slate-200 rounded-xl bg-slate-50/50 p-6 text-center space-y-1">
                <AlertTriangle size={32} className="text-amber-500 animate-pulse" />
                <h4 className="text-xs font-black text-slate-800">لا توجد مدارس مطابقة للبحث أو للخيارات المحددة</h4>
                <p className="text-[10px] text-slate-450 font-bold">يرجى تعديل الكلمات المدخلة أو تغيير مرشح العرض للمرحلة والترتيب</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart
                  data={schoolGapData}
                  margin={{ top: 10, right: 10, left: 10, bottom: 25 }}
                >
                  <RechartsCartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                  <RechartsXAxis 
                    dataKey="name" 
                    tickLine={false} 
                    axisLine={{ stroke: '#E2E8F0' }} 
                    tick={{ fill: '#475569', fontSize: 10, fontWeight: 700 }}
                    interval={0}
                    angle={-15}
                    textAnchor="end"
                  />
                  <RechartsYAxis 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 'medium' }} 
                    orientation="right"
                  />
                  <RechartsTooltip content={<SchoolGapTooltip />} />
                  <RechartsLegend 
                    verticalAlign="top" 
                    height={36} 
                    iconType="circle"
                    align="right"
                    wrapperStyle={{ paddingBottom: '10px' }}
                  />
                  <RechartsBar 
                    name="إجمالي عجز الكوادر (عدد المعلمين المطلوب)" 
                    dataKey="deficit" 
                    fill="#F43F5E" 
                    radius={[4, 4, 0, 0]} 
                    isAnimationActive={true}
                    animationDuration={750}
                  />
                  <RechartsBar 
                    name="إجمالي الفائض بالكوادر (منتدب/زيادة)" 
                    dataKey="surplus" 
                    fill="#10B981" 
                    radius={[4, 4, 0, 0]} 
                    isAnimationActive={true}
                    animationDuration={750}
                  />
                </RechartsBarChart>
              </ResponsiveContainer>
            )}
          </div>
          <div className="text-[10px] text-slate-400 text-center font-bold">
            ✦ يُمكنك الرنو والمرور بمؤشر الماوس فوق الأعمدة لرؤية الحصيلة الرقمية الصافية والتحليل التوازني الدقيق لكل معلم ومادة وعافية المدرسة.
          </div>
        </div>

        {/* Visitors activity logs */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-3 lg:col-span-2">
          <h3 className="text-sm font-bold text-slate-800 border-b border-slate-100 pb-2">
            معدل الزيارات والتوجيه بالإدارة مؤخراً
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {visitors.length === 0 ? (
              <div className="text-center p-6 text-slate-400 text-xs md:col-span-2">
                لا توجد سجلات زيارة للموجهين مقيدة بالإدارة حالياً
              </div>
            ) : (
              visitors.slice(0, 4).map(v => (
                <div key={v.id} className="flex justify-between items-center bg-slate-50 p-3 rounded-xl border border-slate-100 transition-all duration-300 hover:bg-slate-100/75">
                  <div>
                    <h4 className="text-xs font-extrabold text-slate-900 leading-normal">{v.visitorName}</h4>
                    <p className="text-[10px] text-slate-500 leading-normal mt-0.5">{v.jobTitle} - <span className="font-bold text-slate-600">{v.schoolName}</span></p>
                  </div>
                  <span className="text-[10px] font-mono font-bold text-slate-450 shrink-0 bg-white border border-slate-100 px-2 py-0.5 rounded-md">{v.date}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Read-only Statistics Box 1: Material Default Quotas */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-3">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">أنصبة المواد والأنصبة الثابتة بالوزارة</h4>
          <h3 className="text-sm font-extrabold text-slate-800 border-b border-slate-100 pb-2 flex justify-between items-center">
            <span>بيان أنصبة الحصص الأسبوعية الافتراضية لكل مادة</span>
            <span className="text-[10px] bg-slate-100 font-bold px-2 py-0.5 rounded text-slate-650">جدول إحصائي مقروء</span>
          </h3>
          <div className="overflow-y-auto max-h-60 border rounded-lg border-slate-100">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 text-slate-705 font-bold">
                <tr>
                  <th className="p-2 border-b">اسم المادة</th>
                  <th className="p-2 border-b text-center">المرحلة الدراسية</th>
                  <th className="p-2 border-b text-center">النصاب الثابت</th>
                </tr>
              </thead>
              <tbody>
                {materials.map(m => (
                  <tr key={m.id} className="border-b hover:bg-slate-50/50">
                    <td className="p-2 font-bold text-slate-900">{m.name}</td>
                    <td className="p-2 text-center text-slate-600">
                      {m.stage === 'primary' ? 'ابتدائي' : m.stage === 'prep' ? 'إعدادي' : 'ثانوي'}
                    </td>
                    <td className="p-2 text-center text-[#0D47A1] font-black font-mono bg-blue-50/20">{m.quota || 18} حصة</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Read-only Statistics Box 2: Registered Schools & Metadata */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-3">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">سجل المنشآت والصفوف المانحة</h4>
          <h3 className="text-sm font-extrabold text-[#1565C0] border-b border-slate-100 pb-2 flex justify-between items-center">
            <span>بيان الصفوف وحجرات الفصول الموثقة بالمدارس</span>
            <span className="text-[10px] bg-blue-50 text-blue-800 font-black px-2 py-0.5 rounded border border-blue-100">إحصاء كشوف مالي</span>
          </h3>
          <div className="overflow-y-auto max-h-60 border rounded-lg border-slate-100">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 text-slate-705 font-bold">
                <tr>
                  <th className="p-2 border-b">اسم المنشأة التعليمية</th>
                  <th className="p-2 border-b text-center">عدد حجرات الفصول</th>
                  <th className="p-2 border-b text-center">بنين وبنات</th>
                </tr>
              </thead>
              <tbody>
                {schools.map(s => (
                  <tr key={s.id} className="border-b hover:bg-slate-50/50">
                    <td className="p-2 font-black text-slate-900">{s.name}</td>
                    <td className="p-2 text-center font-mono font-bold text-slate-800 bg-slate-50">{s.classroomsCount} فصل</td>
                    <td className="p-2 text-center font-mono text-emerald-800 bg-emerald-50/20">
                      بنين: {s.boysCount || 0} | بنات: {s.girlsCount || 0}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Read-only Statistics Box 3: General Deficit & Surplus Ledger */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-3 lg:col-span-2">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">حصر العجز والزيادة العام بالمدارس</h4>
          <h3 className="text-sm font-extrabold text-[#D32F2F] border-b border-slate-100 pb-2 flex justify-between items-center">
            <span>جدول المراقبة التحليلية لإجمالي العجز والزيادة بالتخصصات والمدارس</span>
            <span className="text-[10px] bg-rose-50 text-rose-800 font-black px-2 py-0.5 rounded border border-rose-105 animate-pulse">رصد عجز فوري</span>
          </h3>
          <div className="overflow-x-auto max-h-80 border rounded-lg border-slate-150">
            <table className="w-full text-right text-xs border-collapse">
              <thead className="bg-[#1e293b] text-white font-bold text-[11px] sticky top-0">
                <tr>
                  <th className="p-2.5 border text-right bg-[#1e293b]" style={{ position: 'sticky', right: 0, zIndex: 10 }}>اسم المدرسة</th>
                  {materials.map(m => (
                    <th key={m.id} className="p-2 border text-center font-bold" style={{ minWidth: '95px' }}>{m.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {schools.map(sch => (
                  <tr key={sch.id} className="border-b hover:bg-slate-50">
                    <td className="p-2.5 font-black border text-slate-900 bg-slate-50/95 sticky right-0" style={{ zIndex: 5 }}>{sch.name}</td>
                    {materials.map(mat => {
                      const count = materialCounts.find(c => c.schoolId === sch.id && c.materialId === mat.id);
                      const metr = dbInstance.calculateMaterialMetrics(sch, mat, count);
                      if (!metr.applicable) {
                        return (
                          <td key={mat.id} className="p-2 text-center border text-slate-350 bg-slate-50 select-none">---</td>
                        );
                      }
                      return (
                        <td key={mat.id} className="p-2 text-center border font-mono font-bold leading-tight">
                          {metr.deficit > 0 ? (
                            <span className="text-rose-650 bg-rose-50 px-1 py-0.5 rounded block text-[10px]">-{metr.deficit}</span>
                          ) : metr.surplus > 0 ? (
                            <span className="text-emerald-700 bg-emerald-50 px-1 py-0.5 rounded block text-[10px] font-black">+{metr.surplus}</span>
                          ) : (
                            <span className="text-indigo-850 bg-indigo-50 px-1 py-0.5 rounded block text-[10px]">كافٍ</span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-[10px] text-slate-400 font-bold mt-1 text-left">(*) ملاحظة: هذا الجدول يحسب كفايات المعلمين الأسبوعية تلقائياً بناءً على فصول المنشأة والمادة المصنفة.</p>
        </div>

      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 1: MATERIALS & DEFAULT STAGES MANAGEMENT
// ----------------------------------------------------
function MaterialsManagementTab({ materials, dbTick }: { materials: Material[]; dbTick: number }) {
  const [list, setList] = useState<Material[]>(materials);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editStage, setEditStage] = useState<'primary' | 'prep' | 'sec'>('primary');
  const [editQuota, setEditQuota] = useState(20);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({ name: '', stage: 'primary' as 'primary' | 'prep' | 'sec', quota: 20 });

  useEffect(() => {
    setList(materials);
  }, [materials, dbTick]);

  const reload = () => {
    setList(dbInstance.getMaterials());
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;
    setSaving(true);
    const newMat: Material = {
      id: 'mat_' + Date.now(),
      name: formData.name.trim(),
      stage: formData.stage,
      quota: Number(formData.quota)
    };
    dbInstance.saveMaterial(newMat);
    setFormData({ name: '', stage: 'primary', quota: 20 });
    setSaving(false);
    reload();
    alert('تم إضافة المادة وحفظها بنظام الإدارة بنجاح.');
  };

  const startEdit = (mat: Material) => {
    setEditingId(mat.id);
    setEditName(mat.name);
    setEditStage(mat.stage);
    setEditQuota(mat.quota);
  };

  const handleSaveEdit = (id: string) => {
    if (!editName.trim()) {
      alert('الرجاء إدخال اسم المادة');
      return;
    }
    const updated: Material = {
      id,
      name: editName,
      stage: editStage,
      quota: Number(editQuota)
    };
    dbInstance.saveMaterial(updated);
    setEditingId(null);
    reload();
    alert('تم تعديل سجل المادة ونصاب الحصص وحفظه بنجاح بنظام الإدارة.');
  };

  const handleDelete = (id: string) => {
    if (confirm('تنبيه: حذف المادة سيقوم بإزالتها تلقائياً من قوائم الحساب لكل المدارس وحذف أنصبتها. هل ترغب في الاستمرار؟')) {
      dbInstance.deleteMaterial(id);
      reload();
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Create form */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4 h-fit">
        <h2 className="text-md font-bold text-slate-900 border-b border-slate-100 pb-2">
          إدراج مادة تعليمية جديدة للمدارس
        </h2>

        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-600 mb-1">اسم المادة التعليمية رباعياً *</label>
            <input
              type="text"
              placeholder="مثال: لغة ألمانية"
              value={formData.name}
              onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
              className="w-full px-3 py-1.5 text-sm border border-slate-200 rounded text-right focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 mb-1">المرحلة التعليمية المستهدفة</label>
            <select
              value={formData.stage}
              onChange={e => setFormData(p => ({ ...p, stage: e.target.value as any, quota: e.target.value === 'primary' ? 20 : 18 }))}
              className="w-full px-3 py-1.5 text-sm border border-slate-200 rounded text-right bg-white focus:outline-none"
            >
              <option value="primary">ابتدائي (حصص النصاب = ٢٠)</option>
              <option value="prep">إعدادي (حصص النصاب = ١٨)</option>
              <option value="sec">ثانوي عام/فني (حصص النصاب = ١٨)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 mb-1">نصاب الحصص الافتراضي للحمل الدراسي *</label>
            <input
              type="number"
              min="0.1"
              step="any"
              value={formData.quota}
              onChange={e => setFormData(p => ({ ...p, quota: parseFloat(e.target.value) || 1 }))}
              className="w-full px-3 py-1.5 text-sm border border-slate-200 rounded text-right font-mono font-bold"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-2 bg-gradient-to-l from-[#1565C0] to-[#1E88E5] hover:brightness-110 active:scale-95 text-white rounded text-xs font-black shadow-md transition-all shrink-0 cursor-pointer"
          >
            {saving ? 'جاري إرسال المفهوم...' : 'تأكيد وإدراج المادة بالبوابة المالية'}
          </button>
        </form>
      </div>

      {/* Materials List tables */}
      <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
        <h3 className="text-sm font-bold text-slate-900">سجل المواد التخصصية المعتمدة بالإدارة</h3>

        <div className="overflow-x-auto border border-slate-200/80 rounded-xl shadow-xs transition-all duration-300">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-gradient-to-r from-[#0D47A1] via-[#1565C0] to-[#1E88E5] text-white font-bold">
                <th className="p-3 border border-blue-700/10">اسم المادة المعتمد</th>
                <th className="p-3 border border-blue-700/10 text-center">المرحلة</th>
                <th className="p-3 border border-blue-700/10 text-center">نصاب تفريد الحصص التلقائي</th>
                <th className="p-3 border border-blue-700/10 text-center">الإجراءات والخيارات</th>
              </tr>
            </thead>
            <tbody>
              {list.map(mat => {
                const isEditing = mat.id === editingId;
                return (
                  <tr key={mat.id} className="hover:bg-gradient-to-r hover:from-blue-50/50 hover:to-indigo-50/30 transition-all duration-300 ease-out border-b border-slate-100/80">
                    <td className="p-3 font-semibold text-slate-800">
                      {isEditing ? (
                        <input
                          type="text"
                          value={editName}
                          onChange={e => setEditName(e.target.value)}
                          className="px-2 py-1 text-xs border border-slate-250 bg-white rounded text-right w-full"
                        />
                      ) : (
                        mat.name
                      )}
                    </td>
                    <td className="p-3 text-center">
                      {isEditing ? (
                        <select
                          value={editStage}
                          onChange={e => setEditStage(e.target.value as any)}
                          className="px-2 py-1 text-xs border border-slate-250 bg-white rounded text-right focus:outline-none"
                        >
                          <option value="primary">ابتدائي</option>
                          <option value="prep">إعدادي</option>
                          <option value="sec">ثانوي</option>
                        </select>
                      ) : (
                        <span className="bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded font-bold text-[10px]">
                          {mat.stage === 'primary' ? 'ابتدائي' : mat.stage === 'prep' ? 'إعدادي' : 'ثانوي'}
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-center font-mono font-bold text-blue-700 text-sm">
                      {isEditing ? (
                        <input
                          type="number"
                          value={editQuota}
                          onChange={e => setEditQuota(Number(e.target.value) || 0)}
                          className="px-2 py-1 text-xs border border-slate-250 bg-white rounded text-center w-16"
                        />
                      ) : (
                        `${mat.quota} حصة`
                      )}
                    </td>
                    <td className="p-2.5 text-center">
                      {isEditing ? (
                        <div className="flex items-center gap-1.5 justify-center">
                          <button
                            type="button"
                            onClick={() => handleSaveEdit(mat.id)}
                            className="p-1 px-2.5 bg-emerald-600 text-white hover:bg-emerald-750 font-bold rounded text-[10px] flex items-center gap-0.5 cursor-pointer shadow-3xs"
                          >
                            <Save size={10} />
                            حفظ
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="p-1 px-2 border border-slate-200 text-slate-500 hover:bg-slate-100 font-bold rounded text-[10px] cursor-pointer"
                          >
                            إلغاء
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 justify-center">
                          <button
                            type="button"
                            onClick={() => startEdit(mat)}
                            className="p-1 px-2 bg-indigo-50 border border-indigo-100 hover:bg-indigo-150 text-indigo-750 font-bold rounded text-[10px] cursor-pointer flex items-center gap-0.5"
                          >
                            <Edit size={10} />
                            تعديل
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(mat.id)}
                            className="p-1 px-2 text-rose-650 hover:bg-rose-50 rounded transition text-[10px] font-bold cursor-pointer inline-flex items-center gap-0.5"
                          >
                            <Trash2 size={10} />
                            حذف
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}


function SchoolMaterialsAndQuotasTab({ 
  schools, 
  materials, 
  materialCounts, 
  settings, 
  dbTick 
}: { 
  schools: School[]; 
  materials: Material[]; 
  materialCounts: any[]; 
  settings: SystemSettings; 
  dbTick: number; 
}) {
  const [subTab, setSubTab] = useState<'materials' | 'base' | 'trash'>('materials');

  return (
    <div className="space-y-6">
      <div className="flex gap-2.5 justify-center md:justify-start print:hidden border-b border-slate-200 pb-3 flex-wrap">
        <button
          type="button"
          onClick={() => setSubTab('materials')}
          className={`px-5 py-2.5 text-xs font-black rounded-lg transition border cursor-pointer ${
            subTab === 'materials'
              ? 'bg-blue-600 text-white border-blue-700 shadow-sm animate-fade-in'
              : 'bg-white text-slate-650 hover:bg-slate-50 border-slate-200'
          }`}
        >
          📂 المواد والأنشطة والأنصبة المعتمدة
        </button>
        <button
          type="button"
          onClick={() => setSubTab('base')}
          className={`px-5 py-2.5 text-xs font-black rounded-lg transition border cursor-pointer ${
            subTab === 'base'
              ? 'bg-blue-600 text-white border-blue-700 shadow-sm animate-fade-in'
              : 'bg-white text-slate-650 hover:bg-slate-50 border-slate-200'
          }`}
        >
          🏫 ميزانية المدارس والأنصبة الافتراضية
        </button>
        <button
          type="button"
          onClick={() => setSubTab('trash')}
          className={`px-5 py-2.5 text-xs font-black rounded-lg transition border cursor-pointer ${
            subTab === 'trash'
              ? 'bg-rose-600 text-white border-rose-700 shadow-sm animate-fade-in'
              : 'bg-white text-slate-650 hover:bg-slate-50 border-slate-200'
          }`}
        >
          🗑️ سلة المهملات والتعافي السريع
        </button>
      </div>

      <div>
        {subTab === 'materials' && (
          <MaterialsManagementTabInner materials={materials} dbTick={dbTick} />
        )}
        {subTab === 'base' && (
          <BaseQuotasTabInner settings={settings} schools={schools} dbTick={dbTick} />
        )}
        {subTab === 'trash' && (
          <TrashManagementTabInner dbTick={dbTick} />
        )}
      </div>
    </div>
  );
}

// ----------------------------------------------------
// TAB 2: DEFAULT BASE QUOTAS VALUES CONFIG & SCHOOL DIRECTORY MANAGEMENT
// ----------------------------------------------------
function BaseQuotasTab({ settings, schools, dbTick }: { settings: any; schools: School[]; dbTick: number }) {
  const [pri, setPri] = useState(settings.quota_primary);
  const [prep, setPrep] = useState(settings.quota_prep);
  const [sec, setSec] = useState(settings.quota_sec);
  const [savingSettings, setSavingSettings] = useState(false);

  // Schools list local state for inline editing
  const [localSchools, setLocalSchools] = useState<School[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStage, setFilterStage] = useState<string>('all');

  // Bulk import states
  const [bulkText, setBulkText] = useState('');
  const [bulkStage, setBulkStage] = useState<'primary' | 'prep' | 'sec' | 'basic' | 'languages'>('primary');

  // Individual add states
  const [addName, setAddName] = useState('');
  const [addStage, setAddStage] = useState<'primary' | 'prep' | 'sec' | 'basic' | 'languages'>('primary');
  const [addClassrooms, setAddClassrooms] = useState(12);

  useEffect(() => {
    setPri(settings.quota_primary);
    setPrep(settings.quota_prep);
    setSec(settings.quota_sec);
  }, [settings, dbTick]);

  useEffect(() => {
    setLocalSchools(schools);
  }, [schools, dbTick]);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);

    dbInstance.saveSettings({
      ...settings,
      quota_primary: Number(pri),
      quota_prep: Number(prep),
      quota_sec: Number(sec)
    });

    setTimeout(() => {
      setSavingSettings(false);
      alert('تم تحديث الأنصبة المرجعية الافتراضية للمراحل التعليمية بالإدارة بنجاح.');
    }, 400);
  };

  // Bulk Import
  const handleBulkImport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bulkText.trim()) return;

    const lines = bulkText.split('\n');
    let count = 0;

    lines.forEach(line => {
      const name = line.trim();
      if (name) {
        // Generate random 6-digit pin
        const generatedPin = String(Math.floor(100000 + Math.random() * 900000));
        const generatedId = 'sch_' + Date.now() + '_' + Math.floor(Math.random() * 100000);

        const newSch: School = {
          id: generatedId,
          name: name,
          address: 'أبو حماد',
          year: '٢٠٢٥/٢٠٢٦',
          stage: bulkStage as any,
          classroomsCount: 12,
          password: generatedPin
        };

        dbInstance.saveSchool(newSch);
        count++;
      }
    });

    setBulkText('');
    alert(`تم استيراد الكشوفات بنجاح! تم تسجيل عدد (${count}) مدرسة وتوليد أرقام سرية للمديرين تلقائياً.`);
  };

  // Single Add
  const handleSingleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addName.trim()) return;

    const generatedPin = String(Math.floor(100000 + Math.random() * 900000));
    const generatedId = 'sch_' + Date.now() + '_' + Math.floor(Math.random() * 100000);

    const newSch: School = {
      id: generatedId,
      name: addName.trim(),
      address: 'أبو حماد',
      year: '٢٠٢٥/٢٠٢٦',
      stage: addStage as any,
      classroomsCount: Number(addClassrooms) || 12,
      password: generatedPin
    };

    dbInstance.saveSchool(newSch);
    setAddName('');
    setAddClassrooms(12);
    alert(`تم إضافة مدرسة "${newSch.name}" وتوليد رقم سري عشوائي للدخول بنجاح.`);
  };

  // Inline inputs callback
  const handleLocalSchoolChange = (id: string, field: keyof School, value: any) => {
    setLocalSchools(prev => {
      const updated = prev.map(s => s.id === id ? { ...s, [field]: value } : s);
      const school = updated.find(s => s.id === id);
      if (school) {
        dbInstance.saveSchool(school);
      }
      return updated;
    });
  };

  // Save individual
  const handleSaveIndividualSchool = (school: School) => {
    dbInstance.saveSchool(school);
    alert(`تم حفظ تعديل بيانات مدرسة "${school.name}" بنجاح.`);
  };

  // Delete individual
  const handleDeleteIndividualSchool = (id: string, name: string) => {
    if (confirm(`⚠️ تنبيه: هل أنت متأكد من حذف مدرسة "${name}" بالكامل من النظام؟\nإجراء الحذف سيقوم بإلغاء كافة جداول غياب الكوادر، والطلاب وحضور الزوار والتغذية المرتبطة بها نهائياً ولن تتمكن من تراجع هذا الخيار.`)) {
      dbInstance.deleteSchool(id);
      alert('تم حذف المدرسة وسجلاتها المرتبطة بنجاح.');
    }
  };

  // Generate new random pin for a school
  const handleRegeneratePin = (id: string) => {
    const randomPin = String(Math.floor(100000 + Math.random() * 900000));
    handleLocalSchoolChange(id, 'password', randomPin);
  };

  // Save All
  const handleSaveAllSchools = () => {
    localSchools.forEach(sch => {
      dbInstance.saveSchool(sch);
    });
    alert('تم ترحيل وحفظ تعديلات كافة مدارس الإدارة بنجاح.');
  };

  // Delete All
  const handleDeleteAllSchools = () => {
    if (confirm('⚠️⚠️⚠️ تحذير فائق الخطورة: هل تريد فعلاً مسح وحذف جميع المدارس المقيدة بالإدارة نهائياً؟؟\nهذا الإجراء سيقوم بتصفير قاعدة البيانات ومسح كل السجلات والمدخلات كلياً!')) {
      if (confirm('تأكيد نهائي وأخير: اضغط موافق لبدء المسح الشامل.')) {
        schools.forEach(sch => {
          dbInstance.deleteSchool(sch.id);
        });
        alert('تم مسح وإفراغ سجل دليل المدارس بالكامل.');
      }
    }
  };

  const handleCopyWhatsAppLogins = () => {
    let text = `📋 دليل بيانات الدخول والأرقام السرية لمدارس إدارة أبوحماد التعليمية:\n`;
    text += `----------------------------------------------------\n\n`;
    localSchools.forEach((s, idx) => {
      const stageStr = s.stage === 'primary' ? 'ابتدائي' : s.stage === 'prep' ? 'إعدادي' : s.stage === 'sec' ? 'ثانوي' : 'تعليم أساسي';
      text += `${idx + 1}. مدرسة: ${s.name}\n`;
      text += `👈 المرحلة: ${stageStr}\n`;
      text += `🔑 الرقم السري للدخول: ${s.password || 'لا يوجد'}\n`;
      text += `----------------------------------------------------\n`;
    });
    
    text += `\n✓ جرى توليدها وتوثيقها تلقائياً عبر منصة الدعم المركزي للتنسيق العام بالإدارة التعليمية.`;
    navigator.clipboard.writeText(text);
    alert('تم نسخ دليل الأرقام السرية لجميع المدارس بصيغة WhatsApp في الحافظة للبدء في توزيعه على المديرين.');
  };

  // Processed schools based on search Query
  const processedSchools = useMemo(() => {
    let list = [...localSchools];
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(s => s.name.toLowerCase().includes(q));
    }
    if (filterStage !== 'all') {
      list = list.filter(s => s.stage === filterStage);
    }
    return list;
  }, [localSchools, searchQuery, filterStage]);

  return (
    <div className="space-y-6">
      
      {/* SECTION 1: SETTINGS / QUOTAS */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-6">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <SlidersHorizontal size={18} className="text-[#0D47A1]" />
            تعديل حدود نصاب المعلمين المرجعي الافتراضي للمراحل التعليمية
          </h2>
          <p className="text-xs text-slate-500 mt-1">تحديد معامل الحساب الافتراضي لكل مرحلة لحساب معادلات السد الفوري للعجز والزيادة</p>
        </div>

        <form onSubmit={handleSaveSettings} className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex justify-between items-center border border-slate-150 bg-slate-50/50 p-2.5 rounded gap-4">
            <span className="text-xs font-bold text-slate-700">الابتدائية (بث قوى):</span>
            <input
              type="number"
              min="1"
              value={pri}
              onChange={e => setPri(parseInt(e.target.value) || 0)}
              className="w-20 px-2 py-1 text-center font-mono font-black border border-slate-200 bg-white rounded focus:outline-none"
            />
          </div>

          <div className="flex justify-between items-center border border-slate-150 bg-slate-50/50 p-2.5 rounded gap-4">
            <span className="text-xs font-bold text-slate-700">الإعدادية الافتراضي:</span>
            <input
              type="number"
              min="1"
              value={prep}
              onChange={e => setPrep(parseInt(e.target.value) || 0)}
              className="w-20 px-2 py-1 text-center font-mono font-black border border-slate-200 bg-white rounded focus:outline-none"
            />
          </div>

          <div className="flex justify-between items-center border border-slate-150 bg-slate-50/50 p-2.5 rounded gap-4">
            <span className="text-xs font-bold text-slate-700">الثانوية الافتراضي:</span>
            <input
              type="number"
              min="1"
              value={sec}
              onChange={e => setSec(parseInt(e.target.value) || 0)}
              className="w-20 px-2 py-1 text-center font-mono font-black border border-slate-200 bg-white rounded focus:outline-none"
            />
          </div>

          <div className="md:col-span-3 flex justify-end pt-2">
            <button
              type="submit"
              disabled={savingSettings}
              className="px-6 py-2 bg-gradient-to-l from-[#1565C0] to-[#1E88E5] hover:brightness-110 active:scale-95 text-white rounded text-xs font-black shadow-md transition-all shrink-0 cursor-pointer"
            >
              {savingSettings ? 'جاري الحفظ...' : 'حفظ ونشر الأنصبة المستهدفة'}
            </button>
          </div>
        </form>
      </div>

      {/* SECTION 2: ADD & IMPORT SCHOOLS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Bulk import box */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Plus size={16} className="text-indigo-600" />
              استيراد دفعة مَدارس كليَة (نسخ ولصق)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              انسخ أسماء المدارس من كشف (Excel) أو ملف نصي، والصقها هنا كل مدرسة في سطر مستقل ليتم توليد أرقام سرية دخول عشوائية لهم فوراً.
            </p>
          </div>

          <form onSubmit={handleBulkImport} className="space-y-4">
            <div>
              <label className="block text-xs font-extrabold text-[#0D47A1] mb-1.5">المرحلة الأساسية الافتراضية للدفعة:</label>
              <select
                value={bulkStage}
                onChange={e => setBulkStage(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded text-right focus:outline-none"
              >
                <option value="primary">ابتدائي (المرحلة الابتدائية)</option>
                <option value="prep">إعدادي (المرحلة الإعدادية)</option>
                <option value="sec">ثانوي عام (المرحلة الثانوية)</option>
                <option value="basic">تعليم أساسي (ابتدائي + إعدادي مشترك)</option>
                <option value="languages">رسمي لغات (تجريبي)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-extrabold text-[#0D47A1] mb-1.5">أسماء المدارس المستهدفة (كل مدرسة في سطر):</label>
              <textarea
                rows={5}
                placeholder="مدرسة الشهيد أحمد أحمد الابتدائية&#10;مدرسة أبو حماد الإعدادية بنين&#10;مدرسة الأمل للغات"
                value={bulkText}
                onChange={e => setBulkText(e.target.value)}
                className="w-full p-3 text-xs border border-slate-200 rounded text-right tracking-wide leading-relaxed placeholder-slate-350 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-gradient-to-l from-indigo-650 to-blue-500 hover:brightness-110 active:scale-95 text-white rounded text-xs font-black shadow-md transition-all cursor-pointer"
            >
              استيراد الدفعة وتوليد الأرقام السرية ⚙️
            </button>
          </form>
        </div>

        {/* Individual Add Box */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Plus size={16} className="text-emerald-600" />
              إضافة مدرسة جديدة منفردة
            </h3>
            <p className="text-xs text-slate-500 mt-1">تضمين مدرسة جديدة مفردة في دليل وعاء الإدارة التعليمية وتوليد رقم مرور تلقائي لها.</p>
          </div>

          <form onSubmit={handleSingleAdd} className="space-y-4">
            <div>
              <label className="block text-xs font-extrabold text-[#0D47A1] mb-1.5">اسم المنشأة التعليمية:</label>
              <input
                type="text"
                placeholder="أدخل اسم المدرسة كاملاً مع توضيح صفتها"
                value={addName}
                onChange={e => setAddName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded text-right focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-extrabold text-[#0D47A1] mb-1.5">المرحلة والتبعية:</label>
                <select
                  value={addStage}
                  onChange={e => setAddStage(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded text-right focus:outline-none"
                >
                  <option value="primary">ابتدائي</option>
                  <option value="prep">إعدادي</option>
                  <option value="sec">ثانوي عام</option>
                  <option value="basic">تعليم أساسي</option>
                  <option value="languages">رسمي لغات</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-extrabold text-[#0D47A1] mb-1.5">عدد فصول المدرسة:</label>
                <input
                  type="number"
                  min="1"
                  value={addClassrooms}
                  onChange={e => setAddClassrooms(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded text-right font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-gradient-to-l from-emerald-600 to-teal-500 hover:brightness-110 active:scale-95 text-white rounded text-xs font-black shadow-md transition-all cursor-pointer"
            >
              تأكيد وإدراج المدرسة بالدليل التعليمي
            </button>
          </form>
        </div>

      </div>

      {/* SECTION 3: EDITABLE SCHOOLS LIST & ALL SYSTEM CONTROLS */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
        
        {/* Dynamic header stats & buttons */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">سجل دليل وعاء المدارس والموقع الجغرافي</h3>
            <p className="text-xs text-slate-500 mt-0.5">يمكنك تعديل أي مدرسة، والمرحلة والسرية، وتطبيق الحفظ الفردي أو الكلي لترحيل البيانات.</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleCopyWhatsAppLogins}
              className="px-3.5 py-1.5 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 text-indigo-755 font-bold rounded-lg text-xs transition cursor-pointer flex items-center gap-1"
            >
              <Copy size={13} />
              نسخ أرقام المدارس (WhatsApp)
            </button>

            <button
              type="button"
              onClick={handleSaveAllSchools}
              className="px-3.5 py-1.5 bg-green-700 hover:bg-green-800 text-white font-extrabold rounded-lg text-xs shadow-3xs transition cursor-pointer flex items-center gap-1"
            >
              <Save size={13} />
              حفظ جميع التغييرات كلياً
            </button>

            <button
              type="button"
              onClick={handleDeleteAllSchools}
              className="px-3.5 py-1.5 bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 font-bold rounded-lg text-xs transition cursor-pointer flex items-center gap-1"
            >
              <Trash2 size={13} />
              حذف كافة المدارس (تصفير)
            </button>
          </div>
        </div>

        {/* Filters and search box */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="relative">
            <input
              type="text"
              placeholder="ابحث عن مدرسة بالاسم..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pr-8 pl-3 py-1.5 text-xs border border-slate-200 rounded text-right focus:outline-none focus:border-blue-500 font-bold font-sans"
            />
            <span className="absolute right-2.5 top-2.5 text-slate-400">
              <Search size={12} />
            </span>
          </div>

          <div>
            <select
              value={filterStage}
              onChange={e => setFilterStage(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded text-right focus:outline-none focus:border-blue-500 font-bold"
            >
              <option value="all">كل المراحل التعليمية</option>
              <option value="primary">ابتدائي</option>
              <option value="prep">إعدادي</option>
              <option value="sec">ثانوي عام</option>
              <option value="basic">تعليم أساسي</option>
              <option value="languages">رسمي لغات</option>
            </select>
          </div>

          <div className="text-left text-xs font-bold text-slate-500 flex items-center justify-end px-1 select-none">
            عدد المدارس المعروضة: <span className="font-mono text-blue-750 mr-1 text-sm font-black">{processedSchools.length}</span>
          </div>
        </div>

        {/* Directory Table */}
        <div className="overflow-x-auto border border-slate-150 rounded-xl">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-slate-900 text-white font-bold">
                <th className="p-3 border text-center">م</th>
                <th className="p-3 border">اسم المدرسة (متاح للتعديل)</th>
                <th className="p-3 border text-center">المرحلة</th>
                <th className="p-3 border text-center">عدد الفصول</th>
                <th className="p-3 border text-center">عنوانها</th>
                <th className="p-3 border text-center">كلمة السر / PIN (دخول المدير)</th>
                <th className="p-3 border text-center">الأفعال</th>
              </tr>
            </thead>
            <tbody>
              {processedSchools.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400 font-bold">
                    لا يوجد مدارس تطابق معايير البحث المسجلة.
                  </td>
                </tr>
              ) : (
                processedSchools.map((sch, index) => {
                  return (
                    <tr key={sch.id} className="hover:bg-slate-50 border-b border-slate-100/90 transition duration-150">
                      
                      {/* Badge identifier */}
                      <td className="p-2 text-center border">
                        <span className="bg-slate-100 font-mono text-[9px] px-1.5 py-0.5 rounded text-slate-600 font-extrabold">
                          {index + 1}
                        </span>
                      </td>

                      {/* Name input */}
                      <td className="p-2 border">
                        <input
                          type="text"
                          value={sch.name}
                          onChange={e => handleLocalSchoolChange(sch.id, 'name', e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-transparent hover:border-slate-200 focus:border-blue-500/80 bg-transparent focus:bg-white rounded font-bold text-slate-800 transition"
                        />
                      </td>

                      {/* Stage selector dropdown */}
                      <td className="p-2 border text-center w-28">
                        <select
                          value={sch.stage}
                          onChange={e => handleLocalSchoolChange(sch.id, 'stage', e.target.value)}
                          className="px-2 py-0.5 text-[10px] border border-transparent hover:border-slate-200 focus:border-blue-500/80 bg-transparent focus:bg-white font-bold rounded text-slate-800"
                        >
                          <option value="primary">ابتدائي</option>
                          <option value="prep">إعدادي</option>
                          <option value="sec">ثانوي عام</option>
                          <option value="basic">تعليم أساسي</option>
                          <option value="languages">رسمي لغات</option>
                        </select>
                      </td>

                      {/* Classrooms input */}
                      <td className="p-2 border text-center w-20">
                        <input
                          type="number"
                          min="1"
                          value={sch.classroomsCount || 0}
                          onChange={e => handleLocalSchoolChange(sch.id, 'classroomsCount', parseInt(e.target.value) || 0)}
                          className="w-14 px-1 py-0.5 text-center font-mono border border-transparent hover:border-slate-200 focus:border-blue-500/80 bg-transparent focus:bg-white rounded font-extrabold text-slate-850"
                        />
                      </td>

                      {/* Address/Location input */}
                      <td className="p-2 border text-center w-36">
                        <input
                          type="text"
                          value={sch.address || 'أبوحماد'}
                          onChange={e => handleLocalSchoolChange(sch.id, 'address', e.target.value)}
                          className="w-full px-2 py-1 text-xs border border-transparent hover:border-slate-200 focus:border-blue-500/80 bg-transparent focus:bg-white rounded text-center text-slate-700"
                        />
                      </td>

                      {/* Password PIN input with utilities */}
                      <td className="p-2 border text-center w-64">
                        <div className="flex items-center gap-1 justify-center">
                          <input
                            type="text"
                            value={sch.password || ''}
                            onChange={e => handleLocalSchoolChange(sch.id, 'password', e.target.value)}
                            className="w-24 px-1.5 py-0.5 text-center font-mono border border-slate-200 bg-white rounded font-black text-blue-750 text-xs"
                          />
                          <button
                            type="button"
                            onClick={() => handleRegeneratePin(sch.id)}
                            title="توليد رقم عشوائي جديد"
                            className="p-1 text-indigo-650 hover:bg-indigo-50 border border-indigo-150 rounded cursor-pointer"
                          >
                            <RefreshCw size={11} className="spin-hover animate-spin-slow" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(sch.password || '');
                              alert('تم نسخ الرقم السري في الحافظة.');
                            }}
                            title="نسخ الرقم السري"
                            className="p-1 text-slate-650 hover:bg-slate-100 border border-slate-200 rounded cursor-pointer"
                          >
                            <Copy size={11} />
                          </button>
                        </div>
                      </td>

                      {/* Individual Actions */}
                      <td className="p-2 border text-center">
                        <div className="flex gap-1 justify-center">
                          <button
                            type="button"
                            onClick={() => handleSaveIndividualSchool(sch)}
                            className="p-1 px-2 border border-emerald-500/30 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded text-[10px] font-extrabold cursor-pointer transition flex items-center gap-0.5"
                          >
                            <Save size={10} />
                            حفظ
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteIndividualSchool(sch.id, sch.name)}
                            className="p-1 px-2 border border-rose-200 text-rose-650 hover:bg-rose-50 rounded text-[10px] font-extrabold cursor-pointer transition flex items-center gap-0.5"
                          >
                            <Trash2 size={10} />
                            حذف
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 3: REAL-TIME DEFICITS & SURPLUS CALCULATIONS GRID
// ----------------------------------------------------
function DeficitsDashboardTab({ 
  schools, 
  materials, 
  materialCounts, 
  dbTick 
}: { 
  schools: School[]; 
  materials: Material[]; 
  materialCounts: MaterialCount[]; 
  dbTick: number;
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStage, setFilterStage] = useState<string>('all');
  const [filterCondition, setFilterCondition] = useState<'all' | 'deficit' | 'surplus' | 'normal'>('all');

  const mathRows = useMemo(() => {
    const rows: Array<{
      id: string;
      school: School;
      material: Material;
      needed: number;
      present: number;
      deficit: number;
      surplus: number;
      percentage: number;
    }> = [];

    schools.forEach(school => {
      materials.forEach(material => {
        const count = materialCounts.find(c => c.schoolId === school.id && c.materialId === material.id);
        const calculated = dbInstance.calculateMaterialMetrics(school, material, count);
        
        if (calculated.applicable) {
          rows.push({
            id: school.id + '_' + material.id,
            school,
            material,
            needed: calculated.needed,
            present: calculated.present,
            deficit: calculated.deficit,
            surplus: calculated.surplus,
            percentage: calculated.percentage
          });
        }
      });
    });

    return rows;
  }, [schools, materials, materialCounts, dbTick]);

  const processedRows = useMemo(() => {
    let list = [...mathRows];

    // search filter school name or specialty
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(r => 
        r.school.name.toLowerCase().includes(q) || 
        r.material.name.toLowerCase().includes(q)
      );
    }

    // stage filter
    if (filterStage !== 'all') {
      list = list.filter(r => r.school.stage === filterStage);
    }

    // condition filter
    if (filterCondition === 'deficit') {
      list = list.filter(r => r.deficit > 0);
    } else if (filterCondition === 'surplus') {
      list = list.filter(r => r.surplus > 0);
    } else if (filterCondition === 'normal') {
      list = list.filter(r => r.deficit === 0 && r.surplus === 0);
    }

    return list;
  }, [mathRows, searchQuery, filterStage, filterCondition]);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-6">
      
      <div>
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <AlertTriangle size={20} className="text-red-650 animate-pulse animate-spin-slow" />
          الحسابات الفورية للعجز والزيادة والنسب بالمستوى والمدارس
        </h2>
        <p className="text-xs text-slate-500 mt-1">تتبع التغطية الكلية: المطلوب (الفصول × النصاب) والفعلي لديناميكية السد والندب</p>
      </div>

      {/* Filter Options Dashboard Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <input
          type="text"
          placeholder="ابحث بالمدرسة أو المادة..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="px-3 py-2 text-sm border border-slate-400 rounded-lg text-right text-black font-black bg-white shadow-xs focus:ring-1 focus:ring-blue-600"
        />

        <select
          value={filterStage}
          onChange={e => setFilterStage(e.target.value)}
          className="px-3 py-2 text-sm border border-slate-400 rounded-lg bg-white text-right text-black font-black shadow-xs focus:ring-1 focus:ring-blue-600"
        >
          <option value="all">كل المراحل</option>
          <option value="primary">ابتدائي</option>
          <option value="prep">إعدادي</option>
          <option value="sec">ثانوي عام</option>
          <option value="basic">تعليم أساسي</option>
        </select>

        <select
          value={filterCondition}
          onChange={e => setFilterCondition(e.target.value as any)}
          className="px-3 py-2 text-sm border border-slate-400 rounded-lg bg-white text-right text-black font-black shadow-xs focus:ring-1 focus:ring-blue-600"
        >
          <option value="all">كل الحالات الاقتصادية</option>
          <option value="deficit">مدارس بها عجز في التخصص</option>
          <option value="surplus">مدارس بها فائض / زيادة</option>
          <option value="normal">مستقر (كفاية تامة)</option>
        </select>

        <div className="text-left text-xs text-slate-400 font-mono self-center">
          مطابق: {processedRows.length} مؤشر تنسيقي مصفى
        </div>
      </div>

      {/* Math results Grid table */}
      <div className="overflow-x-auto rounded-lg border border-slate-100">
        <table className="w-full text-right text-xs border-collapse">
          <thead>
            <tr className="bg-slate-900 text-white font-bold text-xs">
              <th className="p-3 border border-slate-800">المدرسة المستهدفة</th>
              <th className="p-3 border border-slate-800">المادة الدراسية</th>
              <th className="p-3 border border-slate-800 text-center">عدد الفصول</th>
              <th className="p-3 border border-slate-800 text-center">المطلوب (الفصول × النصاب)</th>
              <th className="p-3 border border-slate-800 text-center">الموجود الفعلي</th>
              <th className="p-3 border border-slate-800 text-center text-red-200 bg-red-950">العجــز الديجيتال</th>
              <th className="p-3 border border-slate-800 text-center text-emerald-200 bg-emerald-950">الزيــادة الفائضة</th>
              <th className="p-3 border border-slate-800 text-center">نسبة الكفاية</th>
            </tr>
          </thead>
          <tbody>
            {processedRows.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center p-6 text-slate-400">
                  لا توجد سجلات مطابقة لخيارات المفلترة الحالية
                </td>
              </tr>
            ) : (
              processedRows.map(row => (
                <tr key={row.id} className="hover:bg-slate-50 border-b border-slate-100 [&_td]:p-3 font-semibold">
                  <td className="font-bold text-slate-900 border border-slate-100">{row.school.name}</td>
                  <td className="text-blue-800 border border-slate-100">{row.material.name}</td>
                  <td className="text-center font-mono font-bold text-slate-500 border border-slate-100">{row.school.classroomsCount}</td>
                  <td className="text-center font-mono text-slate-700 border border-slate-100">{row.needed}</td>
                  <td className="text-center font-mono text-slate-900 border border-slate-100">{row.present}</td>
                  
                  {/* Deficit column block with red feedback alerts */}
                  <td className={`text-center font-mono font-black border border-slate-100 ${row.deficit > 0 ? 'bg-red-50 text-red-650' : 'text-slate-350'}`}>
                    {row.deficit > 0 ? `${row.deficit} معلم` : '---'}
                  </td>

                  {/* Surplus column block with green feedback */}
                  <td className={`text-center font-mono font-black border border-slate-100 ${row.surplus > 0 ? 'bg-emerald-50 text-emerald-700' : 'text-slate-350'}`}>
                    {row.surplus > 0 ? `${row.surplus} زيادة` : '---'}
                  </td>

                  <td className="text-center border border-slate-100">
                    <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-black font-mono ${row.percentage >= 100 ? 'bg-green-100 text-green-700' : row.percentage >= 50 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>
                      {row.percentage} %
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 4: OFFICIAL REPORTS GENERATOR & printing
// ----------------------------------------------------
function ReportsPrintingTab({ 
  schools, 
  materials, 
  materialCounts, 
  staff, 
  visitors, 
  nutrition,
  leadership,
  studentAbsences = [],
  teacherAbsences = [],
  activeReportType = 'school'
}: { 
  schools: School[]; 
  materials: Material[]; 
  materialCounts: MaterialCount[]; 
  staff: StaffMember[]; 
  visitors: VisitorLog[]; 
  nutrition: NutritionRecord[];
  leadership: Directorship[];
  studentAbsences: StudentAbsence[];
  teacherAbsences: TeacherAbsence[];
  activeReportType?: string;
}) {
  const [reportType, setReportType] = useState<string>(activeReportType);

  useEffect(() => {
    if (activeReportType) {
      setReportType(activeReportType);
    }
  }, [activeReportType]);
  const [selectedSchoolId, setSelectedSchoolId] = useState<string>('all');
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [schoolSearchQuery, setSchoolSearchQuery] = useState<string>('');
  const [materialSearchQuery, setMaterialSearchQuery] = useState<string>('');

  const filteredSchools = useMemo(() => {
    return schools.filter(s => s.name.toLowerCase().includes(schoolSearchQuery.toLowerCase()));
  }, [schools, schoolSearchQuery]);

  const filteredMaterials = useMemo(() => {
    return materials.filter(m => m.name.toLowerCase().includes(materialSearchQuery.toLowerCase()));
  }, [materials, materialSearchQuery]);

  useEffect(() => {
    if (selectedSchoolId !== 'all' && filteredSchools.length > 0 && !filteredSchools.some(s => s.id === selectedSchoolId)) {
      setSelectedSchoolId('all');
    }
  }, [filteredSchools, selectedSchoolId]);

  useEffect(() => {
    if (selectedMaterialId !== 'all' && filteredMaterials.length > 0 && !filteredMaterials.some(m => m.id === selectedMaterialId)) {
      setSelectedMaterialId('all');
    }
  }, [filteredMaterials, selectedMaterialId]);

  const [filterDate, setFilterDate] = useState<string>('');
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [comprehensiveGrouping, setComprehensiveGrouping] = useState<'none' | 'school' | 'material' | 'stage'>('none');

  // --- LOCAL JSON SNAPSHOT ARRAYS FOR HISTORICAL ANALYSIS ---
  interface Snapshot {
    id: string;
    name: string;
    createdAt: string;
    schools: School[];
    materials: Material[];
    materialCounts: MaterialCount[];
    staff: StaffMember[];
    visitors: VisitorLog[];
    nutrition: NutritionRecord[];
    leadership: Directorship[];
    studentAbsences: StudentAbsence[];
    teacherAbsences: TeacherAbsence[];
  }

  const [snapshots, setSnapshots] = useState<Snapshot[]>(() => {
    try {
      const stored = localStorage.getItem('admin_coordination_report_snapshots');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [activeSnapshotId, setActiveSnapshotId] = useState<string>('');
  const [newSnapshotName, setNewSnapshotName] = useState<string>('');
  const [confirmDeleteSnapshotId, setConfirmDeleteSnapshotId] = useState<string | null>(null);
  const [exportingPdf, setExportingPdf] = useState<boolean>(false);

  // Database-synced Archived Reports States
  const [archivedReports, setArchivedReports] = useState<ArchivedReport[]>(() => dbInstance.getArchivedReports());
  const [archivingReport, setArchivingReport] = useState<boolean>(false);
  const [selectedArchivedReport, setSelectedArchivedReport] = useState<ArchivedReport | null>(null);
  const [isViewArchiveModalOpen, setIsViewArchiveModalOpen] = useState<boolean>(false);

  useEffect(() => {
    setArchivedReports(dbInstance.getArchivedReports());
    const unsub = dbInstance.subscribe(() => {
      setArchivedReports(dbInstance.getArchivedReports());
    });
    return unsub;
  }, []);

  const activeSnapshot = useMemo(() => {
    return snapshots.find(s => s.id === activeSnapshotId) || null;
  }, [snapshots, activeSnapshotId]);

  // Create snapshot handler
  const handleCreateSnapshot = () => {
    const formattedDate = new Date().toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    const formattedTime = new Date().toLocaleTimeString('ar-EG', {
      hour: '2-digit',
      minute: '2-digit'
    });
    const defaultName = `تقرير التنسيق العام المجمع - ${formattedDate} (${formattedTime})`;
    const name = newSnapshotName.trim() || defaultName;

    const newSnap: Snapshot = {
      id: `snap_${Date.now()}`,
      name,
      createdAt: new Date().toISOString(),
      schools: JSON.parse(JSON.stringify(schools)),
      materials: JSON.parse(JSON.stringify(materials)),
      materialCounts: JSON.parse(JSON.stringify(materialCounts)),
      staff: JSON.parse(JSON.stringify(staff)),
      visitors: JSON.parse(JSON.stringify(visitors)),
      nutrition: JSON.parse(JSON.stringify(nutrition)),
      leadership: JSON.parse(JSON.stringify(leadership)),
      studentAbsences: JSON.parse(JSON.stringify(studentAbsences)),
      teacherAbsences: JSON.parse(JSON.stringify(teacherAbsences)),
    };

    const updated = [newSnap, ...snapshots];
    setSnapshots(updated);
    localStorage.setItem('admin_coordination_report_snapshots', JSON.stringify(updated));
    setNewSnapshotName('');
    alert(`🎉 تم بنجاح التقاط وحفظ السجل التاريخي باسم:\n"${name}"`);
  };

  // Delete snapshot handler
  const handleDeleteSnapshot = (id: string, name: string) => {
    const updated = snapshots.filter(s => s.id !== id);
    setSnapshots(updated);
    localStorage.setItem('admin_coordination_report_snapshots', JSON.stringify(updated));
    if (activeSnapshotId === id) {
      setActiveSnapshotId('');
    }
  };

  // Export snapshots to JSON file (desktop download)
  const handleExportSnapshotsJSON = () => {
    if (snapshots.length === 0) {
      alert('لا توجد سجلات تاريخية محفوظة للتصدير حالياً. فضلاً قم بالتقاط سجل أولاً.');
      return;
    }
    const dataStr = JSON.stringify(snapshots, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `سجلات_التنسيق_التاريخية_المجمعة_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Import snapshots from local JSON file (desktop upload)
  const handleImportSnapshotsJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target.result as string);
        const dataArray = Array.isArray(parsed) ? parsed : [parsed];
        
        // Basic validation of fields inside first item to avoid corrupt uploads
        if (dataArray.length > 0) {
          const first = dataArray[0];
          if (!first.schools || !first.materials || !first.materialCounts) {
            alert('❌ خطأ: تنسيق الملف غير صحيح. يجب أن يتكوّن ملف الـ JSON السجلّي من مدارس وأولويات تخصصية معتمدة.');
            return;
          }
        } else {
          alert('❌ ملف الـ JSON فارغ ولا يحتوي على سجلات.');
          return;
        }

        const confirmMerge = confirm(`📂 تم العثور على ${dataArray.length} سجل تاريخي في الملف. هل تريد دمجها مع السجلات المحفوظة مسبقاً في المتصفح؟\n(اضغط "إلغاء لسطح المكتب" لاستبدالها كاملة)`);
        let updated: Snapshot[] = [];
        if (confirmMerge) {
          updated = [...dataArray, ...snapshots];
          // deduplication
          const seen = new Set();
          updated = updated.filter(el => {
            const has = seen.has(el.id);
            seen.add(el.id);
            return !has;
          });
        } else {
          updated = dataArray;
        }

        setSnapshots(updated);
        localStorage.setItem('admin_coordination_report_snapshots', JSON.stringify(updated));
        alert('✅ تم استيراد ودمج السجلات التاريخية للتقرير بنجاح! السجل التاريخي جاهز تماماً للمقارنة الفورية.');
      } catch (err) {
        alert('❌ فشل في استيراد ومزامنة ملف الـ JSON. تأكد من سلامة صياغة الملف.');
      }
    };
    reader.readAsText(file);
    // Clear value to allow re-uploading the same file if needed
    e.target.value = '';
  };

  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortData = <T extends any>(data: T[], extractor: (item: T) => any): T[] => {
    if (!sortField) return data;
    return [...data].sort((a, b) => {
      const valA = extractor(a);
      const valB = extractor(b);
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortDirection === 'asc' ? valA - valB : valB - valA;
      }
      const strA = String(valA || '').toLowerCase();
      const strB = String(valB || '').toLowerCase();
      if (strA < strB) return sortDirection === 'asc' ? -1 : 1;
      if (strA > strB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  };

  // Invoke browser print layout
  const handlePrint = () => {
    try {
      // Auto-archive in background during print for historical preservation
      handleArchiveReport(true);
      window.focus();
      window.print();
    } catch (e) {
      console.error(e);
      alert('نظراً لقيود المتصفح داخل نافذة المعاينة الفورية (iFrame)، يرجى الضغط على زر "فتح في نافذة جديدة" أعلى يسار الشاشة لتشغيل ميزة طباعة التقارير بشكل ممتاز.');
    }
  };

  // Archive current report to the database
  const handleArchiveReport = async (isSilent = false) => {
    const element = document.getElementById('printable-report-area');
    if (!element) {
      if (!isSilent) alert('لم يتم العثور على منطقة التقرير القابلة للطباعة للأرشفة.');
      return;
    }

    try {
      if (!isSilent) setArchivingReport(true);
      const settings = dbInstance.getSettings();

      // 1. Identify Titles & Subtitles
      let title = "تقرير التنسيق العام";
      let subtitle = "تقرير تاريخي مؤرشف";
      const arabicReportType = 
        reportType === 'school' ? 'تقرير مدرسة تفصيلي' : 
        reportType === 'material' ? 'تقرير مادة عبر المدارس' : 
        reportType === 'comprehensive' ? 'التقرير الشامل المجمع' : 
        reportType === 'school_students' ? 'بيان فصول ومقيد الطلاب' : 
        reportType === 'visitors' ? 'سجل متابعة وزيارات الموجهين' : 
        reportType === 'teachers' ? 'بيان تفصيلي بجميع المعلمين' : 
        reportType === 'leadership' ? 'بيان الإشراف والقيادة المدرسية' : 'تقرير إحصائي معتمد';

      if (reportType === 'school') {
        const activeSch = schools.find(s => s.id === selectedSchoolId) || schools[0];
        title = `البيانات الإحصائية لمدرسة: ${activeSch?.name || '---'}`;
        subtitle = `تقرير معتمد لمدرسة ${activeSch?.name || ''} لعام ${activeSch?.year || ''}`;
      } else if (reportType === 'material') {
        const activeMat = materials.find(m => m.id === selectedMaterialId) || materials[0];
        title = `تقرير الكفاية والعجز لمادة: ${activeMat?.name || '---'}`;
        subtitle = `حالة مادة ${activeMat?.name || ''} عبر جميع المدارس`;
      } else if (reportType === 'comprehensive') {
        title = "تقرير العجز والزيادة والأنصبة الكلي والتحليلي للإدارة التعليمية";
        subtitle = `جدول تحليلي مجمع حسب: ${
          comprehensiveGrouping === 'school' ? 'المدرسة' : 
          comprehensiveGrouping === 'material' ? 'المادة الدراسية' : 
          comprehensiveGrouping === 'stage' ? 'المرحلة الدراسية' : 'التفصيلي الشامل'
        }`;
      } else if (reportType === 'school_students') {
        title = "بيان المقيد من الطلاب بالمراحل التعليمية";
        subtitle = "إجمالي الفصول وبنين وبنات لجميع المدارس";
      } else if (reportType === 'visitors') {
        title = "سجل الزيارات والتقارير الميدانية للمتابعة";
        subtitle = "حركة المتابعة وزيارات الموجهين والمسؤولين";
      } else if (reportType === 'teachers') {
        title = "تقرير بيان المعلمين وتوزيعهم ومؤهلاتهم";
        subtitle = "تفاصيل الكوادر التعليمية بالإدارة";
      } else if (reportType === 'leadership') {
        title = "بيان هيئة الإشراف والقيادة المدرسية";
        subtitle = "المدراء والوكلاء وتفاصيل قرارات تكليفهم";
      }

      // Clone HTML content & clean up buttons/inputs so they aren't saved in the static snapshot
      const clonedElement = element.cloneNode(true) as HTMLElement;
      const exclusions = clonedElement.querySelectorAll('.print\\:hidden, button, input, select');
      exclusions.forEach(el => el.remove());
      
      const htmlSnapshot = clonedElement.innerHTML;

      const newArchived: ArchivedReport = {
        id: `archived_pdf_${Date.now()}`,
        title,
        subtitle,
        reportType: arabicReportType,
        exportedAt: new Date().toISOString(),
        exportedBy: settings.coordinationAdminUsername || 'مدير التنسيق العام',
        filterSchoolId: selectedSchoolId,
        filterMaterialId: selectedMaterialId,
        htmlSnapshot,
        stats: {
          totalSchools: schools.length,
          totalTeachers: staff.filter(s => s.role === 'teacher').length
        }
      };

      dbInstance.saveArchivedReport(newArchived);

      if (!isSilent) {
        alert('تم بنجاح أرشفة وتوثيق هذا التقرير في الأرشيف المركزي المعتمد لبيانات التنسيق! يمكنك الرجوع إليه أو طباعته أو تحميله كـ PDF في أي وقت بالأسفل.');
      }
    } catch (e) {
      console.error('Error during report archival:', e);
      if (!isSilent) alert('حدث خطأ أثناء أرشفة التقرير في قاعدة البيانات.');
    } finally {
      if (!isSilent) setArchivingReport(false);
    }
  };

  // Programmatic high-fidelity PDF Export helper
  const handlePdfExport = async () => {
    const element = document.getElementById('printable-report-area');
    if (!element) {
      alert('لم يتم العثور على منطقة التقرير القابلة للطباعة.');
      return;
    }
    setExportingPdf(true);

    // Auto-archive in background during PDF export
    handleArchiveReport(true);
    
    const isWideReport = ['comprehensive', 'teachers', 'visitors', 'leadership', 'specialists', 'admins_supervisors', 'workers', 'students_absences', 'teachers_absences', 'nutrition'].includes(reportType);
    
    // Backup original styles of element and parent elements to allow full expansion
    const originalStyle = element.style.cssText;
    const originalParents: { el: HTMLElement; cssText: string }[] = [];
    const scrollContainers = element.querySelectorAll('.overflow-x-auto, [class*="overflow-"]');
    const originalScrollStyles: { el: HTMLElement; cssText: string }[] = [];
    
    try {
      const targetWidth = isWideReport ? '297mm' : '210mm';
      element.style.cssText += `; width: ${targetWidth} !important; max-width: none !important; height: auto !important; max-height: none !important; overflow: visible !important;`;
      
      scrollContainers.forEach((el: any) => {
        originalScrollStyles.push({ el, cssText: el.style.cssText });
        el.style.cssText += '; overflow: visible !important; max-width: none !important; width: auto !important; display: block !important;';
      });

      let p = element.parentElement;
      while (p && p !== document.body) {
        originalParents.push({ el: p, cssText: p.style.cssText });
        p.style.cssText += '; overflow: visible !important; height: auto !important; max-height: none !important;';
        p = p.parentElement;
      }

      const canvas = await withOklchBypass(async () => {
        return await html2canvas(element, {
          scale: 2, // high clarity
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff'
        });
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const pdf = isWideReport ? new jsPDF('l', 'mm', 'a4') : new jsPDF('p', 'mm', 'a4');
      
      const imgWidth = isWideReport ? 297 : 210; // A4 width in landscape/portrait
      const pageHeight = isWideReport ? 210 : 297; // A4 height in landscape/portrait
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      let docTitle = `تقرير_الإدارة_${reportType}`;
      if (reportType === 'school' && activeSchool) {
        docTitle = `تقرير_مدرسة_${activeSchool.name}`;
      } else if (reportType === 'material' && activeMaterial) {
        docTitle = `تقرير_مادة_${activeMaterial.name}`;
      }
      
      pdf.save(`${docTitle}.pdf`);
    } catch (err) {
      console.error('Failed to generate PDF:', err);
      alert('حدث خطأ أثناء تصدير مستند PDF الفوري. لم يتمكن النظام من التصدير في هذه البيئة.');
    } finally {
      // Restore original styles
      originalScrollStyles.forEach(os => {
        os.el.style.cssText = os.cssText;
      });
      originalParents.forEach(op => {
        op.el.style.cssText = op.cssText;
      });
      element.style.cssText = originalStyle;
      setExportingPdf(false);
    }
  };

  // Excel simulation download generator
  const handleExcelExport = () => {
    let csv = '\uFEFF'; // Arabic formatting BOM
    let titleStr = '';

    if (reportType === 'school') {
      const sch = schools.find(s => s.id === selectedSchoolId) || schools[0];
      titleStr = `تقرير_تنسيق_مدرسة_${sch?.name || ''}`;
      csv += 'البيانات التنسيقية للمدرسة والمواد\n';
      csv += 'اسم المادة,المطلوب,الموجود الفعلي,العجز,الفائض,نسبة الكفاية %\n';
      materials.forEach(mat => {
        if (sch) {
          const count = materialCounts.find(c => c.schoolId === sch.id && c.materialId === mat.id);
          const metrics = dbInstance.calculateMaterialMetrics(sch, mat, count);
          if (metrics.applicable) {
            csv += `"${mat.name}",${metrics.needed},${metrics.present},${metrics.deficit},${metrics.surplus},${metrics.percentage}%\n`;
          }
        }
      });
    } else if (reportType === 'school_students') {
      titleStr = 'تقرير_احصاء_الطلاب_بمدارس_الادارة';
      csv += 'تقرير إحصاء أعداد الطلاب وتوزيعهم بمدارس الإدارة التعليمية\n';
      csv += 'المدرسة,المرحلة,الفصول,بنين,بنات,إجمالي الطلاب\n';
      schools
        .filter(sch => selectedSchoolId === 'all' || sch.id === selectedSchoolId)
        .forEach(sch => {
          csv += `"${sch.name}","${sch.stage}",${sch.classroomsCount},${sch.boysCount || 0},${sch.girlsCount || 0},${sch.totalStudentsCount || 0}\n`;
        });
    } else if (reportType === 'material') {
      const mat = materials.find(m => m.id === selectedMaterialId) || materials[0];
      titleStr = `تقرير_مادة_${mat?.name || ''}`;
      csv += `بيانات عجز وموجود مادة: ${mat?.name || ''}\n`;
      csv += 'المدرسة,فصولها,المطلوب,الموجود الفعلي,العجز,الفائض\n';
      schools
        .filter(sch => selectedSchoolId === 'all' || sch.id === selectedSchoolId)
        .forEach(sch => {
          if (mat) {
            const count = materialCounts.find(c => c.schoolId === sch.id && c.materialId === mat.id);
            const metrics = dbInstance.calculateMaterialMetrics(sch, mat, count);
            if (metrics.applicable) {
              csv += `"${sch.name}",${sch.classroomsCount},${metrics.needed},${metrics.present},${metrics.deficit},${metrics.surplus}\n`;
            }
          }
        });
    } else if (reportType === 'comprehensive') {
      titleStr = 'التقرير_الشامل_لكل_المدارس';
      csv += 'تقرير التنسيق العام والاجتزاء الكلي للإدارة التعليمية\n';
      csv += 'المدرسة,المادة,المطلوب,الفعلي,العجز,الوفر,نسبة الكفاية %\n';
      schools
        .filter(sch => selectedSchoolId === 'all' || sch.id === selectedSchoolId)
        .forEach(sch => {
          materials
            .filter(mat => selectedMaterialId === 'all' || mat.id === selectedMaterialId)
            .forEach(mat => {
              const count = materialCounts.find(c => c.schoolId === sch.id && c.materialId === mat.id);
              const metrics = dbInstance.calculateMaterialMetrics(sch, mat, count);
              if (metrics.applicable) {
                csv += `"${sch.name}","${mat.name}",${metrics.needed},${metrics.present},${metrics.deficit},${metrics.surplus},${metrics.percentage}%\n`;
              }
            });
        });
    } else if (reportType === 'visitors') {
      titleStr = 'تقرير_سجل_الزوار_والموجهين';
      csv += 'تقرير سجل حضور وتوجيهات زائري وموجهي المدارس\n';
      csv += 'التاريخ,اسم الزائر,الوظيفة والتكليف,اسم المدرسة,وقت الوصول\n';
      visitors
        .filter(v => selectedSchoolId === 'all' || v.schoolId === selectedSchoolId || schools.find(s => s.id === selectedSchoolId)?.name === v.schoolName)
        .forEach(v => {
          csv += `"${v.date}","${v.visitorName}","${v.jobTitle}","${v.schoolName}","${v.arrivalTime}"\n`;
        });
    } else if (reportType === 'teachers') {
      titleStr = 'تقرير_قوى_المعلمين_والإداريين_التفصيلي';
      csv += 'سجل الكوادر البشرية المقيدة بمدارس الإدارة\n';
      csv += 'الاسم رباعياً,الرقم القومي,الوظيفة,التخصص,التبعية,الكود,المدرسة\n';
      leadership
        .filter(l => selectedSchoolId === 'all' || l.schoolId === selectedSchoolId)
        .filter(l => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === l.specialty || l.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
        .forEach(leader => {
          const sch = schools.find(s => s.id === leader.schoolId);
          csv += `"${leader.name}","${leader.nationalId}","${leader.role === 'principal' ? 'مدير مدرسة' : 'وكيل مدرسة'}","${leader.specialty}","أصلي","${leader.code}","${sch?.name || ''}"\n`;
        });
      staff
        .filter(member => selectedSchoolId === 'all' || member.schoolId === selectedSchoolId)
        .filter(member => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === member.specialty || member.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
        .forEach(member => {
          const sch = schools.find(s => s.id === member.schoolId);
          const roleLabels: Record<string, string> = { teacher: 'معلم', specialist: 'أخصائي تخصصي', admin: 'إداري عام', worker: 'خدمات معاونة' };
          csv += `"${member.name}","${member.nationalId}","${roleLabels[member.role] || member.role}","${member.specialty}","${member.type === 'original' ? 'أصلي' : 'منتدب'}","${member.code}","${sch?.name || ''}"\n`;
        });
    } else if (reportType === 'leadership') {
      titleStr = 'تقرير_القيادات_المدرسية';
      csv += 'سجل السادة مديري المدارس والوكلاء بالإدارة\n';
      csv += 'المدرسة,الاسم رباعيا,الرقم القومي,كود المعلم,الوظيفة القيادية,التخصص الدراسي,المؤهل الدراسي,تاريخ المؤهل,تاريخ الميلاد,رقم القرار,تاريخ القرار,سنوات العمل بالمدرسة,العنوان بالتفصيل,رقم الهاتف\n';
      leadership
        .filter(l => selectedSchoolId === 'all' || l.schoolId === selectedSchoolId)
        .filter(l => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === l.specialty || l.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
        .forEach(leader => {
          const sch = schools.find(s => s.id === leader.schoolId);
          csv += `"${sch?.name || ''}","${leader.name}","${leader.nationalId}","${leader.code}","${leader.role === 'principal' ? 'مدير مدرسة' : 'وكيل مدرسة'}","${leader.specialty}","${leader.qualification || ''}","${leader.qualificationDate || ''}","${leader.birthDate || ''}","${leader.decisionNumber || ''}","${leader.decisionDate || ''}","${leader.schoolYearsCount !== undefined ? leader.schoolYearsCount : ''}","${leader.address || ''}","${leader.phone || ''}"\n`;
        });
    } else if (reportType === 'specialists') {
      titleStr = 'تقرير_الأخصائيين_التفصيلي_الشامل_بالمدارس';
      csv += 'تقرير حصر الكوادر والأخِصائيين بالمدارس المعتمد\n';
      csv += 'الاسم رباعياً,الرقم القومي,الكود,تاريخ الميلاد,التخصص الدقيق,المؤهل الدراسي,تاريخ التعيين,رقم الهاتف للتواصل,العنوان بالتفصيل,الحالة,المدرسة\n';
      staff
        .filter(member => member.role === 'specialist')
        .filter(member => selectedSchoolId === 'all' || member.schoolId === selectedSchoolId)
        .filter(member => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === member.specialty || member.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
        .forEach(member => {
          const sch = schools.find(s => s.id === member.schoolId);
          csv += `"${member.name}","${member.nationalId || ''}","${member.code || ''}","${member.birthDate || ''}","${member.specialty}","${member.qualification || '---'}","${member.appointmentDate || '---'}","${member.phone || '---'}","${member.address || '---'}","${member.type === 'original' ? 'أصلي' : 'منتدب'}","${sch?.name || ''}"\n`;
        });
    } else if (reportType === 'admins') {
      titleStr = 'تقرير_الإداريين_المفصل';
      csv += 'تقرير حصر الكوادر الإدارية وسكرتارية الكادر الفني بالمدارس\n';
      csv += 'الاسم رباعياً,الرقم القومي,الكود,تاريخ الميلاد,المسمى الوظيفي,المؤهل الدراسي,تاريخ التعيين,رقم الهاتف للتواصل,العنوان بالتفصيل,الحالة,المدرسة\n';
      staff
        .filter(member => member.role === 'admin' && member.specialty !== 'مشرف نشاط')
        .filter(member => selectedSchoolId === 'all' || member.schoolId === selectedSchoolId)
        .filter(member => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === member.specialty || member.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
        .forEach(member => {
          const sch = schools.find(s => s.id === member.schoolId);
          csv += `"${member.name}","${member.nationalId || ''}","${member.code || ''}","${member.birthDate || ''}","${member.specialty}","${member.qualification || '---'}","${member.appointmentDate || '---'}","${member.phone || '---'}","${member.address || '---'}","${member.type === 'original' ? 'أصلي' : 'منتدب'}","${sch?.name || ''}"\n`;
        });
    } else if (reportType === 'activity_supervisors') {
      titleStr = 'تقرير_مشرفي_الأنشطة_المفصل';
      csv += 'تقرير حصر مشرفي الأنشطة بالمدارس\n';
      csv += 'الاسم رباعياً,الرقم القومي,الكود,تاريخ الميلاد,المسمى الوظيفي,المؤهل الدراسي,تاريخ التعيين,رقم الهاتف للتواصل,العنوان بالتفصيل,الحالة,المدرسة\n';
      staff
        .filter(member => member.role === 'activity_supervisor' || (member.role === 'admin' && member.specialty === 'مشرف نشاط'))
        .filter(member => selectedSchoolId === 'all' || member.schoolId === selectedSchoolId)
        .filter(member => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === member.specialty || member.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
        .forEach(member => {
          const sch = schools.find(s => s.id === member.schoolId);
          csv += `"${member.name}","${member.nationalId || ''}","${member.code || ''}","${member.birthDate || ''}","${member.specialty}","${member.qualification || '---'}","${member.appointmentDate || '---'}","${member.phone || '---'}","${member.address || '---'}","${member.type === 'original' ? 'أصلي' : 'منتدب'}","${sch?.name || ''}"\n`;
        });
    } else if (reportType === 'workers') {
      titleStr = 'تقرير_العمال_والخدمات_المعاونة_المفصل_الشامل';
      csv += 'تقرير حصر العمال والحراسة والخدمات المعاونة بكافة المدارس\n';
      csv += 'الاسم رباعياً,الرقم القومي,الكود,تاريخ الميلاد,المسمى الوظيفي/الحرفي,المؤهل الدراسي,تاريخ التعيين,رقم الهاتف للتواصل,العنوان بالتفصيل,الحالة,المدرسة\n';
      staff
        .filter(member => member.role === 'worker')
        .filter(member => selectedSchoolId === 'all' || member.schoolId === selectedSchoolId)
        .filter(member => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === member.specialty || member.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
        .forEach(member => {
          const sch = schools.find(s => s.id === member.schoolId);
          csv += `"${member.name}","${member.nationalId || ''}","${member.code || ''}","${member.birthDate || ''}","${member.specialty || 'خدمات معاونة'}","${member.qualification || '---'}","${member.appointmentDate || '---'}","${member.phone || '---'}","${member.address || '---'}","${member.type === 'original' ? 'أصلي' : 'منتدب'}","${sch?.name || ''}"\n`;
        });
    } else if (reportType === 'students_absences') {
      titleStr = 'تقرير_غياب_الطلاب_اليومي';
      csv += 'تقرير ومؤشرات الحضور والغياب الإجمالي للتلاميذ بالمدارس\n';
      csv += 'المدرسة,التاريخ,الصف الدراسي,المقيد,الحاضر,الغائب,نسبة الغياب %\n';
      studentAbsences
        .filter(abs => selectedSchoolId === 'all' || abs.schoolId === selectedSchoolId)
        .filter(abs => !filterDate || abs.date === filterDate)
        .forEach(abs => {
          const sch = schools.find(s => s.id === abs.schoolId);
          abs.records.forEach(r => {
            const absRate = r.registered > 0 ? ((r.absent / r.registered) * 100).toFixed(1) : '0';
            csv += `"${sch?.name || ''}","${abs.date}","${r.grade}",${r.registered},${r.present},${r.absent},${absRate}%\n`;
          });
        });
    } else if (reportType === 'teachers_absences') {
      titleStr = 'تقرير_حضور_وغياب_الكوادر';
      csv += 'تقرير سجل وأرشفة حضور وغياب المعلمين والمنتدبين والدرجات اليومية\n';
      csv += 'المدرسة,التاريخ,المقيد,الندب,المأموريات,الاعتيادي,المرضي,الغياب كلياً,إجمالي الحضور\n';
      teacherAbsences
        .filter(abs => selectedSchoolId === 'all' || abs.schoolId === selectedSchoolId)
        .filter(abs => !filterDate || abs.date === filterDate)
        .forEach(abs => {
          const sch = schools.find(s => s.id === abs.schoolId);
          csv += `"${sch?.name || ''}","${abs.date}",${abs.registered},${abs.delegated},${abs.mission},${abs.regularLeave},${abs.sickLeave},${abs.absent},${abs.present}\n`;
        });
    } else if (reportType === 'nutrition') {
      titleStr = 'تقرير_التغذية_المدرسية';
      csv += 'سجل وقرارات الدعم والمستفيدين من الوجبات المدرسية\n';
      csv += 'المدرسة,العام الدراسي,أيام التوزيع المقررة,عدد المستحقين,إجمالي الوجبات التقديرية\n';
      nutrition
        .filter(nut => selectedSchoolId === 'all' || nut.schoolId === selectedSchoolId)
        .forEach(nut => {
          const sch = schools.find(s => s.id === nut.schoolId);
          csv += `"${sch?.name || ''}","${nut.academicYear}",${nut.distributionDays},${nut.beneficiariesCount},${nut.beneficiariesCount * nut.distributionDays}\n`;
        });
    }

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${titleStr}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Helper matching filter helper
  const matchesSearch = (text: string) => {
    if (!searchQuery.trim()) return true;
    return text.toString().toLowerCase().includes(searchQuery.toLowerCase());
  };

  const activeSchool = schools.find(s => s.id === selectedSchoolId);
  const activeMaterial = materials.find(m => m.id === selectedMaterialId);

  return (
    <div className="space-y-6">
      
      {/* Configuration bar print options */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4 print:hidden">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-1.5 font-sans">
            <Printer size={16} className="text-[#0D47A1]" />
            التقارير المجمعة الشاملة
          </h2>
          <p className="text-xs text-slate-500 mt-1">استخراج التقارير المجمّعة الشاملة لمدارس الإدارة ومعاينة وتصدير البيانات والطباعة الفورية</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
          <div>
            <label className="block text-xs font-black text-slate-800 mb-1">نوع التقرير الحكومي:</label>
            <select
              value={reportType}
              onChange={e => {
                setReportType(e.target.value);
                setSearchQuery('');
                setFilterDate('');
              }}
              className="w-full px-3 py-1.5 text-xs bg-white text-black font-black border border-slate-400 rounded text-right focus:outline-none focus:ring-1 focus:ring-blue-600 shadow-xs"
            >
              <option value="school" className="text-black bg-white">تقرير مدرسة وموادها وعجزها</option>
              <option value="school_students" className="text-black bg-white">تقرير توزيع وأعداد الطلاب بالمدارس (بنين/بنات/إجمالي)</option>
              <option value="material" className="text-black bg-white">تقرير مادة محددة بكافة المدارس</option>
              <option value="comprehensive" className="text-black bg-white">التقرير العام الشامل (كل الإدارة)</option>
              <option value="visitors" className="text-black bg-white">تقرير سجل زوار وموجّهي الإدارة</option>
              <option value="teachers" className="text-black bg-white">تقرير قوى المعلمين التفصيلي</option>
              <option value="leadership" className="text-black bg-white">تقرير القيادات المدرسية والوكلاء</option>
              <option value="specialists" className="text-black bg-white">تقرير الأخصائيين بالمدارس بالتفصيل</option>
              <option value="admins" className="text-black bg-white">تقرير الإداريين بالمدارس بالتفصيل</option>
              <option value="activity_supervisors" className="text-black bg-white">تقرير مشرفي الأنشطة بالمدارس بالتفصيل</option>
              <option value="workers" className="text-black bg-white">تقرير العمال والخدمات المعاونة والحراسة بالتفصيل</option>
              <option value="students_absences" className="text-black bg-white">تقرير غياب الطلاب اليومي</option>
              <option value="teachers_absences" className="text-black bg-white">تقرير حضور وغياب الكوادر</option>
              <option value="nutrition" className="text-black bg-white">تقرير التغذية المدرسية الكلي</option>
            </select>
          </div>

          {/* School filter is always visible for all reports now to allow smart filtering */}
          <div className="space-y-1">
            <label className="block text-xs font-black text-slate-800 mb-1">تصفية المدارس (البحث والاختيار ذكي):</label>
            <div className="flex gap-1">
              <input
                type="text"
                placeholder="🔍 اكتب لتصفية قائمة المدارس..."
                value={schoolSearchQuery}
                onChange={e => setSchoolSearchQuery(e.target.value)}
                className="w-1/2 px-2 py-1 text-xs bg-slate-50 border border-slate-300 rounded font-bold text-right focus:ring-1 focus:ring-blue-500 text-slate-800"
              />
              <select
                value={selectedSchoolId}
                onChange={e => setSelectedSchoolId(e.target.value)}
                className="w-1/2 px-3 py-1.5 text-xs bg-white text-blue-900 font-black border border-slate-400 rounded text-right focus:outline-none focus:ring-1 focus:ring-blue-600 shadow-xs"
              >
                <option value="all" className="text-blue-950 bg-blue-50 font-extrabold">🌍 جميع المدارس (بدون تصفية مدرسة)</option>
                {filteredSchools.map(s => (
                  <option key={s.id} value={s.id} className="text-black bg-white">{s.name}</option>
                ))}
                {filteredSchools.length === 0 && (
                  <option value="" disabled className="text-slate-400">لا توجد مدارس مطابقة</option>
                )}
              </select>
            </div>
          </div>

          {/* Material/Subject filter is always visible for all reports to allow smart filtering */}
          <div className="space-y-1">
            <label className="block text-xs font-black text-slate-800 mb-1">تصفية المواد الدراسية (البحث والاختيار):</label>
            <div className="flex gap-1">
              <input
                type="text"
                placeholder="🔍 اكتب لتصفية قائمة المواد..."
                value={materialSearchQuery}
                onChange={e => setMaterialSearchQuery(e.target.value)}
                className="w-1/2 px-2 py-1 text-xs bg-slate-50 border border-slate-300 rounded font-bold text-right focus:ring-1 focus:ring-blue-500 text-slate-800"
              />
              <select
                value={selectedMaterialId}
                onChange={e => setSelectedMaterialId(e.target.value)}
                className="w-1/2 px-3 py-1.5 text-xs bg-white text-blue-950 font-black border border-slate-400 rounded text-right focus:outline-none focus:ring-1 focus:ring-blue-600 shadow-xs"
              >
                <option value="all" className="text-blue-950 bg-blue-50 font-extrabold">🌍 جميع المواد الدراسية (بدون تصفية مادة)</option>
                {filteredMaterials.map(m => (
                  <option key={m.id} value={m.id} className="text-black bg-white">{m.name} - ({m.stage === 'primary' ? 'ابتدائي' : m.stage === 'prep' ? 'إعدادي' : 'ثانوي'})</option>
                ))}
                {filteredMaterials.length === 0 && (
                  <option value="" disabled className="text-slate-400">لا توجد مواد مطابقة</option>
                )}
              </select>
            </div>
          </div>

          {/* New Search Input */}
          <div>
            <label className="block text-xs font-black text-slate-800 mb-1">البحث والتصفية الفورية:</label>
            <input
              type="text"
              placeholder="اكتب اسم المدرسة أو البيان للفرز..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-white text-black font-black border border-slate-400 rounded text-right focus:outline-none focus:ring-1 focus:ring-blue-600 shadow-xs font-sans"
            />
          </div>

          {/* Grouping Selection for Deficit/Surplus (Comprehensive Report) */}
          {reportType === 'comprehensive' && (
            <div>
              <label className="block text-xs font-black text-blue-900 mb-1">تجميع الحسابات والتقرير حسب:</label>
              <select
                value={comprehensiveGrouping}
                onChange={e => setComprehensiveGrouping(e.target.value as any)}
                className="w-full px-3 py-1.5 text-xs bg-emerald-50 text-emerald-900 font-extrabold border-2 border-[#D4AF37] rounded focus:outline-none focus:ring-1 focus:ring-blue-600 shadow-xs"
              >
                <option value="none">📋 عرض غير مجمع تفصيلي (لكل مادة ومدرسة)</option>
                <option value="school">🏫 تجميع الحسابات حسب المدارس</option>
                <option value="material">📚 تجميع الحسابات حسب المواد الدراسية</option>
                <option value="stage">🎓 تجميع الحسابات حسب المراحل الدراسية</option>
              </select>
            </div>
          )}

          {/* New Date Filter Input (Optional, for date-based records) */}
          {(reportType === 'visitors' || reportType === 'students_absences' || reportType === 'teachers_absences') && (
            <div>
              <label className="block text-xs font-black text-slate-800 mb-1">تحديد تاريخ اليوم:</label>
              <input
                type="date"
                value={filterDate}
                onChange={e => setFilterDate(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-white text-black font-black border border-slate-400 rounded focus:outline-none focus:ring-1 focus:ring-blue-600 shadow-xs leading-none font-sans"
              />
            </div>
          )}

          <div className="col-span-1 md:col-span-4 flex flex-wrap md:flex-nowrap gap-2">
            <button
              onClick={handlePrint}
              type="button"
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-gradient-to-r from-[#1976D2] to-[#303F9F] hover:from-[#0D47A1] hover:to-[#1A237E] text-white font-extrabold rounded-lg text-xs transition cursor-pointer shadow-sm active:scale-95"
            >
              <Printer size={13} className="text-yellow-300" />
              طباعة التقرير للمتصفح
            </button>
            <button
              onClick={handlePdfExport}
              type="button"
              disabled={exportingPdf}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-gradient-to-r from-[#D4AF37] to-amber-600 hover:from-yellow-600 hover:to-amber-700 text-white font-extrabold rounded-lg text-xs transition cursor-pointer shadow-sm active:scale-95 disabled:opacity-50"
            >
              <Download size={13} className="text-amber-100 font-bold" />
              {exportingPdf ? 'جاري تصدير PDF...' : 'تصدير PDF منفصل (مطور)'}
            </button>

            <button
              onClick={() => handleArchiveReport(false)}
              type="button"
              disabled={archivingReport}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-gradient-to-r from-[#303F9F] to-[#1A237E] hover:from-[#1A237E] hover:to-[#0D47A1] text-white font-extrabold rounded-lg text-xs transition cursor-pointer shadow-sm active:scale-95 disabled:opacity-50"
            >
              <Archive size={13} className="text-pink-300 font-bold" />
              {archivingReport ? 'جاري الحفظ...' : 'أرشفة التقرير تاريخياً'}
            </button>
          </div>
        </div>
      </div>

      {/* 🗄️ LOCAL JSON ARCHIVE & BOOKKEEPING CENTER */}
      <div className="bg-[#FAF9F5] border-2 border-[#D4AF37] rounded-xl p-5 md:p-6 space-y-4 shadow-md select-none print:hidden">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 pb-3 border-b border-[#D4AF37]/30">
          <div>
            <h3 className="text-sm md:text-md font-extrabold text-[#7F600D] flex items-center gap-2 font-sans">
              <History className="text-[#D4AF37] animate-pulse w-5 h-5" />
              منظومة الأرشفة التاريخية وتوثيق السجلات اللحظية للحفظ (JSON)
            </h3>
            <p className="text-[11px] text-slate-600 mt-1 font-bold">
              حفظ وتوثيق سجلات الإدارة بصورة لحظية كملفات مرجعية، واستيراد وتصدير الأرشيف لغايات المتابعة التاريخية والحفظ المضمون
            </p>
          </div>

          <div className="flex flex-wrap gap-2 text-xs font-bold">
            <label className="px-3.5 py-1.5 bg-gradient-to-r from-[#00897B] to-[#00695C] hover:from-[#00695C] hover:to-[#004D40] text-white rounded-lg transition duration-200 cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95">
              <Upload size={13} className="text-white" />
              استيراد أرشيف خارجي (JSON)
              <input
                type="file"
                accept=".json"
                onChange={handleImportSnapshotsJSON}
                className="hidden"
              />
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 pt-1 text-right">
          {/* Capture Section */}
          <div className="space-y-2 lg:border-l lg:border-slate-200 lg:pl-4">
            <h4 className="text-xs font-black text-slate-800 flex items-center gap-1">
              <span className="text-indigo-600 font-extrabold text-sm">●</span> التقاط نسخة أرشيفية جديدة لموسم الحفظ (Snapshot):
            </h4>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="اكتب اسم الفترة الأرشيفية (مثلاً: أرشيف أكتوبر ٢٠٢٦)..."
                value={newSnapshotName}
                onChange={e => setNewSnapshotName(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs bg-white text-[#212121] border border-slate-350 rounded focus:outline-none focus:ring-1 focus:ring-[#1976D2] font-sans"
              />
              <button
                type="button"
                onClick={handleCreateSnapshot}
                className="px-3 py-1.5 bg-gradient-to-r from-[#5E35B1] to-[#3949AB] hover:from-[#4527A0] hover:to-[#283593] text-white font-extrabold rounded-lg text-xs transition duration-200 cursor-pointer flex items-center gap-1 active:scale-95 shadow-xs"
              >
                <Plus size={12} />
                حفظ بالأرشيف
              </button>
            </div>
            <p className="text-[10px] text-slate-500 font-bold leading-relaxed">
              تقوم هذه الميزة بالتقاط لقطة فورية متكاملة لبيانات المدارس والمواد وحضور الكوادر لحفظها محلياً وبصيغة JSON.
            </p>
          </div>

          {/* List of saved snapshots strictly for archival reference */}
          <div className="space-y-2 lg:col-span-2">
            <h4 className="text-xs font-black text-slate-800 flex items-center justify-between">
              <span>
                <span className="text-emerald-700 font-extrabold text-sm">●</span> قائمة النسخ واللقطات المرجعية المحفوظة محلياً:
              </span>
            </h4>

            {/* Snapshots Stats Overview or Delete Options */}
            {snapshots.length > 0 ? (
              <div className="flex flex-wrap gap-1.5 pt-1.5">
                {snapshots.map(snap => (
                  <div 
                    key={snap.id} 
                    className="text-[10px] items-center gap-1.5 px-2.5 py-1 rounded-md border flex transition duration-150 bg-white border-slate-200 text-slate-700 font-bold hover:bg-slate-50 shadow-2xs"
                  >
                    <span>
                      📦 {snap.name} ({new Date(snap.createdAt).toLocaleDateString('ar-EG')})
                    </span>
                    {confirmDeleteSnapshotId === snap.id ? (
                      <div className="flex items-center gap-1 animate-pulse">
                        <button
                          type="button"
                          onClick={() => {
                            handleDeleteSnapshot(snap.id, snap.name);
                            setConfirmDeleteSnapshotId(null);
                          }}
                          className="px-1 py-0.2 bg-rose-600 text-white rounded text-[8px] font-bold font-sans cursor-pointer h-4 flex items-center"
                        >
                          تأكيد
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteSnapshotId(null)}
                          className="px-1 py-0.2 bg-slate-200 text-slate-700 rounded text-[8px] font-bold font-sans cursor-pointer h-4 flex items-center"
                        >
                          تراجع
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteSnapshotId(snap.id)}
                        className="w-4 h-4 rounded-full bg-rose-50 hover:bg-rose-100 flex items-center justify-center text-rose-600 transition cursor-pointer font-bold select-none text-[8.5px]"
                        title="حذف هذا السجل"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[10.5px] text-slate-500 italic pt-1 font-bold">
                لا توجد سجلات تاريخية محفوظة بمتصفحك حالياً. اكتب اسماً في التقاط نسخة زمنية تالية واحفظ لتوثيق أعمال الإشراف!
              </p>
            )}
          </div>
        </div>
      </div>

      {/* 🏛️ CENTRAL DATABASE-BACKED CERTIFIED REPORTS ARCHIVE GATEWAY */}
      <div className="bg-white border border-indigo-150 rounded-xl p-5 md:p-6 space-y-4 shadow-md select-none print:hidden">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 pb-3 border-b border-indigo-100">
          <div>
            <h3 className="text-sm md:text-md font-extrabold text-indigo-900 flex items-center gap-2 font-sans">
              <FileCheck className="text-indigo-600 w-5 h-5" />
              بوابة أرشيف التقارير المعتمدة والمصدرة تاريخياً (قاعدة البيانات السحابية)
            </h3>
            <p className="text-[11px] text-slate-500 mt-1 font-bold">
              مكتبة مراجعة التقارير التاريخية الموثقة لإدارة أبو حماد التعليمية للرجوع لنسخ التنسيق والتشكيلات المدرسية السابقة وحفظها كمرجع قانوني معتمد
            </p>
          </div>
          <div className="text-xs bg-indigo-50 text-indigo-800 px-3 py-1 rounded-md font-black border border-indigo-100">
            إجمالي السجلات السحابية: {archivedReports.length} تقارير
          </div>
        </div>

        {archivedReports.length > 0 ? (
          <div className="overflow-x-auto border border-slate-100 rounded-lg">
            <table className="w-full text-right text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-slate-700 font-extrabold">
                  <th className="p-2.5 text-right font-black">عنوان التقرير المعتمد</th>
                  <th className="p-2.5 text-right font-black">نوع التقرير</th>
                  <th className="p-2.5 text-right font-black">تاريخ الأرشفة</th>
                  <th className="p-2.5 text-right font-black">المسؤول المفوّض</th>
                  <th className="p-2.5 text-center font-black">خيارات التحكم المتاحة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {archivedReports.map(report => (
                  <tr key={report.id} className="hover:bg-indigo-50/20 transition-colors">
                    <td className="p-2.5 font-bold text-slate-900">{report.title}</td>
                    <td className="p-2.5">
                      <span className="px-2 py-0.5 text-[10px] bg-indigo-50 text-indigo-700 rounded-full font-black border border-indigo-100/50">
                        {report.reportType}
                      </span>
                    </td>
                    <td className="p-2.5 font-mono text-slate-500 text-[10px]">
                      {new Date(report.exportedAt).toLocaleDateString('ar-EG', {
                        year: 'numeric', month: 'long', day: 'numeric',
                        hour: '2-digit', minute: '2-digit'
                      })}
                    </td>
                    <td className="p-2.5 text-slate-600 font-medium">{report.exportedBy}</td>
                    <td className="p-2.5 flex items-center justify-center gap-2">
                      <button
                        onClick={() => {
                          setSelectedArchivedReport(report);
                          setIsViewArchiveModalOpen(true);
                        }}
                        type="button"
                        className="px-3 py-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-[11px] font-extrabold rounded flex items-center gap-1 cursor-pointer shadow-2xs active:scale-95"
                      >
                        <Eye size={11} className="text-white" />
                        عرض ومعاينة للطباعة
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('هل أنت متأكد من رغبتك في حذف هذا التقرير المؤرشف نهائياً من قاعدة البيانات السحابية؟')) {
                            dbInstance.deleteArchivedReport(report.id);
                            alert('تم حذف التقرير المؤرشف بنجاح.');
                          }
                        }}
                        type="button"
                        className="px-2 py-1 border border-rose-300 text-rose-600 hover:bg-rose-50 hover:text-rose-700 text-[11px] font-extrabold rounded flex items-center gap-1 cursor-pointer transition active:scale-95"
                      >
                        <Trash2 size={11} />
                        حذف السجل
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="bg-slate-50 p-6 rounded-lg text-center border border-slate-100">
            <p className="text-xs text-slate-500 italic font-bold">
              لا توجد تقارير مؤرشفة في قاعدة البيانات حالياً. يمكنك أرشفة التقرير الحالي بالضغط على زر "أرشفة التقرير تاريخياً" بالأعلى، أو سيقوم النظام تلقائياً بحفظ لقطة مرجعية عند إصدار أي مستند PDF أو طباعته للرجوع القانوني والتاريخي الآمن!
            </p>
          </div>
        )}
      </div>

      {/* 🔍 HIGH-FIDELITY ARCHIVED REPORT PREVIEW MODAL */}
      {isViewArchiveModalOpen && selectedArchivedReport && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 print:hidden">
          <div className="bg-white rounded-2xl w-full max-w-5xl shadow-2xl border border-slate-200 flex flex-col max-h-[90vh] overflow-hidden animate-fade-in" dir="rtl">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-indigo-900 to-[#1976D2] text-white p-5 flex justify-between items-center select-none">
              <div>
                <h3 className="font-sans font-black text-sm md:text-md flex items-center gap-2">
                  <Archive size={18} className="text-pink-300 animate-bounce" />
                  معاينة النسخة التاريخية المعتمدة بالأرشيف
                </h3>
                <p className="text-[11px] text-indigo-100 font-bold mt-0.5">
                  تاريخ الأرشفة: {new Date(selectedArchivedReport.exportedAt).toLocaleString('ar-EG')} | بواسطة: {selectedArchivedReport.exportedBy}
                </p>
              </div>
              <button
                onClick={() => {
                  setIsViewArchiveModalOpen(false);
                  setSelectedArchivedReport(null);
                }}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center font-bold text-white transition cursor-pointer text-sm"
              >
                ✕
              </button>
            </div>

            {/* Modal Actions */}
            <div className="bg-slate-50 border-b border-slate-200 p-4 flex flex-wrap gap-2 justify-between items-center select-none">
              <div className="text-xs text-slate-600 font-black">
                {selectedArchivedReport.title}
              </div>
              <div className="flex gap-2 text-xs font-black">
                <button
                  onClick={() => {
                    const printWindow = window.open('', '_blank');
                    if (printWindow) {
                      printWindow.document.write(`
                        <html>
                          <head>
                            <title>${selectedArchivedReport.title}</title>
                            <style>
                              body { font-family: system-ui, -apple-system, sans-serif; direction: rtl; padding: 20px; }
                              table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 11px; }
                              th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }
                              th { bg-color: #f5f5f5; font-weight: bold; }
                              .print\\:hidden, button, select, input { display: none !important; }
                              @media print {
                                body { padding: 0; }
                              }
                            </style>
                          </head>
                          <body>
                            <div style="text-align: center; margin-bottom: 30px;">
                              <h2>إدارة أبو حماد التعليمية</h2>
                              <h3>الأرشيف المركزي لبيانات التنسيق والمقررات</h3>
                              <p>تاريخ النسخة المعتمدة: ${new Date(selectedArchivedReport.exportedAt).toLocaleDateString('ar-EG')}</p>
                              <hr style="border: 1px solid #111; margin: 20px 0;"/>
                            </div>
                            <div>
                              ${selectedArchivedReport.htmlSnapshot}
                            </div>
                            <script>
                              window.addEventListener('DOMContentLoaded', () => {
                                window.focus();
                                window.print();
                                setTimeout(() => window.close(), 1000);
                              });
                            </script>
                          </body>
                        </html>
                      `);
                      printWindow.document.close();
                    } else {
                      alert('تم حظر فتح النافذة المنبثقة من قبل متصفحك. يرجى السماح بالنوافذ المنبثقة لطباعة التقرير.');
                    }
                  }}
                  type="button"
                  className="px-4 py-1.8 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded cursor-pointer transition shadow-2xs active:scale-95 flex items-center gap-1.5"
                >
                  <Printer size={13} className="text-yellow-300" />
                  طباعة فورية للتقرير
                </button>
                <button
                  onClick={async () => {
                    const modalElement = document.getElementById('archived-modal-print-area');
                    if (!modalElement) return;
                    setExportingPdf(true);
                    
                    const isWide = selectedArchivedReport.title.includes('الشامل') || selectedArchivedReport.title.includes('كل الإدارة');
                    const originalStyle = modalElement.style.cssText;
                    
                    try {
                      const targetWidth = isWide ? '297mm' : '210mm';
                      modalElement.style.cssText += `; width: ${targetWidth} !important; max-width: none !important; overflow: visible !important; background: white !important; padding: 15px;`;
                      
                      const canvas = await withOklchBypass(async () => {
                        return await html2canvas(modalElement, {
                          scale: 2,
                          useCORS: true,
                          backgroundColor: '#ffffff'
                        });
                      });

                      const imgData = canvas.toDataURL('image/jpeg', 0.95);
                      const pdf = isWide ? new jsPDF('l', 'mm', 'a4') : new jsPDF('p', 'mm', 'a4');
                      const imgWidth = isWide ? 297 : 210;
                      const pageHeight = isWide ? 210 : 297;
                      const imgHeight = (canvas.height * imgWidth) / canvas.width;
                      let heightLeft = imgHeight;
                      let position = 0;

                      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
                      heightLeft -= pageHeight;

                      while (heightLeft >= 0) {
                        position = heightLeft - imgHeight;
                        pdf.addPage();
                        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
                        heightLeft -= pageHeight;
                      }

                      pdf.save(`أرشيف_${selectedArchivedReport.title.replace(/\s+/g, '_')}.pdf`);
                    } catch (e) {
                      console.error('Failed to export archived PDF:', e);
                      alert('حدث خطأ أثناء تصدير مستند الأرشيف كـ PDF.');
                    } finally {
                      modalElement.style.cssText = originalStyle;
                      setExportingPdf(false);
                    }
                  }}
                  type="button"
                  className="px-4 py-1.8 bg-gradient-to-r from-[#D4AF37] to-amber-600 hover:from-yellow-600 hover:to-amber-700 text-white rounded cursor-pointer transition shadow-2xs active:scale-95 flex items-center gap-1.5"
                >
                  <Download size={13} className="text-white" />
                  تحميل كـ PDF
                </button>
                <button
                  onClick={() => {
                    setIsViewArchiveModalOpen(false);
                    setSelectedArchivedReport(null);
                  }}
                  type="button"
                  className="px-3.5 py-1.8 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded cursor-pointer transition active:scale-95"
                >
                  إغلاق
                </button>
              </div>
            </div>

            {/* Modal Body / Scrollable Preview Canvas */}
            <div className="flex-1 p-6 overflow-y-auto bg-slate-50 border-t border-slate-100">
              <div 
                id="archived-modal-print-area" 
                className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm max-w-4xl mx-auto min-h-[60vh] text-right select-all"
                dangerouslySetInnerHTML={{ __html: selectedArchivedReport.htmlSnapshot }}
              />
            </div>

          </div>
        </div>
      )}

      {/* Actual printed interface with report wrapper */}
      <div id="printable-report-area" className="print:m-0 print:p-0 bg-white p-4 rounded-xl">
        
        {reportType === 'school' && !activeSchool && (
          <div className="bg-amber-50 border-2 border-amber-300 p-8 rounded-xl text-center space-y-2 select-none print:hidden">
            <AlertTriangle className="mx-auto text-amber-500 mb-2" size={32} />
            <p className="text-sm font-black text-amber-900">يرجى تحديد مدرسة معينة من القائمة أعلاه لعرض هذا التقرير التفصيلي.</p>
            <p className="text-xs text-slate-500">تقرير "مدرسة وموادها وعجزها" هو تقرير فردي تفصيلي يخص المؤسسات منفرداً.</p>
          </div>
        )}

        {reportType === 'school' && activeSchool && (
          <PrintableReport 
            title={`البيانات الإحصائية والأنصبة والتبعية لمدرسة:\n ${activeSchool.name}`} 
            subtitle={`تقرير معتمد صادر عن قسم تنسيق الإدارة التعليمية بأبو حماد لعام ${activeSchool.year}`}
          >
            <div className="space-y-6">
              {/* Active Snapshot banner at top of printed report */}
              {activeSnapshot && (
                <div className="bg-emerald-50/80 border border-emerald-300 rounded-lg p-3 text-[11px] text-slate-800 flex items-center justify-between select-none print:bg-white print:border-emerald-600">
                  <p className="font-extrabold flex items-center gap-1.5">
                    <History size={14} className="text-[#2E7D32]" />
                    مقارنة السجلات مفعلة تلقائياً مع السجل التاريخي: <span className="text-[#2E7D32] font-black underline underline-offset-2">"{activeSnapshot.name}"</span>
                  </p>
                  <p className="text-[10px] text-slate-500 font-bold font-mono">
                    تاريخ الالتقاط: {new Date(activeSnapshot.createdAt).toLocaleDateString('ar-EG')}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 lg:grid-cols-7 gap-4 border border-slate-2 bg-slate-50 p-4 rounded text-[11px] select-none text-slate-700">
                <div>التبعية: <span className="font-bold text-slate-850">حكومي مركزي</span></div>
                <div>المرحلة: <span className="font-bold text-blue-800">{(activeSchool.stage).toUpperCase()}</span></div>
                <div>الفصول: <span className="font-bold font-mono text-slate-950 font-black">{activeSchool.classroomsCount}</span></div>
                <div>بنين: <span className="font-bold font-mono text-[#0D47A1]">{activeSchool.boysCount || 0}</span></div>
                <div>بنات: <span className="font-bold font-mono text-pink-600">{activeSchool.girlsCount || 0}</span></div>
                <div>إجمالي الطلاب: <span className="font-bold font-mono text-emerald-800 font-extrabold">{activeSchool.totalStudentsCount || 0}</span></div>
                <div className="col-span-2 lg:col-span-1">الموقع: <span className="font-bold text-slate-700">{activeSchool.address}</span></div>
              </div>

              <div className="overflow-x-auto border border-slate-200/85 rounded-xl transition-all duration-300 shadow-xs">
                <table className="w-full text-right text-xs border border-collapse">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#0D47A1] to-[#1E88E5] text-white font-bold border">
                      <th className="p-2 border">المادة الدراسية</th>
                      <th className="p-2 border text-center">المطلوب</th>
                      <th className="p-2 border text-center">المقيد الفعلي</th>
                      <th className="p-2 border text-center text-red-600 bg-red-50/10">العجز</th>
                      <th className="p-2 border text-center text-emerald-700 bg-emerald-50/10">الزيادة</th>
                      <th className="p-2 border text-center">الكفاية %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {materials.map(mat => {
                      const count = materialCounts.find(c => c.schoolId === activeSchool.id && c.materialId === mat.id);
                      const metr = dbInstance.calculateMaterialMetrics(activeSchool, mat, count);
                      
                      if (!metr.applicable) return null;

                      // Comparison snapshot checks
                      const compSch = activeSnapshot?.schools.find(s => s.id === activeSchool.id || s.name === activeSchool.name);
                      const compCount = compSch ? activeSnapshot?.materialCounts.find(c => c.schoolId === compSch.id && c.materialId === mat.id) : null;
                      const compMetr = compSch ? dbInstance.calculateMaterialMetrics(compSch, mat, compCount) : null;

                      // Calculate deltas
                      const diffNeeded = metr.needed - (compMetr?.needed || 0);
                      const diffPresent = metr.present - (compMetr?.present || 0);
                      const diffDeficit = metr.deficit - (compMetr?.deficit || 0);
                      const diffSurplus = metr.surplus - (compMetr?.surplus || 0);

                      return (
                        <tr key={mat.id} className="border-b hover:bg-gradient-to-r hover:from-blue-50/40 hover:to-indigo-50/20 transition-all duration-300 hover:translate-x-[-2px]">
                          <td className="p-2 font-bold border">{mat.name}</td>
                          
                          {/* Required */}
                          <td className="p-2 border text-center font-mono">
                            <div className="flex flex-col items-center">
                              <span className="font-bold text-slate-900">{metr.needed}</span>
                              {compMetr && diffNeeded !== 0 && (
                                <span className="text-[9px] font-black text-slate-500 bg-slate-100 px-1 py-0.2 rounded mt-0.5" title={`السابق: ${compMetr.needed}`}>
                                  {diffNeeded > 0 ? `+${diffNeeded} مطلوب` : `${diffNeeded} مطلوب`}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Present strength */}
                          <td className="p-2 border text-center font-mono">
                            <div className="flex flex-col items-center">
                              <span className="font-bold text-[#0D47A1]">{metr.present}</span>
                              {compMetr && diffPresent !== 0 && (
                                <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffPresent > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`} title={`السابق: ${compMetr.present}`}>
                                  {diffPresent > 0 ? `+${diffPresent} معلم` : `${diffPresent} معلم`}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Deficit (العجز) */}
                          <td className={`p-2 border text-center font-mono font-bold ${metr.deficit > 0 ? 'bg-red-50/25 text-red-650' : ''}`}>
                            <div className="flex flex-col items-center">
                              <span>{metr.deficit || '---'}</span>
                              {compMetr && (metr.deficit !== 0 || compMetr.deficit !== 0) && diffDeficit !== 0 && (
                                <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffDeficit < 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`} title={`السابق: ${compMetr.deficit}`}>
                                  {diffDeficit < 0 ? `تحسن ${diffDeficit}` : `زيادة عجز +${diffDeficit}`}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Surplus */}
                          <td className={`p-2 border text-center font-mono font-bold ${metr.surplus > 0 ? 'bg-emerald-50/25 text-emerald-800' : ''}`}>
                            <div className="flex flex-col items-center">
                              <span>{metr.surplus || '---'}</span>
                              {compMetr && (metr.surplus !== 0 || compMetr.surplus !== 0) && diffSurplus !== 0 && (
                                <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffSurplus > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`} title={`السابق: ${compMetr.surplus}`}>
                                  {diffSurplus > 0 ? `وفرة +${diffSurplus}` : `نقص وفر ${diffSurplus}`}
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="p-2 text-center font-mono border font-black">
                            <div className="flex flex-col items-center">
                              <span>{metr.percentage}%</span>
                              {compMetr && metr.percentage !== compMetr.percentage && (
                                <span className={`text-[8px] font-bold ${metr.percentage > compMetr.percentage ? 'text-[#2E7D32]' : 'text-[#D32F2F]'}`}>
                                  {metr.percentage > compMetr.percentage ? '📈 صعد' : '📉 هبط'}
                                </span>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'school_students' && (
          <PrintableReport 
            title="بيان إحصاء وتوزيع أعداد الطلاب بمدارس الإدارة" 
            subtitle="التقرير العام المعتمد للمقيدين الفعليين بالمدارس وتعديلات وتصنيفات الجنس (بنين / بنات / إجمالي)"
          >
            <div className="space-y-4">
              {/* Active Snapshot banner */}
              {activeSnapshot && (
                <div className="bg-emerald-50/80 border border-emerald-300 rounded-lg p-3 text-[11px] text-slate-800 flex items-center justify-between select-none print:bg-white print:border-emerald-600">
                  <p className="font-extrabold flex items-center gap-1.5">
                    <History size={14} className="text-[#2E7D32]" />
                    مقارنة السجلات مفعلة تلقائياً مع السجل التاريخي: <span className="text-[#2E7D32] font-black underline underline-offset-2">"{activeSnapshot.name}"</span>
                  </p>
                  <p className="text-[10px] text-slate-500 font-bold font-mono">
                    تاريخ الالتقاط: {new Date(activeSnapshot.createdAt).toLocaleDateString('ar-EG')}
                  </p>
                </div>
              )}

              <div className="overflow-x-auto border border-slate-200/85 rounded-xl transition-all duration-300 shadow-xs">
                <table className="w-full text-right text-xs border border-collapse select-none">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#0D47A1] to-[#1E88E5] text-white font-bold border">
                      <th className="p-2.5 border cursor-pointer hover:bg-blue-800 text-right" onClick={() => toggleSort('name')}>
                        المدرسة المستهدفة {sortField === 'name' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                      <th className="p-2.5 border text-center cursor-pointer hover:bg-blue-800" onClick={() => toggleSort('stage')}>
                        المرحلة {sortField === 'stage' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                      <th className="p-2.5 border text-center cursor-pointer hover:bg-blue-800" onClick={() => toggleSort('classroomsCount')}>
                        الفصول {sortField === 'classroomsCount' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                      <th className="p-2.5 border text-center cursor-pointer hover:bg-blue-800 bg-[#0D47A1]/85" onClick={() => toggleSort('boysCount')}>
                        عدد البنين {sortField === 'boysCount' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                      <th className="p-2.5 border text-center cursor-pointer hover:bg-blue-800 bg-pink-700/80" onClick={() => toggleSort('girlsCount')}>
                        عدد البنات {sortField === 'girlsCount' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                      <th className="p-2.5 border text-center cursor-pointer hover:bg-blue-800 bg-emerald-750 font-black" onClick={() => toggleSort('totalStudentsCount')}>
                        إجمالي المقيدين بالكامل {sortField === 'totalStudentsCount' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const filtered = schools
                        .filter(s => selectedSchoolId === 'all' || s.id === selectedSchoolId)
                        .filter(s => matchesSearch(s.name));
                      const sorted = sortData(filtered, (item) => {
                        if (sortField === 'name') return item.name;
                        if (sortField === 'stage') return item.stage;
                        if (sortField === 'classroomsCount') return item.classroomsCount || 0;
                        if (sortField === 'boysCount') return item.boysCount || 0;
                        if (sortField === 'girlsCount') return item.girlsCount || 0;
                        if (sortField === 'totalStudentsCount') return item.totalStudentsCount || 0;
                        return item.name;
                      });

                      const totalClassrooms = filtered.reduce((acc, s) => acc + (s.classroomsCount || 0), 0);
                      const totalBoys = filtered.reduce((acc, s) => acc + (s.boysCount || 0), 0);
                      const totalGirls = filtered.reduce((acc, s) => acc + (s.girlsCount || 0), 0);
                      const totalAll = filtered.reduce((acc, s) => acc + (s.totalStudentsCount || 0), 0);

                      // Historical Snapshot Accumulations
                      const prevTotalClassrooms = activeSnapshot ? activeSnapshot.schools
                        .filter(s => selectedSchoolId === 'all' || s.id === selectedSchoolId || schools.find(sch => sch.id === selectedSchoolId)?.name === s.name)
                        .filter(s => matchesSearch(s.name))
                        .reduce((acc, s) => acc + (s.classroomsCount || 0), 0) : 0;
                      const diffTotalClassrooms = totalClassrooms - prevTotalClassrooms;

                      const prevTotalBoys = activeSnapshot ? activeSnapshot.schools
                        .filter(s => selectedSchoolId === 'all' || s.id === selectedSchoolId || schools.find(sch => sch.id === selectedSchoolId)?.name === s.name)
                        .filter(s => matchesSearch(s.name))
                        .reduce((acc, s) => acc + (s.boysCount || 0), 0) : 0;
                      const diffTotalBoys = totalBoys - prevTotalBoys;

                      const prevTotalGirls = activeSnapshot ? activeSnapshot.schools
                        .filter(s => selectedSchoolId === 'all' || s.id === selectedSchoolId || schools.find(sch => sch.id === selectedSchoolId)?.name === s.name)
                        .filter(s => matchesSearch(s.name))
                        .reduce((acc, s) => acc + (s.girlsCount || 0), 0) : 0;
                      const diffTotalGirls = totalGirls - prevTotalGirls;

                      const prevTotalAll = activeSnapshot ? activeSnapshot.schools
                        .filter(s => selectedSchoolId === 'all' || s.id === selectedSchoolId || schools.find(sch => sch.id === selectedSchoolId)?.name === s.name)
                        .filter(s => matchesSearch(s.name))
                        .reduce((acc, s) => acc + (s.totalStudentsCount || 0), 0) : 0;
                      const diffTotalAll = totalAll - prevTotalAll;

                      return (
                        <>
                          {sorted.map(sch => {
                            const compSch = activeSnapshot?.schools.find(s => s.id === sch.id || s.name === sch.name);
                            
                            const diffClassrooms = (sch.classroomsCount || 0) - (compSch?.classroomsCount || 0);
                            const diffBoys = (sch.boysCount || 0) - (compSch?.boysCount || 0);
                            const diffGirls = (sch.girlsCount || 0) - (compSch?.girlsCount || 0);
                            const diffTotal = (sch.totalStudentsCount || 0) - (compSch?.totalStudentsCount || 0);

                            return (
                              <tr key={sch.id} className="border-b hover:bg-gradient-to-r hover:from-blue-50/20 hover:to-indigo-50/10 transition-all duration-300">
                                <td className="p-2.5 font-bold border text-slate-900">{sch.name}</td>
                                <td className="p-2.5 text-center border font-sans uppercase font-bold text-blue-800 text-[10px]">{sch.stage}</td>
                                
                                {/* Classrooms */}
                                <td className="p-2.5 text-center font-mono font-medium border">
                                  <div className="flex flex-col items-center">
                                    <span>{sch.classroomsCount || 0}</span>
                                    {activeSnapshot && compSch && diffClassrooms !== 0 && (
                                      <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffClassrooms > 0 ? 'bg-emerald-105 text-[#2E7D32]' : 'bg-red-105 text-[#D32F2F]'}`} title={`السابق: ${compSch.classroomsCount}`}>
                                        {diffClassrooms > 0 ? `+${diffClassrooms} فصل` : `${diffClassrooms} فصل`}
                                      </span>
                                    )}
                                  </div>
                                </td>

                                {/* Boys */}
                                <td className="p-2.5 text-center font-mono font-bold border text-blue-900 bg-blue-50/15">
                                  <div className="flex flex-col items-center">
                                    <span>{sch.boysCount || 0}</span>
                                    {activeSnapshot && compSch && diffBoys !== 0 && (
                                      <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffBoys > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-105 text-[#D32F2F]'}`} title={`السابق: ${compSch.boysCount}`}>
                                        {diffBoys > 0 ? `+${diffBoys} بنين` : `${diffBoys}`}
                                      </span>
                                    )}
                                  </div>
                                </td>

                                {/* Girls */}
                                <td className="p-2.5 text-center font-mono font-bold border text-pink-700 bg-pink-50/15">
                                  <div className="flex flex-col items-center">
                                    <span>{sch.girlsCount || 0}</span>
                                    {activeSnapshot && compSch && diffGirls !== 0 && (
                                      <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffGirls > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-105 text-[#D32F2F]'}`} title={`السابق: ${compSch.girlsCount}`}>
                                        {diffGirls > 0 ? `+${diffGirls} بنات` : `${diffGirls}`}
                                      </span>
                                    )}
                                  </div>
                                </td>

                                {/* Total students */}
                                <td className="p-2.5 text-center font-mono font-black border text-emerald-800 bg-slate-50">
                                  <div className="flex flex-col items-center">
                                    <span>{sch.totalStudentsCount || 0}</span>
                                    {activeSnapshot && compSch && diffTotal !== 0 && (
                                      <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffTotal > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-105 text-[#D32F2F]'}`} title={`السابق: ${compSch.totalStudentsCount}`}>
                                        {diffTotal > 0 ? `+${diffTotal} طالب` : `${diffTotal}`}
                                      </span>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}

                          {/* Automath Grand totals */}
                          <tr className="bg-slate-100 font-bold text-slate-900">
                            <td className="p-2.5 font-black border text-right">إجمالي الإدارة المشمول بالتقرير</td>
                            <td className="p-2.5 text-center border font-sans text-[10px] text-slate-500">مجموع تراكمي</td>
                            
                            {/* Cumulative classrooms */}
                            <td className="p-2.5 text-center font-mono border text-slate-950 font-black">
                              <div className="flex flex-col items-center">
                                <span>{totalClassrooms} فصل</span>
                                {activeSnapshot && diffTotalClassrooms !== 0 && (
                                  <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffTotalClassrooms > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`} title={`السابق المجموع: ${prevTotalClassrooms}`}>
                                    {diffTotalClassrooms > 0 ? `+${diffTotalClassrooms} مجموع` : `${diffTotalClassrooms}`}
                                  </span>
                                )}
                              </div>
                            </td>

                            {/* Cumulative Boys */}
                            <td className="p-2.5 text-center font-mono border text-blue-950 font-black bg-blue-100/30">
                              <div className="flex flex-col items-center">
                                <span>{totalBoys} تلميذ</span>
                                {activeSnapshot && diffTotalBoys !== 0 && (
                                  <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffTotalBoys > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`} title={`السابق المجموع: ${prevTotalBoys}`}>
                                    {diffTotalBoys > 0 ? `+${diffTotalBoys} بنين` : `${diffTotalBoys}`}
                                  </span>
                                )}
                              </div>
                            </td>

                            {/* Cumulative Girls */}
                            <td className="p-2.5 text-center font-mono border text-pink-950 font-black bg-pink-100/30">
                              <div className="flex flex-col items-center">
                                <span>{totalGirls} تلميذة</span>
                                {activeSnapshot && diffTotalGirls !== 0 && (
                                  <span className={`text-[9px] font-black px-1 py-0.2 rounded mt-0.5 ${diffTotalGirls > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`} title={`السابق المجموع: ${prevTotalGirls}`}>
                                    {diffTotalGirls > 0 ? `+${diffTotalGirls} بنات` : `${diffTotalGirls}`}
                                  </span>
                                )}
                              </div>
                            </td>

                            {/* Cumulative Total */}
                            <td className="p-2.5 text-center font-mono border text-emerald-950 font-black bg-emerald-100">
                              <div className="flex flex-col items-center">
                                <span>{totalAll} طالب وطالبة</span>
                                {activeSnapshot && diffTotalAll !== 0 && (
                                  <span className={`text-[9px] font-black px-1.5 py-0.3 rounded mt-0.5 ${diffTotalAll > 0 ? 'bg-emerald-250 text-[#2E7D32]' : 'bg-red-200 / text-rose-800'}`} title={`السابق المجموع: ${prevTotalAll}`}>
                                    {diffTotalAll > 0 ? `+${diffTotalAll} كلي` : `${diffTotalAll}`}
                                  </span>
                                )}
                              </div>
                            </td>
                          </tr>
                        </>
                      );
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'material' && !activeMaterial && (
          <div className="bg-amber-50 border-2 border-amber-300 p-8 rounded-xl text-center space-y-2 select-none print:hidden">
            <AlertTriangle className="mx-auto text-amber-500 mb-2" size={32} />
            <p className="text-sm font-black text-amber-900">يرجى تحديد مادة معينة من القائمة أعلاه لعرض هذا التقرير التفصيلي.</p>
            <p className="text-xs text-slate-500">تقرير "مادة محددة بكافة المدارس" هو تقرير تفصيلي يخص مادة دراسية معينة ومستهدفاتها لكل مدرسة.</p>
          </div>
        )}

        {reportType === 'material' && activeMaterial && (
          <PrintableReport 
            title={`تقرير عجز وموجود مادة: ${activeMaterial.name}`} 
            subtitle={`أرصدة توزيع قوى تدريس المادة للمستوى بمدارس إدارة أبو حماد التعليمية`}
          >
            <div className="space-y-4">
              {/* Active Snapshot banner */}
              {activeSnapshot && (
                <div className="bg-emerald-50/80 border border-emerald-300 rounded-lg p-3 text-[11px] text-slate-800 flex items-center justify-between select-none print:bg-white print:border-emerald-600">
                  <p className="font-extrabold flex items-center gap-1.5">
                    <History size={14} className="text-[#2E7D32]" />
                    مقارنة السجلات مفعلة تلقائياً مع السجل التاريخي: <span className="text-[#2E7D32] font-black underline underline-offset-2">"{activeSnapshot.name}"</span>
                  </p>
                  <p className="text-[10px] text-slate-500 font-bold font-mono">
                    تاريخ الالتقاط: {new Date(activeSnapshot.createdAt).toLocaleDateString('ar-EG')}
                  </p>
                </div>
              )}

              <div className="overflow-x-auto border border-slate-200/85 rounded-xl transition-all duration-300 shadow-xs">
                <table className="w-full text-right text-xs border border-collapse">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#0D47A1] to-[#1E88E5] text-white font-bold border">
                      <th className="p-2 border">المدرسة المستهدفة</th>
                      <th className="p-2 border text-center">فصولها</th>
                      <th className="p-2 border text-center">مؤشر المطلوب</th>
                      <th className="p-2 border text-center">الموجود الفعلي</th>
                      <th className="p-2 border text-center text-red-600">عجز التخصص</th>
                      <th className="p-2 border text-center text-emerald-600">الوفرة لندب</th>
                    </tr>
                  </thead>
                  <tbody>
                    {schools
                      .filter(sch => selectedSchoolId === 'all' || sch.id === selectedSchoolId)
                      .filter(sch => matchesSearch(sch.name))
                      .map(sch => {
                      const count = materialCounts.find(c => c.schoolId === sch.id && c.materialId === activeMaterial.id);
                      const metr = dbInstance.calculateMaterialMetrics(sch, activeMaterial, count);
                      
                      if (!metr.applicable) return null;

                      // Comparison snapshot checks
                      const compSch = activeSnapshot?.schools.find(s => s.id === sch.id || s.name === sch.name);
                      const compCount = compSch ? activeSnapshot?.materialCounts.find(c => c.schoolId === compSch.id && c.materialId === activeMaterial.id) : null;
                      const compMetr = compSch ? dbInstance.calculateMaterialMetrics(compSch, activeMaterial, compCount) : null;

                      // Calculate deltas
                      const diffClassrooms = (sch.classroomsCount || 0) - (compSch?.classroomsCount || 0);
                      const diffNeeded = metr.needed - (compMetr?.needed || 0);
                      const diffPresent = metr.present - (compMetr?.present || 0);
                      const diffDeficit = metr.deficit - (compMetr?.deficit || 0);
                      const diffSurplus = metr.surplus - (compMetr?.surplus || 0);

                      return (
                        <tr key={sch.id} className="border-b hover:bg-gradient-to-r hover:from-blue-50/40 hover:to-indigo-50/20 transition-all duration-300 hover:translate-x-[-2px]">
                          <td className="p-2 font-bold border">{sch.name}</td>
                          
                          {/* Classrooms */}
                          <td className="p-2 text-center font-mono border">
                            <div className="flex flex-col items-center">
                              <span>{sch.classroomsCount}</span>
                              {compSch && diffClassrooms !== 0 && (
                                <span className={`text-[8px] font-bold px-1 rounded ${diffClassrooms > 0 ? 'bg-emerald-50 text-emerald-750' : 'bg-red-50 text-red-750'}`}>
                                  {diffClassrooms > 0 ? `+${diffClassrooms}` : diffClassrooms}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Needed */}
                          <td className="p-2 text-center font-mono border">
                            <div className="flex flex-col items-center">
                              <span>{metr.needed}</span>
                              {compMetr && diffNeeded !== 0 && (
                                <span className="text-[8px] text-slate-500 font-bold bg-slate-50 px-1 rounded">
                                  {diffNeeded > 0 ? `+${diffNeeded}` : diffNeeded}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Present */}
                          <td className="p-2 text-center font-mono border">
                            <div className="flex flex-col items-center">
                              <span className="text-[#0D47A1] font-bold">{metr.present}</span>
                              {compMetr && diffPresent !== 0 && (
                                <span className={`text-[8px] font-bold px-1 rounded ${diffPresent > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`}>
                                  {diffPresent > 0 ? `+${diffPresent}` : diffPresent}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Deficit */}
                          <td className={`p-2 text-center font-mono border font-black ${metr.deficit > 0 ? 'text-red-650 bg-red-50/10' : ''}`}>
                            <div className="flex flex-col items-center">
                              <span>{metr.deficit || '---'}</span>
                              {compMetr && (metr.deficit !== 0 || compMetr.deficit !== 0) && diffDeficit !== 0 && (
                                <span className={`text-[8px] font-bold px-1 rounded ${diffDeficit < 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`}>
                                  {diffDeficit < 0 ? `تحسن ${diffDeficit}` : `+${diffDeficit}`}
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Surplus */}
                          <td className={`p-2 text-center font-mono border font-black ${metr.surplus > 0 ? 'text-emerald-700 bg-emerald-50/10' : ''}`}>
                            <div className="flex flex-col items-center">
                              <span>{metr.surplus || '---'}</span>
                              {compMetr && (metr.surplus !== 0 || compMetr.surplus !== 0) && diffSurplus !== 0 && (
                                <span className={`text-[8px] font-bold px-1 rounded ${diffSurplus > 0 ? 'bg-emerald-100 text-[#2E7D32]' : 'bg-red-100 text-[#D32F2F]'}`}>
                                  {diffSurplus > 0 ? `وفر +${diffSurplus}` : diffSurplus}
                                </span>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'comprehensive' && (() => {
          // Calculate all data points dynamically
          const rawRows = schools
            .filter(sch => selectedSchoolId === 'all' || sch.id === selectedSchoolId)
            .flatMap(sch => {
              return materials
                .filter(mat => selectedMaterialId === 'all' || mat.id === selectedMaterialId)
                .map(mat => {
              const applicable = dbInstance.isMaterialApplicableToSchool(sch.stage, mat.stage);
              if (!applicable) return null;

              const count = materialCounts.find(c => c.schoolId === sch.id && c.materialId === mat.id);
              const metrics = dbInstance.calculateMaterialMetrics(sch, mat, count);

              return {
                schoolId: sch.id,
                schoolName: sch.name,
                stage: sch.stage,
                materialId: mat.id,
                materialName: mat.name,
                classroomsCount: sch.classroomsCount || 0,
                materialQuota: mat.quota || 0,
                refQuota: metrics.refQuota || 0,
                present: metrics.present,
                needed: metrics.needed,
                deficit: metrics.deficit,
                surplus: metrics.surplus,
                totalLessons: metrics.totalLessons,
                coveredLessons: metrics.coveredLessons,
                periodDeficit: metrics.periodDeficit,
                periodSurplus: metrics.periodSurplus,
                coveragePercentage: metrics.percentage
              };
            }).filter(Boolean);
          });

          // Grouping logic
          let displayRows: any[] = [];
          if (comprehensiveGrouping === 'none') {
            displayRows = rawRows.map(row => {
              if (!row) return null;
              return {
                title: row.schoolName,
                stage: row.stage,
                materialName: row.materialName,
                classroomsCount: row.classroomsCount,
                materialQuotaLabel: row.materialQuota.toString(),
                refQuotaLabel: row.refQuota.toString(),
                present: row.present,
                needed: row.needed,
                deficit: row.deficit,
                surplus: row.surplus,
                totalLessons: row.totalLessons,
                coveredLessons: row.coveredLessons,
                periodDeficit: row.periodDeficit,
                periodSurplus: row.periodSurplus,
                coveragePercentage: row.coveragePercentage
              };
            }).filter(Boolean);
          } else if (comprehensiveGrouping === 'school') {
            const groupedMap = new Map<string, any>();
            rawRows.forEach(row => {
              if (!row) return;
              const key = row.schoolId;
              const existingGroup = groupedMap.get(key);
              if (!existingGroup) {
                groupedMap.set(key, {
                  title: row.schoolName,
                  stage: row.stage,
                  materialName: "كل المواد الدراسية",
                  classroomsCount: row.classroomsCount,
                  materialQuotaLabel: "---",
                  refQuotaLabel: "---",
                  present: row.present,
                  needed: row.needed,
                  deficit: row.deficit,
                  surplus: row.surplus,
                  totalLessons: row.totalLessons,
                  coveredLessons: row.coveredLessons,
                });
              } else {
                existingGroup.present += row.present;
                existingGroup.needed += row.needed;
                existingGroup.deficit += row.deficit;
                existingGroup.surplus += row.surplus;
                existingGroup.totalLessons += row.totalLessons;
                existingGroup.coveredLessons += row.coveredLessons;
              }
            });
            displayRows = Array.from(groupedMap.values()).map(g => {
              const periodDiff = g.coveredLessons - g.totalLessons;
              const periodDeficit = periodDiff < 0 ? Number(Math.abs(periodDiff).toFixed(2)) : 0;
              const periodSurplus = periodDiff > 0 ? Number(periodDiff.toFixed(2)) : 0;
              const coveragePercentage = g.totalLessons > 0 ? Number(((g.coveredLessons / g.totalLessons) * 100).toFixed(1)) : 100;
              return {
                ...g,
                present: Number(g.present.toFixed(2)),
                needed: Number(g.needed.toFixed(2)),
                deficit: Number(g.deficit.toFixed(2)),
                surplus: Number(g.surplus.toFixed(2)),
                totalLessons: Number(g.totalLessons.toFixed(2)),
                coveredLessons: Number(g.coveredLessons.toFixed(2)),
                periodDeficit,
                periodSurplus,
                coveragePercentage
              };
            });
          } else if (comprehensiveGrouping === 'material') {
            const groupedMap = new Map<string, any>();
            rawRows.forEach(row => {
              if (!row) return;
              const key = row.materialId;
              const existingGroup = groupedMap.get(key);
              if (!existingGroup) {
                groupedMap.set(key, {
                  title: "كل المدارس المشمولة بالإدارة",
                  stage: "prep", // multi-stage
                  materialName: row.materialName,
                  classroomsCount: row.classroomsCount,
                  materialQuotaLabel: row.materialQuota.toString(),
                  refQuotaLabel: row.refQuota.toString(),
                  present: row.present,
                  needed: row.needed,
                  deficit: row.deficit,
                  surplus: row.surplus,
                  totalLessons: row.totalLessons,
                  coveredLessons: row.coveredLessons,
                });
              } else {
                existingGroup.classroomsCount += row.classroomsCount;
                existingGroup.present += row.present;
                existingGroup.needed += row.needed;
                existingGroup.deficit += row.deficit;
                existingGroup.surplus += row.surplus;
                existingGroup.totalLessons += row.totalLessons;
                existingGroup.coveredLessons += row.coveredLessons;
              }
            });
            displayRows = Array.from(groupedMap.values()).map(g => {
              const periodDiff = g.coveredLessons - g.totalLessons;
              const periodDeficit = periodDiff < 0 ? Number(Math.abs(periodDiff).toFixed(2)) : 0;
              const periodSurplus = periodDiff > 0 ? Number(periodDiff.toFixed(2)) : 0;
              const coveragePercentage = g.totalLessons > 0 ? Number(((g.coveredLessons / g.totalLessons) * 100).toFixed(1)) : 100;
              return {
                ...g,
                present: Number(g.present.toFixed(2)),
                needed: Number(g.needed.toFixed(2)),
                deficit: Number(g.deficit.toFixed(2)),
                surplus: Number(g.surplus.toFixed(2)),
                totalLessons: Number(g.totalLessons.toFixed(2)),
                coveredLessons: Number(g.coveredLessons.toFixed(2)),
                periodDeficit,
                periodSurplus,
                coveragePercentage
              };
            });
          } else if (comprehensiveGrouping === 'stage') {
            const groupedMap = new Map<string, any>();
            rawRows.forEach(row => {
              if (!row) return;
              const key = row.stage;
              const existingGroup = groupedMap.get(key);
              const arabicStage = key === 'primary' ? 'ابتدائي' : key === 'prep' ? 'إعدادي' : 'ثانوي';
              if (!existingGroup) {
                groupedMap.set(key, {
                  title: `كل مدارس المرحلة (${arabicStage})`,
                  stage: row.stage,
                  materialName: "جميع المواد للمرحلة الدراسية",
                  classroomsCount: row.classroomsCount,
                  materialQuotaLabel: "---",
                  refQuotaLabel: "---",
                  present: row.present,
                  needed: row.needed,
                  deficit: row.deficit,
                  surplus: row.surplus,
                  totalLessons: row.totalLessons,
                  coveredLessons: row.coveredLessons,
                });
              } else {
                existingGroup.classroomsCount += row.classroomsCount;
                existingGroup.present += row.present;
                existingGroup.needed += row.needed;
                existingGroup.deficit += row.deficit;
                existingGroup.surplus += row.surplus;
                existingGroup.totalLessons += row.totalLessons;
                existingGroup.coveredLessons += row.coveredLessons;
              }
            });
            displayRows = Array.from(groupedMap.values()).map(g => {
              const periodDiff = g.coveredLessons - g.totalLessons;
              const periodDeficit = periodDiff < 0 ? Number(Math.abs(periodDiff).toFixed(2)) : 0;
              const periodSurplus = periodDiff > 0 ? Number(periodDiff.toFixed(2)) : 0;
              const coveragePercentage = g.totalLessons > 0 ? Number(((g.coveredLessons / g.totalLessons) * 100).toFixed(1)) : 100;
              return {
                ...g,
                present: Number(g.present.toFixed(2)),
                needed: Number(g.needed.toFixed(2)),
                deficit: Number(g.deficit.toFixed(2)),
                surplus: Number(g.surplus.toFixed(2)),
                totalLessons: Number(g.totalLessons.toFixed(2)),
                coveredLessons: Number(g.coveredLessons.toFixed(2)),
                periodDeficit,
                periodSurplus,
                coveragePercentage
              };
            });
          }

          // Search Filter
          const filteredRows = displayRows.filter((row: any) => {
            if (!row) return false;
            const query = searchQuery.trim().toLowerCase();
            if (!query) return true;
            const arabicStage = row.stage === 'primary' ? 'ابتدائي' : row.stage === 'prep' ? 'إعدادي' : 'ثانوي';
            return (
              row.title.toLowerCase().includes(query) ||
              row.materialName.toLowerCase().includes(query) ||
              arabicStage.includes(query)
            );
          });

          // Calculate Aggregations
          const totalClassrooms = filteredRows.reduce((sum, r) => sum + (r.classroomsCount || 0), 0);
          const grandPresent = Number(filteredRows.reduce((sum, r) => sum + (r.present || 0), 0).toFixed(2));
          const grandNeeded = Number(filteredRows.reduce((sum, r) => sum + (r.needed || 0), 0).toFixed(2));
          const grandDeficit = Number(filteredRows.reduce((sum, r) => sum + (r.deficit || 0), 0).toFixed(2));
          const grandSurplus = Number(filteredRows.reduce((sum, r) => sum + (r.surplus || 0), 0).toFixed(2));
          const grandTotalLessons = Number(filteredRows.reduce((sum, r) => sum + (r.totalLessons || 0), 0).toFixed(2));
          const grandCoveredLessons = Number(filteredRows.reduce((sum, r) => sum + (r.coveredLessons || 0), 0).toFixed(2));
          const grandPeriodDiff = grandCoveredLessons - grandTotalLessons;
          const grandPeriodDeficit = grandPeriodDiff < 0 ? Number(Math.abs(grandPeriodDiff).toFixed(2)) : 0;
          const grandPeriodSurplus = grandPeriodDiff > 0 ? Number(grandPeriodDiff.toFixed(2)) : 0;
          const grandCoveragePercentage = grandTotalLessons > 0 ? Number(((grandCoveredLessons / grandTotalLessons) * 100).toFixed(1)) : 100;

          return (
            <PrintableReport 
              title="تقرير العجز والزيادة والأنصبة الكلي والتحليلي للإدارة التعليمية" 
              subtitle={`جدول تحليلي مجمع حسب: ${
                comprehensiveGrouping === 'school' ? 'المدرسة' : 
                comprehensiveGrouping === 'material' ? 'المادة الدراسية' : 
                comprehensiveGrouping === 'stage' ? 'المرحلة الدراسية' : 'التفصيلي الشامل'
              } - إدارة أبو حماد التعليمية`}
            >
              <div className="space-y-4">
                <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-xs">
                  <table className="w-full text-right text-[10px] border border-slate-400 border-collapse [&_th]:border-slate-400 [&_td]:border-slate-300 [&_tr]:border-b [&_tr:nth-child(even)]:bg-slate-100 [&_tr:nth-child(odd)]:bg-white" style={{ direction: 'rtl' }}>
                    <thead>
                      <tr className="bg-black text-white font-bold select-none border border-slate-400">
                        <th className="p-2 border">المستهدف / البيان</th>
                        <th className="p-2 border text-center">المرحلة</th>
                        <th className="p-2 border">المادة الدراسية</th>
                        <th className="p-2 border text-center">عدد الفصول</th>
                        <th className="p-2 border text-center">نصاب المادة</th>
                        <th className="p-2 border text-center">نصاب المعلم</th>
                        <th className="p-2 border text-center bg-blue-900/10 text-blue-900">الموجود (معلم)</th>
                        <th className="p-2 border text-center bg-amber-50/10 text-amber-800">المطلوب (معلم)</th>
                        <th className="p-2 border text-center bg-red-50 text-red-700">عجز (معلم)</th>
                        <th className="p-2 border text-center bg-emerald-50 text-emerald-800">زيادة (معلم)</th>
                        <th className="p-2 border text-center font-bold bg-slate-50 text-slate-800">إجمالي الحصص المطلوبة</th>
                        <th className="p-2 border text-center font-bold bg-green-50/50 text-green-900">الحصص المغطاة</th>
                        <th className="p-2 border text-center bg-red-100/50 text-red-900">عجز الحصص</th>
                        <th className="p-2 border text-center bg-emerald-100/50 text-emerald-950">زيادة الحصص</th>
                        <th className="p-2 border text-center font-black text-slate-900 bg-yellow-50">نسبة التغطية %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRows.length === 0 ? (
                        <tr>
                          <td colSpan={15} className="text-center p-8 text-slate-400 font-bold italic">
                            لا توجد سجلات تترجم معايير البحث الحالية
                          </td>
                        </tr>
                      ) : (
                        filteredRows.map((row: any, idx: number) => {
                          const isPrimary = row.stage === 'primary';
                          const isPrep = row.stage === 'prep';
                          const stageLabel = isPrimary ? 'ابتدائي' : isPrep ? 'إعدادي' : 'ثانوي';

                          return (
                            <tr 
                              key={idx} 
                              className="border-b text-slate-800 hover:bg-slate-50/80 transitionEven font-sans odd:bg-slate-50/20"
                            >
                              <td className="p-2 border font-bold text-slate-900">{row.title}</td>
                              <td className="p-2 border text-center">
                                <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                                  isPrimary ? 'bg-indigo-50 text-indigo-700 border border-indigo-150' :
                                  isPrep ? 'bg-purple-50 text-purple-700 border border-purple-150' :
                                  'bg-pink-50 text-pink-700 border border-pink-150'
                                }`}>
                                  {stageLabel}
                                </span>
                              </td>
                              <td className="p-2 border font-semibold">{row.materialName}</td>
                              <td className="p-2 border text-center font-mono font-bold text-slate-700">{row.classroomsCount}</td>
                              <td className="p-2 border text-center font-mono">{row.materialQuotaLabel}</td>
                              <td className="p-2 border text-center font-mono">{row.refQuotaLabel}</td>
                              <td className="p-2 border text-center font-mono font-black text-blue-900 bg-blue-50/20">{row.present || '0'}</td>
                              <td className="p-2 border text-center font-mono font-black text-amber-900 bg-amber-50/20">{row.needed || '0'}</td>
                              <td className={`p-2 border text-center font-mono font-bold ${row.deficit > 0 ? 'text-red-700 bg-red-50' : 'text-slate-350'}`}>
                                {row.deficit > 0 ? row.deficit : '---'}
                              </td>
                              <td className={`p-2 border text-center font-mono font-bold ${row.surplus > 0 ? 'text-emerald-700 bg-emerald-50' : 'text-slate-350'}`}>
                                {row.surplus > 0 ? row.surplus : '---'}
                              </td>
                              <td className="p-2 border text-center font-mono font-extrabold text-slate-800 bg-slate-50/30">{row.totalLessons}</td>
                              <td className="p-2 border text-center font-mono font-extrabold text-green-900 bg-green-50/20">{row.coveredLessons}</td>
                              <td className={`p-2 border text-center font-mono font-bold ${row.periodDeficit > 0 ? 'text-red-800 bg-red-100/20' : 'text-slate-300'}`}>
                                {row.periodDeficit > 0 ? row.periodDeficit : '---'}
                              </td>
                              <td className={`p-2 border text-center font-mono font-bold ${row.periodSurplus > 0 ? 'text-emerald-800 bg-emerald-100/20' : 'text-slate-300'}`}>
                                {row.periodSurplus > 0 ? row.periodSurplus : '---'}
                              </td>
                              <td className={`p-2 border text-center font-mono font-black text-slate-900 ${
                                row.coveragePercentage >= 100 ? 'bg-emerald-100/50 text-emerald-950' : 
                                row.coveragePercentage >= 75 ? 'bg-yellow-100/50 text-yellow-950' : 
                                'bg-rose-100/40 text-rose-950 font-black'
                              }`}>
                                {row.coveragePercentage}%
                              </td>
                            </tr>
                          );
                        })
                      )}
                      
                      {/* Section 6: Automated Aggregations / Totals Row */}
                      {filteredRows.length > 0 && (
                        <tr className="bg-slate-900 text-white font-extrabold select-none text-[10px] print:bg-slate-950 border-t-2 border-slate-950">
                          <td className="p-2.5 border" colSpan={3}>إجمالي التلخيص العام للإدارة التعليمية (أبوحماد)</td>
                          <td className="p-2.5 border text-center font-mono text-xs">{totalClassrooms}</td>
                          <td className="p-2.5 border text-center font-mono">---</td>
                          <td className="p-2.5 border text-center font-mono">---</td>
                          <td className="p-2.5 border text-center font-mono text-[#4FC3F7]">{grandPresent}</td>
                          <td className="p-2.5 border text-center font-mono text-amber-200">{grandNeeded}</td>
                          <td className="p-2.5 border text-center font-mono text-rose-300">{grandDeficit}</td>
                          <td className="p-2.5 border text-center font-mono text-emerald-300">{grandSurplus}</td>
                          <td className="p-2.5 border text-center font-mono text-slate-300">{grandTotalLessons}</td>
                          <td className="p-2.5 border text-center font-mono text-green-300">{grandCoveredLessons}</td>
                          <td className="p-2.5 border text-center font-mono text-rose-300">{grandPeriodDeficit}</td>
                          <td className="p-2.5 border text-center font-mono text-emerald-300">{grandPeriodSurplus}</td>
                          <td className="p-2.5 border text-center font-mono text-yellow-300 text-xs">{grandCoveragePercentage}%</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </PrintableReport>
          );
        })()}

        {reportType === 'visitors' && (
          <PrintableReport 
            title="سجل الموجهين المعتمد وحضور وتوجيهات الزائرين بالإدارة" 
            subtitle="قائمة الزيارات الميدانية التفتيشية وتقييم المتابعة لمدارس إدارة أبو حماد"
          >
            <div className="space-y-4">
              <div className="overflow-x-auto border border-slate-200/85 rounded-xl transition-all duration-300 shadow-xs">
                <table className="w-full text-right text-xs border border-slate-400 border-collapse [&_th]:border-slate-400 [&_td]:border-slate-300 [&_tr]:border-b [&_tr:nth-child(even)]:bg-slate-100 [&_tr:nth-child(odd)]:bg-white">
                  <thead>
                    <tr className="bg-black text-white font-bold border border-slate-400">
                      <th className="p-2 border">تاريخ الزيارة</th>
                      <th className="p-2 border">اسم الموجه / الزائر</th>
                      <th className="p-2 border">الوظيفة والتكليف المالي</th>
                      <th className="p-2 border">المدرسة المعنية</th>
                      <th className="p-2 border text-center">الوقت</th>
                      <th className="p-2 border text-center print:hidden">المستند المرسل (الصورة الضوئية)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const filtered = visitors
                        .filter(visit => !filterDate || visit.date === filterDate)
                        .filter(visit => selectedSchoolId === 'all' || visit.schoolId === selectedSchoolId || schools.find(s => s.id === selectedSchoolId)?.name === visit.schoolName)
                        .filter(visit => matchesSearch(visit.visitorName) || matchesSearch(visit.schoolName) || matchesSearch(visit.jobTitle));
                      if (filtered.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="p-4 text-center text-slate-400 font-sans font-medium bg-white">
                              لا توجد زيارات مسجلة تطابق شروط التصفية والبحث.
                            </td>
                          </tr>
                        );
                      }
                      return filtered.map(visit => (
                        <tr key={visit.id} className="border-b hover:bg-gradient-to-r hover:from-blue-50/40 hover:to-indigo-50/20 transition-all duration-300 hover:translate-x-[-2px]">
                          <td className="p-2 font-mono border">{visit.date}</td>
                          <td className="p-2 font-bold border">{visit.visitorName}</td>
                          <td className="p-2 border">{visit.jobTitle}</td>
                          <td className="p-2 border">{visit.schoolName}</td>
                          <td className="p-2 text-center font-mono border">{visit.arrivalTime}</td>
                          <td className="p-2 text-center border print:hidden font-sans">
                            {visit.attachmentData ? (
                              <div className="flex flex-col items-center justify-center gap-1">
                                {visit.attachmentType?.startsWith('image/') || visit.attachmentData?.includes('image/') || visit.attachmentData?.startsWith('data:image/') ? (
                                  <img
                                    src={visit.attachmentData}
                                    alt="المستند الضوئي المرفق"
                                    className="w-14 h-10 object-cover rounded border border-slate-205 shadow-3xs cursor-pointer hover:border-blue-500 transition-colors"
                                    referrerPolicy="no-referrer"
                                    onClick={() => {
                                      const w = window.open();
                                      if (w) {
                                        w.document.write(`<img src="${visit.attachmentData}" style="max-width:100%;" />`);
                                      }
                                    }}
                                  />
                                ) : (
                                  <span className="text-[10px] text-blue-700 font-extrabold">📄 مرفق رقمي</span>
                                )}
                                <a
                                  href={visit.attachmentData}
                                  download={`صورة_مستند_${visit.visitorName}_${visit.date}`}
                                  className="text-[9px] text-[#0D47A1] font-black hover:underline"
                                >
                                  تنزيل المستند
                                </a>
                              </div>
                            ) : (
                              <span className="text-slate-350 text-[10px]">لا يوجد مستند</span>
                            )}
                          </td>
                        </tr>
                      ));
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'teachers' && (
          <PrintableReport 
            title="سجل قوى تدريس وموظفي المدارس المعتمد سحابياً" 
            subtitle="قائمة حصر الموظفين المقيدين بمدارس الإدارة التعليمية مع تخصصاتهم وعناوينهم وتواريخ تعيينهم"
          >
            <div className="space-y-4 text-slate-800">
              {/* Report summary cards inside the printable area for premium look */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 print:grid-cols-4 print:gap-2 mb-4">
                <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100 text-right">
                  <span className="text-[10px] text-blue-600 block font-bold mb-0.5">إجمالي القيادة المدرسية</span>
                  <span className="text-lg font-black text-blue-900">
                    {leadership
                      .filter(l => selectedSchoolId === 'all' || l.schoolId === selectedSchoolId)
                      .filter(l => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === l.specialty || l.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
                      .filter(l => matchesSearch(l.name) || matchesSearch(l.specialty)).length} كادر
                  </span>
                </div>
                <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 text-right">
                  <span className="text-[10px] text-emerald-600 block font-bold mb-0.5">إجمالي المعلمين والوظائف</span>
                  <span className="text-lg font-black text-emerald-900">
                    {staff
                      .filter(m => m.role === 'teacher' && (selectedSchoolId === 'all' || m.schoolId === selectedSchoolId))
                      .filter(m => selectedMaterialId === 'all' || materials.find(mat => mat.id === selectedMaterialId)?.name === m.specialty || m.specialty.includes(materials.find(mat => mat.id === selectedMaterialId)?.name || ''))
                      .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty)).length} معلم
                  </span>
                </div>
                <div className="p-3 bg-purple-50/50 rounded-xl border border-purple-100 text-right">
                  <span className="text-[10px] text-purple-600 block font-bold mb-0.5">الكوادر الإدارية والفنية</span>
                  <span className="text-lg font-black text-purple-900">
                    {staff
                      .filter(m => m.role !== 'teacher' && (selectedSchoolId === 'all' || m.schoolId === selectedSchoolId))
                      .filter(m => selectedMaterialId === 'all' || materials.find(mat => mat.id === selectedMaterialId)?.name === m.specialty || m.specialty.includes(materials.find(mat => mat.id === selectedMaterialId)?.name || ''))
                      .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty)).length} موظف
                  </span>
                </div>
                <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-100 text-right">
                  <span className="text-[10px] text-amber-600 block font-bold mb-0.5">إجمالي القوى البشرية بالمخرجات</span>
                  <span className="text-lg font-black text-amber-900">
                    {(() => {
                      const lCount = leadership
                        .filter(l => selectedSchoolId === 'all' || l.schoolId === selectedSchoolId)
                        .filter(l => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === l.specialty || l.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
                        .filter(l => matchesSearch(l.name) || matchesSearch(l.specialty)).length;
                      const sCount = staff
                        .filter(m => selectedSchoolId === 'all' || m.schoolId === selectedSchoolId)
                        .filter(m => selectedMaterialId === 'all' || materials.find(mat => mat.id === selectedMaterialId)?.name === m.specialty || m.specialty.includes(materials.find(mat => mat.id === selectedMaterialId)?.name || ''))
                        .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty)).length;
                      return lCount + sCount;
                    })()} فرد
                  </span>
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-300 rounded-xl transition-all duration-300 shadow-sm">
                <table className="w-full text-right text-xs border border-slate-400 border-collapse select-none [&_th]:border-slate-400 [&_td]:border-slate-300 [&_tr]:border-b [&_tr:nth-child(even)]:bg-slate-100 [&_tr:nth-child(odd)]:bg-white">
                  <thead>
                    <tr className="bg-black text-white font-bold border border-slate-400">
                      <th className="p-2 border border-slate-700 cursor-pointer hover:bg-slate-700 text-center" style={{ width: '22%' }} onClick={() => toggleSort('name')}>
                        الموظف والمؤسسة {sortField === 'name' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                      <th className="p-2 border border-slate-700 text-center" style={{ width: '13%' }}>الكود والرقم القومي</th>
                      <th className="p-2 border border-slate-700 text-center cursor-pointer hover:bg-slate-700" style={{ width: '12%' }} onClick={() => toggleSort('role')}>
                        المنصب والوظيفة {sortField === 'role' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                      <th className="p-2 border border-slate-700 text-center cursor-pointer hover:bg-slate-700" style={{ width: '12%' }} onClick={() => toggleSort('specialty')}>
                        التخصص والمادة {sortField === 'specialty' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                      <th className="p-2 border border-slate-700 text-center" style={{ width: '13%' }}>التكليف والعمل المكلف به</th>
                      <th className="p-2 border border-slate-700 text-center" style={{ width: '14%' }}>المؤهل وتاريخ الميلاد</th>
                      <th className="p-2 border border-slate-700 text-center" style={{ width: '14%' }}>التعيين وقرار التكليف</th>
                      <th className="p-2 border border-slate-700 text-center" style={{ width: '15%' }}>بيانات التواصل والعنوان</th>
                      <th className="p-2 border border-slate-700 text-center cursor-pointer hover:bg-slate-700" style={{ width: '8%' }} onClick={() => toggleSort('type')}>
                        التبعية {sortField === 'type' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Helper to calculate age from birthDate */}
                    {(() => {
                      const calculateAgeStr = (bDate?: string) => {
                        if (!bDate) return '';
                        try {
                          const birth = new Date(bDate);
                          if (isNaN(birth.getTime())) return '';
                          const today = new Date();
                          let age = today.getFullYear() - birth.getFullYear();
                          const m = today.getMonth() - birth.getMonth();
                          if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
                            age--;
                          }
                          return age > 0 ? `(السن: ${age} سنة)` : '';
                        } catch {
                          return '';
                        }
                      };

                      // 1. Map school leadership (directorship)
                      const filteredLeaders = sortData(
                        leadership
                          .filter(leader => selectedSchoolId === 'all' || leader.schoolId === selectedSchoolId)
                          .filter(leader => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === leader.specialty || leader.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
                          .filter(leader => matchesSearch(leader.name) || matchesSearch(leader.specialty)),
                        (item) => item[sortField as keyof Directorship] || ''
                      );

                      // 2. Map other staff (teachers, specialists, admins, workers)
                      const filteredStaff = sortData(
                        staff
                          .filter(member => selectedSchoolId === 'all' || member.schoolId === selectedSchoolId)
                          .filter(member => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === member.specialty || member.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
                          .filter(member => matchesSearch(member.name) || matchesSearch(member.specialty)),
                        (item) => item[sortField as keyof StaffMember] || ''
                      );

                      const roleLabels: Record<string, string> = {
                        teacher: 'معلم مادة',
                        specialist: 'أخصائي تخصصي',
                        admin: 'إداري عام',
                        worker: 'خدمات معاونة'
                      };

                      return (
                        <>
                          {/* Render Leadership Row by Row */}
                          {filteredLeaders.map(leader => {
                            const sch = schools.find(s => s.id === leader.schoolId);
                            const ageInfo = calculateAgeStr(leader.birthDate);
                            return (
                              <tr key={leader.id} className="border-b border-slate-200 hover:bg-slate-50/70 transition-colors bg-rose-50/5">
                                <td className="p-2 border text-right">
                                  <div className="font-extrabold text-slate-900 text-[12px]">{leader.name}</div>
                                  <div className="flex items-center gap-1 mt-0.5">
                                    <span className="text-[10px] bg-slate-100 text-slate-800 px-1 py-0.2 rounded font-black border border-slate-200">
                                      {sch?.name || '---'}
                                    </span>
                                    <span className="text-[9px] text-slate-500 font-sans">({sch ? STAGE_LABELS[sch.stage] : '---'})</span>
                                  </div>
                                </td>
                                <td className="p-2 border text-center font-mono text-[10.5px]">
                                  <div className="text-slate-900 font-bold">{leader.code || '---'}</div>
                                  <div className="text-[9.5px] text-slate-500 mt-0.5">{leader.nationalId || '---'}</div>
                                </td>
                                <td className="p-2 border text-center">
                                  <span className="bg-rose-100 text-rose-800 border border-rose-200 px-2 py-0.5 rounded text-[10px] font-black inline-block shadow-2xs">
                                    {leader.role === 'principal' ? 'مدير مدرسة' : 'وكيل مدرسة'}
                                  </span>
                                </td>
                                <td className="p-2 border text-center font-bold text-slate-800 text-[11px] bg-slate-50/20">
                                  {leader.specialty || '---'}
                                </td>
                                <td className="p-2 border text-center">
                                  <span className="text-rose-700 text-[10px] font-extrabold bg-rose-50 px-1.5 py-0.5 rounded border border-rose-100">
                                    {leader.role === 'principal' ? 'إدارة المدرسة والقيادة العليا' : 'الشؤون التعليمية والجدول المدرسي'}
                                  </span>
                                </td>
                                <td className="p-2 border text-right text-[10.5px]">
                                  <div className="font-medium text-slate-800">{leader.qualification || '---'}</div>
                                  <div className="text-[9px] text-slate-500 mt-0.5 flex flex-wrap gap-1">
                                    <span>ت.المؤهل: {leader.qualificationDate || '---'}</span>
                                    {leader.birthDate && <span>• م: {leader.birthDate}</span>}
                                    {ageInfo && <span className="text-blue-700 font-bold">{ageInfo}</span>}
                                  </div>
                                </td>
                                <td className="p-2 border text-right text-[10.5px]">
                                  <div className="font-bold text-slate-700">قرار تكليف رقم {leader.decisionNumber || '---'}</div>
                                  <div className="text-[9.5px] text-slate-500 mt-0.5">
                                    تاريخ القرار: {leader.decisionDate || '---'}
                                  </div>
                                  <div className="text-[9px] text-slate-400 mt-0.2">
                                    العمل بالمدرسة: {leader.schoolYearsCount !== undefined ? `${leader.schoolYearsCount} سنة` : '---'}
                                  </div>
                                </td>
                                <td className="p-2 border text-right text-[10.5px]">
                                  <div className="text-emerald-800 font-mono font-extrabold tracking-wider">{leader.phone || '---'}</div>
                                  <div className="text-[9px] text-slate-500 mt-0.5 truncate max-w-[150px]" title={leader.address}>
                                    {leader.address || '---'}
                                  </div>
                                </td>
                                <td className="p-2 border text-center">
                                  <span className="inline-block px-1.5 py-0.5 rounded text-[9.5px] font-black bg-blue-100 text-blue-800 border border-blue-200">
                                    كادر قيادي
                                  </span>
                                </td>
                              </tr>
                            );
                          })}

                          {/* Render Staff Rows by Row */}
                          {filteredStaff.map(member => {
                            const sch = schools.find(s => s.id === member.schoolId);
                            const ageInfo = calculateAgeStr(member.birthDate);
                            
                            // Color code role badges
                            const roleColorMap: Record<string, string> = {
                              teacher: 'bg-emerald-100 text-emerald-800 border-emerald-200',
                              specialist: 'bg-cyan-100 text-cyan-800 border-cyan-200',
                              admin: 'bg-indigo-100 text-indigo-800 border-indigo-200',
                              worker: 'bg-slate-100 text-slate-700 border-slate-200'
                            };

                            return (
                              <tr key={member.id} className="border-b border-slate-200 hover:bg-slate-50/70 transition-colors">
                                <td className="p-2 border text-right">
                                  <div className="font-bold text-slate-900 text-[11.5px]">{member.name}</div>
                                  <div className="flex items-center gap-1 mt-0.5">
                                    <span className="text-[10px] bg-slate-100 text-slate-800 px-1 py-0.2 rounded font-black border border-slate-200">
                                      {sch?.name || '---'}
                                    </span>
                                    <span className="text-[9px] text-slate-500 font-sans">({sch ? STAGE_LABELS[sch.stage] : '---'})</span>
                                  </div>
                                </td>
                                <td className="p-2 border text-center font-mono text-[10.5px]">
                                  <div className="text-slate-900 font-bold">{member.code || '---'}</div>
                                  <div className="text-[9.5px] text-slate-500 mt-0.5">{member.nationalId || '---'}</div>
                                </td>
                                <td className="p-2 border text-center">
                                  <span className={`${roleColorMap[member.role] || 'bg-slate-100 text-slate-800 border-slate-200'} border px-1.5 py-0.5 rounded text-[10px] font-bold inline-block`}>
                                    {roleLabels[member.role] || (member.role).toUpperCase()}
                                  </span>
                                </td>
                                <td className="p-2 border text-center font-bold text-slate-700 text-[11px] bg-slate-50/20">
                                  {member.specialty || '---'}
                                </td>
                                <td className="p-2 border text-center font-medium text-indigo-900 text-[10.5px] bg-indigo-50/5">
                                  {member.assignedJob || (
                                    <span className="text-slate-400 font-normal">لم يحدد بالجدول</span>
                                  )}
                                </td>
                                <td className="p-2 border text-right text-[10.5px]">
                                  <div className="font-medium text-slate-800">{member.qualification || '---'}</div>
                                  <div className="text-[9px] text-slate-500 mt-0.5 flex flex-wrap gap-1">
                                    {member.birthDate && <span>مواليد: {member.birthDate}</span>}
                                    {ageInfo && <span className="text-blue-700 font-bold">{ageInfo}</span>}
                                  </div>
                                </td>
                                <td className="p-2 border text-right text-[10.5px]">
                                  <div className="font-bold text-slate-700">تاريخ التعيين</div>
                                  <div className="text-[9.5px] text-slate-500 mt-0.5">
                                    {member.appointmentDate || '---'}
                                  </div>
                                </td>
                                <td className="p-2 border text-right text-[10.5px]">
                                  <div className="text-emerald-800 font-mono font-extrabold tracking-wider">{member.phone || '---'}</div>
                                  <div className="text-[9px] text-slate-500 mt-0.5 truncate max-w-[150px]" title={member.address}>
                                    {member.address || '---'}
                                  </div>
                                </td>
                                <td className="p-2 border text-center">
                                  <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-black border ${
                                    member.type === 'original' 
                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                                      : 'bg-amber-50 text-amber-700 border-amber-200'
                                  }`}>
                                    {member.type === 'original' ? 'أصلي' : 'منتدب'}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </>
                      );
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'leadership' && (
          <PrintableReport 
            title="سجل القيادات المدرسية والوكلاء المعتمد بالإدارة" 
            subtitle="بيان حصر مديري المدارس والوكلاء وقرارات تعيينهم وتخصصاتهم وعناوينهم وأرقام هواتفهم"
          >
            <div className="space-y-4">
              <div className="overflow-x-auto border border-slate-200/85 rounded-xl transition-all duration-300 shadow-xs">
                <table className="w-full text-right text-xs border border-collapse font-sans">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#01579B] to-[#0288D1] text-white font-bold border text-right font-sans select-none">
                      <th className="p-2 border cursor-pointer hover:bg-sky-800" onClick={() => toggleSort('school')}>المدرسة {sortField === 'school' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}</th>
                      <th className="p-2 border cursor-pointer hover:bg-sky-800" onClick={() => toggleSort('name')}>الاسم بالكامل {sortField === 'name' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}</th>
                      <th className="p-2 border text-center font-mono">الرقم القومي / الكود</th>
                      <th className="p-2 border text-center font-sans">الوظيفة الإشرافية</th>
                      <th className="p-2 border cursor-pointer hover:bg-sky-800" onClick={() => toggleSort('specialty')}>التخصص الدراسي {sortField === 'specialty' ? (sortDirection === 'asc' ? '▲' : '▼') : ''}</th>
                      <th className="p-2 border">رقم وبند تاريخ القرار الوزاري</th>
                      <th className="p-2 border text-center font-sans">العنوان للتواصل</th>
                      <th className="p-2 border text-center font-sans">رقم الهاتف</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      // Get all matching leaders first
                      const matchedLeaders = leadership
                        .filter(leader => selectedSchoolId === 'all' || leader.schoolId === selectedSchoolId)
                        .filter(leader => selectedMaterialId === 'all' || materials.find(m => m.id === selectedMaterialId)?.name === leader.specialty || leader.specialty.includes(materials.find(m => m.id === selectedMaterialId)?.name || ''))
                        .filter(leader => matchesSearch(leader.name) || matchesSearch(leader.specialty));
                      
                      // Find which schools have matched leaders
                      const matchedSchoolIds = Array.from(new Set(matchedLeaders.map(l => l.schoolId)));
                      
                      // Filter schools having matched leaders
                      const filteredSchools = schools
                        .filter(s => selectedSchoolId === 'all' || s.id === selectedSchoolId)
                        .filter(s => matchedSchoolIds.includes(s.id));
                      
                      // Sort schools if sortField is 'school', otherwise based on first leader matching
                      const sortedSchools = [...filteredSchools].sort((a, b) => {
                        if (sortField === 'school') {
                          return sortDirection === 'asc' 
                            ? a.name.localeCompare(b.name, 'ar') 
                            : b.name.localeCompare(a.name, 'ar');
                        }
                        
                        const leaderA = matchedLeaders.find(l => l.schoolId === a.id && l.role === 'principal') 
                          || matchedLeaders.find(l => l.schoolId === a.id && l.role === 'vice_principal')
                          || matchedLeaders.find(l => l.schoolId === a.id);
                        const leaderB = matchedLeaders.find(l => l.schoolId === b.id && l.role === 'principal') 
                          || matchedLeaders.find(l => l.schoolId === b.id && l.role === 'vice_principal')
                          || matchedLeaders.find(l => l.schoolId === b.id);
                          
                        const valA = leaderA ? (leaderA[sortField as keyof Directorship] || '') : '';
                        const valB = leaderB ? (leaderB[sortField as keyof Directorship] || '') : '';
                        
                        return sortDirection === 'asc'
                          ? String(valA).localeCompare(String(valB), 'ar')
                          : String(valB).localeCompare(String(valA), 'ar');
                      });

                      return sortedSchools.flatMap(sch => {
                        // Find leaders for this school matching criteria
                        const schoolLeaders = matchedLeaders.filter(l => l.schoolId === sch.id);
                        
                        // Sort school leaders so 'principal' (المدير) is always first, then 'vice_principal' (الوكيل)
                        const sortedLeaders = [...schoolLeaders].sort((a, b) => {
                          if (a.role === 'principal' && b.role !== 'principal') return -1;
                          if (a.role !== 'principal' && b.role === 'principal') return 1;
                          return 0;
                        });
                        
                        const L = sortedLeaders.length;
                        if (L === 0) return null;
                        
                        return sortedLeaders.map((leader, index) => {
                          const isFirst = index === 0;
                          return (
                            <tr key={leader.id} className="border-b hover:bg-slate-50 transition text-right font-sans even:bg-slate-50/20">
                              {isFirst && (
                                <td 
                                  className="p-2.5 font-black border border-slate-200 text-indigo-950 font-sans align-middle bg-slate-50 text-right" 
                                  rowSpan={L}
                                >
                                  {sch.name}
                                </td>
                              )}
                              <td className="p-2 font-bold border text-indigo-900 font-sans">{leader.name}</td>
                              <td className="p-2 font-mono border text-xs">
                                <div>{leader.nationalId}</div>
                                <span className="text-[10px] text-slate-450 font-sans">({leader.code})</span>
                              </td>
                              <td className="p-2 border text-center">
                                <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                                  leader.role === 'principal' 
                                    ? 'bg-blue-150 text-blue-900 border border-blue-300' 
                                    : 'bg-indigo-50 text-indigo-800 border border-indigo-200'
                                }`}>
                                  {leader.role === 'principal' ? 'مدير مدرسة' : 'وكيل مدرسة'}
                                </span>
                              </td>
                              <td className="p-2 border font-sans text-slate-700 font-medium">{leader.specialty}</td>
                              <td className="p-2 text-center font-mono border text-[11px] text-slate-700">
                                <div className="font-bold">رقم: {leader.decisionNumber || '---'}</div>
                                <div className="text-[9px] text-slate-450">تاريخ: {leader.decisionDate || '---'}</div>
                              </td>
                              <td className="p-2 border text-center font-sans text-slate-600 text-[11px] truncate max-w-[130px]" title={leader.address}>{leader.address || '---'}</td>
                              <td className="p-2 border text-center font-sans font-mono text-emerald-800 font-bold">{leader.phone || '---'}</td>
                            </tr>
                          );
                        });
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'students_absences' && (
          <PrintableReport 
            title="تقرير غياب الطلاب الإجمالي اليومي بالمدارس" 
            subtitle="مؤشرات وإحصائيات نسب الحضور والغياب لتلاميذ المدارس والصفوف بالتاريخ"
          >
            <div className="space-y-4">
              <div className="overflow-x-auto border border-slate-200/85 rounded-xl transition-all duration-300 shadow-xs font-sans">
                <table className="w-full text-right text-xs border border-collapse font-sans font-sans">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#01579B] to-[#0288D1] text-white font-bold border text-right">
                      <th className="p-2 border">المدرسة</th>
                      <th className="p-2 border text-center">التاريخ</th>
                      <th className="p-2 border text-center font-sans">الصف الدراسي</th>
                      <th className="p-2 border text-center font-sans">المقيد</th>
                      <th className="p-2 border text-center font-sans">الحاضر</th>
                      <th className="p-2 border text-center font-sans">الغائب</th>
                      <th className="p-2 border text-center font-sans">نسبة الغياب %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {studentAbsences
                      .filter(abs => !filterDate || abs.date === filterDate)
                      .filter(abs => selectedSchoolId === 'all' || abs.schoolId === selectedSchoolId)
                      .filter(abs => {
                        const sch = schools.find(s => s.id === abs.schoolId);
                        return sch ? matchesSearch(sch.name) : true;
                      })
                      .flatMap(abs => {
                        const sch = schools.find(s => s.id === abs.schoolId);
                        return abs.records.map((r, rIdx) => {
                          const absRate = r.registered > 0 ? ((r.absent / r.registered) * 100).toFixed(1) : '0';
                          return (
                            <tr key={`${abs.id}-${rIdx}`} className="border-b hover:bg-slate-50 transition">
                              <td className="p-2 border font-bold text-slate-800">{sch?.name || ''}</td>
                              <td className="p-2 border text-center font-mono">{abs.date}</td>
                              <td className="p-2 border text-center font-sans">{r.grade}</td>
                              <td className="p-2 border text-center font-mono">{r.registered}</td>
                              <td className="p-2 border text-center font-mono">{r.present}</td>
                              <td className="p-2 border text-center font-mono font-bold text-red-650">{r.absent}</td>
                              <td className="p-2 border text-center font-mono font-black text-rose-700 bg-red-50/10">
                                {absRate}%
                              </td>
                            </tr>
                          );
                        });
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'teachers_absences' && (
          <PrintableReport 
            title="تقرير حضور وغياب المعلمين والمنتدبين بالإدارة" 
            subtitle="سجل الأرشفة اليومي لقوى الهيئات والدرجات والغياب كلياً والندب"
          >
            <div className="space-y-4 font-sans">
              <div className="overflow-x-auto border border-slate-200/85 rounded-xl shadow-xs">
                <table className="w-full text-right text-xs border border-collapse bg-white">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#01579B] to-[#0288D1] text-white font-bold border text-right">
                      <th className="p-2 border">المدرسة</th>
                      <th className="p-2 border text-center font-sans">التاريخ</th>
                      <th className="p-2 border text-center font-sans">المقيد</th>
                      <th className="p-2 border text-center font-sans">الندب</th>
                      <th className="p-2 border text-center font-sans">المأموريات</th>
                      <th className="p-2 border text-center font-sans">الاعتيادي</th>
                      <th className="p-2 border text-center font-sans">المرضي</th>
                      <th className="p-2 border text-center bg-rose-900 text-white font-sans">الغياب كلياً</th>
                      <th className="p-2 border text-center bg-emerald-900 text-white font-sans">إجمالي الحضور</th>
                    </tr>
                  </thead>
                  <tbody>
                    {teacherAbsences
                      .filter(abs => !filterDate || abs.date === filterDate)
                      .filter(abs => selectedSchoolId === 'all' || abs.schoolId === selectedSchoolId)
                      .filter(abs => {
                        const sch = schools.find(s => s.id === abs.schoolId);
                        return sch ? matchesSearch(sch.name) : true;
                      })
                      .map(abs => {
                        const sch = schools.find(s => s.id === abs.schoolId);
                        return (
                          <tr key={abs.id} className="border-b bg-white hover:bg-slate-50 transition font-mono text-right">
                            <td className="p-2 border font-bold font-sans text-slate-900 text-right">{sch?.name || ''}</td>
                            <td className="p-2 border text-center font-sans">{abs.date}</td>
                            <td className="p-2 border text-center">{abs.registered}</td>
                            <td className="p-2 border text-center">{abs.delegated}</td>
                            <td className="p-2 border text-center">{abs.mission}</td>
                            <td className="p-2 border text-center font-sans">{abs.regularLeave}</td>
                            <td className="p-2 border text-center font-sans">{abs.sickLeave}</td>
                            <td className="p-2 border text-center font-extrabold text-rose-650 bg-rose-50/25">{abs.absent}</td>
                            <td className="p-2 border text-center font-black text-emerald-805 bg-emerald-50/25">{abs.present}</td>
                          </tr>
                        );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'nutrition' && (
          <PrintableReport 
            title="التقرير السنوي لإحصائيات الدعم الصحي للتغذية المدرسية" 
            subtitle="مخرجات مستحقي التغذية وأيام استلام وتوزيع وجبات التلاميذ والوجبات"
          >
            <div className="space-y-4">
              <div className="overflow-x-auto border border-slate-200/85 rounded-xl shadow-xs">
                <table className="w-full text-right text-xs border border-collapse bg-white">
                  <thead>
                    <tr className="bg-gradient-to-r from-[#0D47A1] to-[#1E88E5] text-white font-bold border text-right">
                      <th className="p-2 border">المدرسة المستحِقة</th>
                      <th className="p-2 border text-center">العام الدراسي</th>
                      <th className="p-2 border text-center">أيام التوزيع المقررة</th>
                      <th className="p-2 border text-center">عدد التلاميذ المستحقين</th>
                      <th className="p-2 border text-center bg-[#0D47A1]/95 text-white">إجمالي الوجبات الموزعة تقديرياً</th>
                    </tr>
                  </thead>
                  <tbody>
                    {nutrition
                      .filter(nut => selectedSchoolId === 'all' || nut.schoolId === selectedSchoolId)
                      .filter(nut => {
                        const sch = schools.find(s => s.id === nut.schoolId);
                        return sch ? matchesSearch(sch.name) : true;
                      })
                      .map(nut => {
                        const sch = schools.find(s => s.id === nut.schoolId);
                        return (
                          <tr key={nut.id} className="border-b bg-white hover:bg-slate-50 transition text-right font-sans">
                            <td className="p-2 border font-bold text-slate-800 text-right">{sch?.name || ''}</td>
                            <td className="p-2 text-center font-mono border">{nut.academicYear}</td>
                            <td className="p-2 text-center font-mono border">{nut.distributionDays} يوم</td>
                            <td className="p-2 text-center font-mono border">{nut.beneficiariesCount} تلميذ</td>
                            <td className="p-2 text-center font-mono font-black text-blue-800 border bg-slate-50/50">
                              {(nut.beneficiariesCount * nut.distributionDays).toLocaleString('ar-EG')} وجبة
                            </td>
                          </tr>
                        );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'specialists' && (
          <PrintableReport 
            title="التقرير الشامل التخصصي للأخصائيين الاجتماعيين والنفسيين والمكتبات بكافة المدارس" 
            subtitle="بيان حصر كافة البيانات التفصيلية المرسلة من مدراء المدارس للأخصائيين بالمنظومة دون إغفال أي منها"
          >
            <div className="space-y-4 font-sans text-right">
              <div className="bg-gradient-to-r from-teal-800 to-teal-900 text-white px-4 py-2.5 rounded-t-xl font-bold flex justify-between items-center text-xs shadow-xs">
                <span>كادر الأخصائيين المسجلين الفعلي بالإدارة</span>
                <span className="bg-white/20 px-2.5 py-0.5 rounded font-mono font-black text-[11px]">
                  العدد الجملة المكتشف: {staff
                    .filter(m => m.role === 'specialist')
                    .filter(m => selectedSchoolId === 'all' || m.schoolId === selectedSchoolId)
                    .filter(m => selectedMaterialId === 'all' || materials.find(x => x.id === selectedMaterialId)?.name === m.specialty || m.specialty.includes(materials.find(x => x.id === selectedMaterialId)?.name || ''))
                    .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty)).length} أخصائي
                </span>
              </div>
              <div className="overflow-x-auto border border-slate-200 rounded-b-xl shadow-xs">
                <table className="w-full text-right text-[10px] border border-slate-400 border-collapse bg-white [&_th]:border-slate-400 [&_td]:border-slate-300 [&_tr]:border-b [&_tr:nth-child(even)]:bg-slate-100 [&_tr:nth-child(odd)]:bg-white">
                  <thead>
                    <tr className="bg-black text-white font-bold text-right select-none [&_th]:p-2 [&_th]:border">
                      <th className="p-2 border text-right">الاسم رباعياً</th>
                      <th className="p-2 border text-right">المدرسة المعيّن بها</th>
                      <th className="p-2 border text-center">الرقم القومي</th>
                      <th className="p-2 border text-center font-sans">كود الموظف</th>
                      <th className="p-2 border text-center font-sans">تاريخ الميلاد</th>
                      <th className="p-2 border font-sans text-right">التخصص الدقيق</th>
                      <th className="p-2 border font-sans text-right">المؤهل الدراسي</th>
                      <th className="p-2 border text-center font-sans">تاريخ التعيين</th>
                      <th className="p-2 border font-sans text-center">رقم الهاتف</th>
                      <th className="p-2 border font-sans text-right">العنوان بالتفصيل</th>
                      <th className="p-2 border text-center">حالة التبعية</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const filtered = staff
                        .filter(m => m.role === 'specialist')
                        .filter(m => selectedSchoolId === 'all' || m.schoolId === selectedSchoolId)
                        .filter(m => selectedMaterialId === 'all' || materials.find(x => x.id === selectedMaterialId)?.name === m.specialty || m.specialty.includes(materials.find(x => x.id === selectedMaterialId)?.name || ''))
                        .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty));
                      const sorted = sortData(filtered, (item) => {
                        if (sortField === 'school') {
                          const sch = schools.find(s => s.id === item.schoolId);
                          return sch?.name || '';
                        }
                        return item[sortField as keyof StaffMember] || '';
                      });
                      if (sorted.length === 0) {
                        return (
                          <tr>
                            <td colSpan={11} className="p-4 text-center text-slate-400 font-sans font-medium bg-white">
                              لا توجد سجلات مطابقة لخيارات البحث الحالية.
                            </td>
                          </tr>
                        );
                      }
                      return sorted.map(member => {
                        const sch = schools.find(s => s.id === member.schoolId);
                        return (
                          <tr key={member.id} className="border-b bg-white hover:bg-slate-50 transition text-right [&_td]:p-2 [&_td]:border font-sans">
                            <td className="font-bold text-slate-900 border text-right">{member.name}</td>
                            <td className="font-bold text-indigo-900 border text-right">{sch?.name || '---'}</td>
                            <td className="font-mono border text-center">{member.nationalId || '---'}</td>
                            <td className="font-mono border text-center">{member.code || '---'}</td>
                            <td className="text-center font-mono border text-center">{member.birthDate || '---'}</td>
                            <td className="text-slate-800 border text-right">{member.specialty || '---'}</td>
                            <td className="text-slate-700 border text-right">{member.qualification || '---'}</td>
                            <td className="text-center font-mono border text-center">{member.appointmentDate || '---'}</td>
                            <td className="font-mono text-emerald-800 border text-center">{member.phone || '---'}</td>
                            <td className="text-slate-650 border text-right">{member.address || '---'}</td>
                            <td className="text-center border text-center">
                              <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-black ${
                                member.type === 'original' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                              }`}>
                                {member.type === 'original' ? 'أصلي' : 'منتدب'}
                              </span>
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'admins_supervisors' && (
          <PrintableReport 
            title="التقرير الشامل التفصيلي للكوادر الإدارية ومشرفي الأنشطة بكافة المدارس" 
            subtitle="بيان حصر كافة البيانات التفصيلية المرسلة من مدراء المدارس للكوادر الإدارية ومشرفي الأنشطة دون إغفال أي منها"
          >
            <div className="space-y-4 font-sans text-right">
              {/* 2. Admins Table */}
              <div className="space-y-2">
                <div className="bg-gradient-to-r from-blue-800 to-blue-900 text-white px-4 py-2.5 rounded-t-xl font-bold flex justify-between items-center text-xs shadow-xs">
                  <span>سجل الكوادر الإدارية وسكرتارية الأعمال ومشرفي الأنشطة بكافة المدارس</span>
                  <span className="bg-white/20 px-2.5 py-0.5 rounded font-mono font-black text-[11px]">
                    العدد الجملة المكتشف: {staff
                      .filter(m => m.role === 'admin')
                      .filter(m => selectedSchoolId === 'all' || m.schoolId === selectedSchoolId)
                      .filter(m => selectedMaterialId === 'all' || materials.find(x => x.id === selectedMaterialId)?.name === m.specialty || m.specialty.includes(materials.find(x => x.id === selectedMaterialId)?.name || ''))
                      .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty)).length} موظف إداري ومشرف نشاط
                  </span>
                </div>
                <div className="overflow-x-auto border border-slate-200 rounded-b-xl shadow-xs">
                  <table className="w-full text-right text-[10px] border-collapse bg-white">
                    <thead>
                      <tr className="bg-blue-50 text-blue-950 font-bold border-b text-right select-none [&_th]:p-2 [&_th]:border">
                        <th className="p-2 border text-right">الاسم رباعياً</th>
                        <th className="p-2 border text-right">المدرسة المعيّن بها</th>
                        <th className="p-2 border text-center font-sans">الرقم القومي / الكود</th>
                        <th className="p-2 border font-sans text-right">الوظيفة والتخصص المحدد</th>
                        <th className="p-2 border font-sans text-right">المؤهل وتاريخ التعيين</th>
                        <th className="p-2 border text-center font-sans">رقم الهاتف والعنوان</th>
                        <th className="p-2 border text-center">حالة التبعية</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(() => {
                        const filtered = staff
                          .filter(m => m.role === 'admin')
                          .filter(m => selectedSchoolId === 'all' || m.schoolId === selectedSchoolId)
                          .filter(m => selectedMaterialId === 'all' || materials.find(x => x.id === selectedMaterialId)?.name === m.specialty || m.specialty.includes(materials.find(x => x.id === selectedMaterialId)?.name || ''))
                          .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty));
                        const sorted = sortData(filtered, (item) => {
                          if (sortField === 'school') {
                            const sch = schools.find(s => s.id === item.schoolId);
                            return sch?.name || '';
                          }
                          return item[sortField as keyof StaffMember] || '';
                        });
                        if (sorted.length === 0) {
                          return (
                            <tr>
                              <td colSpan={7} className="p-4 text-center text-slate-400 font-sans font-medium bg-white">
                                لا يوجد إداريون مسجلون يطابقون شروط البحث والتصفية.
                              </td>
                            </tr>
                          );
                        }
                        return sorted.map(member => {
                          const sch = schools.find(s => s.id === member.schoolId);
                          return (
                            <tr key={member.id} className="border-b bg-white even:bg-blue-50/15 hover:bg-slate-50 transition text-right font-sans [&_td]:p-2 [&_td]:border">
                              <td className="font-bold text-slate-900 text-xs text-right">{member.name}</td>
                              <td className="font-bold text-indigo-900 text-right">{sch?.name || '---'}</td>
                              <td className="font-mono text-center text-[11px]">
                                <div>{member.nationalId}</div>
                                <span className="text-[10px] text-slate-450 font-sans block">كود: ({member.code})</span>
                              </td>
                              <td className="text-slate-700 font-medium text-xs font-sans text-right">{member.specialty}</td>
                              <td className="text-center text-slate-650 text-[11px]">
                                <div>{member.qualification || '---'}</div>
                                <div className="text-[9px] text-slate-400">تاريخ: {member.appointmentDate || '---'}</div>
                              </td>
                              <td className="text-center text-xs font-sans text-slate-600">
                                <div className="max-w-[130px] truncate">{member.address || '---'}</div>
                                <div className="text-emerald-800 font-mono font-bold text-[11px]">{member.phone || '---'}</div>
                              </td>
                              <td className="text-center">
                                <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-black ${
                                  member.type === 'original' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                                }`}>
                                  {member.type === 'original' ? 'أصلي' : 'منتدب'}
                                </span>
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 3. Activity Supervisors Table */}
              <div className="space-y-2">
                <div className="bg-gradient-to-r from-violet-800 to-violet-900 text-white px-4 py-2.5 rounded-t-xl font-bold flex justify-between items-center text-xs shadow-xs">
                  <span className="font-sans">ثالثاً: مشرفو الأنشطة المدرسية بالصفوف</span>
                  <span className="bg-white/20 px-2 py-0.5 rounded font-mono font-black text-[11px]">العدد الفعلي: {
                    staff.filter(m => m.role === 'admin' && m.specialty === 'مشرف نشاط' && (matchesSearch(m.name) || matchesSearch(m.specialty))).length
                  }</span>
                </div>
                <div className="overflow-x-auto border border-slate-200 rounded-b-xl shadow-xs font-sans">
                  <table className="w-full text-right text-xs border-collapse bg-white">
                    <thead>
                      <tr className="bg-violet-50 text-violet-955 font-bold border-b text-right select-none [&_th]:p-2.5 [&_th]:border-l">
                        <th className="p-2 border text-right">الاسم رباعياً</th>
                        <th className="p-2 border font-sans text-right font-sans">المدرسة المعيّن بها</th>
                        <th className="p-2 border text-center font-sans">الرقم القومي</th>
                        <th className="p-2 border text-center font-sans">كود الموظف</th>
                        <th className="p-2 border text-center font-sans">تاريخ التعيين</th>
                        <th className="p-2 border font-sans text-right">المسمى والوظيفة</th>
                        <th className="p-2 border font-sans text-center font-sans">رقم الهاتف</th>
                        <th className="p-2 border text-center">حالة التبعية</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(() => {
                        const filtered = staff.filter(m => m.role === 'admin' && m.specialty === 'مشرف نشاط' && (matchesSearch(m.name) || matchesSearch(m.specialty)));
                        if (filtered.length === 0) {
                          return (
                            <tr>
                              <td colSpan={8} className="p-4 text-center text-slate-400 font-sans font-medium bg-white">
                                لا يوجد مشرفو أنشطة مسجلون يطابقون شروط البحث والتصفية.
                              </td>
                            </tr>
                          );
                        }
                        return filtered.map(member => {
                          const sch = schools.find(s => s.id === member.schoolId);
                          return (
                            <tr key={member.id} className="border-b bg-white even:bg-indigo-50/10 hover:bg-slate-50 transition text-right font-sans [&_td]:p-2.5 [&_td]:border-l text-xs">
                              <td className="font-bold text-slate-900">{member.name}</td>
                              <td className="font-black text-indigo-950 text-right">{sch?.name || '---'}</td>
                              <td className="font-mono text-center text-[11px]">{member.nationalId}</td>
                              <td className="font-mono text-center text-[11px]">{member.code || '---'}</td>
                              <td className="text-center text-[11px] font-mono">{member.appointmentDate || '---'}</td>
                              <td className="text-slate-700 font-medium font-sans text-right">{member.specialty}</td>
                              <td className="font-mono text-center font-bold text-emerald-800">{member.phone || '---'}</td>
                              <td className="p-2 text-center text-[10px]">
                                <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-black ${
                                  member.type === 'original' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                                }`}>
                                  {member.type === 'original' ? 'أصلي' : 'منتدب'}
                                </span>
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </PrintableReport>
        )}

        {reportType === 'workers' && (
          <PrintableReport 
            title="التقرير الشامل التفصيلي للعمال والحراسة والخدمات المعاونة بكافة المدارس" 
            subtitle="بيان حصر كافة البيانات التفصيلية المرسلة من مدراء المدارس للعمال والحراسة والخدمات المعاونة"
          >
            <div className="space-y-4 font-sans text-right">
              <div className="bg-gradient-to-r from-emerald-800 to-emerald-900 text-white px-4 py-2.5 rounded-t-xl font-bold flex justify-between items-center text-xs shadow-xs">
                <span>كادر العمال والخدمات المعاونة الفعلي بالإدارة</span>
                <span className="bg-white/20 px-2.5 py-0.5 rounded font-mono font-black text-[11px]">
                  العدد الجملة المكتشف: {staff
                    .filter(m => m.role === 'worker')
                    .filter(m => selectedSchoolId === 'all' || m.schoolId === selectedSchoolId)
                    .filter(m => selectedMaterialId === 'all' || materials.find(x => x.id === selectedMaterialId)?.name === m.specialty || m.specialty?.includes(materials.find(x => x.id === selectedMaterialId)?.name || ''))
                    .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty || '')).length} عامل
                </span>
              </div>
              <div className="overflow-x-auto border border-slate-200 rounded-b-xl shadow-xs">
                <table className="w-full text-right text-[10px] border-collapse bg-white">
                  <thead>
                    <tr className="bg-emerald-50 text-emerald-950 font-bold border-b text-right select-none [&_th]:p-2 [&_th]:border">
                      <th className="p-2 border text-right">الاسم رباعياً</th>
                      <th className="p-2 border text-right">المدرسة المعيّن بها</th>
                      <th className="p-2 border text-center font-sans">الرقم القومي</th>
                      <th className="p-2 border text-center font-sans">كود الموظف</th>
                      <th className="p-2 border text-center font-sans">تاريخ الميلاد</th>
                      <th className="p-2 border font-sans text-right font-sans">الوظيفة/التخصص</th>
                      <th className="p-2 border font-sans text-right">المؤهل الدراسي</th>
                      <th className="p-2 border text-center font-sans">تاريخ التعيين</th>
                      <th className="p-2 border font-sans text-center">رقم الهاتف</th>
                      <th className="p-2 border font-sans text-right">العنوان بالتفصيل</th>
                      <th className="p-2 border text-center">حالة التبعية</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const filtered = staff
                        .filter(m => m.role === 'worker')
                        .filter(m => selectedSchoolId === 'all' || m.schoolId === selectedSchoolId)
                        .filter(m => selectedMaterialId === 'all' || materials.find(x => x.id === selectedMaterialId)?.name === m.specialty || m.specialty?.includes(materials.find(x => x.id === selectedMaterialId)?.name || ''))
                        .filter(m => matchesSearch(m.name) || matchesSearch(m.specialty || ''));
                      const sorted = sortData(filtered, (item) => {
                        if (sortField === 'school') {
                          const sch = schools.find(s => s.id === item.schoolId);
                          return sch?.name || '';
                        }
                        return item[sortField as keyof StaffMember] || '';
                      });
                      if (sorted.length === 0) {
                        return (
                          <tr>
                            <td colSpan={11} className="p-4 text-center text-slate-400 font-sans font-medium bg-white">
                              لا توجد سجلات مطابقة لخيارات البحث الحالية.
                            </td>
                          </tr>
                        );
                      }
                      return sorted.map(member => {
                        const sch = schools.find(s => s.id === member.schoolId);
                        return (
                          <tr key={member.id} className="border-b bg-white hover:bg-slate-50 transition text-right [&_td]:p-2 [&_td]:border font-sans text-xs">
                            <td className="font-bold text-slate-900 border text-right">{member.name}</td>
                            <td className="font-bold text-indigo-900 border text-right">{sch?.name || '---'}</td>
                            <td className="font-mono border text-center text-[10.5px]">{member.nationalId || '---'}</td>
                            <td className="font-mono border text-center text-[10.5px]">{member.code || '---'}</td>
                            <td className="text-center font-mono border text-center text-[10.5px]">{member.birthDate || '---'}</td>
                            <td className="text-slate-800 border text-right">{member.specialty || 'خدمات معاونة'}</td>
                            <td className="text-slate-700 border text-right">{member.qualification || '---'}</td>
                            <td className="text-center font-mono border text-center text-[10.5px]">{member.appointmentDate || '---'}</td>
                            <td className="font-mono text-emerald-800 border text-center font-bold">{member.phone || '---'}</td>
                            <td className="text-slate-600 border text-right">{member.address || '---'}</td>
                            <td className="text-center border text-center">
                              <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-black ${
                                member.type === 'original' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                              }`}>
                                {member.type === 'original' ? 'أصلي' : 'منتدب'}
                              </span>
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </PrintableReport>
        )}
      </div>
    </div>
  );
}

function MaterialsManagementTabInner({ materials, dbTick }: { materials: Material[]; dbTick: number }) {
  const [list, setList] = useState<Material[]>(materials);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editStage, setEditStage] = useState<'primary' | 'prep' | 'sec'>('primary');
  const [editQuota, setEditQuota] = useState(20);
  const [editTeacherQuota, setEditTeacherQuota] = useState(24);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({ 
    name: '', 
    stage: 'prep' as 'primary' | 'prep' | 'sec', 
    quota: 18,
    teacherQuota: 24
  });
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredList = useMemo(() => {
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter(m => m.name.toLowerCase().includes(q));
  }, [list, searchQuery]);

  const primaryList = useMemo(() => filteredList.filter(m => m.stage === 'primary'), [filteredList]);
  const prepList = useMemo(() => filteredList.filter(m => m.stage === 'prep'), [filteredList]);
  const secList = useMemo(() => filteredList.filter(m => m.stage === 'sec'), [filteredList]);

  const renderMaterialRow = (mat: Material) => {
    const isEditing = mat.id === editingId;
    return (
      <tr key={mat.id} className="border-b even:bg-slate-50/50 hover:bg-slate-50/50 transition border-slate-100 font-sans text-right">
        <td className="p-3 font-bold text-slate-800 border-l text-right">
          {isEditing ? (
            <input
              type="text"
              value={editName}
              onChange={e => setEditName(e.target.value)}
              className="px-2.5 py-1 text-xs border border-slate-250 bg-white rounded font-bold text-right w-full"
            />
          ) : (
            mat.name
          )}
        </td>
        <td className="p-3 text-center border-l justify-center">
          {isEditing ? (
            <select
              value={editStage}
              onChange={e => setEditStage(e.target.value as any)}
              className="px-2 py-0.5 text-xs border border-slate-250 bg-white rounded text-right focus:outline-none font-bold"
            >
              <option value="primary">ابتدائي</option>
              <option value="prep">إعدادي</option>
              <option value="sec">ثانوي</option>
            </select>
          ) : (
            <span className={`inline-block px-2.5 py-0.5 rounded-lg text-[9px] font-black ${
              mat.stage === 'primary' ? 'bg-blue-50 text-blue-755 border border-blue-100' :
              mat.stage === 'prep' ? 'bg-purple-50 text-purple-755 border border-purple-100' :
              'bg-amber-50 text-amber-755 border border-amber-100'
            }`}>
              {mat.stage === 'primary' ? 'ابتدائي' : mat.stage === 'prep' ? 'إعدادي' : 'ثانوي'}
            </span>
          )}
        </td>
        <td className="p-3 text-center font-mono font-bold text-blue-800 text-sm border-l">
          {isEditing ? (
            <input
              type="number"
              value={editQuota}
              onChange={e => setEditQuota(Number(e.target.value) || 0)}
              className="px-2 py-0.5 text-xs border border-slate-250 bg-white rounded text-center w-16 font-bold"
            />
          ) : (
            `${mat.quota} حصة`
          )}
        </td>
        <td className="p-3 text-center font-mono font-bold text-emerald-800 text-sm border-l">
          {isEditing ? (
            <input
              type="number"
              value={editTeacherQuota}
              onChange={e => setEditTeacherQuota(Number(e.target.value) || 0)}
              className="px-2 py-0.5 text-xs border border-slate-250 bg-white rounded text-center w-16 font-bold"
            />
          ) : (
            `${mat.teacherQuota || (mat.stage === 'primary' ? 20 : 18)} حصة`
          )}
        </td>
        <td className="p-3 text-center w-40">
          {isEditing ? (
            <div className="flex items-center gap-1.5 justify-center">
              <button
                type="button"
                onClick={() => handleSaveEdit(mat.id)}
                className="px-2 py-0.5 bg-emerald-600 text-white hover:bg-emerald-700 font-bold rounded text-[9px] flex items-center gap-0.5 cursor-pointer shadow-3xs"
              >
                <Save size={10} />
                حفظ
              </button>
              <button
                type="button"
                onClick={() => setEditingId(null)}
                className="px-2 py-0.5 border border-slate-205 text-slate-500 hover:bg-slate-100 font-bold rounded text-[9px] cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 justify-center">
              <button
                type="button"
                onClick={() => startEdit(mat)}
                className="px-2 py-0.5 bg-indigo-50 border border-indigo-100 hover:bg-indigo-100 text-indigo-750 font-bold rounded text-[9px] cursor-pointer flex items-center gap-0.5"
              >
                <Edit size={10} />
                تعديل
              </button>
              {confirmDeleteId === mat.id ? (
                <div className="flex items-center gap-1 justify-center bg-rose-50 border border-rose-100 rounded p-0.5 animate-pulse">
                  <button
                    type="button"
                    onClick={() => {
                      handleDelete(mat.id);
                      setConfirmDeleteId(null);
                    }}
                    className="px-1.5 py-0.2 bg-rose-600 text-white font-bold rounded text-[8.5px] cursor-pointer"
                  >
                    تأكيد
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteId(null)}
                    className="px-1.5 py-0.2 border border-slate-205 text-slate-500 font-bold rounded text-[8.5px] cursor-pointer bg-white"
                  >
                    إلغاء
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmDeleteId(mat.id)}
                  className="px-2 py-0.5 text-rose-600 hover:bg-rose-50 rounded text-[9px] font-bold cursor-pointer inline-flex items-center gap-0.5"
                  title="حذف المادة ونصابها المعتمد"
                >
                  <Trash2 size={10} />
                  حذف
                </button>
              )}
            </div>
          )}
        </td>
      </tr>
    );
  };

  useEffect(() => {
    setList(materials);
  }, [materials, dbTick]);

  const reload = () => {
    setList(dbInstance.getMaterials());
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;
    setSaving(true);
    const newMat: Material = {
      id: 'mat_' + Date.now(),
      name: formData.name.trim(),
      stage: formData.stage,
      quota: Number(formData.quota),
      teacherQuota: Number(formData.teacherQuota)
    };
    dbInstance.saveMaterial(newMat);
    dbInstance.addAuditLog('مدير التنسيق', 'إضافة مادة', `تم إضافة المادة الجديدة "${newMat.name}" بنصاب ${newMat.quota} حصة ونصاب معلم مرجعي ${newMat.teacherQuota}.`, undefined, newMat);
    setFormData({ name: '', stage: 'prep', quota: 18, teacherQuota: 24 });
    setSaving(false);
    reload();
    alert('تم إضافة المادة وحفظها وإتاحتها فوراً لجميع المدارس.');
  };

  const startEdit = (mat: Material) => {
    setEditingId(mat.id);
    setEditName(mat.name);
    setEditStage(mat.stage);
    setEditQuota(mat.quota);
    setEditTeacherQuota(mat.teacherQuota || (mat.stage === 'primary' ? 20 : 18));
  };

  const handleSaveEdit = (id: string) => {
    if (!editName.trim()) {
      alert('الرجاء إدخال اسم المادة');
      return;
    }
    const oldMat = list.find(m => m.id === id);
    const updated: Material = {
      id,
      name: editName,
      stage: editStage,
      quota: Number(editQuota),
      teacherQuota: Number(editTeacherQuota)
    };
    dbInstance.saveMaterial(updated);
    dbInstance.addAuditLog('مدير التنسيق', 'تعديل مادة', `تم تعديل مادة "${editName}".`, oldMat, updated);
    setEditingId(null);
    reload();
    alert('تم تعديل سجل المادة ونصابها المعتمد بنجاح.');
  };

  const handleDelete = (id: string) => {
    const originalMat = list.find(m => m.id === id);
    if (originalMat) {
      const trash: TrashItem = {
        id: 'trash_mat_' + Date.now(),
        type: 'material',
        originalId: id,
        name: originalMat.name,
        deletedAt: Date.now(),
        data: originalMat
      };
      dbInstance.saveTrashItem(trash);
      dbInstance.addAuditLog('مدير التنسيق', 'نقل مادة لسلة المهملات', `تم نقل المادة "${originalMat.name}" إلى سلة المهملات المؤقتة.`, originalMat, undefined);
    }
    dbInstance.deleteMaterial(id);
    reload();
    alert('🗑️ تم نقل المادة لسلة المهملات بنجاح. يمكنك استرجاعها في أي وقت من تبويب "سلة المهملات والتعافي السريع".');
  };

  const formattedDate = new Date().toLocaleDateString('ar-EG', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="space-y-6">
      
      {/* Dynamic Date Header to Match Specification */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-2xl p-6 shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-lg font-black tracking-wide">📂 Materials and Quotas | المواد والأنصبة</h2>
          <p className="text-xs text-blue-150 font-bold mt-1">{formattedDate}</p>
        </div>
        <button
          type="button"
          onClick={() => {
            alert(`تم إرسال وتحديث وتعميم جميع المواد والأنصبة (${list.length} مادة) لجميع الإدارات المدرسية المربوطة بنجاح.`);
          }}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 font-black text-xs rounded-xl shadow-md transition duration-150 active:scale-95 cursor-pointer flex items-center gap-2"
        >
          <Send size={13} />
          إرسال للمدارس ({list.length} مادة)
        </button>
      </div>

      {/* Search Materials */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-4">
        <input
          type="text"
          placeholder="البحث في قائمة المواد المعتمدة..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500 font-bold text-xs text-right bg-slate-50 animate-fadeIn"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Create form */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4 h-fit text-right">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h2 className="text-xs font-black text-slate-900">
              ➕ إضافة مادة جديدة
            </h2>
            <button
              type="button"
              onClick={reload}
              className="p-1.5 hover:bg-slate-50 rounded-lg text-slate-500 font-bold text-[10px] cursor-pointer flex items-center gap-1 transition-all border border-slate-100"
              title="تحديث القوائم"
            >
              <RefreshCw size={11} />
              تحديث
            </button>
          </div>

          <form onSubmit={handleCreate} className="space-y-4">
            <div>
              <label className="block text-[10px] font-black text-slate-600 mb-1">اسم المادة *</label>
              <input
                type="text"
                placeholder="أدخل اسم المادة"
                value={formData.name}
                onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                className="w-full px-3.5 py-2 text-xs border border-slate-200 bg-white rounded-lg text-right focus:outline-none focus:border-blue-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-600 mb-1">المرحلة التعليمية</label>
              <select
                value={formData.stage}
                onChange={e => setFormData(p => ({ 
                  ...p, 
                  stage: e.target.value as any, 
                  quota: e.target.value === 'primary' ? 20 : 18,
                  teacherQuota: e.target.value === 'primary' ? 24 : 18
                }))}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg text-right bg-white focus:outline-none font-bold"
              >
                <option value="primary">ابتدائي (حصص النصاب = ٢٠)</option>
                <option value="prep">إعدادي (حصص النصاب = ١٨)</option>
                <option value="sec">ثانوي عام/فني (حصص النصاب = ١٨)</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-655 mb-1">نصاب حصص المادة للمدرسة:</label>
              <input
                type="number"
                min="0.1"
                step="any"
                value={formData.quota}
                onChange={e => setFormData(p => ({ ...p, quota: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-lg text-right font-mono font-bold focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-655 mb-1">نصاب المعلم المعتمد بالمرحلة:</label>
              <input
                type="number"
                min="1"
                value={formData.teacherQuota}
                onChange={e => setFormData(p => ({ ...p, teacherQuota: parseInt(e.target.value) || 24 }))}
                className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-lg text-right font-mono font-bold focus:outline-none focus:border-blue-500"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-2.5 bg-gradient-to-l from-indigo-750 to-blue-600 hover:brightness-110 active:scale-95 text-white rounded-lg text-xs font-black shadow-md transition-all shrink-0 cursor-pointer"
            >
              {saving ? 'جاري الحفظ والتعميم...' : 'حفظ الآن'}
            </button>
          </form>
        </div>

        {/* Materials Lists split by Stages */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Primary Stage Table */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                <h3 className="text-xs font-black text-slate-900 font-sans">جدول مواد المرحلة الابتدائية</h3>
              </div>
              <span className="text-[10px] font-bold text-blue-755 bg-blue-50 border px-2.5 py-0.5 rounded-lg border-blue-100">مواد الابتدائي: {primaryList.length}</span>
            </div>

            <div className="overflow-x-auto border border-slate-150 rounded-xl">
              <table className="w-full text-right text-xs border-collapse font-sans bg-white">
                <thead>
                  <tr className="bg-blue-900 text-white font-bold text-right py-3 select-none">
                    <th className="p-3 border">اسم المادة التعليمية</th>
                    <th className="p-3 border text-center font-sans">المرحلة المستهدفة</th>
                    <th className="p-3 border text-center font-sans">نصاب المادة (حصص)</th>
                    <th className="p-3 border text-center font-sans">نصاب المعلم (حصص)</th>
                    <th className="p-3 border text-center">الخيارات والإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {primaryList.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center p-6 text-slate-400 font-bold font-sans">
                        لا توجد مواد مقيدة للمرحلة الابتدائية حالياً.
                      </td>
                    </tr>
                  ) : (
                    primaryList.map(mat => renderMaterialRow(mat))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Preparatory Stage Table */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-600"></span>
                <h3 className="text-xs font-black text-slate-900 font-sans">جدول مواد المرحلة الإعدادية</h3>
              </div>
              <span className="text-[10px] font-bold text-purple-755 bg-purple-50 border px-2.5 py-0.5 rounded-lg border-purple-100">مواد الإعدادي: {prepList.length}</span>
            </div>

            <div className="overflow-x-auto border border-slate-150 rounded-xl">
              <table className="w-full text-right text-xs border-collapse font-sans bg-white">
                <thead>
                  <tr className="bg-purple-900 text-white font-bold text-right py-3 select-none">
                    <th className="p-3 border">اسم المادة التعليمية</th>
                    <th className="p-3 border text-center font-sans">المرحلة المستهدفة</th>
                    <th className="p-3 border text-center font-sans">نصاب المادة (حصص)</th>
                    <th className="p-3 border text-center font-sans">نصاب المعلم (حصص)</th>
                    <th className="p-3 border text-center">الخيارات والإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {prepList.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center p-6 text-slate-400 font-bold font-sans">
                        لا توجد مواد مقيدة للمرحلة الإعدادية حالياً.
                      </td>
                    </tr>
                  ) : (
                    prepList.map(mat => renderMaterialRow(mat))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Secondary Stage Table */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-600"></span>
                <h3 className="text-xs font-black text-slate-900 font-sans">جدول مواد المرحلة الثانوية</h3>
              </div>
              <span className="text-[10px] font-bold text-amber-755 bg-amber-50 border px-2.5 py-0.5 rounded-lg border-amber-100">مواد الثانوي: {secList.length}</span>
            </div>

            <div className="overflow-x-auto border border-slate-150 rounded-xl">
              <table className="w-full text-right text-xs border-collapse font-sans bg-white">
                <thead>
                  <tr className="bg-amber-900 text-white font-bold text-right py-3 select-none">
                    <th className="p-3 border">اسم المادة التعليمية</th>
                    <th className="p-3 border text-center font-sans">المرحلة المستهدفة</th>
                    <th className="p-3 border text-center font-sans">نصاب المعلم (حصص)</th>
                    <th className="p-3 border text-center">الخيارات والإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {secList.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center p-6 text-slate-400 font-bold font-sans">
                        لا توجد مواد مقيدة للمرحلة الثانوية حالياً.
                      </td>
                    </tr>
                  ) : (
                    secList.map(mat => renderMaterialRow(mat))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}

// ----------------------------------------------------------------------------
// 2. STAGE DEF-QUOTAS VALUES & SCHOOL BUILD DIRECTORY (PIN generation and bulk edit)
// ----------------------------------------------------------------------------
function BaseQuotasTabInner({ settings, schools, dbTick }: { settings: SystemSettings; schools: School[]; dbTick: number }) {
  const [pri, setPri] = useState(settings.quota_primary);
  const [prep, setPrep] = useState(settings.quota_prep);
  const [sec, setSec] = useState(settings.quota_sec);
  const [savingSettings, setSavingSettings] = useState(false);

  // local editable roster
  const [localSchools, setLocalSchools] = useState<School[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStage, setFilterStage] = useState<string>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [exportingPasscodesPdf, setExportingPasscodesPdf] = useState(false);

  // High-fidelity PDF Export for School Passcodes Registry
  const handleExportPasscodesPdf = async () => {
    const element = document.getElementById('printable-school-passcodes-area');
    if (!element) {
      alert('لم يتم العثور على منطقة سجل المدارس للطباعة.');
      return;
    }
    setExportingPasscodesPdf(true);
    
    // Backup original styles of element and parent elements to allow full expansion
    const originalStyle = element.style.cssText;
    const originalParents: { el: HTMLElement; cssText: string }[] = [];
    const scrollContainers = element.querySelectorAll('.overflow-x-auto, [class*="overflow-"]');
    const originalScrollStyles: { el: HTMLElement; cssText: string }[] = [];
    
    try {
      element.style.cssText += `; width: 210mm !important; max-width: none !important; height: auto !important; max-height: none !important; overflow: visible !important; display: block !important;`;
      
      scrollContainers.forEach((el: any) => {
        originalScrollStyles.push({ el, cssText: el.style.cssText });
        el.style.cssText += '; overflow: visible !important; max-width: none !important; width: auto !important; display: block !important;';
      });

      let p = element.parentElement;
      while (p && p !== document.body) {
        originalParents.push({ el: p, cssText: p.style.cssText });
        p.style.cssText += '; overflow: visible !important; height: auto !important; max-height: none !important;';
        p = p.parentElement;
      }

      const canvas = await withOklchBypass(async () => {
        return await html2canvas(element, {
          scale: 2, // high clarity
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff'
        });
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const imgWidth = 210; // A4 width in portrait
      const pageHeight = 297; // A4 height in portrait
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`سجل_دليل_المدارس_وأرقام_المرور.pdf`);
    } catch (err) {
      console.error('Failed to generate PDF:', err);
      alert('حدث خطأ أثناء تصدير مستند PDF لسجل أرقام المرور.');
    } finally {
      // Restore original styles
      originalScrollStyles.forEach(os => {
        os.el.style.cssText = os.cssText;
      });
      originalParents.forEach(op => {
        op.el.style.cssText = op.cssText;
      });
      element.style.cssText = originalStyle;
      setExportingPasscodesPdf(false);
    }
  };

  const handlePrintPasscodes = () => {
    try {
      window.focus();
      window.print();
    } catch (e) {
      console.error(e);
      alert('نظراً لقيود المتصفح داخل نافذة المعاينة الفورية (iFrame)، يرجى الضغط على زر "فتح في نافذة جديدة" أعلى يسار الشاشة لتشغيل ميزة طباعة التقارير بشكل ممتاز.');
    }
  };

  const [bulkText, setBulkText] = useState('');
  const [bulkStage, setBulkStage] = useState<'primary' | 'prep' | 'sec' | 'basic' | 'languages'>('primary');

  const [addName, setAddName] = useState('');
  const [addStage, setAddStage] = useState<'primary' | 'prep' | 'sec' | 'basic' | 'languages'>('primary');
  const [addClassrooms, setAddClassrooms] = useState(12);

  useEffect(() => {
    setPri(settings.quota_primary);
    setPrep(settings.quota_prep);
    setSec(settings.quota_sec);
  }, [settings, dbTick]);

  useEffect(() => {
    setLocalSchools(schools);
  }, [schools, dbTick]);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    dbInstance.saveSettings({
      ...settings,
      quota_primary: Number(pri),
      quota_prep: Number(prep),
      quota_sec: Number(sec)
    });
    setTimeout(() => {
      setSavingSettings(false);
      alert('تم تحديث وحفظ نصاب المعلم المرجعي المستهدف للمراحل بنجاح.');
    }, 400);
  };

  const handleBulkImport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bulkText.trim()) return;

    const lines = bulkText.split('\n');
    let count = 0;

    lines.forEach(line => {
      const name = line.trim();
      if (name) {
        // Generate random 4-digit PIN/Password for each school (سرية مدير من 4 ارقام عشوائية)
        const generatedPin = String(Math.floor(1000 + Math.random() * 9000));
        const generatedId = 'sch_' + Date.now() + '_' + Math.floor(Math.random() * 100000);

        const newSch: School = {
          id: generatedId,
          name: name,
          address: 'أبوحماد',
          year: '٢٠٢٥/٢٠٢٦',
          stage: bulkStage as any,
          classroomsCount: 12,
          password: generatedPin
        };
        dbInstance.saveSchool(newSch);
        count++;
      }
    });

    dbInstance.addAuditLog('مدير التنسيق', 'استيراد جماعي للمدارس', `تم استيراد عدد (${count}) مدرسة بنجاح إلى النظام.`, undefined, undefined);
    setBulkText('');
    alert(`تم استيراد الكشوفات بنجاح! تم رصد وتسجيل (${count}) مدرسة وتوليد أرقام سرية (من ٤ أرقام) تلقائياً.`);
  };

  const handleSingleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addName.trim()) return;

    // Generate random 4-digit PIN default
    const generatedPin = String(Math.floor(1000 + Math.random() * 9000));
    const generatedId = 'sch_' + Date.now() + '_' + Math.floor(Math.random() * 100000);

    const newSch: School = {
      id: generatedId,
      name: addName.trim(),
      address: 'أبوحماد',
      year: '٢٠٢٥/٢٠٢٦',
      stage: addStage as any,
      classroomsCount: Number(addClassrooms) || 12,
      password: generatedPin
    };

    dbInstance.saveSchool(newSch);
    dbInstance.addAuditLog('مدير التنسيق', 'إضافة مدرسة', `تم إضافة المدرسة الجديدة "${newSch.name}" رقم المرور: ${newSch.password}.`, undefined, newSch);
    setAddName('');
    setAddClassrooms(12);
    alert(`تم تسجيل منشأة "${newSch.name}" بنجاح، الرقم السري دخول المولد: (${generatedPin})`);
  };

  const handleLocalSchoolChange = (id: string, field: keyof School, value: any) => {
    setLocalSchools(prev => {
      const updated = prev.map(s => s.id === id ? { ...s, [field]: value } : s);
      const school = updated.find(s => s.id === id);
      if (school) {
        const oldSch = schools.find(s => s.id === id);
        dbInstance.saveSchool(school);
        dbInstance.addAuditLog('مدير التنسيق', 'تعديل حقل مدرسة', `تعديل حقل ${field} للمدرسة "${school.name}" إلى: ${value}`, oldSch, school);
      }
      return updated;
    });
  };

  const handleSaveIndividualSchool = (school: School) => {
    const oldSch = schools.find(s => s.id === school.id);
    dbInstance.saveSchool(school);
    dbInstance.addAuditLog('مدير التنسيق', 'تعديل مدرسة', `تم تعديل بيانات المدرسة "${school.name}".`, oldSch, school);
    alert(`تم رصد وحفظ تعديل مدرسة "${school.name}" بنجاح.`);
  };

  const handleDeleteIndividualSchool = (id: string, name: string) => {
    const sch = localSchools.find(s => s.id === id);
    if (sch) {
      const trash: TrashItem = {
        id: 'trash_sch_' + Date.now(),
        type: 'school',
        originalId: id,
        name: sch.name,
        deletedAt: Date.now(),
        data: sch
      };
      dbInstance.saveTrashItem(trash);
      dbInstance.addAuditLog('مدير التنسيق', 'نقل مدرسة لسلة المهملات', `تم نقل المدرسة "${sch.name}" إلى سلة المهملات المؤقتة.`, sch, undefined);
    }
    dbInstance.deleteSchool(id);
    alert('🗑️ تم نقل المدرسة لسلة المهملات بنجاح. يمكنك استرجاعها في أي وقت من تبويب "سلة المهملات والتعافي السريع".');
  };

  const handleRegeneratePin = (id: string) => {
    // Regenerate random 4-digit password
    const randomPin = String(Math.floor(1000 + Math.random() * 9000));
    handleLocalSchoolChange(id, 'password', randomPin);
  };

  const handleSaveAllSchools = () => {
    localSchools.forEach(sch => {
      dbInstance.saveSchool(sch);
    });
    alert('تم ترحيل وتأكيد تعديلات أرقام السرية والبيانات المحدثة لكل المدارس بنجاح كلي.');
  };

  const handleDeleteAllSchools = () => {
    if (confirm('⚠️⚠️⚠️ تحذير مدمر: مسح كل المدارس سيقوم بتصفير قاعدة البيانات بالكامل للتصاميم! هل توافق؟')) {
      schools.forEach(sch => dbInstance.deleteSchool(sch.id));
      alert('تم تصفير المنظومة بنجاح.');
    }
  };

  const processedSchools = useMemo(() => {
    let list = [...localSchools];
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(s => s.name.toLowerCase().includes(q));
    }
    if (filterStage !== 'all') {
      list = list.filter(s => s.stage === filterStage);
    }
    return list;
  }, [localSchools, searchQuery, filterStage]);

  return (
    <div className="space-y-6 font-sans">
      
      {/* settings quota */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4">
        <div>
          <h2 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
            ⚔️ إعداد وتحوير نصاب المعلم المقـرر بكل مرحلة تعليمية
          </h2>
          <p className="text-[10px] text-slate-400 mt-1">المكافئ التدريسي المعتمد لحساب السد الفوري للعجز والزيادة بالإدارة (الافتراضي: ابتدائي=20، إعدادي=18، ثانوي=18)</p>
        </div>

        <form onSubmit={handleSaveSettings} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <div className="flex justify-between items-center bg-slate-50 border p-2 py-1.5 rounded-xl">
            <span className="text-[11px] font-bold text-slate-700">ابتدائي (النصاب):</span>
            <input
              type="number"
              min="1"
              value={pri}
              onChange={e => setPri(parseInt(e.target.value) || 0)}
              className="w-16 px-2 py-0.5 text-center font-mono font-bold border rounded-lg bg-white"
            />
          </div>
          <div className="flex justify-between items-center bg-slate-50 border p-2 py-1.5 rounded-xl">
            <span className="text-[11px] font-bold text-slate-700">إعدادي (النصاب):</span>
            <input
              type="number"
              min="1"
              value={prep}
              onChange={e => setPrep(parseInt(e.target.value) || 0)}
              className="w-16 px-2 py-0.5 text-center font-mono font-bold border rounded-lg bg-white"
            />
          </div>
          <div className="flex justify-between items-center bg-slate-50 border p-2 py-1.5 rounded-xl">
            <span className="text-[11px] font-bold text-slate-700">ثانوي (النصاب):</span>
            <input
              type="number"
              min="1"
              value={sec}
              onChange={e => setSec(parseInt(e.target.value) || 0)}
              className="w-16 px-2 py-0.5 text-center font-mono font-bold border rounded-lg bg-white"
            />
          </div>
          <button
            type="submit"
            disabled={savingSettings}
            className="py-2.5 bg-gradient-to-l from-indigo-750 to-blue-600 hover:brightness-110 active:scale-95 text-white rounded-lg text-xs font-black shadow-md transition-all cursor-pointer h-full"
          >
            {savingSettings ? 'جاري النشر المرجعي...' : 'تطبيق وحفظ الحدود المعتمدة ⚙️'}
          </button>
        </form>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Bulk addition schools */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4">
          <div>
            <h3 className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
              📥 استيراد المدارس التعليمية دفعة واحدة (كل مدرسة في سطر منفرد)
            </h3>
            <p className="text-[10px] text-slate-400 mt-1">
              انسخ أسماء المدارس من ملف إكسيل أو نصي والصقها هنا، سيقوم المترجم بتوليد **رقم سري من 4 أرقام عشوائية** خاص بكل مدرسة.
            </p>
          </div>

          <form onSubmit={handleBulkImport} className="space-y-4 font-sans">
            <div>
              <label className="block text-[10px] font-black text-slate-650 mb-1">المرحلة الأساسية الافتراضية للمدفوعات:</label>
              <select
                value={bulkStage}
                onChange={e => setBulkStage(e.target.value as any)}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-right focus:outline-none focus:border-indigo-500 font-bold"
              >
                <option value="primary">ابتدائي</option>
                <option value="prep">إعدادي</option>
                <option value="sec">ثانوي عام</option>
                <option value="basic">تعليم أساسي</option>
                <option value="languages">رسمي لغات</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-650 mb-1">المنشآت المستوردة (كل واحدة في سطر مستقل):</label>
              <textarea
                rows={4}
                placeholder="مدرسة السيدة خديجة الابتدائية&#10;مدرسة الجلاء الإعدادية بنات&#10;مدرسة الفاروق للغات"
                value={bulkText}
                onChange={e => setBulkText(e.target.value)}
                className="w-full p-2.5 text-xs border border-slate-200 rounded-lg text-right tracking-wide leading-relaxed placeholder-slate-350 focus:outline-none bg-slate-50/20"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-gradient-to-l from-indigo-755 to-blue-500 hover:brightness-110 active:scale-95 text-white rounded-lg text-xs font-black shadow-md transition-all cursor-pointer"
            >
              تشغيل الاستيراد الكلي لوعاء المدارس ⚙️
            </button>
          </form>
        </div>

        {/* Single school add */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4">
          <div>
            <h3 className="text-xs font-black text-emerald-950 flex items-center gap-1.5">
              ➕ تسجيل وإضافة مدرسة واحدة منفردة
            </h3>
            <p className="text-[10px] text-slate-400 mt-1">توليد منشأة مخصصة مع رقم سري مرور من أربعة خانات عشوائية.</p>
          </div>

          <form onSubmit={handleSingleAdd} className="space-y-4 font-sans">
            <div>
              <label className="block text-[10px] font-black text-slate-600 mb-1">اسم المدرسة بالكامل:</label>
              <input
                type="text"
                placeholder="أدخل الاسم بوضوح"
                value={addName}
                onChange={e => setAddName(e.target.value)}
                className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg text-right focus:outline-none focus:border-indigo-500 font-bold"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-black text-slate-650 mb-1">المرحلة والتبعية:</label>
                <select
                  value={addStage}
                  onChange={e => setAddStage(e.target.value as any)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-right focus:outline-none font-bold"
                >
                  <option value="primary">ابتدائي</option>
                  <option value="prep">إعدادي</option>
                  <option value="sec">ثانوي عام</option>
                  <option value="basic">تعليم أساسي</option>
                  <option value="languages">رسمي لغات</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-655 mb-1">عدد الفصول:</label>
                <input
                  type="number"
                  min="1"
                  value={addClassrooms}
                  onChange={e => setAddClassrooms(parseInt(e.target.value) || 12)}
                  className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg text-right font-mono font-bold"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-gradient-to-l from-emerald-600 to-teal-500 hover:brightness-110 active:scale-95 text-white rounded-lg text-xs font-black shadow-md transition-all cursor-pointer"
            >
              رصد وإدراج المنشأة بالدورة الأساسية
            </button>
          </form>
        </div>

      </div>

      {/* Editable schools directory */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-xs font-black text-slate-900">سجل دليل المدارس وأرقام المرور السرية المعتمدة</h3>
            <p className="text-[10px] text-slate-400 mt-1">توليد تلقائي وتعديل فوري من صلاحيات مشرف التنسيق فقط للدخول الآمن لبرج التفاعل للمرحلة.</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleExportPasscodesPdf}
              disabled={exportingPasscodesPdf}
              className="px-3.5 py-1.5 bg-indigo-650 hover:bg-indigo-750 text-white font-black rounded-lg text-[10px] shadow-3xs cursor-pointer flex items-center transition gap-1"
            >
              <span>{exportingPasscodesPdf ? 'جاري التصدير...' : 'تصدير كـ PDF 📄'}</span>
            </button>
            <button
              type="button"
              onClick={handlePrintPasscodes}
              className="px-3.5 py-1.5 bg-sky-650 hover:bg-sky-750 text-white font-black rounded-lg text-[10px] shadow-3xs cursor-pointer flex items-center transition gap-1"
            >
              <span>طباعة الكشف 🖨️</span>
            </button>
            <button
              type="button"
              onClick={handleSaveAllSchools}
              className="px-3.5 py-1.5 bg-green-700 hover:bg-green-800 text-white font-black rounded-lg text-[10px] shadow-3xs cursor-pointer flex items-center transition"
            >
              حفظ جميع تفاصيل الدليل 📥
            </button>
            <button
              type="button"
              onClick={handleDeleteAllSchools}
              className="px-3.5 py-1.5 bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 font-extrabold rounded-lg text-[10px] cursor-pointer inline-flex items-center transition animate-pulse"
            >
              تصفير وسحق الدلائل كلياً 🚨
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-2 font-sans text-right">
          <input
            type="text"
            placeholder="ابحث عن مدرسة مدرجة بالاسم..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="px-3 py-1.5 text-xs border border-slate-200 rounded-lg text-right focus:outline-none focus:border-indigo-500 font-bold"
          />
          <select
            value={filterStage}
            onChange={e => setFilterStage(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-right focus:outline-none font-bold text-right"
          >
            <option value="all">كل المراحل التعليمية بالإدارة</option>
            <option value="primary">ابتدائي</option>
            <option value="prep">إعدادي</option>
            <option value="sec">ثانوي عام</option>
            <option value="basic">تعليم أساسي</option>
            <option value="languages">رسمي لغات</option>
          </select>
        </div>

        {/* Schools registry list */}
        <div className="overflow-x-auto border border-slate-150 rounded-xl">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-slate-900 text-white font-bold text-right select-none">
                <th className="p-3 border text-center">م</th>
                <th className="p-3 border">اسم المدرسة متاحاً للتحديث البيني</th>
                <th className="p-3 border text-center">المرحلة</th>
                <th className="p-3 border text-center">عدد الفصل</th>
                <th className="p-3 border text-center">عنوانها المعتمد</th>
                <th className="p-3 border text-center">رمز السر PIN (مدير التنسيق فقط)</th>
                <th className="p-3 border text-center">الأفعال</th>
              </tr>
            </thead>
            <tbody>
              {processedSchools.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center p-6 text-slate-450 font-bold">
                    لا توجد مدارس مدرجة تطابق شروط التصفية.
                  </td>
                </tr>
              ) : (
                processedSchools.map((sch, i) => (
                  <tr key={sch.id} className="border-b bg-white odd:bg-slate-50/30 hover:bg-slate-50 transition border-slate-100 font-sans">
                    <td className="p-2 text-center border font-mono font-bold text-slate-500">{i + 1}</td>
                    <td className="p-1 border">
                      <input
                        type="text"
                        value={sch.name}
                        onChange={e => handleLocalSchoolChange(sch.id, 'name', e.target.value)}
                        className="w-full px-2 py-1 text-xs border border-transparent hover:border-slate-200 rounded font-bold bg-transparent focus:bg-white"
                      />
                    </td>
                    <td className="p-1 border text-center">
                      <select
                        value={sch.stage}
                        onChange={e => handleLocalSchoolChange(sch.id, 'stage', e.target.value)}
                        className="px-2 py-0.5 text-xs border border-transparent rounded bg-transparent focus:bg-white font-bold"
                      >
                        <option value="primary">ابتدائي</option>
                        <option value="prep">إعدادي</option>
                        <option value="sec">ثانوي عام</option>
                        <option value="basic">تعليم أساسي</option>
                        <option value="languages">رسمي لغات</option>
                      </select>
                    </td>
                    <td className="p-1 border text-center w-16">
                      <input
                        type="number"
                        min="1"
                        value={sch.classroomsCount || 0}
                        onChange={e => handleLocalSchoolChange(sch.id, 'classroomsCount', parseInt(e.target.value) || 12)}
                        className="w-12 text-center font-mono font-bold border border-transparent rounded bg-transparent focus:bg-white"
                      />
                    </td>
                    <td className="p-1 border text-center">
                      <input
                        type="text"
                        value={sch.address || 'أبو حماد'}
                        onChange={e => handleLocalSchoolChange(sch.id, 'address', e.target.value)}
                        className="w-full px-2 py-1 text-xs border border-transparent hover:border-slate-200 rounded bg-transparent focus:bg-white text-center text-slate-700"
                      />
                    </td>
                    <td className="p-1 border text-center w-40">
                      <div className="flex items-center gap-1 justify-center">
                        <input
                          type="text"
                          value={sch.password || ''}
                          maxLength={4}
                          onChange={e => handleLocalSchoolChange(sch.id, 'password', e.target.value)}
                          className="w-16 px-1 py-0.5 text-center font-mono font-bold text-blue-900 border rounded bg-white text-xs border-slate-200"
                        />
                        <button
                          type="button"
                          onClick={() => handleRegeneratePin(sch.id)}
                          title="توليد رقم سري من 4 خانات عشوائي"
                          className="p-1 hover:bg-slate-100 rounded text-indigo-750 transition cursor-pointer"
                        >
                          <RefreshCw size={11} />
                        </button>
                      </div>
                    </td>
                    <td className="p-1 text-center w-24">
                      <div className="flex items-center gap-1 justify-center">
                        <button
                          type="button"
                          onClick={() => handleSaveIndividualSchool(sch)}
                          className="px-2 py-0.5 bg-emerald-600 text-white hover:bg-emerald-700 font-bold rounded text-[9px] cursor-pointer inline-flex items-center"
                        >
                          <Save size={9} />
                          حفظ
                        </button>
                        {confirmDeleteId === sch.id ? (
                          <div className="flex items-center gap-1 justify-center bg-rose-50 border border-rose-100 rounded p-0.5 animate-pulse">
                            <button
                              type="button"
                              onClick={() => {
                                handleDeleteIndividualSchool(sch.id, sch.name);
                                setConfirmDeleteId(null);
                              }}
                              className="px-1.5 py-0.2 bg-rose-600 text-white font-bold rounded text-[8.5px] cursor-pointer"
                            >
                              تأكيد
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-1.5 py-0.2 border border-slate-205 text-slate-500 font-bold rounded text-[8.5px] cursor-pointer bg-white"
                            >
                              إلغاء
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(sch.id)}
                            className="px-2 py-0.5 text-rose-600 hover:bg-rose-50 rounded text-[9px] font-bold cursor-pointer inline-flex items-center gap-0.5"
                            title="حذف المدرسة وسجلاتها بالكامل"
                          >
                            <Trash2 size={9} />
                            حذف
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Printable/Exportable School Passcodes Registry Table (hidden on screen, visible on print or when exporting PDF) */}
      <div 
        id="printable-school-passcodes-area" 
        className={`printable-area bg-white p-8 text-right font-sans ${exportingPasscodesPdf ? 'block' : 'hidden print:block'}`}
        dir="rtl"
        style={exportingPasscodesPdf ? { position: 'fixed', left: '-9999px', top: '0px', width: '210mm', zIndex: 99999, background: 'white' } : {}}
      >
        <PrintHeader 
          title="بيان سجل دليل المدارس وأرقام المرور السرية المعتمدة" 
          subtitle="سجل دليل مستخدمي منشآت التنسيق العام والتبادل التفاعلي السحابي لعام ٢٠٢٦/٢٠٢٧" 
          isVisible={true} 
        />
        
        <div className="my-6 font-sans">
          <p className="text-sm font-bold text-slate-800 mb-2">إدارة أبو حماد التعليمية - قسم التنسيق والمتابعة الإلكترونية</p>
          <p className="text-xs text-slate-500">تم توليد وتصدير هذا التقرير بتاريخ: {new Date().toLocaleDateString('ar-EG')} م في {new Date().toLocaleTimeString('ar-EG')}</p>
        </div>

        <table className="w-full text-right text-xs border-collapse border border-black font-sans">
          <thead>
            <tr className="bg-slate-100 text-slate-900 font-extrabold text-right border border-black">
              <th className="p-2 border border-black text-center w-10">م</th>
              <th className="p-2 border border-black text-right">اسم المنشأة التعليمية</th>
              <th className="p-2 border border-black text-center w-28">المرحلة</th>
              <th className="p-2 border border-black text-center w-28">عدد الفصول</th>
              <th className="p-2 border border-black text-center w-36">رمز المرور السري PIN</th>
              <th className="p-2 border border-black text-center w-36">توقيع المستلم للرقم</th>
            </tr>
          </thead>
          <tbody>
            {processedSchools.map((sch, i) => (
              <tr key={sch.id} className="border border-black font-sans">
                <td className="p-2 text-center border border-black font-mono font-bold text-slate-900">{i + 1}</td>
                <td className="p-2 border border-black font-extrabold text-slate-900">{sch.name}</td>
                <td className="p-2 border border-black text-center font-bold text-slate-800">
                  {sch.stage === 'primary' ? 'ابتدائي' :
                   sch.stage === 'prep' ? 'إعدادي' :
                   sch.stage === 'sec' ? 'ثانوي عام' :
                   sch.stage === 'basic' ? 'تعليم أساسي' :
                   sch.stage === 'languages' ? 'رسمي لغات' : sch.stage}
                </td>
                <td className="p-2 border border-black text-center font-mono text-slate-800">{sch.classroomsCount || 12}</td>
                <td className="p-2 border border-black text-center font-mono font-extrabold text-blue-900 text-sm tracking-widest">{sch.password || '----'}</td>
                <td className="p-2 border border-black text-center text-[10px] text-slate-400 font-bold">....................................</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-12 flex justify-between items-center text-xs px-4 font-sans">
          <div className="text-center space-y-1">
            <p className="font-bold text-slate-850">مسؤول التنسيق الإلكتروني</p>
            <p className="text-slate-400">............................</p>
          </div>
          <div className="text-center space-y-1">
            <p className="font-bold text-slate-850">رئيس لجنة الامتحان بالقسم</p>
            <p className="text-slate-400">............................</p>
          </div>
          <div className="text-center space-y-1">
            <p className="font-bold text-slate-850">يعتمد: مدير عام الإدارة التعليمية</p>
            <p className="text-slate-400">............................</p>
          </div>
        </div>

        <PrintFooter isVisible={true} />
      </div>

    </div>
  );
}

// ----------------------------------------------------------------------------
// 2.5 TRASH BIN AND RESTORATION MANAGEMENT (سلة المهملات المؤقتة والتعافي السريع)
// ----------------------------------------------------------------------------
function TrashManagementTabInner({ dbTick }: { dbTick: number }) {
  const [trashItems, setTrashItems] = useState<TrashItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const reload = () => {
    setTrashItems(dbInstance.getTrashItems());
  };

  useEffect(() => {
    reload();
  }, [dbTick]);

  const handleRestore = (item: TrashItem) => {
    try {
      const data = item.data;
      if (item.type === 'school') {
        dbInstance.saveSchool(data);
        dbInstance.addAuditLog('مدير التنسيق', 'استرجاع مدرسة', `تم استرجاع المدرسة "${item.name}" بنجاح من سلة المهملات.`, undefined, data);
      } else if (item.type === 'material') {
        dbInstance.saveMaterial(data);
        dbInstance.addAuditLog('مدير التنسيق', 'استرجاع مادة', `تم استرجاع المادة "${item.name}" بنجاح من سلة المهملات.`, undefined, data);
      }
      dbInstance.deleteTrashItem(item.id);
      reload();
      alert(`🔄 تم استرجاع سجل "${item.name}" بنجاح وإعادة دمج بياناته فوراً!`);
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء محاولة استرجاع هذا السجل.');
    }
  };

  const handlePermanentDelete = (item: TrashItem) => {
    if (confirm(`⚠️ تحذير نهائي ودائم: هل أنت متأكد من حذف "${item.name}" نهائياً بالكامل؟ لا يمكن التراجع عن هذا الإجراء!`)) {
      dbInstance.deleteTrashItem(item.id);
      dbInstance.addAuditLog('مدير التنسيق', 'حذف نهائي', `تم مسح سجل "${item.name}" نهائياً من سلة المهملات.`);
      reload();
      alert('❌ تم حذف السجل نهائياً بنجاح.');
    }
  };

  const handleEmptyTrash = () => {
    if (confirm('⚠️ هل تريد إفراغ سلة المهملات بالكامل ومسح كل المحتويات نهائياً؟')) {
      const items = dbInstance.getTrashItems();
      items.forEach(item => {
        dbInstance.deleteTrashItem(item.id);
      });
      dbInstance.addAuditLog('مدير التنسيق', 'تفريغ سلة المهملات', 'تم تفريغ سلة المهملات بالكامل.');
      reload();
      alert('🗑️ تم إفراغ سلة المهملات بالكامل بنجاح.');
    }
  };

  const filteredItems = useMemo(() => {
    return trashItems.filter(item => 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.type === 'school' ? 'مدرسة' : 'مادة').includes(searchQuery)
    );
  }, [trashItems, searchQuery]);

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4 text-right font-sans">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-3 border-b border-slate-100">
        <div>
          <h2 className="text-sm font-black text-rose-800 flex items-center gap-2">
            🗑️ سلة المهملات المؤقتة واسترجاع المحذوفات
          </h2>
          <p className="text-[10px] text-slate-400 mt-1">يحتفظ النظام بالمواد والمدارس المحذوفة مؤقتاً لتمكين الاسترجاع الفوري أو التطهير النهائي لتجنب الفقدان العرضي للبيانات.</p>
        </div>
        
        {trashItems.length > 0 && (
          <button
            type="button"
            onClick={handleEmptyTrash}
            className="px-3.5 py-2 bg-rose-50 text-rose-700 hover:bg-rose-100/80 border border-rose-200/50 font-black text-xs rounded-xl transition duration-150 active:scale-95 flex items-center gap-1.5 cursor-pointer"
          >
            🗑️ إفراغ السلة بالكامل
          </button>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="flex-grow">
          <input
            type="text"
            placeholder="البحث في سلة المهملات (باسم المدرسة أو المادة)..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-rose-500 font-bold text-xs text-right bg-slate-50"
          />
        </div>
      </div>

      {filteredItems.length === 0 ? (
        <div className="py-12 text-center text-slate-400 font-bold text-xs">
          {searchQuery ? 'لا توجد نتائج مطابقة لفلتر البحث.' : 'سلة المهملات فارغة تماماً. لا توجد محذوفات مؤقتة حالياً.'}
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-200/80">
          <table className="w-full text-right border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-black">
                <th className="p-3">اسم العنصر</th>
                <th className="p-3 text-center">نوع السجل</th>
                <th className="p-3 text-center">تاريخ الحذف</th>
                <th className="p-3 text-center">حذف بواسطة</th>
                <th className="p-3 text-center w-48">العمليات والإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map(item => (
                <tr key={item.id} className="border-b hover:bg-slate-50/50 transition border-slate-100 font-sans">
                  <td className="p-3 font-bold text-slate-800">{item.name}</td>
                  <td className="p-3 text-center">
                    <span className={`inline-block px-2.5 py-0.5 rounded-lg text-[9px] font-black ${
                      item.type === 'school' ? 'bg-amber-50 text-amber-755 border border-amber-100' : 'bg-blue-50 text-blue-755 border border-blue-100'
                    }`}>
                      {item.type === 'school' ? '🏫 مدرسة' : '📂 مادة ونصاب'}
                    </span>
                  </td>
                  <td className="p-3 text-center font-mono text-slate-500">
                    {new Date(item.deletedAt).toLocaleString('ar-EG', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'numeric' })}
                  </td>
                  <td className="p-3 text-center text-slate-600 font-bold">مدير التنسيق</td>
                  <td className="p-3">
                    <div className="flex items-center gap-2 justify-center">
                      <button
                        type="button"
                        onClick={() => handleRestore(item)}
                        className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200/50 font-black rounded-lg text-[10px] cursor-pointer flex items-center gap-1 active:scale-95"
                      >
                        🔄 استرجاع
                      </button>
                      <button
                        type="button"
                        onClick={() => handlePermanentDelete(item)}
                        className="px-2.5 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200/50 font-black rounded-lg text-[10px] cursor-pointer flex items-center gap-1 active:scale-95"
                      >
                        ❌ حذف نهائي
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// 3. LIVE AUTOMATIC CALCULATIONS VIEW (المطلوب، الموجود، العجز والزيادة والنسبة)
// ----------------------------------------------------------------------------
function DeficitsDashboardTabInner({ 
  schools, 
  materials, 
  materialCounts, 
  dbTick 
}: { 
  schools: School[]; 
  materials: Material[]; 
  materialCounts: MaterialCount[]; 
  dbTick: number; 
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStage, setFilterStage] = useState<string>('all');

  const mathRows = useMemo(() => {
    const rows: Array<{
      id: string;
      schoolName: string;
      schoolStage: string;
      classrooms: number;
      materialName: string;
      materialStage: string;
      materialQuota: number;
      needed: number;
      present: number;
      deficit: number;
      surplus: number;
      percentage: number;
    }> = [];

    schools.forEach(school => {
      materials.forEach(material => {
        const isApplicable = dbInstance.isMaterialApplicableToSchool(school.stage, material.stage);
        if (isApplicable) {
          const count = materialCounts.find(c => c.schoolId === school.id && c.materialId === material.id);
          const metrics = dbInstance.calculateMaterialMetrics(school, material, count);

          rows.push({
            id: `${school.id}_${material.id}`,
            schoolName: school.name,
            schoolStage: school.stage,
            classrooms: school.classroomsCount || 0,
            materialName: material.name,
            materialStage: material.stage,
            materialQuota: material.quota || 0,
            needed: metrics.needed,
            present: metrics.present,
            deficit: metrics.deficit,
            surplus: metrics.surplus,
            percentage: metrics.percentage
          });
        }
      });
    });

    return rows;
  }, [schools, materials, materialCounts, dbTick]);

  const filteredRows = useMemo(() => {
    let list = [...mathRows];
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(r => 
        r.schoolName.toLowerCase().includes(q) || 
        r.materialName.toLowerCase().includes(q)
      );
    }
    if (filterStage !== 'all') {
      list = list.filter(r => r.schoolStage === filterStage);
    }
    return list;
  }, [mathRows, searchQuery, filterStage]);

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-6 space-y-4">
      <div>
        <h3 className="text-xs font-black text-slate-900">📊 جدول حصر العجز والزيادة والعمليات الرياضية التلقائية</h3>
        <p className="text-[10px] text-slate-400 mt-1">
          بث حي لمخرجات الربط: <strong>المطلوب</strong> (= الفصول × نصاب المادة)، <strong>الموجود</strong> (= مجمّع المعلمين)، <strong>العجز</strong>، <strong>الزيادة</strong>، و<strong>نسبة التغطية المئوية %</strong>.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input
          type="text"
          placeholder="ابحث بمدرسة أو مادة تخصصية..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="px-3.5 py-1.5 text-xs border border-slate-200 rounded-lg text-right focus:outline-none focus:border-indigo-505 font-bold"
        />
        <select
          value={filterStage}
          onChange={e => setFilterStage(e.target.value)}
          className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-right focus:outline-none focus:border-indigo-505 font-bold text-right"
        >
          <option value="all">كل المراحل التعليمية للإدارة</option>
          <option value="primary">ابتدائي</option>
          <option value="prep">إعدادي</option>
          <option value="sec">ثانوي عام</option>
          <option value="basic">تعليم أساسي</option>
          <option value="languages">رسمي لغات</option>
        </select>
      </div>

      {/* alternating row styled live table */}
      <div className="overflow-x-auto border border-slate-150 rounded-xl shadow-3xs">
        <table className="w-full text-right text-xs border-collapse">
          <thead>
            <tr className="bg-slate-900 text-white font-bold text-right py-3 select-none">
              <th className="p-3 border">اسم المدرسة المعتمد</th>
              <th className="p-3 border">المادة الدراسية</th>
              <th className="p-3 border text-center">الفصول الدراسية</th>
              <th className="p-3 border text-center">النصاب</th>
              <th className="p-3 border text-center bg-blue-900 text-blue-50 font-black">المطلوب</th>
              <th className="p-3 border text-center bg-emerald-900 text-emerald-50 font-black">الموجود</th>
              <th className="p-3 border text-center text-rose-500 font-bold">العجز</th>
              <th className="p-3 border text-center text-teal-600 font-bold">الزيادة العليا</th>
              <th className="p-3 border text-center">النسبة المئوية لسد الاحتياج (%)</th>
            </tr>
          </thead>
          <tbody>
            {filteredRows.length === 0 ? (
              <tr>
                <td colSpan={9} className="text-center p-6 text-slate-400 font-bold bg-white">
                  لا توجد سجلات حسابية مسجلة تتناسق مع خيارات البحث والتصفية.
                </td>
              </tr>
            ) : (
              filteredRows.map((r, i) => (
                <tr key={r.id} className="hover:bg-slate-50 transition border-b border-slate-100 font-sans text-right odd:bg-white even:bg-slate-50/50">
                  <td className="p-3 font-bold text-slate-900">{r.schoolName}</td>
                  <td className="p-3 font-semibold text-indigo-900">{r.materialName}</td>
                  <td className="p-3 text-center font-mono font-bold text-slate-650">{r.classrooms}</td>
                  <td className="p-3 text-center font-mono text-slate-450">{r.materialQuota}</td>
                  <td className="p-3 text-center font-mono font-black bg-blue-50/80 text-blue-800 text-sm border-r">{r.needed}</td>
                  <td className="p-3 text-center font-mono font-black bg-emerald-50/80 text-emerald-805 text-sm border-r">{r.present}</td>
                  <td className="p-3 text-center font-mono font-black text-rose-600 text-sm w-20">
                    {r.deficit > 0 ? `${r.deficit} م` : '◀ متزن'}
                  </td>
                  <td className="p-3 text-center font-mono font-black text-teal-600 text-sm w-24">
                    {r.surplus > 0 ? `${r.surplus} م` : '◀ متزن'}
                  </td>
                  <td className="p-3 text-center">
                    <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                      r.percentage >= 100 ? 'bg-green-100 text-green-800' :
                      r.percentage >= 50 ? 'bg-amber-100 text-amber-805' :
                      'bg-rose-100 text-rose-800'
                    }`}>
                      {r.percentage}%
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================================
// TAB 3: SYSTEM SECURITY SETTINGS & CREDENTIALS (تغيير كود مرور واسم مستخدم مدير التنسيق)
// ============================================================================
interface SystemSecuritySettingsTabProps {
  settings: SystemSettings;
  dbTick: number;
}

function SystemSecuritySettingsTab({ settings, dbTick }: SystemSecuritySettingsTabProps) {
  const [activeSubTab, setActiveSubTab] = useState<'security' | 'import'>('security');
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [administrationName, setAdministrationName] = useState(settings.administrationName || 'إدارة أبو حماد التعليمية');
  const [departmentName, setDepartmentName] = useState(settings.departmentName || 'قسم التنسيق المركزي والمتابعة لموازنة الوظائف والأنصبة');
  const [undersecretariesNames, setUndersecretariesNames] = useState(settings.undersecretariesNames || 'الأستاذ علاء المرجل / الأستاذ عبد المنعم شعلان');
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    setAdministrationName(settings.administrationName || 'إدارة أبو حماد التعليمية');
    setDepartmentName(settings.departmentName || 'قسم التنسيق المركزي والمتابعة لموازنة الوظائف والأنصبة');
    setUndersecretariesNames(settings.undersecretariesNames || 'الأستاذ علاء المرجل / الأستاذ عبد المنعم شعلان');
  }, [settings, dbTick]);

  const handleUpdateCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (newPass || confirmPass) {
      if (currentPass !== settings.coordinationAdminPass) {
        setErrorMsg('الرقم السري الحالي المدخل غير صحيح.');
        return;
      }
      if (!newPass.trim()) {
        setErrorMsg('الرقم السري الجديد لا يمكن أن يكون فارغاً.');
        return;
      }
      if (newPass !== confirmPass) {
        setErrorMsg('كلمتا المرور الجديدتان غير متطابقتين.');
        return;
      }
    }

    setSaving(true);
    const updatedPass = newPass.trim() ? newPass.trim() : settings.coordinationAdminPass;

    dbInstance.saveSettings({
      ...settings,
      coordinationAdminPass: updatedPass,
      administrationName: administrationName.trim(),
      departmentName: departmentName.trim(),
      undersecretariesNames: undersecretariesNames.trim()
    });

    setTimeout(() => {
      setSaving(false);
      setCurrentPass('');
      setNewPass('');
      setConfirmPass('');
      alert('🔒 تم ترحيل وحفظ الإعدادات الفنية والرقم السري بنجاح ومزامنتها سحابياً في منطقة آمنة ومستقرة بـ Google Cloud Firestore لضمان الحفظ الدائم والمستمر!');
    }, 500);
  };

  return (
    <div className="space-y-6 font-sans text-right" dir="rtl">
      {/* Sub-tab Navigation */}
      <div className="flex border-b border-blue-900/30 gap-4 pb-1">
        <button
          type="button"
          onClick={() => setActiveSubTab('security')}
          className={`pb-2.5 px-4 text-xs font-black transition-all border-b-2 cursor-pointer ${
            activeSubTab === 'security'
              ? 'border-blue-500 text-blue-400 font-extrabold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          🔑 تعديل الإعدادات والرقم السري
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('import')}
          className={`pb-2.5 px-4 text-xs font-black transition-all border-b-2 cursor-pointer ${
            activeSubTab === 'import'
              ? 'border-blue-500 text-blue-400 font-extrabold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          📥 استيراد بيانات المدارس المعتمدة
        </button>
      </div>

      {activeSubTab === 'security' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 2. EDITABLE ADMIN CREDENTIALS & SYSTEM VARIABLE VALUES INFO */}
          <div className="bg-slate-900 border border-blue-900/40 rounded-2xl p-6 space-y-6 text-white shadow-2xl animate-fadeIn">
            <div>
              <h2 className="text-sm font-black text-white border-b border-blue-900/40 pb-3 flex items-center gap-2">
                <Lock size={18} className="text-blue-400" />
                تعديل الرقم السري وبيانات المنظومة
              </h2>
              <p className="text-[11px] text-slate-400 mt-1">تغيير كود المرور ومسميات جهات الإشراف للمنصة التعليمية بأمان</p>
            </div>

            <form onSubmit={handleUpdateCredentials} className="space-y-4">
              <div className="p-4 bg-slate-950/60 border border-blue-900/20 rounded-xl space-y-3">
                <h3 className="text-xs font-black text-[#90CDF4]">🔑 تغيير الرقم السري للمشرف</h3>
                
                <div className="p-3 bg-blue-950/50 border border-blue-500/20 rounded-xl space-y-2 animate-fadeIn">
                  <div className="flex justify-between items-center flex-wrap gap-2">
                    <span className="text-[10px] text-slate-300 font-extrabold flex items-center gap-1">
                      🔒 كود المرور الفعّال حالياً بالمنصة:
                    </span>
                    <span className="text-xs font-mono font-black text-amber-350 bg-slate-950 px-3 py-1 rounded-md border border-amber-500/30 tracking-widest">
                      {settings.coordinationAdminPass}
                    </span>
                  </div>
                  <div className="text-[9px] text-emerald-350 font-black leading-relaxed">
                    ● سيتم تشفير وحفظ الرقم السري الجديد سحابياً في منطقة تخزين آمنة بـ <span className="underline">Google Cloud Firestore</span> لضمان ديمومة الوصول الإشرافي بنسبة 100%.
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-350">الرقم السري الحالي:</label>
                  <input
                    type="password"
                    value={currentPass}
                    onChange={e => setCurrentPass(e.target.value)}
                    placeholder="أدخل الرقم السري الحالي لاعتماد التعديل"
                    className="w-full px-3 py-2 text-xs text-center font-mono border border-blue-900/45 bg-slate-950 text-white rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-350">الرقم السري الجديد:</label>
                    <input
                      type="password"
                      value={newPass}
                      onChange={e => setNewPass(e.target.value)}
                      placeholder="أدخل الرقم السري الجديد"
                      className="w-full px-3 py-2 text-xs text-center font-mono border border-blue-900/45 bg-slate-950 text-emerald-350 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-350">تأكيد الرقم الجديد:</label>
                    <input
                      type="password"
                      value={confirmPass}
                      onChange={e => setConfirmPass(e.target.value)}
                      placeholder="أعد كتابة الرقم للتأكيد"
                      className="w-full px-3 py-2 text-xs text-center font-mono border border-blue-900/45 bg-slate-950 text-emerald-350 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {errorMsg && (
                  <p className="text-rose-400 text-[10px] font-bold bg-rose-950/40 p-2 rounded-lg border border-rose-900/25">{errorMsg}</p>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1.5">بيانات اسم الإدارة والوزارة:</label>
                <input
                  type="text"
                  value={administrationName}
                  onChange={e => setAdministrationName(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-blue-900/40 bg-slate-950 text-white rounded-xl text-right font-bold focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1.5">اسم القسم المختص بالمنصة:</label>
                <input
                  type="text"
                  value={departmentName}
                  onChange={e => setDepartmentName(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-blue-900/40 bg-slate-950 text-white rounded-xl text-right font-bold focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1.5">أسماء السادة الوكلاء المعتمدين:</label>
                <input
                  type="text"
                  value={undersecretariesNames}
                  onChange={e => setUndersecretariesNames(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-blue-900/40 bg-slate-950 text-white rounded-xl text-right font-bold focus:outline-none focus:border-blue-500"
                  placeholder="مثال: الأستاذ علاء المرجل / الأستاذ عبد المنعم شعلان"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="w-full py-2.5 bg-gradient-to-l from-indigo-700 to-blue-600 hover:from-indigo-600 hover:to-blue-500 text-white rounded-xl text-xs font-black shadow-md transition-all cursor-pointer"
                >
                  {saving ? 'جاري الترحيل والحفظ الآمن...' : 'حفظ البيانات وتحديث المنظومة'}
                </button>
              </div>
            </form>
          </div>

          {/* 1. FIXED VALUES DISPLAY CARD */}
          <div className="bg-slate-900/95 border border-blue-900/40 rounded-2xl p-6 space-y-6 text-white shadow-2xl animate-fadeIn">
            <div>
              <h2 className="text-sm font-black text-white border-b border-blue-900/40 pb-3 flex items-center gap-2">
                <SlidersHorizontal size={18} className="text-blue-400" />
                المسؤولون الفنيون ومطورو المنظومة المعتمدون (ثوابت المنظومة المرموزة)
              </h2>
              <p className="text-[11px] text-slate-400 mt-1">توضح المعالم والبيانات الفنية الثابتة لبيئة العمل البرمجية المشرفة المعتمدة بالإدارة</p>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-slate-950 border border-blue-950/50 rounded-xl space-y-1">
                <span className="block text-[10px] text-slate-400 font-black">اسم الإدارة المفتوحة سحابياً</span>
                <span className="block text-xs font-extrabold text-[#90CDF4]">{administrationName}</span>
              </div>

              <div className="p-4 bg-slate-950 border border-blue-950/50 rounded-xl space-y-1">
                <span className="block text-[10px] text-slate-400 font-black">القسم المتابع المعتمد</span>
                <span className="block text-xs font-extrabold text-[#90CDF4]">{departmentName}</span>
              </div>

              <div className="p-4 bg-slate-950 border border-blue-950/50 rounded-xl space-y-1">
                <span className="block text-[10px] text-slate-400 font-black">المطور والمبرمج التقني المسؤول</span>
                <span className="block text-sm font-black text-indigo-300">الأستاذ محمد نجم - مدير التنسيق العام</span>
              </div>

              <div className="p-4 bg-indigo-950/50 border border-indigo-900/40 rounded-xl space-y-2">
                <span className="block text-[10px] text-indigo-300 font-extrabold">الاعتماد التقني والبرمجة</span>
                <span className="block text-xs font-semibold text-slate-200">
                  تم التطوير بواسطة: الأستاذ محمد نجم (برمجة وتصميم وإدارة فنية كاملة لربط الكوادر بالإدارة بنجاح)
                </span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <ImportSchoolDataSubTab dbTick={dbTick} />
      )}
    </div>
  );
}

// ----------------------------------------------------
// SUB-TAB COMPONENT: IMPORT SCHOOL DATA (استيراد بيانات المدارس المعتمدة)
// ----------------------------------------------------
interface StagedFile {
  file: File;
  success: boolean;
  error?: string;
  metadata?: {
    schoolId: string;
    schoolName: string;
    schoolCode: string;
    exportDateTime: string;
    fileId: string;
  };
  parsedData?: any;
  recordsCount?: number;
}

function ImportSchoolDataSubTab({ dbTick }: { dbTick: number }) {
  const [stagedFiles, setStagedFiles] = useState<StagedFile[]>([]);
  const [importing, setImporting] = useState(false);
  const [logs, setLogs] = useState<any[]>([]);
  const [forceTick, setForceTick] = useState(0);
  const [importResults, setImportResults] = useState<{
    fileName: string;
    schoolName: string;
    status: 'success' | 'duplicate' | 'failed';
    message: string;
    recordsCount?: number;
  }[] | null>(null);

  // Load logs
  useEffect(() => {
    const operationLogs = JSON.parse(localStorage.getItem('coordination_import_export_logs') || '[]');
    setLogs(operationLogs);
  }, [dbTick, forceTick]);

  const handleFilesChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const filesArray = Array.from(e.target.files) as File[];
    
    // Process only files ending with .abhm
    const abhmFiles = filesArray.filter(f => f.name.endsWith('.abhm') || f.name.includes('.abhm'));
    if (abhmFiles.length === 0) {
      alert('⚠️ لم يتم العثور على ملفات استيراد صالحة بامتداد (.abhm).');
      return;
    }

    const processed = await Promise.all(abhmFiles.map(file => processFile(file)));
    setStagedFiles(prev => [...prev, ...processed]);
  };

  const processFile = async (file: File): Promise<StagedFile> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          const decodedStr = base64ToUtf8(content.trim());
          const parsed = JSON.parse(decodedStr);
          
          if (!parsed.metadata || !parsed.payload) {
            resolve({ file, success: false, error: 'صيغة الملف غير صالحة ولا تحتوي على الحزمة المطلوبة.' });
            return;
          }

          const { metadata, payload, checksum } = parsed;
          const calculated = dbInstance.calculateChecksum(payload);

          if (calculated !== checksum) {
            resolve({ file, success: false, error: 'فشل التحقق من صحة الملف (Checksum غير متطابق).' });
            return;
          }

          const payloadObj = JSON.parse(payload);
          const recordsCount = (payloadObj.leadership?.length || 0) + 
                               (payloadObj.staff?.length || 0) + 
                               (payloadObj.materialCounts?.length || 0) + 
                               (payloadObj.studentAbsences?.length || 0) + 
                               (payloadObj.teacherAbsences?.length || 0) + 
                               (payloadObj.visitors?.length || 0) + 
                               (payloadObj.nutrition?.length || 0) + 
                               (payloadObj.examNominations?.length || 0) + 
                               (payloadObj.examExcuses?.length || 0);

          resolve({
            file,
            success: true,
            metadata,
            parsedData: parsed,
            recordsCount
          });
        } catch (err) {
          resolve({ file, success: false, error: 'الملف تالف أو غير صالح لفك التشفير.' });
        }
      };
      reader.onerror = () => resolve({ file, success: false, error: 'فشل قراءة الملف.' });
      reader.readAsText(file);
    });
  };

  const handleImportAllStaged = () => {
    const validFiles = stagedFiles.filter(f => f.success);
    if (validFiles.length === 0) {
      alert('❌ لا توجد أي ملفات صالحة وجاهزة للاستيراد في القائمة.');
      return;
    }

    setImporting(true);
    const resultsList: {
      fileName: string;
      schoolName: string;
      status: 'success' | 'duplicate' | 'failed';
      message: string;
      recordsCount?: number;
    }[] = [];

    validFiles.forEach(staged => {
      const res = dbInstance.importSchoolData(staged.parsedData);
      
      let status: 'success' | 'duplicate' | 'failed' = 'success';
      if (!res.success) {
        if (res.message.includes('بالفعل مسبقاً') || res.message.includes('أحدث أو مساوي')) {
          status = 'duplicate';
        } else {
          status = 'failed';
        }
      }

      resultsList.push({
        fileName: staged.file.name,
        schoolName: staged.metadata?.schoolName || 'غير معروف',
        status,
        message: res.message,
        recordsCount: staged.recordsCount
      });
    });

    setImporting(false);
    setStagedFiles([]);
    setImportResults(resultsList);
    setForceTick(prev => prev + 1);
  };

  const handleClearLogs = () => {
    if (confirm('هل أنت متأكد من رغبتك في تفريغ سجل عمليات الاستيراد والتصدير بالكامل؟')) {
      localStorage.removeItem('coordination_import_export_logs');
      setForceTick(prev => prev + 1);
    }
  };

  return (
    <div className="bg-slate-900 border border-blue-900/40 rounded-2xl p-6 text-white space-y-6 shadow-2xl animate-fadeIn">
      <div>
        <h2 className="text-sm font-black text-white border-b border-blue-900/40 pb-3 flex items-center gap-2">
          <Upload size={18} className="text-emerald-400" />
          مركز استيراد وتحديث بيانات المدارس الحكومية (.abhm)
        </h2>
        <p className="text-[11px] text-slate-400 mt-1">تتيح لك هذه اللوحة استيراد الملفات المصدرة من المدارس بشكل منفرد، متعدد، أو عبر استيراد مجلد كامل دفعة واحدة وتحديث التقارير والإحصائيات فورياً.</p>
      </div>

      {/* Buttons Panel */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 1. Single File */}
        <label className="flex flex-col items-center justify-center p-4 bg-slate-950/60 hover:bg-slate-950/90 border border-blue-900/30 hover:border-blue-500 rounded-xl cursor-pointer transition-all space-y-2 text-center group">
          <Upload size={20} className="text-indigo-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-black">📥 استيراد ملف مدرسة فردي</span>
          <span className="text-[9px] text-slate-400">تحميل ملف منفرد (.abhm)</span>
          <input
            type="file"
            accept=".abhm"
            onChange={handleFilesChange}
            className="hidden"
          />
        </label>

        {/* 2. Multiple Files */}
        <label className="flex flex-col items-center justify-center p-4 bg-slate-950/60 hover:bg-slate-950/90 border border-blue-900/30 hover:border-blue-500 rounded-xl cursor-pointer transition-all space-y-2 text-center group">
          <Upload size={20} className="text-emerald-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-black">📚 استيراد عدة ملفات</span>
          <span className="text-[9px] text-slate-400">تحديد مجموعة ملفات معاً</span>
          <input
            type="file"
            accept=".abhm"
            multiple
            onChange={handleFilesChange}
            className="hidden"
          />
        </label>

        {/* 3. Entire Folder */}
        <label className="flex flex-col items-center justify-center p-4 bg-slate-950/60 hover:bg-slate-950/90 border border-blue-900/30 hover:border-blue-500 rounded-xl cursor-pointer transition-all space-y-2 text-center group">
          <Upload size={20} className="text-amber-400 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-black">📁 استيراد مجلد كامل</span>
          <span className="text-[9px] text-slate-400">اختيار مجلد يحتوي على الملفات</span>
          <input
            type="file"
            {...{ webkitdirectory: "", directory: "", multiple: true }}
            onChange={handleFilesChange}
            className="hidden"
          />
        </label>
      </div>

      {/* Staged Files Table Preview */}
      {stagedFiles.length > 0 && (
        <div className="space-y-4 border border-blue-900/30 bg-slate-950/40 p-4 rounded-xl">
          <div className="flex justify-between items-center border-b border-blue-900/20 pb-2">
            <h3 className="text-xs font-black text-[#90CDF4]">📋 معاينة الملفات المرفوعة الجاهزة للاستيراد</h3>
            <button
              type="button"
              onClick={() => setStagedFiles([])}
              className="text-[10px] text-rose-400 hover:text-rose-300 font-bold"
            >
              إلغاء وتفريغ القائمة 🗑️
            </button>
          </div>

          <div className="overflow-x-auto max-h-64 border border-blue-900/20 rounded-lg">
            <table className="w-full text-[10px] text-right border-collapse bg-slate-950/60">
              <thead>
                <tr className="bg-slate-900 text-slate-300 border-b border-blue-900/20 font-black">
                  <th className="p-2">اسم الملف</th>
                  <th className="p-2">المدرسة</th>
                  <th className="p-2 text-center">تاريخ التصدير</th>
                  <th className="p-2 text-center">عدد السجلات</th>
                  <th className="p-2 text-left">حالة الفحص والمطابقة</th>
                </tr>
              </thead>
              <tbody>
                {stagedFiles.map((st, idx) => (
                  <tr key={idx} className="border-b border-blue-900/10 hover:bg-blue-950/30">
                    <td className="p-2 font-mono text-slate-300 break-all">{st.file.name}</td>
                    <td className="p-2 font-black text-indigo-300">{st.metadata?.schoolName || '---'}</td>
                    <td className="p-2 text-center font-mono text-slate-400">
                      {st.metadata?.exportDateTime ? new Date(st.metadata.exportDateTime).toLocaleString('ar-EG') : '---'}
                    </td>
                    <td className="p-2 text-center font-mono font-black text-emerald-400">{st.recordsCount ?? '---'}</td>
                    <td className="p-2 text-left font-black">
                      {st.success ? (
                        <span className="text-emerald-400">جاهز للاستيراد ✅</span>
                      ) : (
                        <span className="text-rose-400" title={st.error}>فشل الفحص ❌ ({st.error})</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-2">
            <button
              type="button"
              onClick={handleImportAllStaged}
              disabled={importing}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-black shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span>تحديث قاعدة البيانات وتأكيد الاستيراد الفوري لحزمة المدارس ⚡</span>
            </button>
          </div>
        </div>
      )}

      {/* Operations Log */}
      <div className="space-y-4 border border-blue-900/20 p-4 rounded-xl bg-slate-950/30">
        <div className="flex justify-between items-center border-b border-blue-900/20 pb-2">
          <h3 className="text-xs font-black text-[#90CDF4] flex items-center gap-1.5">
            <SlidersHorizontal size={14} className="text-blue-400" />
            سجل عمليات الاستيراد والتحديث الأخير بالإدارة
          </h3>
          {logs.length > 0 && (
            <button
              type="button"
              onClick={handleClearLogs}
              className="text-[9px] text-slate-400 hover:text-rose-400 font-bold transition-all"
            >
              مسح السجل 🗑️
            </button>
          )}
        </div>

        {logs.length > 0 ? (
          <div className="overflow-x-auto max-h-64 border border-blue-900/15 rounded-lg">
            <table className="w-full text-[10px] text-right border-collapse">
              <thead>
                <tr className="bg-slate-900 text-slate-400 border-b border-blue-900/20">
                  <th className="p-2">المدرسة</th>
                  <th className="p-2">اسم ملف التصدير</th>
                  <th className="p-2 text-center">تاريخ التصدير</th>
                  <th className="p-2 text-center">تاريخ الاستيراد</th>
                  <th className="p-2 text-center">عدد السجلات</th>
                  <th className="p-2 text-left">حالة العملية</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((lg) => (
                  <tr key={lg.id || lg.exportedAt} className="border-b border-blue-900/10 hover:bg-slate-950/50">
                    <td className="p-2 font-bold text-slate-200">{lg.schoolName}</td>
                    <td className="p-2 font-mono text-slate-400">{lg.fileName}</td>
                    <td className="p-2 text-center font-mono text-slate-400">{new Date(lg.exportedAt).toLocaleString('ar-EG')}</td>
                    <td className="p-2 text-center font-mono text-emerald-400">{new Date(lg.importedAt).toLocaleString('ar-EG')}</td>
                    <td className="p-2 text-center font-mono font-black text-indigo-300">{lg.recordsCount} سجل</td>
                    <td className="p-2 text-left font-black text-emerald-400">ناجحة 🟢</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-[10px] text-slate-500 italic text-center py-6">لم يتم تنفيذ أي عمليات استيراد بيانات مدارس مؤخراً.</p>
        )}
      </div>

      {/* Detailed Import Results Feedback Modal */}
      {importResults && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" dir="rtl">
          <div className="bg-slate-900 border-2 border-blue-900/60 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl relative text-right text-white max-h-[90vh] overflow-y-auto">
            <div className="border-b border-blue-900/40 pb-3 flex justify-between items-center">
              <h3 className="text-sm font-black text-blue-300 flex items-center gap-2">
                📢 تقرير نتائج استيراد وتحديث حزمة المدارس الحكومية
              </h3>
              <button 
                type="button"
                onClick={() => setImportResults(null)}
                className="text-slate-400 hover:text-white transition-colors text-xs font-black cursor-pointer bg-slate-800 hover:bg-slate-750 px-2.5 py-1 rounded-md"
              >
                إغلاق التقرير ✕
              </button>
            </div>

            <p className="text-[11px] text-slate-300">
              تمت معالجة جميع الملفات المرفوعة ومقارنتها بقاعدة البيانات المركزية للإدارة. إليك التغذية الراجعة التفصيلية لنتائج العمليات:
            </p>

            <div className="space-y-3">
              {importResults.map((res, index) => (
                <div 
                  key={index} 
                  className={`p-3.5 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                    res.status === 'success' 
                      ? 'bg-emerald-950/40 border-emerald-900/30' 
                      : res.status === 'duplicate' 
                      ? 'bg-amber-950/30 border-amber-900/30' 
                      : 'bg-rose-950/35 border-rose-900/25'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-extrabold text-xs text-slate-200">مدرسة: {res.schoolName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">({res.fileName})</span>
                    </div>
                    <p className={`text-[11px] ${
                      res.status === 'success' 
                        ? 'text-emerald-450' 
                        : res.status === 'duplicate' 
                        ? 'text-amber-450 font-bold' 
                        : 'text-rose-450'
                    }`}>
                      {res.message}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                    {res.status === 'success' && (
                      <div className="text-right">
                        <span className="inline-block px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-black rounded-lg">
                          تم الاستيراد بنجاح 🟢
                        </span>
                        <span className="block text-[9px] text-slate-400 mt-0.5 text-left font-mono">{res.recordsCount} سجل</span>
                      </div>
                    )}
                    {res.status === 'duplicate' && (
                      <span className="inline-block px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black rounded-lg">
                        ملف مكرر / متطابق 🟡
                      </span>
                    )}
                    {res.status === 'failed' && (
                      <span className="inline-block px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-black rounded-lg">
                        فشل الاستيراد 🔴
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setImportResults(null)}
                className="px-6 py-2 bg-gradient-to-l from-indigo-700 to-blue-600 hover:from-indigo-600 hover:to-blue-500 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition-all"
              >
                تأكيد ومتابعة العمل بالإدارة 👍
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Convert Base64 to UTF-8
function base64ToUtf8(str: string): string {
  return decodeURIComponent(Array.prototype.map.call(atob(str), (c) => {
    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
  }).join(''));
}

// ----------------------------------------------------
// TAB 2: AI COMPREHENSIVE ANALYSIS
// ----------------------------------------------------
interface AIComprehensiveAnalysisTabProps {
  schools: School[];
  materials: Material[];
  materialCounts: MaterialCount[];
  aggregatedAnalytics: any;
}

function AIComprehensiveAnalysisTab({
  schools,
  materials,
  materialCounts,
  aggregatedAnalytics
}: AIComprehensiveAnalysisTabProps) {
  const [reportText, setReportText] = useState<string>(() => {
    return localStorage.getItem('coordination_ai_comprehensive_report') || '';
  });
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<number>(0);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let timer: any;
    if (loading) {
      setLoadingStep(1);
      timer = setInterval(() => {
        setLoadingStep(prev => {
          if (prev < 3) return prev + 1;
          return prev;
        });
      }, 3500);
    } else {
      setLoadingStep(0);
    }
    return () => clearInterval(timer);
  }, [loading]);

  const generateReport = async () => {
    setLoading(true);
    setError('');
    try {
      // Create simplified schools data list
      const schoolsData = schools.map(s => {
        const schoolDeficits: string[] = [];
        const schoolSurpluses: string[] = [];
        
        materials.forEach(m => {
          const count = materialCounts.find(c => c.schoolId === s.id && c.materialId === m.id);
          const metr = dbInstance.calculateMaterialMetrics(s, m, count);
          if (metr.applicable) {
            if (metr.deficit > 0) {
              schoolDeficits.push(`${m.name}: عجز ${metr.deficit}`);
            }
            if (metr.surplus > 0) {
              schoolSurpluses.push(`${m.name}: زيادة ${metr.surplus}`);
            }
          }
        });

        return {
          name: s.name,
          stage: s.stage === 'primary' ? 'ابتدائي' : s.stage === 'prep' ? 'إعدادي' : 'ثانوي',
          students: s.totalStudentsCount || 0,
          classrooms: s.classroomsCount || 0,
          deficits: schoolDeficits,
          surpluses: schoolSurpluses
        };
      });

      // Create simplified materials data list
      const materialsData = materials.map(m => {
        let totalDeficit = 0;
        let totalSurplus = 0;
        let totalNeeded = 0;
        let totalPresent = 0;

        schools.forEach(s => {
          const count = materialCounts.find(c => c.schoolId === s.id && c.materialId === m.id);
          const metr = dbInstance.calculateMaterialMetrics(s, m, count);
          if (metr.applicable) {
            totalDeficit += metr.deficit;
            totalSurplus += metr.surplus;
            totalNeeded += metr.needed;
            totalPresent += metr.present;
          }
        });

        return {
          name: m.name,
          stage: m.stage === 'primary' ? 'ابتدائي' : m.stage === 'prep' ? 'إعدادي' : 'ثانوي',
          totalNeeded: Number(totalNeeded.toFixed(1)),
          totalPresent: Number(totalPresent.toFixed(1)),
          deficit: Number(totalDeficit.toFixed(1)),
          surplus: Number(totalSurplus.toFixed(1)),
          coverage: totalNeeded > 0 ? Number(((totalPresent / totalNeeded) * 100).toFixed(1)) : 100
        };
      });

      const response = await fetch('/api/ai-report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          analytics: aggregatedAnalytics,
          schoolsData,
          materialsData
        })
      });

      const data = await response.json();
      if (data.success && data.report) {
        setReportText(data.report);
        localStorage.setItem('coordination_ai_comprehensive_report', data.report);
      } else {
        throw new Error(data.error || 'فشل توليد التقرير من الذكاء الاصطناعي.');
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'حدث خطأ غير متوقع أثناء الاتصال بـ الذكاء الاصطناعي.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(reportText);
    alert('تم نسخ مستند التقرير بالكامل بنجاح للمشاركة الورقية أو الرفع المستندي.');
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    if (confirm('هل ترغب في حذف نسخة التقرير الحالية وإعادة تشغيل محرك الرصد والتحليل ببيانات جديدة؟')) {
      setReportText('');
      localStorage.removeItem('coordination_ai_comprehensive_report');
    }
  };

  // Inline markdown rendering helper
  const renderMarkdown = (content: string) => {
    const parseInlineFormatting = (text: string) => {
      const boldParts = text.split(/(\*\*.*?\*\*)/);
      return boldParts.map((part, index) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <span key={index} className="font-extrabold text-[#0D47A1] bg-blue-50/50 px-1 rounded">{part.slice(2, -2)}</span>;
        }
        return part;
      });
    };

    const lines = content.split('\n');
    return lines.map((line, idx) => {
      const trimmed = line.trim();
      if (!trimmed) return <div key={idx} className="h-2" />;

      if (trimmed.startsWith('###')) {
        return (
          <h4 key={idx} className="text-sm font-black text-blue-900 border-r-4 border-amber-500 pr-2.5 mt-4 mb-2">
            {trimmed.replace(/^###\s*/, '')}
          </h4>
        );
      }
      if (trimmed.startsWith('##')) {
        return (
          <h3 key={idx} className="text-base font-black text-[#0D47A1] border-r-4 border-[#1976D2] pr-3 mt-6 mb-3 bg-[#0D47A1]/5 py-1.5 rounded-lg">
            {trimmed.replace(/^##\s*/, '')}
          </h3>
        );
      }
      if (trimmed.startsWith('#')) {
        return (
          <h2 key={idx} className="text-lg font-black text-slate-900 border-r-4 border-indigo-600 pr-3 mt-8 mb-4">
            {trimmed.replace(/^#\s*/, '')}
          </h2>
        );
      }

      if (trimmed.startsWith('*') || trimmed.startsWith('-')) {
        const cleanText = trimmed.replace(/^[\*\-]\s*/, '');
        return (
          <li key={idx} className="text-xs text-slate-700 leading-relaxed font-semibold mr-6 list-disc mb-1.5 list-inside">
            {parseInlineFormatting(cleanText)}
          </li>
        );
      }

      return (
        <p key={idx} className="text-xs text-slate-700 leading-relaxed font-semibold mb-3 text-justify">
          {parseInlineFormatting(trimmed)}
        </p>
      );
    });
  };

  return (
    <div className="space-y-6">
      
      {/* 2. Introductory Hero Card - HIDDEN on print */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-2xl p-6 shadow-md border-b-4 border-[#D4AF37] space-y-4 print:hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <span className="bg-white/10 text-yellow-300 font-extrabold text-[10px] px-2.5 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 w-max">
              <Sparkles size={11} /> ذكاء اصطناعي سيادي معتمد
            </span>
            <h2 className="text-lg font-black font-sans flex items-center gap-2">
              <Brain size={22} className="text-blue-300 animate-pulse" />
              التقرير الشامل بالذكاء الاصطناعي (مستشار التخطيط الذكي)
            </h2>
            <p className="text-xs text-blue-100 font-bold max-w-4xl">
              محرك ذكي يقرأ التوزع الفعلي لأنصبة الفصول ومستويات الكوادر الحالية بالإدارة، ويقوم تلقائياً بتوليد تحليل علمي وعملي ملخص ومفيد جداً يدعم القرارات التنظيمية ويبرز العجز والزيادة مع توصيات استراتيجية عميقة ومباشرة.
            </p>
          </div>
          
          {!reportText && !loading && (
            <button
              onClick={generateReport}
              className="px-6 py-3 bg-[#D4AF37] hover:bg-[#C29B2B] text-slate-950 font-black text-xs rounded-xl transition duration-150 shadow-lg cursor-pointer flex items-center gap-2 animate-bounce hover:scale-105 shrink-0"
            >
              <Sparkles size={14} className="animate-spin-slow text-slate-950" />
              توليد التقرير الاستراتيجي الآن
            </button>
          )}
        </div>
      </div>

      {loading && (
        <div className="bg-white rounded-2xl border border-slate-100 p-12 text-center space-y-6 shadow-sm print:hidden">
          <div className="relative w-20 h-20 mx-auto">
            {/* Pulsing circles */}
            <div className="absolute inset-0 bg-blue-100 rounded-full animate-ping opacity-60"></div>
            <div className="absolute inset-2 bg-blue-600 rounded-full flex items-center justify-center shadow-lg">
              <Brain size={32} className="text-white animate-pulse" />
            </div>
          </div>
          
          <div className="space-y-2">
            <p className="text-sm font-black text-slate-800">
              {loadingStep === 1 && "⏳ قراءة وتحصيل البيانات الإحصائية لمدارس أبو حماد..."}
              {loadingStep === 2 && "⚡ تصنيف مستويات العجز والزيادة بالتخصصات والأنصبة الحالية..."}
              {loadingStep === 3 && "🌟 استشارة الذكاء الاصطناعي وبناء صياغة علمية ملخصة ومفيدة للتقرير..."}
              {loadingStep === 0 && "⌛ جاري تهيئة رصد البيانات لبناء الرؤية الفنية..."}
            </p>
            <p className="text-xs text-slate-400 font-bold">يرجى عدم إغلاق الصفحة، يستغرق هذا الإجراء بضع ثوانٍ</p>
          </div>

          <div className="w-64 mx-auto bg-slate-100 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-blue-600 h-full transition-all duration-1000" 
              style={{ width: loadingStep === 1 ? '33%' : loadingStep === 2 ? '66%' : loadingStep === 3 ? '95%' : '10%' }}
            />
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border-2 border-red-200 rounded-xl p-5 text-center space-y-3 print:hidden shadow-xs">
          <AlertTriangle className="mx-auto text-red-500" size={32} />
          <p className="text-xs font-black text-red-900">{error}</p>
          <button
            onClick={generateReport}
            className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg transition"
          >
            إعادة المحاولة
          </button>
        </div>
      )}

      {/* 2. Compiled AI Content Wrapper */}
      {reportText && !loading && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Action Operations Toolbar - HIDDEN on print */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-4 flex flex-wrap justify-between items-center gap-3 print:hidden">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-black text-slate-700 text-right">التقرير جاهز ومحفوظ محلياً ومستمد من بيانات الإدارة المحدثة</span>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleCopy}
                className="px-4 py-2 hover:bg-indigo-50 border border-indigo-200 text-indigo-700 font-extrabold text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5 bg-indigo-50/20 active:scale-95 shadow-2xs"
              >
                <Copy size={13} /> نسخ كـ مستند كامل
              </button>
              
              <button
                type="button"
                onClick={handlePrint}
                className="px-4 py-2 hover:bg-blue-50 border border-blue-200 text-blue-800 font-extrabold text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5 bg-blue-50/20 active:scale-95 shadow-2xs"
              >
                <Printer size={13} /> طباعة التقرير الفورية
              </button>
              
              <button
                type="button"
                onClick={generateReport}
                className="px-4 py-2 hover:bg-emerald-50 border border-emerald-200 text-emerald-800 font-extrabold text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5 bg-emerald-50/25 active:scale-95 shadow-2xs"
              >
                <RefreshCw size={13} /> إعادة توليد وتحديث الرصد
              </button>

              <button
                type="button"
                onClick={handleReset}
                className="px-3 py-2 hover:bg-rose-50 border border-rose-200 text-rose-600 font-extrabold text-xs rounded-xl transition cursor-pointer flex items-center gap-1"
                title="إعادة تعيين وبدء من جديد"
              >
                <Trash2 size={13} /> حذف التقرير
              </button>
            </div>
          </div>

          {/* Real Official Document Container */}
          <div className="bg-white rounded-2xl border-2 border-slate-300 p-8 shadow-md relative antialiased printable-report-card">
            
            {/* Header of official government department */}
            <div className="border-b-4 border-slate-900 pb-5 mb-6">
              <div className="grid grid-cols-3 gap-2 items-center text-center">
                {/* Right side educational department */}
                <div className="text-right space-y-1 select-none">
                  <span className="block text-xs font-black text-slate-900 leading-tight">جمهورية مصر العربية</span>
                  <span className="block text-xs font-black text-slate-850 leading-tight">وزارة التربية والتعليم والتعليم الفني</span>
                  <span className="block text-xs font-black text-slate-805 leading-tight">مديرية التربية والتعليم بالشرقية</span>
                  <span className="block text-xs font-black text-blue-900 leading-tight">إدارة أبو حماد التعليمية (قسم التنسيق)</span>
                </div>
                
                {/* Logo Middle */}
                <div className="flex justify-center items-center">
                  <EducationalLogo size="xs" glowing={false} />
                </div>
                
                {/* Left side Metadata */}
                <div className="text-left space-y-1 text-slate-700 select-none">
                  <span className="block text-[10px] font-bold">بوابة التنسيق الرقمي الذكي</span>
                  <span className="block text-[10px] font-bold">تاريخ الرصد: {new Date().toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                  <span className="block text-[10px] font-bold">جهة العرض: السيد الأستاذ مدير عام الإدارة</span>
                  <span className="block text-[10px] font-black p-0.5 px-2 bg-slate-100 rounded border border-slate-200 text-slate-800 w-max ml-0">تقرير استشاري سري للغاية</span>
                </div>
              </div>

              {/* Central report title */}
              <div className="text-center mt-6">
                <h1 className="text-base md:text-lg font-black text-slate-900 inline-block border-b-2 border-slate-950 pb-1 uppercase tracking-wide">
                  التقرير العلمي والعملي التلخيصي الشامل لدراسة عجز وزيادة كوادر المدارس
                </h1>
                <p className="text-[10px] text-slate-500 font-bold mt-1.5">تم إعداده وإخراجه بواسطة وحدة الذكاء الاصطناعي لوكالة التنسيق العام برعاية الأستاذ محمد نجم</p>
              </div>
            </div>

            {/* AI Generated Content Container */}
            <div className="space-y-4 text-justify font-sans text-slate-800 pr-2 pl-2 md:pr-4 md:pl-4">
              {renderMarkdown(reportText)}
            </div>

            {/* Official Signatures bottom on document */}
            <div className="border-t border-slate-300 mt-12 pt-6 grid grid-cols-2 gap-4 text-slate-900 select-none">
              <div className="text-right pr-6 space-y-1">
                <span className="block text-xs font-extrabold">معد ومشرف التقرير:</span>
                <span className="block text-xs font-black text-slate-900 pt-6">الأستاذ محمد نجم</span>
                <span className="block text-[10px] font-extrabold text-slate-500">مدير عام التنسيق في إدارة أبوحماد الرقمية</span>
                <span className="block text-[10px] text-slate-400 font-bold">التوقيع: ............................</span>
              </div>
              <div className="text-left pl-6 space-y-1">
                <span className="block text-xs font-extrabold">يُعتمد ويُنفذ من:</span>
                <span className="block text-xs font-black text-slate-950 pt-6">السيد مدير عام إدارة أبو حماد التعليمية</span>
                <span className="block text-[10px] font-extrabold text-slate-500">وكيل أول وزارة التربية والتعليم</span>
                <span className="block text-[10px] text-slate-400 font-bold">التوقيع والختم: ............................</span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* 3. Empty State fallback - Hidden on print */}
      {!reportText && !loading && (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-4 print:hidden">
          <Brain className="mx-auto text-indigo-400 animate-pulse" size={48} />
          <div className="space-y-1">
            <h3 className="text-sm font-black text-slate-800">لا يوجد تقرير توليدي ذكي في هذه الأثناء</h3>
            <p className="text-xs text-slate-500 font-bold">بإمكانك استقراء حالة التوزع الفني ومعدل توازن العجز والزيادة والتوظيف بالإدارة من خلال كفاءة نظام الذكاء الاصطناعي</p>
          </div>
          <button
            onClick={generateReport}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-xl shadow-md transition active:scale-95 cursor-pointer flex items-center gap-2 mx-auto"
          >
            <Sparkles size={14} /> بناء وتحصيل التقرير الاستراتيجي الذكي
          </button>
        </div>
      )}

    </div>
  );
}
