/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Tooltip, 
  Legend, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  LineChart, 
  Line,
  AreaChart,
  Area
} from 'recharts';

/**
 * ---------------------------------------------------------------------------
 * CUSTOM TOOLTIP BUILDER (Standard elegant layout for premium theme)
 * ---------------------------------------------------------------------------
 */
const CustomChartTooltip = ({ active, payload, label, suffix = '' }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#111827] border border-amber-500/30 text-white rounded-xl p-3 shadow-xl text-xs text-right font-medium font-sans">
        {label && <p className="font-extrabold border-b border-white/10 pb-1.5 mb-1.5 text-amber-100">{label}</p>}
        <div className="space-y-1.5">
          {payload.map((item: any, idx: number) => (
            <div key={idx} className="flex items-center gap-3 justify-between">
              <span className="font-bold font-mono text-amber-400">
                {item.value} {suffix}
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-slate-300 font-bold">{item.name}:</span>
                <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: item.color }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  return null;
};

/**
 * ---------------------------------------------------------------------------
 * 1. PIE CHART COMPONENT (High-Fidelity Recharts implementation)
 * ---------------------------------------------------------------------------
 */
export function CustomPieChart({ 
  data, 
  valueKey = 'value', 
  nameKey = 'name',
  colors = ['#1565C0', '#2E7D32', '#EF5350', '#FFA726', '#7E57C2', '#26A69A'] 
}: { 
  data: any[]; 
  valueKey?: string; 
  nameKey?: string; 
  colors?: string[];
}) {
  const total = data.reduce((sum, item) => sum + (item[valueKey] || 0), 0);
  
  if (total === 0) {
    return (
      <div className="flex items-center justify-center h-48 bg-slate-50/50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-xs">
        لا توجد بيانات كافية للرسم البياني الدائري
      </div>
    );
  }

  // Map the input data to reachart compatible format if keys differ
  const formattedData = data.map(item => ({
    name: item[nameKey],
    value: item[valueKey],
  }));

  return (
    <div className="w-full h-64 flex flex-col justify-center">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={formattedData}
            cx="50%"
            cy="50%"
            innerRadius={0}
            outerRadius={75}
            paddingAngle={2}
            dataKey="value"
            nameKey="name"
            isAnimationActive={true}
            animationDuration={800}
          >
            {formattedData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={colors[index % colors.length]} className="focus:outline-none" />
            ))}
          </Pie>
          <Tooltip content={<CustomChartTooltip />} />
          <Legend 
            verticalAlign="bottom" 
            height={36} 
            iconType="circle"
            formatter={(value, entry: any) => (
              <span className="text-slate-700 font-bold text-xs">{value} : <span className="font-mono text-slate-900">{entry.payload.value}</span></span>
            )}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

/**
 * ---------------------------------------------------------------------------
 * 2. DOUGHNUT CHART COMPONENT
 * ---------------------------------------------------------------------------
 */
export function CustomDoughnutChart({ 
  data, 
  valueKey = 'value', 
  nameKey = 'name',
  colors = ['#1565C0', '#2E7D32', '#EF5350', '#FFA726', '#7E57C2'] 
}: { 
  data: any[]; 
  valueKey?: string; 
  nameKey?: string; 
  colors?: string[];
}) {
  const total = data.reduce((sum, item) => sum + (item[valueKey] || 0), 0);
  
  if (total === 0) {
    return (
      <div className="flex items-center justify-center h-48 bg-slate-50/50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-xs">
        لا توجد بيانات غياب كافية للرسم التوضيحي حالياً
      </div>
    );
  }

  const formattedData = data.map(item => ({
    name: item[nameKey],
    value: item[valueKey],
  }));

  return (
    <div className="w-full h-64 flex flex-col justify-center relative">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={formattedData}
            cx="50%"
            cy="47%"
            innerRadius={50}
            outerRadius={75}
            paddingAngle={3}
            dataKey="value"
            nameKey="name"
            isAnimationActive={true}
            animationDuration={850}
          >
            {formattedData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={colors[index % colors.length]} className="focus:outline-none" />
            ))}
          </Pie>
          <Tooltip content={<CustomChartTooltip />} />
          <Legend 
            verticalAlign="bottom" 
            height={36} 
            iconType="circle"
            formatter={(value, entry: any) => (
              <span className="text-slate-700 font-bold text-xs">{value}</span>
            )}
          />
        </PieChart>
      </ResponsiveContainer>

      {/* Decorative center overlay for total indicator */}
      <div className="absolute top-[47%] left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none text-center flex flex-col justify-center items-center">
        <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">الإجمالي</span>
        <span className="text-md font-black font-mono text-slate-800">{total}</span>
      </div>
    </div>
  );
}

/**
 * ---------------------------------------------------------------------------
 * 3. BAR CHART COMPONENT
 * ---------------------------------------------------------------------------
 */
export function CustomBarChart({ 
  data, 
  xKey, 
  yKey, 
  color = '#1565C0',
  height = 240
}: { 
  data: any[]; 
  xKey: string; 
  yKey: string; 
  color?: string;
  height?: number;
}) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center bg-slate-50/50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-xs" style={{ height: `${height}px` }}>
        لا توجد بيانات متاحة لعرض أعمدة الإحصاء
      </div>
    );
  }

  return (
    <div className="w-full font-sans" style={{ height: `${height}px` }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{ top: 20, right: 10, left: 10, bottom: 5 }}
        >
          <defs>
            <linearGradient id="bar-gradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.9} />
              <stop offset="100%" stopColor={color} stopOpacity={0.55} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
          <XAxis 
            dataKey={xKey} 
            tickLine={false} 
            axisLine={{ stroke: '#CBD5E1' }} 
            tick={{ fill: '#475569', fontSize: 11, fontWeight: 705 }} 
          />
          <YAxis 
            tickLine={false} 
            axisLine={false} 
            tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 'medium' }} 
            orientation="right"
          />
          <Tooltip content={<CustomChartTooltip />} />
          <Bar 
            dataKey={yKey} 
            fill="url(#bar-gradient)" 
            radius={[4, 4, 0, 0]} 
            isAnimationActive={true}
            animationDuration={850}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/**
 * ---------------------------------------------------------------------------
 * 4. LINE CHART COMPONENT
 * ---------------------------------------------------------------------------
 */
export function CustomLineChart({ 
  data, 
  xKey, 
  yKey, 
  color = '#2E7D32',
  height = 240
}: { 
  data: any[]; 
  xKey: string; 
  yKey: string; 
  color?: string;
  height?: number;
}) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center bg-slate-50/50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-xs" style={{ height: `${height}px` }}>
        لا توجد بيانات زمنية متاحة لخطوط التتبع
      </div>
    );
  }

  return (
    <div className="w-full font-sans" style={{ height: `${height}px` }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{ top: 20, right: 15, left: 15, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
          <XAxis 
            dataKey={xKey} 
            tickLine={false} 
            axisLine={{ stroke: '#CBD5E1' }} 
            tick={{ fill: '#475569', fontSize: 11, fontWeight: 705 }} 
          />
          <YAxis 
            tickLine={false} 
            axisLine={false} 
            tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 'medium' }} 
            orientation="right"
          />
          <Tooltip content={<CustomChartTooltip suffix="%" />} />
          <Line 
            type="monotone" 
            dataKey={yKey} 
            stroke={color} 
            strokeWidth={3} 
            activeDot={{ r: 6, strokeWidth: 0 }} 
            dot={{ r: 4, strokeWidth: 1.5, stroke: '#FFFFFF', fill: color }}
            isAnimationActive={true}
            animationDuration={900}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

/**
 * ---------------------------------------------------------------------------
 * 5. ADVANCED DOUBLE BAR CHART FOR DEFICITS & SURPLUS (NEW/EXCLUSIVE)
 * ---------------------------------------------------------------------------
 */
interface CompareBarChartProps {
  data: any[];
  xKey: string;
  bar1Key: string;
  bar1Name: string;
  bar2Key: string;
  bar2Name: string;
  bar1Color?: string;
  bar2Color?: string;
  height?: number;
}

export function DoubleGroupedBarChart({
  data,
  xKey,
  bar1Key,
  bar1Name,
  bar2Key,
  bar2Name,
  bar1Color = '#EF5350', // Red for deficit
  bar2Color = '#10B981', // Green for surplus
  height = 280
}: CompareBarChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center bg-slate-50/50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-xs" style={{ height: `${height}px` }}>
         لا توجد بيانات متاحة للمقارنة التناظرية
      </div>
    );
  }

  return (
    <div className="w-full font-sans" style={{ height: `${height}px` }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{ top: 20, right: 10, left: 10, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
          <XAxis 
            dataKey={xKey} 
            tickLine={false} 
            axisLine={{ stroke: '#CBD5E1' }} 
            tick={{ fill: '#334155', fontSize: 11, fontWeight: 705 }} 
          />
          <YAxis 
            tickLine={false} 
            axisLine={false} 
            tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 'medium' }} 
            orientation="right"
          />
          <Tooltip content={<CustomChartTooltip />} />
          <Legend 
            verticalAlign="top" 
            height={36} 
            iconType="circle"
            align="right"
            wrapperStyle={{ paddingBottom: '10px' }}
          />
          <Bar 
            name={bar1Name} 
            dataKey={bar1Key} 
            fill={bar1Color} 
            radius={[3, 3, 0, 0]} 
            isAnimationActive={true}
            animationDuration={805}
          />
          <Bar 
            name={bar2Name} 
            dataKey={bar2Key} 
            fill={bar2Color} 
            radius={[3, 3, 0, 0]} 
            isAnimationActive={true}
            animationDuration={805}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/**
 * ---------------------------------------------------------------------------
 * 6. ADVANCED AREA CHART (For smoother visualizer coverage trends)
 * ---------------------------------------------------------------------------
 */
export function CustomAreaChart({
  data,
  xKey,
  yKey,
  color = '#1E3A8A',
  height = 240
}: {
  data: any[];
  xKey: string;
  yKey: string;
  color?: string;
  height?: number;
}) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center bg-slate-50/50 rounded-xl border border-dashed border-slate-200 text-slate-400 text-xs" style={{ height: `${height}px` }}>
        لا توجد بيانات كافية لعرض الرسم البياني المساحي
      </div>
    );
  }

  return (
    <div className="w-full font-sans" style={{ height: `${height}px` }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{ top: 20, right: 15, left: 15, bottom: 5 }}
        >
          <defs>
            <linearGradient id="area-grad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.4} />
              <stop offset="95%" stopColor={color} stopOpacity={0.0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
          <XAxis 
            dataKey={xKey} 
            tickLine={false} 
            axisLine={{ stroke: '#CBD5E1' }} 
            tick={{ fill: '#475569', fontSize: 11, fontWeight: 705 }} 
          />
          <YAxis 
            tickLine={false} 
            axisLine={false} 
            tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 'medium' }} 
            orientation="right"
          />
          <Tooltip content={<CustomChartTooltip />} />
          <Area 
            type="monotone" 
            dataKey={yKey} 
            stroke={color} 
            strokeWidth={2.5} 
            fillOpacity={1} 
            fill="url(#area-grad)" 
            isAnimationActive={true}
            animationDuration={900}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
