/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { School, Material, MaterialCount, Directorship, StudentAbsence, StudentAbsenceRecord, TeacherAbsence, VisitorLog, NutritionRecord, STAGE_LABELS } from '../types';
import { dbInstance } from '../data/db';
import { withOklchBypass } from './CoordinationAdminPortal';
import StaffRegistryTable from './StaffRegistryTable';
import ExamNominationTab from './ExamNominationTab';
import PrintableReport, { PrintHeader, PrintFooter } from './ReportTemplate';
import { CustomPieChart, CustomBarChart, CustomLineChart } from './DashboardCharts';
import { EducationalLogo } from './EducationalLogo';
import { 
  School as SchoolIcon, 
  Users, 
  UserCheck, 
  Calendar, 
  Clock, 
  BookOpen, 
  ShieldCheck, 
  FileText, 
  Save, 
  Printer, 
  Upload, 
  Download,
  ChevronRight, 
  TrendingUp, 
  History, 
  Trash2,
  Lock,
  Apple,
  LogOut,
  ArrowUpDown,
  ChevronUp,
  ChevronDown,
  Plus,
  Edit,
  Sparkles,
  CloudLightning,
  AlertCircle,
  RefreshCw
} from 'lucide-react';

function SortIndicator({ field, currentField, direction }: { field: string; currentField: string | null; direction: 'asc' | 'desc' }) {
  if (currentField !== field) {
    return <ArrowUpDown size={11} className="text-white/40 group-hover:text-white/80 transition-colors shrink-0 mr-1.5" />;
  }
  return direction === 'asc' 
    ? <ChevronUp size={11} className="text-amber-300 shrink-0 mr-1.5 font-bold" />
    : <ChevronDown size={11} className="text-amber-300 shrink-0 mr-1.5 font-bold" />;
}

function handleDecimalKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
  // Allowed helper/navigation keys and single decimal point
  const allowed = [
    'Backspace', 'Tab', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown',
    'Home', 'End', 'Escape', 'Enter', '.'
  ];
  if (allowed.includes(e.key)) {
    if (e.key === '.' && e.currentTarget.value.includes('.')) {
      e.preventDefault();
    }
    return;
  }
  // Prevent space and any non-numeric keyboard input
  if (e.key === ' ' || isNaN(Number(e.key))) {
    e.preventDefault();
  }
}

interface SchoolPrincipalPortalProps {
  schoolId: string;
  onLogout: () => void;
}

export default function SchoolPrincipalPortal({ schoolId, onLogout }: SchoolPrincipalPortalProps) {
  const [school, setSchool] = useState<School | null>(null);
  const [activeTab, setActiveTab] = useState<number>(0);
  const [syncing, setSyncing] = useState(false);
  
  // Trigger update on database operations
  const [dbTick, setDbTick] = useState(0);
  const [exportingTabPdf, setExportingTabPdf] = useState(false);

  useEffect(() => {
    // Load school-specific data from Firestore on-demand
    dbInstance.loadSchoolDataFromServer(schoolId);
  }, [schoolId]);

  useEffect(() => {
    const handleUpdate = () => {
      const sch = dbInstance.getSchools().find(s => s.id === schoolId);
      if (sch) setSchool(sch);
      setDbTick(prev => prev + 1);
    };

    handleUpdate();
    return dbInstance.subscribe(handleUpdate);
  }, [schoolId]);

  if (!school) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-slate-500 font-medium">
        جاري تحميل بيانات المدرسة...
      </div>
    );
  }

  const tabs = [
    { title: 'بيانات المدرسة والأنصبة', icon: <SchoolIcon size={16} /> },
    { title: 'القيادة المدرسية', icon: <ShieldCheck size={16} /> },
    { title: 'بيانات العاملين', icon: <Users size={16} /> },
    { title: 'غياب الطلاب', icon: <Calendar size={16} /> },
    { title: 'غياب المعلمين', icon: <UserCheck size={16} /> },
    { title: 'سجل الزوار والموجهين', icon: <Clock size={16} /> },
    { title: 'إحصاء التغذية المدرسية', icon: <Apple size={16} /> },
    { title: 'التقارير والأرشفة المدرسية', icon: <History size={16} className="text-amber-500" /> },
    { title: '📝 استمارة (1 سري)', icon: <FileText size={16} className="text-rose-500" /> },
    { title: '📤 تصدير البيانات للإدارة', icon: <Upload size={16} className="text-emerald-600" /> }
  ];

  const handleActiveTabExportPdf = async () => {
    const element = document.getElementById('school-active-tab-print-area');
    if (!element) {
      alert('لم يتم العثور على منطقة التبويب للطباعة.');
      return;
    }
    setExportingTabPdf(true);

    // Backup original styles of element and all parent elements to allow full expansion
    const originalStyle = element.style.cssText;
    const originalParents: { el: HTMLElement; cssText: string }[] = [];

    try {
      element.style.cssText += '; width: 210mm !important; max-width: none !important; height: auto !important; max-height: none !important; overflow: visible !important;';
      
      let p = element.parentElement;
      while (p && p !== document.body) {
        originalParents.push({ el: p, cssText: p.style.cssText });
        p.style.cssText += '; overflow: visible !important; height: auto !important; max-height: none !important;';
        p = p.parentElement;
      }

      const canvas = await withOklchBypass(async () => {
        return await html2canvas(element, {
          scale: 2,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff'
        });
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`مدرسة_${school.name}_تبويب_${tabs[activeTab].title}.pdf`);
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء تصدير ملف PDF.');
    } finally {
      // Restore original styles
      originalParents.forEach(op => {
        op.el.style.cssText = op.cssText;
      });
      element.style.cssText = originalStyle;
      setExportingTabPdf(false);
    }
  };

  const handlePrint = () => {
    try {
      window.focus();
      window.print();
    } catch (e) {
      alert('الرجاء فتح التطبيق في نافذة مستقلة للتمكن من الطباعة المباشرة.');
    }
  };

  return (
    <div className="w-full bg-[#F5F7FA] min-h-screen text-[#212121] flex flex-col md:flex-row gap-6 p-4 md:p-6" dir="rtl">
      
      {/* Sidebar Tabs */}
      <div className="w-full md:w-80 shrink-0 bg-white shadow-xl border border-slate-200 p-5 flex flex-col justify-between rounded-2xl print:hidden text-[#212121]">
        <div>
          <div className="p-4 bg-[#0D47A1] border-b-4 border-[#D4AF37] rounded-xl text-center mb-6 flex flex-col items-center shadow-xs">
            <div className="mb-2.5">
              <EducationalLogo size="sm" glowing={true} />
            </div>
            <span className="inline-block px-3 py-0.5 bg-white/20 text-[#D4AF37] border border-white/20 font-black text-[10px] rounded-full mb-1.5 shadow-md">
              {STAGE_LABELS[school.stage]}
            </span>
            <h1 className="text-sm md:text-md font-extrabold text-white leading-snug">{school.name}</h1>
            <p className="text-slate-100 text-[11px] mt-1 font-bold">العام الدراسي: {school.year}</p>
          </div>

          <nav className="space-y-1.5">
            {tabs.map((tab, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setActiveTab(idx)}
                className={`w-full text-right flex items-center gap-2.5 px-3 py-2.5 text-xs font-black rounded-lg transition-all border outline-none cursor-pointer ${
                  activeTab === idx
                    ? 'bg-[#1976D2] text-white border-[#0D47A1] shadow-lg'
                    : 'bg-slate-50 text-slate-700 hover:bg-slate-100/80 hover:text-black border-slate-200 shadow-2xs'
                }`}
              >
                {tab.icon}
                <span className="truncate">{tab.title}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-8 pt-4 border-t border-slate-200 space-y-2">
          <div className="text-xs text-slate-500 font-bold">
            الوضع الحالي: <span className="text-amber-600 font-black">⚠️ حفظ محلي مباشر (بسبب انتهاء التخزين السحابي المجاني)</span>
          </div>
          
          <button
            type="button"
            onClick={handlePrint}
            className="w-full py-2.5 border border-[#1976D2]/20 bg-[#1976D2]/10 hover:bg-[#1976D2]/20 text-[#1976D2] font-black text-xs rounded-xl transition duration-200 text-center cursor-pointer active:scale-95 flex items-center justify-center gap-1.5"
          >
            <Printer size={13} className="text-[#1976D2]" />
            طباعة الصفحة الحالية (ورقياً) 🖨️
          </button>

          <button
            type="button"
            onClick={handleActiveTabExportPdf}
            disabled={exportingTabPdf}
            className="w-full py-2.5 border border-[#4CAF50]/20 bg-[#4CAF50]/10 hover:bg-[#4CAF50]/20 text-[#2E7D32] font-black text-xs rounded-xl transition duration-200 text-center cursor-pointer active:scale-95 flex items-center justify-center gap-1.5 disabled:opacity-50"
          >
            <Download size={13} className="text-[#2E7D32]" />
            {exportingTabPdf ? 'جاري تصدير PDF...' : 'تصدير الصفحة (PDF منفصل) 📄'}
          </button>

          <button
            type="button"
            onClick={onLogout}
            className="w-full py-2.5 border border-[#D32F2F]/20 bg-[#D32F2F]/10 hover:bg-[#D32F2F]/20 text-[#D32F2F] font-black text-xs rounded-xl transition duration-200 text-center cursor-pointer active:scale-95 flex items-center justify-center gap-1.5"
          >
            <LogOut size={13} />
            خروج وعودة للرئيسية
          </button>
        </div>
      </div>

      {/* Main Content Pane */}
      <div id="school-active-tab-print-area" className="flex-grow p-1.5 md:p-6 overflow-hidden bg-white relative">
        <PrintHeader 
          title={`التقرير التفصيلي لمدرسة: ${school.name}`} 
          subtitle={`قسم: ${tabs[activeTab]?.title || ''} - لعام ${school.year}`} 
          isVisible={exportingTabPdf} 
        />
        
        {/* Universal Top Save/Sync Bar */}
        <div className="flex justify-between items-center bg-gradient-to-l from-amber-50 to-orange-50 border border-amber-200 p-3 rounded-xl mb-4 gap-3 print:hidden shadow-3xs flex-wrap">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
            <span className="text-amber-800 font-extrabold flex items-center gap-1.5">
              <AlertCircle size={14} className="text-amber-600 shrink-0" />
              جاري المزامنة والحفظ محلياً (نظراً لانتهاء باقة التخزين السحابي المجاني ⚠️)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                alert('💾 تم حفظ كافة التعديلات والبيانات المدرسية الحالية محلياً بنجاح بنسبة 100%! يرجى تصدير حزمة (.abhm) الآن للإرسال للإدارة.');
              }}
              className="px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-700 hover:from-amber-700 hover:to-orange-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
            >
              <Save size={14} className="text-white" />
              <span>حفظ محلي 💾</span>
            </button>

            <button
              type="button"
              disabled={syncing}
              onClick={async () => {
                setSyncing(true);
                await dbInstance.loadSchoolDataFromServer(school.id, true);
                setSyncing(false);
                alert('🔄 تم تحديث السجلات وتأكيد مزامنة البيانات محلياً بنجاح!');
              }}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 font-extrabold text-xs rounded-xl transition-all active:scale-95 flex items-center gap-1 cursor-pointer disabled:opacity-50"
              title="تحديث وإعادة تحميل البيانات"
            >
              <RefreshCw size={12} className={syncing ? 'animate-spin' : ''} />
              <span>تحديث 🔄</span>
            </button>
          </div>
        </div>

        {/* Free Cloud Storage Expiration Notice Alert */}
        <div className="bg-amber-50 border-r-4 border-amber-500 p-4 rounded-xl mb-6 shadow-xs flex items-start gap-3 print:hidden animate-fadeIn">
          <AlertCircle size={20} className="text-amber-600 mt-0.5 shrink-0 animate-bounce" />
          <div className="space-y-1.5 text-right text-xs">
            <h4 className="font-extrabold text-amber-950 text-sm flex items-center gap-1.5">
              ⚠️ تنبيه هام ومستعجل لمدير المدرسة ومن يدخل البيانات
            </h4>
            <p className="text-amber-900 font-extrabold leading-relaxed text-[11px]">
              نظراً لانتهاء باقة التخزين السحابي المجاني المخصصة للمنصة، يتم حالياً حفظ وتحديث كافة البيانات الجديدة والتعديلات <span className="underline font-black text-rose-700">محلياً بالكامل على هذا المتصفح فقط</span>.
            </p>
            <p className="text-slate-800 font-bold leading-relaxed">
              💡 <span className="text-indigo-900 font-black">أي شخص يدخل بيانات جديدة أو يقوم بتعديلات</span> يلتزم بالتوجه فوراً بعد الانتهاء إلى تبويب <span className="bg-amber-150 px-1.5 py-0.5 rounded text-[#0D47A1] border border-amber-300 font-black">"📤 تصدير البيانات للإدارة"</span> وتنزيل ملف التصدير المعتمد بامتداد <span className="font-mono text-indigo-700 font-black">(.abhm)</span> لحفظ مجهوده وإرسال الملف الفوري للإدارة لتحديث قاعدة بيانات الإشراف بنجاح.
            </p>
          </div>
        </div>
        
        {activeTab === 0 && <SchoolDetailsTab school={school} dbTick={dbTick} />}
        {activeTab === 1 && <LeadershipTab schoolId={school.id} dbTick={dbTick} />}
        {activeTab === 2 && <StaffRegistryTable schoolId={school.id} role="all" title="سجل بيانات العاملين بالمدرسة (معلمين - أخصائيين - إداريين - مشرفين - عمال)" />}
        {activeTab === 3 && <StudentAbsenceTab schoolId={school.id} dbTick={dbTick} />}
        {activeTab === 4 && <TeacherAbsenceTab schoolId={school.id} dbTick={dbTick} />}
        {activeTab === 5 && <VisitorLogTab schoolId={school.id} schoolName={school.name} dbTick={dbTick} />}
        {activeTab === 6 && <NutritionTab schoolId={school.id} dbTick={dbTick} />}
        {activeTab === 7 && <PrincipalReportsTab school={school} dbTick={dbTick} />}
        {activeTab === 8 && <ExamNominationTab school={school} dbTick={dbTick} />}
        {activeTab === 9 && <ExportSchoolDataTab school={school} dbTick={dbTick} />}

        <PrintFooter isVisible={exportingTabPdf} />
      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 1: SCHOOL DETAILS & TEACHER MATERIAL ALLOCATIONS
// ----------------------------------------------------
function SchoolDetailsTab({ school, dbTick }: { school: School; dbTick: number }) {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [counts, setCounts] = useState<MaterialCount[]>([]);
  const [metaCounts, setMetaCounts] = useState<Record<string, Partial<MaterialCount>>>({});
  const [inputValues, setInputValues] = useState<Record<string, Record<string, string>>>({});
  const [address, setAddress] = useState(school.address);
  const [classrooms, setClassrooms] = useState<string>(String(school.classroomsCount || 0));
  const [boysCount, setBoysCount] = useState<string>(String(school.boysCount ?? 0));
  const [girlsCount, setGirlsCount] = useState<string>(String(school.girlsCount ?? 0));
  const [saving, setSaving] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);

  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const autoSaveTimeout = useRef<NodeJS.Timeout | null>(null);
  const isInitialMount = useRef(true);

  // Reset initial mount flag when school changes
  useEffect(() => {
    isInitialMount.current = true;
  }, [school]);

  // Debounced Auto-save to Firestore & Local Storage
  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    if (autoSaveTimeout.current) {
      clearTimeout(autoSaveTimeout.current);
    }

    setAutoSaveStatus('saving');

    autoSaveTimeout.current = setTimeout(() => {
      try {
        const targetClassrooms = Number(classrooms) || 0;

        // Save updated school metadata
        dbInstance.saveSchool({
          ...school,
          address,
          classroomsCount: targetClassrooms,
          boysCount: Number(boysCount),
          girlsCount: Number(girlsCount),
          totalStudentsCount: Number(boysCount) + Number(girlsCount)
        });

        // Save material counts
        const payload: MaterialCount[] = Object.keys(metaCounts).map(matId => {
          const specificClassrooms = typeof metaCounts[matId].classroomsCount === 'number'
            ? metaCounts[matId].classroomsCount
            : targetClassrooms;

          return {
            schoolId: school.id,
            materialId: matId,
            super_senior: Number(metaCounts[matId].super_senior || 0),
            expert: Number(metaCounts[matId].expert || 0),
            first_a: Number(metaCounts[matId].first_a || 0),
            first: Number(metaCounts[matId].first || 0),
            teacher: Number(metaCounts[matId].teacher || 0),
            assistant: Number(metaCounts[matId].assistant || 0),
            delegated: Number(metaCounts[matId].delegated || 0),
            by_class: Number(metaCounts[matId].by_class || 0),
            classroomsCount: specificClassrooms
          };
        });

        dbInstance.saveBulkMaterialCounts(school.id, payload);
        setAutoSaveStatus('saved');
      } catch (e) {
        console.error('Auto-save error:', e);
        setAutoSaveStatus('idle');
      }
    }, 1500); // Debounce time: 1.5s

    return () => {
      if (autoSaveTimeout.current) {
        clearTimeout(autoSaveTimeout.current);
      }
    };
  }, [metaCounts, address, classrooms, boysCount, girlsCount]);

  // Dynamic live school state that incorporates immediate un-saved form changes
  const liveSchool: School = useMemo(() => ({
    ...school,
    classroomsCount: parseInt(classrooms) || 0,
    boysCount: parseInt(boysCount) || 0,
    girlsCount: parseInt(girlsCount) || 0,
    totalStudentsCount: (parseInt(boysCount) || 0) + (parseInt(girlsCount) || 0),
    address
  }), [school, classrooms, boysCount, girlsCount, address]);

  const handlePdfExport = async () => {
    const element = document.getElementById('school-details-quota-section');
    if (!element) {
      alert('لم يتم العثور على منطقة جدول الأنصبة لتصديرها.');
      return;
    }
    setExportingPdf(true);

    // Backup original styles of element and all parent elements to allow full expansion
    const originalStyle = element.style.cssText;
    const originalParents: { el: HTMLElement; cssText: string }[] = [];

    try {
      element.style.cssText += '; width: 210mm !important; max-width: none !important; height: auto !important; max-height: none !important; overflow: visible !important;';
      
      let p = element.parentElement;
      while (p && p !== document.body) {
        originalParents.push({ el: p, cssText: p.style.cssText });
        p.style.cssText += '; overflow: visible !important; height: auto !important; max-height: none !important;';
        p = p.parentElement;
      }

      const canvas = await withOklchBypass(async () => {
        return await html2canvas(element, {
          scale: 2,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff'
        });
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`جدول_عجز_زيادة_أنصبة_${school.name}.pdf`);
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء تصدير ملف PDF.');
    } finally {
      // Restore original styles
      originalParents.forEach(op => {
        op.el.style.cssText = op.cssText;
      });
      element.style.cssText = originalStyle;
      setExportingPdf(false);
    }
  };

  // Sorting state
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedMaterials = useMemo(() => {
    if (!sortField) return materials;

    return [...materials].sort((a, b) => {
      let valA: any = 0;
      let valB: any = 0;

      if (sortField === 'name') {
        valA = a.name.toLowerCase();
        valB = b.name.toLowerCase();
      } else {
        const countsA = metaCounts[a.id] || {};
        const countsB = metaCounts[b.id] || {};

        if (sortField === 'total') {
          valA =
            (countsA.super_senior || 0) +
            (countsA.expert || 0) +
            (countsA.first_a || 0) +
            (countsA.first || 0) +
            (countsA.teacher || 0) +
            (countsA.assistant || 0) +
            (countsA.delegated || 0) +
            (countsA.by_class || 0);

          valB =
            (countsB.super_senior || 0) +
            (countsB.expert || 0) +
            (countsB.first_a || 0) +
            (countsB.first || 0) +
            (countsB.teacher || 0) +
            (countsB.assistant || 0) +
            (countsB.delegated || 0) +
            (countsB.by_class || 0);
        } else {
          valA = countsA[sortField as keyof MaterialCount] || 0;
          valB = countsB[sortField as keyof MaterialCount] || 0;
        }
      }

      if (typeof valA === 'string' && typeof valB === 'string') {
        return sortDirection === 'asc' ? valA.localeCompare(valB, 'ar') : valB.localeCompare(valA, 'ar');
      }

      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [materials, metaCounts, sortField, sortDirection]);

  useEffect(() => {
    const allMats = dbInstance.getMaterials();
    // Filter only applicable materials
    const filtered = allMats.filter(m => dbInstance.isMaterialApplicableToSchool(school.stage, m.stage));
    setMaterials(filtered);

    const schoolCounts = dbInstance.getMaterialCounts().filter(c => c.schoolId === school.id);
    setCounts(schoolCounts);

    const meta: Record<string, Partial<MaterialCount>> = {};
    const rawInputs: Record<string, Record<string, string>> = {};
    filtered.forEach(mat => {
      const match = schoolCounts.find(sc => sc.materialId === mat.id);
      const defaults = match || {
        super_senior: 0,
        expert: 0,
        first_a: 0,
        first: 0,
        teacher: 0,
        assistant: 0,
        delegated: 0,
        by_class: 0,
        classroomsCount: school.classroomsCount || 0
      };
      
      const mClassrooms = match && typeof match.classroomsCount === 'number' 
        ? match.classroomsCount 
        : (school.classroomsCount || 0);

      meta[mat.id] = {
        ...defaults,
        classroomsCount: mClassrooms
      };

      rawInputs[mat.id] = {
        super_senior: String(defaults.super_senior ?? 0),
        expert: String(defaults.expert ?? 0),
        first_a: String(defaults.first_a ?? 0),
        first: String(defaults.first ?? 0),
        teacher: String(defaults.teacher ?? 0),
        assistant: String(defaults.assistant ?? 0),
        delegated: String(defaults.delegated ?? 0),
        by_class: String(defaults.by_class ?? 0),
        classroomsCount: String(mClassrooms)
      };
    });
    setMetaCounts(meta);
    setInputValues(rawInputs);
    setAddress(school.address);
    setClassrooms(String(school.classroomsCount || 0));
    setBoysCount(String(school.boysCount ?? 0));
    setGirlsCount(String(school.girlsCount ?? 0));
  }, [school, dbTick]);

  const handleValueChange = (materialId: string, field: string, val: string) => {
    setInputValues(prev => ({
      ...prev,
      [materialId]: {
        ...(prev[materialId] || {}),
        [field]: val
      }
    }));

    const num = parseFloat(val) || 0;
    setMetaCounts(prev => ({
      ...prev,
      [materialId]: {
        ...(prev[materialId] || {}),
        [field]: num
      }
    }));
  };

  const handleGeneralSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    
    const targetClassrooms = Number(classrooms) || 0;

    // Save updated school metadata
    dbInstance.saveSchool({
      ...school,
      address,
      classroomsCount: targetClassrooms,
      boysCount: Number(boysCount),
      girlsCount: Number(girlsCount),
      totalStudentsCount: Number(boysCount) + Number(girlsCount)
    });

    // Save material counts
    const payload: MaterialCount[] = Object.keys(metaCounts).map(matId => {
      // Use the per-material classroomsCount if available (for secondary), otherwise fallback to the general classrooms count
      const specificClassrooms = typeof metaCounts[matId].classroomsCount === 'number'
        ? metaCounts[matId].classroomsCount
        : targetClassrooms;

      return {
        schoolId: school.id,
        materialId: matId,
        super_senior: Number(metaCounts[matId].super_senior || 0),
        expert: Number(metaCounts[matId].expert || 0),
        first_a: Number(metaCounts[matId].first_a || 0),
        first: Number(metaCounts[matId].first || 0),
        teacher: Number(metaCounts[matId].teacher || 0),
        assistant: Number(metaCounts[matId].assistant || 0),
        delegated: Number(metaCounts[matId].delegated || 0),
        by_class: Number(metaCounts[matId].by_class || 0),
        classroomsCount: specificClassrooms
      };
    });

    dbInstance.saveBulkMaterialCounts(school.id, payload);

    setTimeout(() => {
      setSaving(false);
      alert('تم حفظ البيانات والأنصبة وإرسالها للتنسيق العام بالإدارة التعليمية في الوقت الحقيقي!');
    }, 600);
  };

  return (
    <form onSubmit={handleGeneralSave} className="space-y-6">
      
      {/* School card */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
        <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
          <SchoolIcon size={20} className="text-blue-600" />
          تحديث بيانات المدرسة الإحصائية
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pb-4 border-b border-slate-150">
          <div>
            <label className="block text-xs font-black text-slate-700 mb-1">اسم المدرسة</label>
            <input 
              type="text" 
              value={school.name} 
              disabled 
              className="w-full px-3 py-1.5 text-sm bg-slate-100 text-slate-900 border border-slate-300 rounded cursor-not-allowed text-right font-black shadow-xs" 
            />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-700 mb-1">المرحلة التعليمية</label>
            <input 
              type="text" 
              value={STAGE_LABELS[school.stage]} 
              disabled 
              className="w-full px-3 py-1.5 text-sm bg-slate-100 text-slate-900 border border-slate-300 rounded cursor-not-allowed text-right font-black shadow-xs" 
            />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-800 mb-1">رقم الفصول بالمدرسة *</label>
            <input 
              type="number" 
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={classrooms} 
              onChange={e => setClassrooms(e.target.value)}
              className="w-full px-3 py-1.5 text-sm bg-white text-black border border-slate-400 rounded text-right font-mono font-black focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 shadow-xs" 
            />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-800 mb-1">عنوان المدرسة بالتفصيل</label>
            <input 
              type="text" 
              value={address} 
              onChange={e => setAddress(e.target.value)}
              className="w-full px-3 py-1.5 text-sm bg-white text-black border border-slate-400 rounded text-right font-black focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 shadow-xs" 
            />
          </div>
        </div>

        {/* Students counts (boys, girls, total auto-calculated) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
          <div>
            <label className="block text-xs font-black text-slate-800 mb-1">عدد الطلاب (بنين) *</label>
            <input 
              type="number" 
              min="0"
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={boysCount} 
              onChange={e => setBoysCount(e.target.value)}
              className="w-full px-3 py-1.5 text-sm bg-white text-black border border-slate-400 rounded text-right font-mono font-black focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 shadow-xs" 
            />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-800 mb-1">عدد الطالبات (بنات) *</label>
            <input 
              type="number" 
              min="0"
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={girlsCount} 
              onChange={e => setGirlsCount(e.target.value)}
              className="w-full px-3 py-1.5 text-sm bg-white text-black border border-slate-400 rounded text-right font-mono font-black focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 shadow-xs" 
            />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-700 mb-1">إجمالي عدد الطلاب (جمع تلقائي)</label>
            <input 
              type="number" 
              disabled
              step="any"
              value={(Number(boysCount) || 0) + (Number(girlsCount) || 0)}
              className="w-full px-3 py-1.5 text-sm bg-slate-150 text-slate-900 border border-slate-350 rounded text-right font-mono font-black cursor-not-allowed shadow-inner" 
            />
          </div>
        </div>
      </div>

      {/* Teachers count section by material */}
      <div id="school-details-quota-section" className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
        <PrintHeader 
          title={`تقرير الحصص والأنصبة والتبعية لمدرسة: ${school.name}`} 
          subtitle={`المقيد الفعلي والأنصبة والتبعية لعام ${school.year}`} 
          isVisible={exportingPdf} 
        />
        
        <div className="flex justify-between items-start border-b border-slate-100 pb-3 flex-wrap gap-2">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <BookOpen size={20} className="text-emerald-700" />
              قسم أنصبة المعلمين التفصيلي بالمواد الإلزامية
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              يتم استقبال المواد ونصاب الحصص تلقائياً من الإدارة العامة للتنسيق (ممنوع الإضافة أو الحذف)
            </p>
          </div>
          
          <div className="flex items-center gap-2 flex-wrap text-xs">
            <button
              type="button"
              onClick={handlePdfExport}
              disabled={exportingPdf}
              className="px-3.5 py-1.5 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-600 hover:to-yellow-700 text-white font-extrabold rounded-lg text-xs transition duration-200 cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 disabled:opacity-50"
            >
              <FileText size={13} className="text-white" />
              {exportingPdf ? 'جاري التصدير...' : 'تصدير الجدول PDF 📄'}
            </button>
            <div className="bg-slate-100 rounded text-[10px] text-slate-600 px-3 py-1.5 flex items-center gap-1">
              <Lock size={12} className="text-slate-400 shrink-0" />
              تعديل هيكل المواد مقتصر على التنسيق العام
            </div>
            
            {autoSaveStatus === 'saving' && (
              <div className="bg-amber-50 text-amber-700 rounded text-[10px] px-3 py-1.5 flex items-center gap-1 border border-amber-200 animate-pulse font-extrabold shadow-3xs">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping shrink-0" />
                جاري المزامنة والحفظ محلياً... 💾
              </div>
            )}
            {autoSaveStatus === 'saved' && (
              <div className="bg-green-50 text-green-700 rounded text-[10px] px-3 py-1.5 flex items-center gap-1 border border-green-200 font-extrabold shadow-3xs animate-fade-in">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 shrink-0" />
                تم الحفظ محلياً (انتهاء التخزين السحابي ⚠️)
              </div>
            )}
            {autoSaveStatus === 'idle' && (
              <div className="bg-slate-50 text-slate-500 rounded text-[10px] px-3 py-1.5 flex items-center gap-1 border border-slate-200 font-extrabold shadow-3xs">
                <span>جاري الحفظ محلياً (بسبب انتهاء السعة السحابية ⚠️)</span>
              </div>
            )}
          </div>
        </div>

        <div className="overflow-x-auto border border-slate-200/80 rounded-xl shadow-xs transition-all duration-300 hover:shadow-sm">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-gradient-to-r from-[#0D47A1] via-[#1565C0] to-[#1E88E5] text-white font-bold select-none animate-fade-in">
                <th onClick={() => handleSort('name')} className="p-2.5 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-start">
                    <span>اسم المادة لـ ({STAGE_LABELS[school.stage]})</span>
                    <SortIndicator field="name" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                {(school.stage === 'sec' || school.stage === 'primary') && (
                  <th onClick={() => handleSort('classroomsCount')} className="p-2.5 border border-amber-600/20 text-center bg-gradient-to-b from-amber-600 to-amber-800 text-white font-extrabold shadow-sm transition-all duration-300 hover:brightness-111 cursor-pointer group">
                    <div className="flex items-center gap-1 justify-center">
                      <span>عدد الفصول</span>
                      <SortIndicator field="classroomsCount" currentField={sortField} direction={sortDirection} />
                    </div>
                  </th>
                )}
                <th onClick={() => handleSort('super_senior')} className="p-2.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>كبير معلمين</span>
                    <SortIndicator field="super_senior" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('expert')} className="p-2.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>معلم خبير</span>
                    <SortIndicator field="expert" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('first_a')} className="p-2.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>معلم أول أ</span>
                    <SortIndicator field="first_a" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('first')} className="p-2.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>معلم أول</span>
                    <SortIndicator field="first" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('teacher')} className="p-2.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>معلم</span>
                    <SortIndicator field="teacher" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('assistant')} className="p-2.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>معلم مساعد</span>
                    <SortIndicator field="assistant" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('delegated')} className="p-2.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>منتدب</span>
                    <SortIndicator field="delegated" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('by_class')} className="p-2.5 border border-emerald-700/20 text-center bg-gradient-to-b from-[#10B981] via-emerald-700 to-emerald-950 text-white font-extrabold shadow-sm transition-all duration-300 hover:brightness-111 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>بالحصة (عشري)</span>
                    <SortIndicator field="by_class" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('total')} className="p-2.5 border border-blue-700/10 text-center bg-gradient-to-b from-indigo-600 to-[#0D47A1] font-extrabold transition-all duration-300 hover:brightness-110 cursor-pointer group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>إجمالي المعلمين</span>
                    <SortIndicator field="total" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedMaterials.length === 0 ? (
                <tr>
                  <td colSpan={(school.stage === 'sec' || school.stage === 'primary') ? 11 : 10} className="text-center p-6 text-slate-400">
                    لا توجد مواد مقيدة لهذه المرحلة حالياً في الإدارة التعليمية
                  </td>
                </tr>
              ) : (
                sortedMaterials.map(mat => {
                  const payload = metaCounts[mat.id] || {};
                  const total =
                    (payload.super_senior || 0) +
                    (payload.expert || 0) +
                    (payload.first_a || 0) +
                    (payload.first || 0) +
                    (payload.teacher || 0) +
                    (payload.assistant || 0) +
                    (payload.delegated || 0) +
                    (payload.by_class || 0);

                  return (
                    <tr key={mat.id} className="hover:bg-gradient-to-r hover:from-blue-50/70 hover:to-indigo-50/40 hover:shadow-[0_4px_15px_-3px_rgba(21,101,192,0.12)] hover:slate-100 transition-all duration-300 ease-out border-b border-slate-100/80 hover:translate-x-[-2px] relative z-0 hover:z-10">
                      <td className="p-2 font-bold text-slate-800 border-r border-l border-slate-100 leading-snug">
                        {mat.name}
                      </td>
                      
                      {(school.stage === 'sec' || school.stage === 'primary') && (
                        <td className="p-1 border border-slate-100 text-center bg-amber-50/30">
                          <input
                            type="number"
                            min="0"
                            step="1"
                            value={(inputValues[mat.id] && inputValues[mat.id].classroomsCount) ?? String(payload.classroomsCount ?? school.classroomsCount ?? 0)}
                            onChange={e => handleValueChange(mat.id, 'classroomsCount', e.target.value)}
                            onKeyDown={handleDecimalKeyDown}
                            className="w-14 px-1 py-1 text-center font-mono border border-amber-400 rounded text-xs bg-white font-black text-amber-950 shadow-3xs focus:border-amber-600 focus:outline-none focus:ring-1 focus:ring-amber-600"
                          />
                        </td>
                      )}
                      
                      {/* Inputs Column */}
                      {[
                        'super_senior',
                        'expert',
                        'first_a',
                        'first',
                        'teacher',
                        'assistant',
                        'delegated'
                      ].map(field => (
                        <td key={field} className="p-1 border border-slate-100 text-center">
                          <input
                            type="number"
                            min="0"
                            step="0.5"
                            value={(inputValues[mat.id] && inputValues[mat.id][field]) ?? String(payload[field as keyof MaterialCount] ?? 0)}
                            onChange={e => handleValueChange(mat.id, field, e.target.value)}
                            onKeyDown={handleDecimalKeyDown}
                            className="w-12 px-1 py-1 text-center font-mono border border-slate-300 rounded text-xs leading-none bg-white font-black text-slate-950 shadow-3xs focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
                          />
                        </td>
                      ))}

                      {/* بالحصة column allows decimal */}
                      <td className="p-1 border border-slate-100 text-center bg-emerald-50/40">
                        <input
                          type="number"
                          min="0"
                          step="0.5"
                          value={(inputValues[mat.id] && inputValues[mat.id].by_class) ?? String(payload.by_class ?? 0)}
                          onChange={e => handleValueChange(mat.id, 'by_class', e.target.value)}
                          onKeyDown={handleDecimalKeyDown}
                          className="w-14 px-1 py-1 text-center font-mono border border-emerald-400 rounded text-xs bg-white font-black text-emerald-950 shadow-3xs focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-600"
                        />
                      </td>

                      {/* Total calculated output */}
                      <td className="p-2 text-center font-mono font-black text-slate-900 bg-slate-100/50 border border-slate-100">
                        {total}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Dynamic Deficit/Surplus Real-time Calculation Panel */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-5 space-y-4 shadow-3xs">
          <div>
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
              <Sparkles size={16} className="text-emerald-700 animate-pulse shrink-0" />
              التحليل والتقييم الرياضي الفوري للرواكد والعجز والزيادة بالمدرسة
            </h3>
            <p className="text-[11px] text-slate-550 mt-0.5">
              يتم الحساب تلقائياً بناءً على مدخلاتك الحالية وقوة الفصول المقيدة بالمدرسة (<span className="font-bold text-slate-800">{liveSchool.classroomsCount || 0} فصول</span>) مقابل نصاب تدريس كل مادة.
            </p>
          </div>

          <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
            <table className="w-full text-right text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100/80 text-slate-700 font-bold text-[10px] border-b border-slate-200 uppercase">
                  <th className="p-2.5 text-right">اسم المادة المعتمد</th>
                  {(liveSchool.stage === 'sec' || liveSchool.stage === 'primary') && <th className="p-2.5 text-center">عدد الفصول</th>}
                  <th className="p-2.5 text-center">النصاب الأسبوعي للمادة</th>
                  <th className="p-2.5 text-center">المطلوب المرجعي من المعلمين</th>
                  <th className="p-2.5 text-center">القوة الحالية بالجدول</th>
                  <th className="p-2.5 text-center bg-red-50 text-red-800">العجـــــز</th>
                  <th className="p-2.5 text-center bg-emerald-50 text-emerald-900">الزيـــــادة</th>
                  <th className="p-2.5 text-center">مؤشر الكفاية التوجيهي</th>
                </tr>
              </thead>
              <tbody>
                {sortedMaterials.map(mat => {
                  const payload = metaCounts[mat.id] || {};
                  
                  // Get current input values if changed, or use database values
                  const currentCount: MaterialCount = {
                    schoolId: liveSchool.id,
                    materialId: mat.id,
                    super_senior: parseFloat(inputValues[mat.id]?.super_senior ?? String(payload.super_senior ?? 0)) || 0,
                    expert: parseFloat(inputValues[mat.id]?.expert ?? String(payload.expert ?? 0)) || 0,
                    first_a: parseFloat(inputValues[mat.id]?.first_a ?? String(payload.first_a ?? 0)) || 0,
                    first: parseFloat(inputValues[mat.id]?.first ?? String(payload.first ?? 0)) || 0,
                    teacher: parseFloat(inputValues[mat.id]?.teacher ?? String(payload.teacher ?? 0)) || 0,
                    assistant: parseFloat(inputValues[mat.id]?.assistant ?? String(payload.assistant ?? 0)) || 0,
                    delegated: parseFloat(inputValues[mat.id]?.delegated ?? String(payload.delegated ?? 0)) || 0,
                    by_class: parseFloat(inputValues[mat.id]?.by_class ?? String(payload.by_class ?? 0)) || 0,
                    classroomsCount: (liveSchool.stage === 'sec' || liveSchool.stage === 'primary') ? (parseFloat(inputValues[mat.id]?.classroomsCount ?? String(payload.classroomsCount ?? liveSchool.classroomsCount ?? 0)) || 0) : undefined
                  };

                  const metrics = dbInstance.calculateMaterialMetrics(liveSchool, mat, currentCount);

                  return (
                    <tr key={mat.id} className="border-b border-slate-105 last:border-none font-sans hover:bg-slate-50 transition-colors">
                      <td className="p-2.5 font-bold text-slate-800 border-r">{mat.name}</td>
                      {(liveSchool.stage === 'sec' || liveSchool.stage === 'primary') && (
                        <td className="p-2.5 text-center font-mono text-slate-800 font-extrabold bg-amber-50/10">
                          {currentCount.classroomsCount !== undefined ? currentCount.classroomsCount : (liveSchool.classroomsCount || 0)} فصل
                        </td>
                      )}
                      <td className="p-2.5 text-center font-mono text-slate-600 bg-slate-50/20 font-bold">{mat.quota} حصة / فصل</td>
                      <td className="p-2.5 text-center font-mono text-slate-800 font-extrabold bg-slate-100/30">{metrics.needed} معلم</td>
                      <td className="p-2.5 text-center font-mono text-[#0D47A1] font-black">{metrics.present} معلم</td>
                      <td className={`p-2.5 text-center font-mono font-black ${metrics.deficit > 0 ? 'bg-red-50 text-red-650' : 'text-slate-350 bg-slate-50/10'}`}>
                        {metrics.deficit > 0 ? `${metrics.deficit} معلم` : '---'}
                      </td>
                      <td className={`p-2.5 text-center font-mono font-black ${metrics.surplus > 0 ? 'bg-emerald-50 text-emerald-700' : 'text-slate-350 bg-slate-50/10'}`}>
                        {metrics.surplus > 0 ? `${metrics.surplus} زيادة` : '---'}
                      </td>
                      <td className="p-2 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-black font-mono ${
                          metrics.percentage >= 100 ? 'bg-green-100 text-green-700' : metrics.percentage >= 50 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {metrics.percentage}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-100">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-1.5 px-6 py-2 bg-gradient-to-l from-[#0D47A1] to-[#1E88E5] hover:brightness-110 active:scale-95 text-white text-sm font-extrabold rounded-lg shadow-md transition-all cursor-pointer"
          >
            <Save size={16} />
            {saving ? 'جاري الإرسال للتنسيق...' : 'حفظ وإرسال التعديلات فوراً'}
          </button>
        </div>

        <PrintFooter isVisible={exportingPdf} />

      </div>

    </form>
  );
}

// ----------------------------------------------------
// TAB 2: SCHOOL LEADERSHIP (PRINCIPAL & ASSISTANTS)
// ----------------------------------------------------
function LeadershipTab({ schoolId, dbTick }: { schoolId: string; dbTick: number }) {
  const school = dbInstance.getSchools().find(s => s.id === schoolId) || { name: '', stage: '' };
  const [boardList, setBoardList] = useState<Directorship[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [formData, setFormData] = useState<Partial<Directorship>>({
    name: '',
    nationalId: '',
    role: 'principal',
    specialty: '',
    decisionNumber: '',
    decisionDate: '',
    address: '',
    schoolYearsCount: 0,
    qualification: '',
    qualificationDate: '',
    birthDate: '',
    code: '',
    phone: ''
  });

  const reloadData = () => {
    const list = dbInstance.getLeadership().filter(l => l.schoolId === schoolId);
    setBoardList(list);
  };

  useEffect(() => {
    reloadData();
  }, [schoolId, dbTick]);

  const triggerAutoSave = (updatedData: Partial<Directorship>) => {
    if (!updatedData.name || !updatedData.nationalId) return;
    setAutoSaveStatus('saving');

    const payload: Directorship = {
      id: updatedData.id || editingId || 'lead_temp',
      schoolId,
      name: updatedData.name,
      nationalId: updatedData.nationalId,
      role: (updatedData.role as 'principal' | 'vice_principal') || 'vice_principal',
      specialty: updatedData.specialty || '',
      decisionNumber: updatedData.decisionNumber || '',
      decisionDate: updatedData.decisionDate || '',
      address: updatedData.address || '',
      schoolYearsCount: Number(updatedData.schoolYearsCount || 0),
      qualification: updatedData.qualification || '',
      qualificationDate: updatedData.qualificationDate || '',
      birthDate: updatedData.birthDate || '',
      code: updatedData.code || '',
      phone: updatedData.phone || ''
    };

    dbInstance.saveLeadership(payload);

    setTimeout(() => {
      setAutoSaveStatus('saved');
      reloadData();
    }, 400);
  };

  const handleFieldChange = (field: keyof Directorship, value: any) => {
    setFormData(prev => {
      const next = { ...prev, [field]: value };
      triggerAutoSave(next);
      return next;
    });
  };

  const startAdd = () => {
    const newId = 'lead_' + Date.now();
    setFormData({
      id: newId,
      name: '',
      nationalId: '',
      role: 'principal',
      specialty: '',
      decisionNumber: '',
      decisionDate: '',
      address: '',
      schoolYearsCount: 0,
      qualification: '',
      qualificationDate: '',
      birthDate: '',
      code: '',
      phone: ''
    });
    setEditingId(newId);
    setIsFormOpen(true);
    setAutoSaveStatus('idle');
  };

  const startEdit = (item: Directorship) => {
    setFormData(item);
    setEditingId(item.id);
    setIsFormOpen(true);
    setAutoSaveStatus('idle');
  };

  const handleDelete = (id: string) => {
    dbInstance.deleteLeadership(id);
    reloadData();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.nationalId) {
      alert('الرجاء تعبئة اسم القيادي والرقم القومي بالتفصيل.');
      return;
    }

    const phoneStr = (formData.phone || '').trim();
    if (phoneStr.length !== 11) {
      alert('الرجاء إدخال رقم هاتف محمول صحيح يتكون من 11 رقماً تماماً لإنهاء الحفظ المعين (مثال: 01012345678).');
      return;
    }

    const payload: Directorship = {
      id: editingId || 'lead_' + Date.now(),
      schoolId,
      name: formData.name,
      nationalId: formData.nationalId,
      role: (formData.role as 'principal' | 'vice_principal') || 'vice_principal',
      specialty: formData.specialty || '',
      decisionNumber: formData.decisionNumber || '',
      decisionDate: formData.decisionDate || '',
      address: formData.address || '',
      schoolYearsCount: Number(formData.schoolYearsCount || 0),
      qualification: formData.qualification || '',
      qualificationDate: formData.qualificationDate || '',
      birthDate: formData.birthDate || '',
      code: formData.code || '',
      phone: formData.phone || ''
    };

    dbInstance.saveLeadership(payload);
    setIsFormOpen(false);
    reloadData();
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-6">
      
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck size={20} className="text-blue-600 animate-pulse" />
            سجل القيادة المدرسية والوكلاء المساعدين
          </h2>
          <p className="text-xs text-slate-500 mt-1">تحديد المدير المسؤول والوكلاء المعتمدين بالمدرسة لتقييم الحوكمة</p>
        </div>

        {!isFormOpen && (
          <button
            type="button"
            onClick={startAdd}
            className="px-4 py-2 bg-gradient-to-l from-[#1565C0] to-[#1E88E5] hover:brightness-110 active:scale-95 text-white rounded-lg text-xs font-black shadow-md transition-all cursor-pointer"
          >
            إضافة مدير / وكيل جديد
          </button>
        )}
      </div>

      {isFormOpen && (
        <form onSubmit={handleSubmit} className="p-5 border border-slate-150 rounded-lg bg-slate-50 space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-slate-200">
            <h3 className="text-xs font-bold text-slate-800">
              {editingId && !editingId.startsWith('lead_temp') ? 'تحديث السجل القيادي الحالي' : 'إضافة قيادي جديد بمجلس إدارة المدرسة'}
            </h3>
            <div className="flex items-center gap-1.5">
              {autoSaveStatus === 'saving' && (
                <span className="text-[10px] text-amber-600 font-bold bg-amber-50 px-2.5 py-1 rounded-md animate-pulse">
                  ⏳ جاري الحفظ والتزامن محلياً...
                </span>
              )}
              {autoSaveStatus === 'saved' && (
                <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2.5 py-1 rounded-md shadow-3xs border border-emerald-100">
                  ✓ تم الحفظ محلياً (بسبب انتهاء السعة السحابية ⚠️)
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">اسم المدرسة المنسوب إليها السجل</label>
              <input 
                type="text" 
                readOnly 
                disabled 
                value={school.name} 
                className="w-full px-3 py-1.5 text-sm bg-slate-100 border border-slate-200 rounded text-right text-slate-600 font-bold cursor-not-allowed" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">الاسم رباعياً *</label>
              <input 
                type="text" 
                value={formData.name || ''} 
                onChange={e => handleFieldChange('name', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">الرقم القومي (14 رقماً) *</label>
              <input 
                type="text" 
                maxLength={14}
                value={formData.nationalId || ''} 
                onChange={e => handleFieldChange('nationalId', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right font-mono" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">الوظيفة الإدارية</label>
              <select 
                value={formData.role || 'principal'} 
                onChange={e => handleFieldChange('role', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white text-black font-black border border-slate-350 rounded text-right shadow-xs focus:ring-1 focus:ring-blue-500"
              >
                <option value="principal">مدير المدرسة</option>
                <option value="vice_principal">وكيل المدرسة</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">العنوان بالتفصيل</label>
              <input 
                type="text" 
                value={formData.address || ''} 
                onChange={e => handleFieldChange('address', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">الهاتف الجوال / رقم التواصل (11 رقماً) *</label>
              <input 
                type="text" 
                maxLength={11}
                placeholder="مثال: 01012345678"
                value={formData.phone || ''} 
                onChange={e => {
                  const cleaned = e.target.value.replace(/[^0-9]/g, '');
                  handleFieldChange('phone', cleaned);
                }}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right font-mono" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">التخصص الأصلي</label>
              <input 
                type="text" 
                value={formData.specialty || ''} 
                onChange={e => handleFieldChange('specialty', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">رقم قرار التكليف باللجنة</label>
              <input 
                type="text" 
                value={formData.decisionNumber || ''} 
                onChange={e => handleFieldChange('decisionNumber', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right font-mono" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">تاريخ القرار</label>
              <input 
                type="date" 
                value={formData.decisionDate || ''} 
                onChange={e => handleFieldChange('decisionDate', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right font-mono" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">مكث بالمدرسة (عدد السنوات)</label>
              <input 
                type="number" 
                step="any"
                value={formData.schoolYearsCount || 0} 
                onChange={e => handleFieldChange('schoolYearsCount', parseFloat(e.target.value) || 0)}
                onKeyDown={handleDecimalKeyDown}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right font-mono" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">الكود</label>
              <input 
                type="text" 
                value={formData.code || ''} 
                onChange={e => handleFieldChange('code', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right font-mono" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">المؤهل الدراسي</label>
              <input 
                type="text" 
                value={formData.qualification || ''} 
                onChange={e => handleFieldChange('qualification', e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right" 
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="submit"
              className="px-4 py-1.5 bg-gradient-to-l from-green-700 to-emerald-600 hover:brightness-110 active:scale-95 text-white rounded text-xs font-black shadow-md transition-all cursor-pointer animate-none"
            >
              موافق وتثبيت الحفظ الرسمي
            </button>
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="px-4 py-1.5 bg-slate-200 text-slate-707 rounded text-xs font-medium cursor-pointer"
            >
              إغلاق النافذة
            </button>
          </div>
        </form>
      )}

      {/* Grid of leader cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {boardList.length === 0 ? (
          <div className="col-span-2 text-center p-8 text-slate-400 bg-slate-50 rounded border border-dashed border-slate-200">
            أنتج السجل الإداري القيادي فارغاً لتلك المدرسة حالياً. قم بإضافة المعنيين لبدء التبادل السحابي.
          </div>
        ) : (
          boardList.map(member => (
            <div key={member.id} className="border border-slate-100 rounded-lg p-5 bg-slate-50 relative hover:shadow-md transition">
              <span className={`absolute left-4 top-4 px-2 py-0.5 rounded text-[10px] font-bold ${member.role === 'principal' ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700'}`}>
                {member.role === 'principal' ? 'مدير عام مدرسة' : 'وكيل إدارة مدرسية'}
              </span>

              <h3 className="font-extrabold text-slate-900 text-base leading-tight pl-16 truncate">
                {member.name}
              </h3>

              <div className="grid grid-cols-2 gap-y-2 gap-x-4 mt-4 text-xs font-medium text-slate-600">
                <div>الكود المالي: <span className="font-mono text-slate-900 font-bold">{member.code || 'غير محدد'}</span></div>
                <div>التخصص: <span className="text-slate-900">{member.specialty}</span></div>
                <div>رقم القرار: <span className="font-mono text-slate-900 font-bold">{member.decisionNumber || '---'}</span></div>
                <div>تاريخ القرار: <span className="font-mono text-slate-900">{member.decisionDate || '---'}</span></div>
                <div>المكث بالمدرسة: <span className="text-blue-700 font-bold">{member.schoolYearsCount} سنوات</span></div>
                <div>رقم الهاتف: <span className="font-mono text-slate-900 font-bold">{member.phone || '---'}</span></div>
                <div className="col-span-2 border-t border-slate-100 pt-2 truncate" title={member.qualification}>
                  المؤهل: <span className="text-slate-900 text-[11px]">{member.qualification}</span>
                </div>
              </div>

              <div className="mt-4 pt-2 border-t border-slate-200/50 flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => startEdit(member)}
                  className="px-2 py-1 border border-slate-200 hover:bg-slate-100 rounded text-slate-700 cursor-pointer"
                >
                  تعديل
                </button>
                {confirmDeleteId === member.id ? (
                  <div className="flex items-center gap-1 bg-rose-50 border border-rose-200 rounded p-0.5 animate-pulse">
                    <button
                      type="button"
                      onClick={() => {
                        handleDelete(member.id);
                        setConfirmDeleteId(null);
                      }}
                      className="px-2 py-0.5 bg-rose-600 text-white font-black rounded text-[10px] cursor-pointer"
                    >
                      تأكيد
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(null)}
                      className="px-2 py-0.5 border border-slate-300 text-slate-700 font-black rounded text-[10px] cursor-pointer bg-white"
                    >
                      إلغاء
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteId(member.id)}
                    className="px-2 py-1 bg-red-100 text-red-700 hover:bg-red-200 border border-red-200 rounded cursor-pointer font-bold"
                  >
                    حذف
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 4: STUDENT ABSENCE (RECORDS & CHARTS)
// ----------------------------------------------------
function StudentAbsenceTab({ schoolId, dbTick }: { schoolId: string; dbTick: number }) {
  const school = dbInstance.getSchools().find(s => s.id === schoolId) || { name: '', stage: '' };
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [grades, setGrades] = useState<StudentAbsenceRecord[]>([
    { grade: 'الصف الأول', registered: 120, present: 110, absent: 10 },
    { grade: 'الصف الثاني', registered: 110, present: 105, absent: 5 },
    { grade: 'الصف الثالث', registered: 95, present: 85, absent: 10 }
  ]);
  const [success, setSuccess] = useState(false);

  // Sorting state
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedGrades = useMemo(() => {
    if (!sortField) return grades;

    return [...grades].sort((a, b) => {
      let valA: any = 0;
      let valB: any = 0;

      if (sortField === 'grade') {
        valA = a.grade;
        valB = b.grade;
      } else if (sortField === 'registered') {
        valA = a.registered;
        valB = b.registered;
      } else if (sortField === 'absent') {
        valA = a.absent;
        valB = b.absent;
      } else if (sortField === 'present') {
        valA = a.present;
        valB = b.present;
      } else if (sortField === 'total') {
        valA = Number(a.present || 0) + Number(a.absent || 0);
        valB = Number(b.present || 0) + Number(b.absent || 0);
      } else if (sortField === 'ratio') {
        valA = a.registered > 0 ? a.present / a.registered : 0;
        valB = b.registered > 0 ? b.present / b.registered : 0;
      }

      if (typeof valA === 'string' && typeof valB === 'string') {
        return sortDirection === 'asc' ? valA.localeCompare(valB, 'ar') : valB.localeCompare(valA, 'ar');
      }

      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [grades, sortField, sortDirection]);

  useEffect(() => {
    const existing = dbInstance.getStudentAbsences().find(a => a.schoolId === schoolId && a.date === date);
    if (existing && existing.records && existing.records.length > 0) {
      setGrades(existing.records);
    } else {
      setGrades([
        { grade: 'الصف الأول', registered: 120, present: 110, absent: 10 },
        { grade: 'الصف الثاني', registered: 110, present: 105, absent: 5 },
        { grade: 'الصف الثالث', registered: 95, present: 85, absent: 10 }
      ]);
    }
  }, [date, schoolId, dbTick]);

  const handleValueChange = (index: number, key: keyof StudentAbsenceRecord, val: number) => {
    const updated = [...grades];
    const rec = { ...updated[index] };
    
    if (key === 'registered') {
      rec.registered = val || 0;
      // Autocomplete formula variables
      rec.absent = Math.max(0, rec.registered - rec.present);
    } else if (key === 'present') {
      rec.present = val || 0;
      rec.absent = Math.max(0, rec.registered - rec.present);
    } else if (key === 'absent') {
      rec.absent = val || 0;
      rec.present = Math.max(0, rec.registered - rec.absent);
    }

    updated[index] = rec;
    setGrades(updated);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    dbInstance.saveStudentAbsence({
      id: 'stu_abs_' + schoolId + '_' + date,
      schoolId,
      date,
      records: grades
    });
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  // Math totals
  const aggregated = grades.reduce(
    (acc, curr) => {
      acc.registered += curr.registered;
      acc.present += curr.present;
      acc.absent += curr.absent;
      return acc;
    },
    { registered: 0, present: 0, absent: 0 }
  );

  const presentPercentage = aggregated.registered > 0 ? ((aggregated.present / aggregated.registered) * 100).toFixed(1) : '0';
  const absentPercentage = aggregated.registered > 0 ? ((aggregated.absent / aggregated.registered) * 105).toFixed(1) : '0'; // standard scaling

  // Chart Payload mappings
  const pieData = [
    { name: 'الحضور الإجمالي', value: aggregated.present },
    { name: 'الغياب الإجمالي', value: aggregated.absent }
  ];

  const barData = grades.map(g => ({
    grade: g.grade,
    'المقيد': g.registered,
    'الحضور': g.present,
    'الغياب': g.absent
  }));

  const lineData = grades.map(g => ({
    grade: g.grade,
    'نسبة الغياب %': g.registered > 0 ? Number(((g.absent / g.registered) * 100).toFixed(1)) : 0
  }));

  return (
    <div className="space-y-6">
      
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Calendar size={20} className="text-indigo-600" />
              سجل الحضور والغياب اليومي للطلاب والدارسين
            </h2>
            <p className="text-xs text-slate-500 mt-1">تحديد نسب الغياب اليومي وحساب المؤشرات الإحصائية ومقاربتها سحابياً</p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">اسم المدرسة:</span>
              <span className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded text-xs font-bold text-slate-700">{school.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs font-bold text-slate-600">اختر التاريخ الإداري:</label>
              <input 
                type="date" 
                value={date} 
                onChange={e => setDate(e.target.value)}
                className="px-3 py-1.5 text-sm border border-slate-200 rounded font-mono"
              />
            </div>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-4 overflow-x-auto border border-slate-200/80 rounded-xl shadow-xs transition-all duration-300 hover:shadow-sm">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-gradient-to-r from-[#0D47A1] via-[#1565C0] to-[#1E88E5] text-white font-bold select-none cursor-pointer animate-fade-in">
                <th onClick={() => handleSort('grade')} className="p-3.5 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-start">
                    <span>الصف الدراسي</span>
                    <SortIndicator field="grade" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('registered')} className="p-3.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>عدد المقيدين</span>
                    <SortIndicator field="registered" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('absent')} className="p-3.5 border border-blue-700/10 text-center font-extrabold text-red-100 bg-gradient-to-b from-red-600 via-rose-700 to-rose-900 transition-all duration-300 hover:brightness-110 shadow-sm group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>عدد الغائبين</span>
                    <SortIndicator field="absent" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('present')} className="p-3.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>عدد الحاضرين</span>
                    <SortIndicator field="present" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('total')} className="p-3.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>إجمالي الجملة اليومية</span>
                    <SortIndicator field="total" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('ratio')} className="p-3.5 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>نسبة الحضور %</span>
                    <SortIndicator field="ratio" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedGrades.map((g) => {
                const originalIndex = grades.findIndex(item => item.grade === g.grade);
                const ratio = g.registered > 0 ? ((g.present / g.registered) * 100).toFixed(1) : '0';
                return (
                  <tr key={g.grade} className="hover:bg-gradient-to-r hover:from-blue-50/70 hover:to-indigo-50/40 hover:shadow-[0_4px_15px_-3px_rgba(21,101,192,0.12)] transition-all duration-300 ease-out border-b border-slate-100 hover:translate-x-[-2px] relative z-0 hover:z-10">
                    <td className="p-3 font-extrabold text-slate-800 border-r border-l border-slate-100">
                      {g.grade}
                    </td>
                    <td className="p-2 border border-slate-100 text-center">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        onKeyDown={handleDecimalKeyDown}
                        value={g.registered}
                        onChange={e => handleValueChange(originalIndex, 'registered', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-1 text-center font-mono border border-slate-200 rounded"
                      />
                    </td>
                    <td className="p-2 border border-slate-100 text-center bg-red-50/10">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        onKeyDown={handleDecimalKeyDown}
                        value={g.absent}
                        onChange={e => handleValueChange(originalIndex, 'absent', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-1 text-center font-mono border border-red-300 rounded text-red-700 bg-red-50/20 font-bold"
                      />
                    </td>
                    <td className="p-2 border border-slate-100 text-center">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        onKeyDown={handleDecimalKeyDown}
                        value={g.present}
                        onChange={e => handleValueChange(originalIndex, 'present', parseFloat(e.target.value) || 0)}
                        className="w-16 px-1.5 py-1 text-center font-mono border border-slate-200 rounded font-bold"
                      />
                    </td>
                    <td className="p-3 text-center border border-slate-100 font-mono font-bold text-slate-600 bg-slate-50/30">
                      {Number(g.present) + Number(g.absent)}
                    </td>
                    <td className="p-3 text-center border border-slate-100 font-mono font-bold text-green-700">
                      {ratio} %
                    </td>
                  </tr>
                );
              })}
              {/* Grand Totals */}
              <tr className="bg-slate-100 font-extrabold text-xs">
                <td className="p-3 border border-slate-200">الإجمالي العام للطلاب</td>
                <td className="p-3 border border-slate-200 text-center font-mono text-slate-800">{aggregated.registered}</td>
                <td className="p-3 border border-slate-200 text-center font-mono text-red-600">{aggregated.absent}</td>
                <td className="p-3 border border-slate-200 text-center font-mono text-green-700">{aggregated.present}</td>
                <td className="p-3 border border-slate-200 text-center font-mono">{aggregated.present + aggregated.absent}</td>
                <td className="p-3 border border-slate-200 text-center font-mono text-blue-700">{presentPercentage} %</td>
              </tr>
            </tbody>
          </table>

          <div className="flex justify-end pt-3">
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-l from-[#1565C0] to-[#1E88E5] hover:brightness-110 active:scale-95 text-white rounded shadow-md text-xs font-black transition-all cursor-pointer"
            >
              {success ? '✓ تم حفظ اليومية وتحديث المؤشرات' : 'ترحيل وحفظ التقرير اليومي'}
            </button>
          </div>
        </form>
      </div>

      {/* Graphical Panel charts dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Pie Chart: attendance ratios */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-5">
          <h3 className="text-xs font-bold text-slate-800 mb-3 border-b border-slate-100 pb-2">
            توزيع الحضور والغياب الإجمالي (Pie Chart)
          </h3>
          <CustomPieChart 
            data={pieData} 
            colors={['#2E7D32', '#EF5350']}
          />
        </div>

        {/* Bar Chart: registered by grade */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-5">
          <h3 className="text-xs font-bold text-slate-800 mb-3 border-b border-slate-100 pb-2">
            تمثيل القوى العددية المقيّدة في الصفوف (Bar Chart)
          </h3>
          <CustomBarChart 
            data={grades.map(g => ({ label: g.grade, val: g.registered }))}
            xKey="label"
            yKey="val"
            color="#1565C0"
          />
        </div>

        {/* Line Chart: Absences percentage */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-5">
          <h3 className="text-xs font-bold text-slate-800 mb-3 border-b border-slate-100 pb-2">
            تحليل منحنى نسبة تفشي الغياب طردياً (Line Chart)
          </h3>
          <CustomLineChart 
            data={lineData} 
            xKey="grade" 
            yKey="نسبة الغياب %"
            color="#E53935"
          />
        </div>

      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 5: TEACHER ABSENCE (ARCHIVING & HISTORIC LOG)
// ----------------------------------------------------
function TeacherAbsenceTab({ schoolId, dbTick }: { schoolId: string; dbTick: number }) {
  const school = dbInstance.getSchools().find(s => s.id === schoolId) || { name: '', stage: '' };
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [absLog, setAbsLog] = useState<TeacherAbsence>({
    id: '',
    schoolId,
    date,
    registered: 35,
    delegated: 2,
    mission: 1,
    regularLeave: 1,
    sickLeave: 1,
    present: 30,
    absent: 5
  });

  const [historyList, setHistoryList] = useState<TeacherAbsence[]>([]);

  // Sorting state for historical records table
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedHistoryList = useMemo(() => {
    if (!sortField) return historyList;

    return [...historyList].sort((a, b) => {
      let valA: any = 0;
      let valB: any = 0;

      if (sortField === 'date') {
        valA = a.date;
        valB = b.date;
      } else {
        valA = a[sortField as keyof TeacherAbsence] || 0;
        valB = b[sortField as keyof TeacherAbsence] || 0;
      }

      if (typeof valA === 'string' && typeof valB === 'string') {
        return sortDirection === 'asc' ? valA.localeCompare(valB, 'ar') : valB.localeCompare(valA, 'ar');
      }

      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [historyList, sortField, sortDirection]);

  const loadLocalData = () => {
    const hist = dbInstance.getTeacherAbsences().filter(a => a.schoolId === schoolId);
    setHistoryList(hist);

    const existing = hist.find(a => a.date === date);
    if (existing) {
      setAbsLog(existing);
    } else {
      setAbsLog({
        id: 'teach_abs_' + schoolId + '_' + date,
        schoolId,
        date,
        registered: 35,
        delegated: 2,
        mission: 1,
        regularLeave: 1,
        sickLeave: 1,
        present: 30,
        absent: 5
      });
    }
  };

  useEffect(() => {
    loadLocalData();
  }, [date, schoolId, dbTick]);

  const handleFieldChange = (key: keyof TeacherAbsence, val: number) => {
    const updated = { ...absLog, [key]: val };
    
    // Auto calculations variables
    if (['registered', 'delegated', 'mission', 'regularLeave', 'sickLeave', 'absent'].includes(key as string)) {
      const reg = updated.registered || 0;
      const del = updated.delegated || 0;
      const miss = updated.mission || 0;
      const regLv = updated.regularLeave || 0;
      const sickList = updated.sickLeave || 0;
      const absVal = updated.absent || 0;

      // present = registered - (mission + regular + sick + absent) // standard logic
      updated.present = Math.max(0, reg - (miss + regLv + sickList + absVal));
    }
    setAbsLog(updated);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    dbInstance.saveTeacherAbsence({
      ...absLog,
      id: 'teach_abs_' + schoolId + '_' + date,
      monthKey: date.substring(0, 7)
    });
    alert('تم أرشفة سجل غياب المعلمين بنجاح وتحديث القاعدة المركزية.');
    loadLocalData();
  };

  return (
    <div className="space-y-6">
      
      {/* Dynamic input log form */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <UserCheck size={20} className="text-green-700 animate-bounce" />
              أرشفة غياب المعلمين والدرجات الوظيفية اليومي الكلي
            </h2>
            <p className="text-xs text-slate-500 mt-1">أرشفة نسب الحضور والغياب المالي للـتنسيق والمأموريات والندب</p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">اسم المدرسة:</span>
              <span className="px-3 py-1 bg-slate-100 border border-slate-200 rounded text-xs font-bold text-slate-700">{school.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-650">اليوم الإداري:</span>
              <input 
                type="date" 
                value={date} 
                onChange={e => setDate(e.target.value)}
                className="px-3 py-1 text-sm border border-slate-200 rounded font-mono"
              />
            </div>
          </div>
        </div>

        <form onSubmit={handleFormSubmit} className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">المقيد الأساسي</label>
            <input
              type="number"
              min="0"
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={absLog.registered}
              onChange={e => handleFieldChange('registered', parseFloat(e.target.value) || 0)}
              className="w-full px-2 py-1 text-center font-mono border border-slate-200 rounded text-xs"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">الندب الخارجي</label>
            <input
              type="number"
              min="0"
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={absLog.delegated}
              onChange={e => handleFieldChange('delegated', parseFloat(e.target.value) || 0)}
              className="w-full px-2 py-1 text-center font-mono border border-slate-200 rounded text-xs"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">في مأمورية</label>
            <input
              type="number"
              min="0"
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={absLog.mission}
              onChange={e => handleFieldChange('mission', parseFloat(e.target.value) || 0)}
              className="w-full px-2 py-1 text-center font-mono border border-slate-200 rounded text-xs"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">إجازة اعتيادية</label>
            <input
              type="number"
              min="0"
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={absLog.regularLeave}
              onChange={e => handleFieldChange('regularLeave', parseFloat(e.target.value) || 0)}
              className="w-full px-2 py-1 text-center font-mono border border-slate-200 rounded text-xs"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">مرضي اليوم</label>
            <input
              type="number"
              min="0"
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={absLog.sickLeave}
              onChange={e => handleFieldChange('sickLeave', parseFloat(e.target.value) || 0)}
              className="w-full px-2 py-1 text-center font-mono border border-slate-200 rounded text-xs"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">غياب بدون إذن</label>
            <input
              type="number"
              min="0"
              step="any"
              onKeyDown={handleDecimalKeyDown}
              value={absLog.absent}
              onChange={e => handleFieldChange('absent', parseFloat(e.target.value) || 0)}
              className="w-full px-2 py-1 text-center font-mono border border-red-300 rounded text-red-700 bg-red-50/10 text-xs font-bold"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-emerald-800 mb-1">إجمالي الحضور</label>
            <input
              type="number"
              disabled
              step="any"
              value={absLog.present}
              className="w-full px-2 py-1 text-center font-mono border border-emerald-200 bg-emerald-50 text-emerald-800 rounded font-bold text-xs"
            />
          </div>
          
          <div className="flex items-end">
            <button
              type="submit"
              className="w-full py-1 bg-gradient-to-l from-green-700 to-emerald-600 hover:brightness-110 active:scale-95 text-white rounded text-xs font-black transition-all shadow-md h-[32px] cursor-pointer"
            >
              أرشفة اليوم
            </button>
          </div>
        </form>
      </div>

      {/* Historical Archives Log list */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <History size={16} className="text-slate-500" />
          السجلات المؤرشفة لغياب الكوادر بالتاريخ
        </h3>

        <div className="overflow-x-auto border border-slate-200/80 rounded-xl shadow-xs transition-all duration-300 hover:shadow-sm">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-gradient-to-r from-[#0D47A1] via-[#1565C0] to-[#1E88E5] text-white font-bold select-none cursor-pointer animate-fade-in">
                <th onClick={() => handleSort('date')} className="p-3 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-start">
                    <span>التاريخ اليومي</span>
                    <SortIndicator field="date" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('registered')} className="p-3 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>المقيد</span>
                    <SortIndicator field="registered" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('delegated')} className="p-3 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>الندب</span>
                    <SortIndicator field="delegated" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('mission')} className="p-3 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>المأموريات</span>
                    <SortIndicator field="mission" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('regularLeave')} className="p-3 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>الاعتيادي</span>
                    <SortIndicator field="regularLeave" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('sickLeave')} className="p-3 border border-blue-700/10 text-center bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>المرضي</span>
                    <SortIndicator field="sickLeave" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('absent')} className="p-3 border border-blue-700/10 text-center text-red-100 bg-gradient-to-b from-red-650 via-rose-700 to-rose-900 transition-all duration-300 hover:brightness-110 font-bold group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>الغياب كلياً</span>
                    <SortIndicator field="absent" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('present')} className="p-3 border border-blue-700/10 text-center text-emerald-100 bg-gradient-to-b from-emerald-600 via-teal-700 to-teal-900 transition-all duration-300 hover:brightness-110 font-bold group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>إجمالي الحضور</span>
                    <SortIndicator field="present" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedHistoryList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center p-6 text-slate-400 font-sans">
                    لم يحفظ السجل التاريخي أي ملفات لتاريخ مسبق حالياً
                  </td>
                </tr>
              ) : (
                sortedHistoryList.map(hist => (
                  <tr key={hist.id} className="hover:bg-gradient-to-r hover:from-blue-50/70 hover:to-indigo-50/40 hover:shadow-[0_4px_15px_-3px_rgba(21,101,192,0.12)] transition-all duration-300 ease-out border-b border-slate-100 font-mono hover:translate-x-[-2px] relative z-0 hover:z-10">
                    <td className="p-2.5 font-bold text-slate-800 border-r border-l border-slate-100 font-sans">
                      {hist.date}
                    </td>
                    <td className="p-2.5 text-center border border-slate-100">{hist.registered}</td>
                    <td className="p-2.5 text-center border border-slate-100">{hist.delegated}</td>
                    <td className="p-2.5 text-center border border-slate-100 text-slate-600">{hist.mission}</td>
                    <td className="p-2.5 text-center border border-slate-100 text-slate-500">{hist.regularLeave}</td>
                    <td className="p-2.5 text-center border border-slate-100 text-slate-550">{hist.sickLeave}</td>
                    <td className="p-2.5 text-center border border-slate-100 text-red-600 font-bold">{hist.absent}</td>
                    <td className="p-2.5 text-center border border-slate-100 text-emerald-700 font-black">{hist.present}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 6: VISITOR & INSPECTOR LOGS (WITH FILE UPLOADS LOCAL)
// ----------------------------------------------------
function VisitorLogTab({ schoolId, schoolName, dbTick }: { schoolId: string; schoolName: string; dbTick: number }) {
  const school = dbInstance.getSchools().find(s => s.id === schoolId) || { name: schoolName, stage: '' };
  const [visitorList, setVisitorList] = useState<VisitorLog[]>([]);
  const [formData, setFormData] = useState({
    visitorName: '',
    jobTitle: '',
    day: 'الأحد',
    date: new Date().toISOString().split('T')[0],
    arrivalTime: '',
    fileBase64: '',
    fileName: ''
  });

  const [saving, setSaving] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Sorting state for visitors log
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedVisitorList = useMemo(() => {
    if (!sortField) return visitorList;

    return [...visitorList].sort((a, b) => {
      let valA: any = '';
      let valB: any = '';

      if (sortField === 'visitorName') {
        valA = a.visitorName.toLowerCase();
        valB = b.visitorName.toLowerCase();
      } else if (sortField === 'jobTitle') {
        valA = a.jobTitle.toLowerCase();
        valB = b.jobTitle.toLowerCase();
      } else if (sortField === 'date') {
        valA = a.date;
        valB = b.date;
      } else if (sortField === 'arrivalTime') {
        valA = a.arrivalTime.toLowerCase();
        valB = b.arrivalTime.toLowerCase();
      } else if (sortField === 'attachmentName') {
        valA = (a.attachmentName || '').toLowerCase();
        valB = (b.attachmentName || '').toLowerCase();
      }

      if (typeof valA === 'string' && typeof valB === 'string') {
        return sortDirection === 'asc' ? valA.localeCompare(valB, 'ar') : valB.localeCompare(valA, 'ar');
      }

      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [visitorList, sortField, sortDirection]);

  const reloadData = () => {
    const list = dbInstance.getVisitors().filter(v => v.schoolId === schoolId);
    setVisitorList(list);
  };

  useEffect(() => {
    reloadData();
  }, [schoolId, dbTick]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData(p => ({
        ...p,
        fileBase64: reader.result as string,
        fileName: file.name
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.visitorName || !formData.jobTitle) {
      alert('الرجاء كتابة اسم الموجه ووظيفته بالتفصيل');
      return;
    }

    setSaving(true);
    const payload: VisitorLog = {
      id: 'visit_' + Date.now(),
      schoolId,
      schoolName,
      visitorName: formData.visitorName,
      jobTitle: formData.jobTitle,
      day: formData.day,
      date: formData.date,
      arrivalTime: formData.arrivalTime || '---',
      attachmentName: formData.fileName,
      attachmentData: formData.fileBase64
    };

    dbInstance.saveVisitor(payload);
    setTimeout(() => {
      setSaving(false);
      setFormData({
        visitorName: '',
        jobTitle: '',
        day: 'الأحد',
        date: new Date().toISOString().split('T')[0],
        arrivalTime: '',
        fileBase64: '',
        fileName: ''
      });
      alert('تم تقييد الزيارة بنجاح ومزامنة التقرير سحابياً للأرشيف الفوري بالإدارة.');
      reloadData();
    }, 500);
  };

  const handleDelete = (id: string) => {
    dbInstance.deleteVisitor(id);
    reloadData();
  };

  return (
    <div className="space-y-6">
      
      {/* Input log form */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
        <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Clock size={20} className="text-blue-600 animate-spin-slow" />
          تقييد زيارات الموجهين ودفتر الحضور الإداري للمتابعة
        </h2>

        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">اسم المدرسة المنسوب إليها السجل</label>
              <input
                type="text"
                readOnly
                disabled
                value={school.name}
                className="w-full px-3 py-1.5 text-sm bg-slate-100 border border-slate-200 rounded text-right text-slate-600 font-bold cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">اسم الموجه / الزائر رباعياً *</label>
              <input
                type="text"
                value={formData.visitorName}
                onChange={e => setFormData(p => ({ ...p, visitorName: e.target.value }))}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">الصفة الوظيفية (توجيه مادة/إداري...) *</label>
              <input
                type="text"
                placeholder="مثال: موجه مالي وإداري بالإدارة"
                value={formData.jobTitle}
                onChange={e => setFormData(p => ({ ...p, jobTitle: e.target.value }))}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">اليوم</label>
              <select
                value={formData.day}
                onChange={e => setFormData(p => ({ ...p, day: e.target.value }))}
                className="w-full px-3 py-1.5 text-sm bg-white text-black font-black border border-slate-350 rounded text-right focus:outline-none focus:border-blue-500 shadow-xs focus:ring-1 focus:ring-blue-500"
              >
                {['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'السبت'].map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">ساعة الحضور الفعلي</label>
              <input
                type="text"
                placeholder="مثال: 08:30 صباحا"
                value={formData.arrivalTime}
                onChange={e => setFormData(p => ({ ...p, arrivalTime: e.target.value }))}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded text-right focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-2">
            
            {/* Attachment inputs stored base64 */}
            <div className="max-w-md">
              <label className="block text-xs font-bold text-slate-600 mb-1">
                مسح التكليف اليومي للزائر (إرفاق ملف PDF, JPG, PNG)
              </label>
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1 px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs rounded font-bold cursor-pointer transition">
                  <Upload size={14} />
                  اختر الملف الممسوح ضوئياً
                  <input
                    type="file"
                    accept=".pdf, .png, .jpg, .jpeg"
                    onChange={handleFileUpload}
                    className="absolute opacity-0 pointer-events-none"
                  />
                </label>
                {formData.fileName && (
                  <span className="text-xs text-green-700 font-semibold truncate animate-pulse">
                    ✓ {formData.fileName}
                  </span>
                )}
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2 bg-gradient-to-l from-[#1565C0] to-[#1E88E5] hover:brightness-110 active:scale-95 text-white rounded text-xs font-black shadow-md transition-all shrink-0 cursor-pointer"
            >
              {saving ? 'جاري رفع الملف للتخزين السحابي...' : 'تسجيل الزيارة والتقرير وتأكيده'}
            </button>
          </div>
        </form>
      </div>

      {/* List logs */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900">سجلات زيارة التوجيه والمتابعة المقيدة</h3>

        <div className="overflow-x-auto border border-slate-200/80 rounded-xl shadow-xs transition-all duration-300 hover:shadow-sm">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-gradient-to-r from-[#0D47A1] via-[#1565C0] to-[#1E88E5] text-white font-bold select-none cursor-pointer animate-fade-in">
                <th onClick={() => handleSort('visitorName')} className="p-3 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-start">
                    <span>اسم الزائر</span>
                    <SortIndicator field="visitorName" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('jobTitle')} className="p-3 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 group">
                  <div className="flex items-center gap-1 justify-start">
                    <span>الوظيفة / التكليف</span>
                    <SortIndicator field="jobTitle" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('date')} className="p-3 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 font-mono text-center group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>اليوم والتاريخ</span>
                    <SortIndicator field="date" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('arrivalTime')} className="p-3 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 text-center group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>ساعة الحضور</span>
                    <SortIndicator field="arrivalTime" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th onClick={() => handleSort('attachmentName')} className="p-3 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 text-center group">
                  <div className="flex items-center gap-1 justify-center">
                    <span>المرفقات الضوئية</span>
                    <SortIndicator field="attachmentName" currentField={sortField} direction={sortDirection} />
                  </div>
                </th>
                <th className="p-3 border border-blue-700/10 bg-gradient-to-b from-[#1E88E5] via-[#1565C0] to-[#0D47A1] transition-all duration-300 hover:brightness-110 text-center">الخيارات</th>
              </tr>
            </thead>
            <tbody>
              {sortedVisitorList.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center p-6 text-slate-400 bg-slate-50/20">
                    لم يحفظ الدفتر أي زيارة مقيدة للمدرسة للعام الدراسي الجاري
                  </td>
                </tr>
              ) : (
                sortedVisitorList.map(visit => (
                  <tr key={visit.id} className="hover:bg-gradient-to-r hover:from-blue-50/70 hover:to-indigo-50/40 hover:shadow-[0_4px_15px_-3px_rgba(21,101,192,0.12)] transition-all duration-300 ease-out border-b border-slate-100 hover:translate-x-[-2px] relative z-0 hover:z-10">
                    <td className="p-3 font-semibold text-slate-900 border border-slate-105">{visit.visitorName}</td>
                    <td className="p-3 text-slate-650 border border-slate-105">{visit.jobTitle}</td>
                    <td className="p-3 text-center border border-slate-105 font-mono">{visit.day} {visit.date}</td>
                    <td className="p-3 text-center border border-slate-105 font-mono font-bold">{visit.arrivalTime}</td>
                    <td className="p-3 text-center border border-slate-105">
                      {visit.attachmentName ? (
                        <a
                          href={visit.attachmentData || '#'}
                          download={visit.attachmentName}
                          className="bg-blue-50 text-blue-700 hover:underline px-2 py-0.5 rounded text-[10px] font-bold"
                          title="تحميل مرفق الزيارة الفوري"
                        >
                          تحميل {visit.attachmentName.substring(0, 15)}...
                        </a>
                      ) : (
                        <span className="text-slate-400 text-[10px]">بدون مرفقات</span>
                      )}
                    </td>
                    <td className="p-3 text-center border border-slate-105">
                      {confirmDeleteId === visit.id ? (
                        <div className="flex items-center gap-1 bg-rose-50 border border-rose-200 rounded p-0.5 animate-pulse">
                          <button
                            type="button"
                            onClick={() => {
                              handleDelete(visit.id);
                              setConfirmDeleteId(null);
                            }}
                            className="px-1.5 py-0.2 bg-rose-600 text-white font-black rounded text-[8px] cursor-pointer"
                          >
                            تأكيد
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-1.5 py-0.2 border border-slate-300 text-slate-700 font-black rounded text-[8px] cursor-pointer bg-white"
                          >
                            إلغاء
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(visit.id)}
                          className="p-1 text-red-600 hover:bg-red-50 rounded transition cursor-pointer"
                          title="حذف المحضر"
                        >
                          <Trash2 size={12} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 10: SCHOOL NUTRITION STATS
// ----------------------------------------------------
function NutritionTab({ schoolId, dbTick }: { schoolId: string; dbTick: number }) {
  const school = dbInstance.getSchools().find(s => s.id === schoolId) || { name: '', stage: '' };
  const [records, setRecords] = useState<NutritionRecord[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  
  // Form fields
  const [academicYear, setAcademicYear] = useState('٢٠٢٥/٢٠٢٦');
  const [beneficiaries, setBeneficiaries] = useState(155);
  const [distDays, setDistDays] = useState(30);
  const [saving, setSaving] = useState(false);

  // Load all records for this school
  const loadRecords = () => {
    const list = dbInstance.getNutritionRecords().filter(n => n.schoolId === schoolId);
    setRecords(list);
  };

  useEffect(() => {
    loadRecords();
    // Default form configuration
    setAcademicYear('٢٠٢٥/٢٠٢٦');
    setBeneficiaries(155);
    setDistDays(30);
    setActiveId(null);
  }, [schoolId, dbTick]);

  const triggerNewYear = () => {
    setActiveId('nut_new_' + Date.now());
    setAcademicYear('');
    setBeneficiaries(120);
    setDistDays(30);
  };

  const startEdit = (rec: NutritionRecord) => {
    setActiveId(rec.id);
    setAcademicYear(rec.academicYear);
    setBeneficiaries(rec.beneficiariesCount);
    setDistDays(rec.distributionDays);
  };

  const handleDelete = (id: string, year: string) => {
    dbInstance.deleteNutritionRecord(id);
    loadRecords();
    if (activeId === id) {
      setActiveId(null);
      setAcademicYear('');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!academicYear.trim()) {
      alert('الرجاء إدخال العام الدراسي يدوياً (مثال: ٢٠٢٥/٢٠٢٦)');
      return;
    }

    setSaving(true);

    const payload: NutritionRecord = {
      id: activeId && !activeId.startsWith('nut_new_') ? activeId : 'nut_record_' + Date.now(),
      schoolId,
      academicYear: academicYear.trim(),
      distributionDays: Number(distDays) || 0,
      beneficiariesCount: Number(beneficiaries) || 0
    };

    dbInstance.saveNutritionRecord(payload);

    setTimeout(() => {
      setSaving(false);
      setActiveId(null);
      setAcademicYear('');
      setBeneficiaries(120);
      setDistDays(30);
      loadRecords();
      alert('تم حفظ كشف التغذية وإرساله إلى المنصة الإدارية بنجاح 💫');
    }, 450);
  };

  // Live estimated meals sum
  const liveTotal = beneficiaries * distDays;

  return (
    <div className="space-y-6">
      
      {/* Introduction Card */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Apple size={20} className="text-emerald-600" />
            منظومة أرشفة التغذية المدرسية الصحية وتراكم السجلات
          </h2>
          <p className="text-xs text-slate-500 mt-1">تتبع كشوفات مستحقي الوجبات، التوزيع السنوي، وإحصاءات الهيئات والوجبات التقديرية لكل عام مالي.</p>
        </div>

        {(!activeId) && (
          <button
            type="button"
            onClick={triggerNewYear}
            className="px-4 py-2 bg-gradient-to-l from-emerald-600 to-teal-500 hover:brightness-110 active:scale-95 text-white rounded-lg text-xs font-black shadow-md transition-all cursor-pointer flex items-center gap-1"
          >
            <Plus size={14} />
            إضافة عام دراسي جديد
          </button>
        )}
      </div>

      {/* Form Overlay - Open when adding or editing */}
      {(activeId !== null || records.length === 0) && (
        <form onSubmit={handleSave} className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4 animate-fade-in">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-800">
              {activeId && !activeId.startsWith('nut_new_') ? `تحديث كشف العام الدراسي الحالي: ${academicYear}` : 'تسجيل وإشهار ميزانية تغذية لعام دراسي جديد'}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">الرجاء إدخال البيانات المعتمدة لتقوم المنصة التنسيقية بحساب الجمع التلقائي.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5">اسم المدرسة المنسوب إليها السجل</label>
              <input
                type="text"
                readOnly
                disabled
                value={school.name}
                className="w-full px-3 py-1.5 text-sm bg-slate-100 border border-slate-200 rounded text-right text-slate-600 font-bold cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1.5">العام الدراسي (كتابة يدوية) *</label>
              <input
                type="text"
                placeholder="مثال: ٢٠٢٥/٢٠٢٦"
                value={academicYear}
                onChange={e => setAcademicYear(e.target.value)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded font-bold text-slate-800 focus:outline-none focus:border-blue-500 font-mono text-center"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1.5">عدد التلاميذ المستحقين للوجبة *</label>
              <input
                type="number"
                min="0"
                step="any"
                onKeyDown={handleDecimalKeyDown}
                value={beneficiaries}
                onChange={e => setBeneficiaries(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded font-mono font-bold text-slate-800 focus:outline-none focus:border-blue-500 text-center"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1.5">أيام التوزيع المعتمدة بجدول العام *</label>
              <input
                type="number"
                min="0"
                step="any"
                onKeyDown={handleDecimalKeyDown}
                value={distDays}
                onChange={e => setDistDays(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-1.5 text-sm bg-white border border-slate-200 rounded font-mono font-bold text-slate-800 focus:outline-none focus:border-blue-500 text-center"
              />
            </div>

            <div className="bg-emerald-50/50 border border-emerald-100 p-2.5 rounded text-center leading-tight">
              <span className="block text-[10px] text-slate-500 font-bold mb-0.5">إجمالي الوجبات التقديرية للعام:</span>
              <strong className="text-sm font-mono text-emerald-800 font-black">
                {liveTotal.toLocaleString('ar-EG')} وجبة
              </strong>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 bg-gradient-to-l from-blue-700 to-indigo-600 hover:brightness-110 active:scale-95 text-white rounded text-xs font-black shadow-md transition-all cursor-pointer"
            >
              {saving ? 'جاري الحفظ للتنسيق...' : 'حفظ ونشر التعديلات فوراً ✓'}
            </button>
            {records.length > 0 && (
              <button
                type="button"
                onClick={() => setActiveId(null)}
                className="px-4 py-2 border border-slate-200 text-slate-500 hover:bg-slate-50 font-bold rounded text-xs transition cursor-pointer"
              >
                إلغاء النافذة
              </button>
            )}
          </div>
        </form>
      )}

      {/* History Ledger Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 space-y-4">
        <div>
          <h3 className="text-sm font-black text-slate-800">موجز السجل التاريخي للأعوام الدراسية بالمنشأة</h3>
          <p className="text-[11px] text-slate-505">محفوظات التغذية المعتمدة والمرحلة للتنسيق العام بإدارة أبوحماد</p>
        </div>

        <div className="overflow-x-auto border border-slate-150 rounded-lg">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-slate-900 text-white font-bold">
                <th className="p-2.5 border text-center">العام الدراسي</th>
                <th className="p-2.5 border text-center">عدد التلاميذ المستحقين</th>
                <th className="p-2.5 border text-center">أيام التوزيع</th>
                <th className="p-2.5 border text-center bg-slate-800">إجمالي الوجبات السنوية التقديرية</th>
                <th className="p-2.5 border text-center">الأفعال والتعديل الإداري</th>
              </tr>
            </thead>
            <tbody>
              {records.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-400 font-black">
                    لا يوجد كشوفات أو أعوام دراسية تغذية مقيدة للمدرسة حالياً. قم بإدراج عام دراسي للبدء.
                  </td>
                </tr>
              ) : (
                records.map(rec => {
                  const totalMeals = rec.beneficiariesCount * rec.distributionDays;
                  const isCurrentEditing = activeId === rec.id;
                  
                  return (
                    <tr key={rec.id} className={`hover:bg-slate-50 border-b border-slate-100/90 ${isCurrentEditing ? 'bg-indigo-50/40 font-bold' : ''}`}>
                      <td className="p-2.5 text-center border font-mono font-black text-slate-900">{rec.academicYear}</td>
                      <td className="p-2.5 text-center border font-mono font-bold">{rec.beneficiariesCount} تلميذ</td>
                      <td className="p-2.5 text-center border font-mono font-bold">{rec.distributionDays} يوم توزيح</td>
                      <td className="p-2.5 text-center border font-mono font-black text-blue-900 bg-slate-50/80">
                        {totalMeals.toLocaleString('ar-EG')} وجبة
                      </td>
                      <td className="p-2 border text-center w-40">
                        <div className="flex gap-1.5 justify-center">
                          <button
                            type="button"
                            onClick={() => startEdit(rec)}
                            className="p-1 px-2 border border-blue-200 bg-blue-50 text-blue-750 hover:bg-blue-105 rounded text-[10px] font-extrabold cursor-pointer transition flex items-center gap-0.5"
                          >
                            <Edit size={10} />
                            تعديل
                          </button>
                          {confirmDeleteId === rec.id ? (
                            <div className="flex items-center gap-1 bg-rose-50 border border-rose-200 rounded p-0.5 animate-pulse">
                              <button
                                type="button"
                                onClick={() => {
                                  handleDelete(rec.id, rec.academicYear);
                                  setConfirmDeleteId(null);
                                }}
                                className="px-1.5 py-0.2 bg-rose-600 text-white font-black rounded text-[8px] cursor-pointer"
                              >
                                تأكيد
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(null)}
                                className="px-1.5 py-0.2 border border-slate-300 text-slate-700 font-black rounded text-[8px] cursor-pointer bg-white"
                              >
                                إلغاء
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(rec.id)}
                              className="p-1 px-2 text-rose-650 hover:bg-rose-50 rounded text-[10px] font-extrabold cursor-pointer transition flex items-center gap-0.5"
                            >
                              <Trash2 size={10} />
                              حذف
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

// ----------------------------------------------------
// TAB 11: SCHOOL REPORTS & LOCALIZED ARCHIVING SNAPSHOTS
// ----------------------------------------------------
function PrincipalReportsTab({ school, dbTick }: { school: School; dbTick: number }) {
  const [snapshots, setSnapshots] = useState<any[]>([]);
  const [newSnapshotName, setNewSnapshotName] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [exportingPdf, setExportingPdf] = useState(false);

  // Load snapshots from localstorage
  useEffect(() => {
    const saved = localStorage.getItem(`school_${school.id}_snapshots`);
    if (saved) {
      try {
        setSnapshots(JSON.parse(saved));
      } catch (e) {
        setSnapshots([]);
      }
    }
  }, [school.id]);

  const saveSnapshots = (newSnaps: any[]) => {
    setSnapshots(newSnaps);
    localStorage.setItem(`school_${school.id}_snapshots`, JSON.stringify(newSnaps));
  };

  const handleCreateSnapshot = () => {
    const name = newSnapshotName.trim();
    if (!name) {
      alert('يرجى كتابة اسم للفترة الأرشيفية.');
      return;
    }

    const schoolCounts = dbInstance.getMaterialCounts().filter(c => c.schoolId === school.id);
    const schoolStaff = dbInstance.getStaff().filter(s => s.schoolId === school.id);
    const schoolLeadership = dbInstance.getLeadership().filter(l => l.schoolId === school.id);

    const newSnapshot = {
      id: 'snap_' + Date.now(),
      name,
      createdAt: new Date().toISOString(),
      school,
      materialCounts: schoolCounts,
      staff: schoolStaff,
      leadership: schoolLeadership
    };

    const updated = [newSnapshot, ...snapshots];
    saveSnapshots(updated);
    setNewSnapshotName('');
    alert('تم التقاط وحفظ اللقطة الأرشيفية للمدرسة بنجاح.');
  };

  const handleDeleteSnapshot = (id: string) => {
    const updated = snapshots.filter(s => s.id !== id);
    saveSnapshots(updated);
    alert('تم حذف اللقطة الأرشيفية.');
  };

  const handleExportJSON = () => {
    if (snapshots.length === 0) {
      alert('لا توجد لقطات أرشيفية لتصديرها.');
      return;
    }
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(snapshots, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `أرشيف_سجلات_${school.name}_أبوحماد.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          const merged = [...parsed, ...snapshots];
          saveSnapshots(merged);
          alert('تم استيراد اللقطات الأرشيفية بنجاح.');
        } else {
          alert('تنسيق ملف الأرشيف غير صالح.');
        }
      } catch (err) {
        alert('فشل قراءة ملف الأرشيف.');
      }
    };
    reader.readAsText(file);
  };

  // Detailed teacher calculations for the school reports view
  const schoolDetailedRows = useMemo(() => {
    const allMats = dbInstance.getMaterials();
    const applicableMats = allMats.filter(m => dbInstance.isMaterialApplicableToSchool(school.stage, m.stage));
    const schoolCounts = dbInstance.getMaterialCounts().filter(c => c.schoolId === school.id);

    return applicableMats.map(mat => {
      const count = schoolCounts.find(c => c.materialId === mat.id);
      const metrics = dbInstance.calculateMaterialMetrics(school, mat, count);

      return {
        materialName: mat.name,
        materialQuota: mat.quota || 0,
        refQuota: metrics.refQuota || 0,
        present: metrics.present,
        needed: metrics.needed,
        deficit: metrics.deficit,
        surplus: metrics.surplus,
        totalLessons: metrics.totalLessons,
        coveredLessons: metrics.coveredLessons,
        periodDeficit: metrics.periodDeficit,
        periodSurplus: metrics.periodSurplus,
        coveragePercentage: metrics.percentage
      };
    });
  }, [school, dbTick]);

  const schoolStaff = useMemo(() => {
    return dbInstance.getStaff().filter(s => s.schoolId === school.id);
  }, [school.id, dbTick]);

  const schoolTeacherAbsences = useMemo(() => {
    return dbInstance.getTeacherAbsences()
      .filter(a => a.schoolId === school.id)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [school.id, dbTick]);

  const schoolStudentAbsences = useMemo(() => {
    return dbInstance.getStudentAbsences()
      .filter(a => a.schoolId === school.id)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [school.id, dbTick]);

  const handleExportPdf = async () => {
    const element = document.getElementById('school-comprehensive-report-container');
    if (!element) {
      alert('لم يتم العثور على منطقة التقرير للطباعة.');
      return;
    }
    setExportingPdf(true);

    // Backup original styles of element and all parent elements to allow full expansion
    const originalStyle = element.style.cssText;
    const originalParents: { el: HTMLElement; cssText: string }[] = [];

    try {
      element.style.cssText += '; width: 210mm !important; max-width: none !important; height: auto !important; max-height: none !important; overflow: visible !important;';
      
      let p = element.parentElement;
      while (p && p !== document.body) {
        originalParents.push({ el: p, cssText: p.style.cssText });
        p.style.cssText += '; overflow: visible !important; height: auto !important; max-height: none !important;';
        p = p.parentElement;
      }

      const canvas = await withOklchBypass(async () => {
        return await html2canvas(element, {
          scale: 2,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff'
        });
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`تقرير_العجز_والزيادة_الكلي_${school.name}.pdf`);
    } catch (err) {
      console.error(err);
      alert('فشل تصدير ملف PDF.');
    } finally {
      // Restore original styles
      originalParents.forEach(op => {
        op.el.style.cssText = op.cssText;
      });
      element.style.cssText = originalStyle;
      setExportingPdf(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* LOCAL JSON BOOKKEEPING CENTRE */}
      <div className="bg-[#FAF9F5] border-2 border-[#D4AF37] rounded-xl p-6 space-y-4 shadow-sm select-none">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 pb-3 border-b border-[#D4AF37]/35">
          <div>
            <h3 className="text-md font-extrabold text-[#7F600D] flex items-center gap-2">
              <History className="text-[#D4AF37] w-5 h-5 shadow-3xs rounded-full" />
              مركز أرشفة السجلات التاريخية والنسخ المرجعية اللحظية (JSON) للتوثيق
            </h3>
            <p className="text-[11px] text-slate-600 mt-1 font-bold">
              حفظ وتوثيق لقطات كاملة لهيكل المدرسة ومعلميها، للحفظ السهل واسترجاع البيانات بملف أرشيفي بدون تداخل أو مقارنات
            </p>
          </div>

          <div className="flex flex-wrap gap-2 text-xs font-bold font-sans">
            <label className="px-3.5 py-1.5 bg-gradient-to-r from-[#00897B] to-[#00695C] hover:from-[#00695C] hover:to-[#004D40] text-white rounded-lg transition cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95">
              <Upload size={13} />
              استيراد أرشيف (JSON)
              <input
                type="file"
                accept=".json"
                onChange={handleImportJSON}
                className="hidden"
              />
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 pt-1 text-right">
          {/* Capture section */}
          <div className="space-y-2 lg:border-l lg:border-slate-200 lg:pl-4">
            <h4 className="text-xs font-black text-slate-800">
              <span className="text-indigo-600 font-extrabold text-sm">●</span> تسجيل لقطة أرشيفية للبيانات الحالية:
            </h4>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="اكتب تسمية للنسخة (مثلاً: أرشيف ما قبل المظاريف)..."
                value={newSnapshotName}
                onChange={e => setNewSnapshotName(e.target.value)}
                className="flex-1 px-3 py-1.5 text-xs bg-white text-black border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-600 font-sans"
              />
              <button
                type="button"
                onClick={handleCreateSnapshot}
                className="px-3.5 py-1.5 bg-gradient-to-r from-[#5E35B1] to-[#3949AB] hover:from-[#4527A0] hover:to-[#283593] text-white font-extrabold rounded-lg text-xs transition cursor-pointer flex items-center gap-1 shadow-sm shrink-0"
              >
                <Plus size={12} />
                حفظ بالأرشيف
              </button>
            </div>
          </div>

          {/* List Section */}
          <div className="space-y-2 lg:col-span-2">
            <h4 className="text-xs font-black text-slate-800">
              <span className="text-emerald-700 font-extrabold text-sm">●</span> لقطات السجلات المرجعية الموثقة:
            </h4>
            {snapshots.length > 0 ? (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {snapshots.map(snap => (
                  <div
                    key={snap.id}
                    className="text-[10px] items-center gap-1.5 px-2.5 py-1 rounded-md border flex bg-white border-slate-200 text-slate-700 font-bold hover:bg-slate-50 shadow-3xs"
                  >
                    <span>📦 {snap.name} ({new Date(snap.createdAt).toLocaleDateString('ar-EG')})</span>
                    {confirmDeleteId === snap.id ? (
                      <div className="flex items-center gap-1 bg-red-50 p-0.5 rounded">
                        <button
                          type="button"
                          onClick={() => {
                            handleDeleteSnapshot(snap.id);
                            setConfirmDeleteId(null);
                          }}
                          className="px-1.5 py-0.2 bg-rose-600 text-white rounded text-[8px] font-bold cursor-pointer"
                        >
                          تأكيد
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(null)}
                          className="px-1.5 py-0.2 bg-slate-200 text-slate-705 rounded text-[8px] font-bold cursor-pointer"
                        >
                          تراجع
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(snap.id)}
                        className="w-3.5 h-3.5 text-rose-600 hover:bg-rose-50 text-[8.5px] rounded-full flex items-center justify-center border border-rose-200 cursor-pointer text-center"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[10.5px] text-slate-500 italic pt-1 font-bold">
                لا توجد سجلات تاريخية محفوظة للمدرسة حالياً.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* COMPREHENSIVE SCHOOL REPORT TABLE WITH PDF EXPORT */}
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200/80 p-6 space-y-4">
        <div className="flex justify-between items-center border-b border-slate-100 pb-3.5 flex-wrap gap-3">
          <div>
            <h2 className="text-md font-extrabold text-slate-900 flex items-center gap-2">
              <FileText className="text-blue-700" size={20} />
              تقرير العجز والزيادة التفصيلي الشامل ومعايير سد الفجوات
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              تقرير ومذكرة معيارية مجمعة للأنصبة والحصص وعجز/زيادة الكوادر التدريسية لمدرسة: {school.name}
            </p>
          </div>

          <button
            type="button"
            onClick={handleExportPdf}
            disabled={exportingPdf}
            className="px-4 py-2 bg-gradient-to-r from-[#1976D2] to-[#0D47A1] hover:from-[#0D47A1] text-white font-extrabold rounded-xl text-xs transition cursor-pointer flex items-center gap-2 shadow-md active:scale-95 disabled:opacity-50"
          >
            <FileText size={13} />
            {exportingPdf ? 'جاري تصدير PDF...' : 'تصدير التقرير كـ PDF 📄'}
          </button>
        </div>

        <div id="school-comprehensive-report-container" className="p-4 bg-white space-y-6">
          <PrintableReport
            title={`التقرير الشامل والأرشيف المعتمد لمدرسة: ${school.name}`}
            subtitle={`دراسة إحصائية تفصيلية لميزان المعلمين والأنصبة والكوادر الحالية والغياب لعام ${school.year}`}
          >
            <div className="space-y-8 text-right font-sans" dir="rtl">
              {/* Snapshot header notice */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-800 space-y-1">
                <p className="font-extrabold text-blue-900">🏢 البيانات الأساسية للمؤسسة التعليمية:</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-[11px] pt-1 text-slate-700">
                  <div>المرحلة الدراسية: <span className="font-black text-slate-900">{STAGE_LABELS[school.stage]}</span></div>
                  <div>إجمالي الفصول المعتمدة: <span className="font-mono font-black text-[#0D47A1]">{school.classroomsCount} فصلاً</span></div>
                  <div>المقيد بنين: <span className="font-mono font-bold text-slate-900">{school.boysCount || 0} طالباً</span></div>
                  <div>المقيد بنات: <span className="font-mono font-bold text-slate-900">{school.girlsCount || 0} طالبةً</span></div>
                </div>
              </div>

              {/* Section 1 */}
              <div className="space-y-3">
                <h3 className="text-sm font-black text-slate-900 border-r-4 border-blue-700 pr-2">
                  أولاً: ميزان أنصبة المواد الدراسية وحساب العجز والزيادة
                </h3>
                <p className="text-[11px] text-slate-500">يوضح الجدول التالي العجز والزيادة في عدد المعلمين والأنصبة والحصص الأسبوعية الفعلية لكل مادة دراسية:</p>
                
                <div className="overflow-x-auto border border-slate-200 rounded-lg">
                  <table className="w-full text-right text-[10px] border-collapse">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                        <th className="p-2 border-l font-bold text-slate-900">المادة الدراسية</th>
                        <th className="p-2 border-l text-center font-bold">الفصول</th>
                        <th className="p-2 border-l text-center font-bold">نصاب المادة</th>
                        <th className="p-2 border-l text-center font-bold">نصاب المعلم</th>
                        <th className="p-2 border-l text-center font-bold bg-blue-50 text-blue-900">الموجود</th>
                        <th className="p-2 border-l text-center font-bold bg-amber-50 text-amber-950">المطلوب</th>
                        <th className="p-2 border-l text-center font-bold bg-red-50 text-red-900">عجز (معلم)</th>
                        <th className="p-2 border-l text-center font-bold bg-emerald-50 text-emerald-950">زيادة (معلم)</th>
                        <th className="p-2 border-l text-center font-bold">إجمالي الحصص</th>
                        <th className="p-2 border-l text-center font-bold text-green-900">المغطاة</th>
                        <th className="p-2 border-l text-center font-bold text-rose-900">عجز الحصص</th>
                        <th className="p-2 border-l text-center font-bold text-emerald-900">زيادة الحصص</th>
                        <th className="p-2 text-center font-bold bg-slate-200 text-slate-950">التغطية %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {schoolDetailedRows.map((row, idx) => (
                        <tr key={idx} className="border-b hover:bg-slate-50/50 transition font-sans">
                          <td className="p-2 border-l font-semibold text-slate-900">{row.materialName}</td>
                          <td className="p-2 border-l text-center font-mono font-bold text-slate-600">{school.classroomsCount}</td>
                          <td className="p-2 border-l text-center font-mono">{row.materialQuota}</td>
                          <td className="p-2 border-l text-center font-mono">{row.refQuota}</td>
                          <td className="p-2 border-l text-center font-mono font-black text-blue-900 bg-blue-50/10">{row.present}</td>
                          <td className="p-2 border-l text-center font-mono font-black text-amber-900 bg-amber-50/10">{row.needed}</td>
                          <td className={`p-2 border-l text-center font-mono font-bold ${row.deficit > 0 ? 'text-red-700 bg-red-50' : 'text-slate-300'}`}>
                            {row.deficit > 0 ? row.deficit : '---'}
                          </td>
                          <td className={`p-2 border-l text-center font-mono font-bold ${row.surplus > 0 ? 'text-emerald-700 bg-emerald-50' : 'text-slate-300'}`}>
                            {row.surplus > 0 ? row.surplus : '---'}
                          </td>
                          <td className="p-2 border-l text-center font-mono font-semibold text-slate-800">{row.totalLessons}</td>
                          <td className="p-2 border-l text-center font-mono font-semibold text-green-900">{row.coveredLessons}</td>
                          <td className={`p-2 border-l text-center font-mono font-bold ${row.periodDeficit > 0 ? 'text-rose-800 bg-rose-50/30' : 'text-slate-300'}`}>
                            {row.periodDeficit > 0 ? row.periodDeficit : '---'}
                          </td>
                          <td className={`p-2 border-l text-center font-mono font-bold ${row.periodSurplus > 0 ? 'text-emerald-800 bg-emerald-50/30' : 'text-slate-300'}`}>
                            {row.periodSurplus > 0 ? row.periodSurplus : '---'}
                          </td>
                          <td className={`p-2 text-center font-mono font-black ${
                            row.coveragePercentage >= 100 ? 'bg-emerald-100/40 text-emerald-950 font-black' :
                            row.coveragePercentage >= 75 ? 'bg-yellow-50 font-bold' : 'bg-rose-100/30 text-rose-950 font-black'
                          }`}>
                            {row.coveragePercentage}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Section 2 */}
              <div className="space-y-3">
                <h3 className="text-sm font-black text-slate-900 border-r-4 border-indigo-700 pr-2">
                  ثانياً: سجل الكوادر البشرية والتكليفات والوظائف المحددة بالمدرسة
                </h3>
                <p className="text-[11px] text-slate-500">يسرد الجدول التالي الطاقم الفعلي المسجل بالمؤسسة مع توضيح أدوارهم والتكليفات المسندة إليهم رسمياً في الجداول المدرسية:</p>
                
                <div className="overflow-x-auto border border-slate-200 rounded-lg">
                  <table className="w-full text-right text-[10px] border-collapse">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
                        <th className="p-2 border-l font-bold text-slate-900">#</th>
                        <th className="p-2 border-l font-bold text-slate-900">الاسم رباعياً</th>
                        <th className="p-2 border-l font-bold text-slate-900">الرقم القومي</th>
                        <th className="p-2 border-l font-bold text-slate-900">الكود المالي</th>
                        <th className="p-2 border-l font-bold text-slate-900 text-center">الوظيفة</th>
                        <th className="p-2 border-l font-bold text-slate-900">التخصص المحدد</th>
                        <th className="p-2 border-l font-bold text-slate-900 text-center bg-indigo-50 text-indigo-950">العمل المكلف به بالمدرسة</th>
                        <th className="p-2 border-l font-bold text-slate-900">المؤهل وتاريخ التعيين</th>
                        <th className="p-2 text-center font-bold">التبعية المدرسية</th>
                      </tr>
                    </thead>
                    <tbody>
                      {schoolStaff.length > 0 ? (
                        schoolStaff.map((member, idx) => {
                          const roleLabels: Record<string, string> = {
                            teacher: 'معلم',
                            specialist: 'أخصائي',
                            admin: 'إداري',
                            worker: 'عامل'
                          };
                          return (
                            <tr key={member.id} className="border-b hover:bg-slate-50/50 transition font-sans">
                              <td className="p-2 border-l font-mono text-slate-400">{idx + 1}</td>
                              <td className="p-2 border-l font-bold text-slate-900">{member.name}</td>
                              <td className="p-2 border-l font-mono text-slate-700">{member.nationalId}</td>
                              <td className="p-2 border-l font-mono text-slate-600">{member.code || '---'}</td>
                              <td className="p-2 border-l text-center">
                                <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-[9px] font-black">
                                  {roleLabels[member.role] || member.role}
                                </span>
                              </td>
                              <td className="p-2 border-l font-semibold text-slate-750">{member.specialty || 'عام'}</td>
                              <td className="p-2 border-l font-black text-indigo-850 bg-indigo-50/20">{member.assignedJob || '---'}</td>
                              <td className="p-2 border-l text-slate-600">
                                <span className="font-medium text-[10px]">{member.qualification || '---'}</span>
                                {member.appointmentDate && <span className="block text-[8px] text-slate-400">تعيين: {member.appointmentDate}</span>}
                              </td>
                              <td className="p-2 text-center font-bold">
                                <span className={`px-1.5 py-0.5 rounded text-[9px] ${
                                  member.type === 'delegated' ? 'bg-amber-100 text-amber-850' : 'bg-green-100 text-green-800'
                                }`}>
                                  {member.type === 'delegated' ? 'منتدب للمدرسة' : 'أصلي بالمدرسة'}
                                </span>
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={9} className="p-4 text-center text-slate-400 italic">لا توجد سجلات كوادر مضافة بالمدرسة بعد.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Section 3 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3 border border-slate-100 p-3 rounded-lg bg-slate-50/50">
                  <h3 className="text-xs font-black text-[#0D47A1] border-r-3 border-[#0D47A1] pr-1.5">
                    ثالثاً: ملخص حضور وغياب الكوادر التعليمية بالمدرسة
                  </h3>
                  {schoolTeacherAbsences.length > 0 ? (
                    <div className="overflow-x-auto border border-slate-200 rounded">
                      <table className="w-full text-[9px] border-collapse text-right bg-white">
                        <thead>
                          <tr className="bg-slate-100 text-slate-800 font-extrabold border-b">
                            <th className="p-1.5 border-l">التاريخ</th>
                            <th className="p-1.5 border-l text-center">المقيد</th>
                            <th className="p-1.5 border-l text-center">الحاضر</th>
                            <th className="p-1.5 border-l text-center">الغائب</th>
                            <th className="p-1.5 border-l text-center text-amber-900">الندب</th>
                            <th className="p-1.5 border-l text-center text-indigo-900">المأمورية</th>
                            <th className="p-1.5 text-center text-rose-900">الإجازات</th>
                          </tr>
                        </thead>
                        <tbody>
                          {schoolTeacherAbsences.slice(0, 5).map(record => (
                            <tr key={record.id} className="border-b hover:bg-slate-50/50">
                              <td className="p-1.5 border-l font-mono font-bold text-slate-700">{record.date}</td>
                              <td className="p-1.5 border-l text-center font-mono font-bold">{record.registered}</td>
                              <td className="p-1.5 border-l text-center font-mono text-emerald-800 font-extrabold">{record.present}</td>
                              <td className="p-1.5 border-l text-center font-mono text-red-700 font-bold">{record.absent}</td>
                              <td className="p-1.5 border-l text-center font-mono text-amber-700">{record.delegated || 0}</td>
                              <td className="p-1.5 border-l text-center font-mono text-indigo-700">{record.mission || 0}</td>
                              <td className="p-1.5 text-center font-mono font-bold text-slate-700">
                                {Number(record.regularLeave || 0) + Number(record.sickLeave || 0)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-[10px] text-slate-400 italic">لا توجد سجلات غياب معلمين مسجلة قريباً.</p>
                  )}
                </div>

                <div className="space-y-3 border border-slate-100 p-3 rounded-lg bg-slate-50/50">
                  <h3 className="text-xs font-black text-rose-800 border-r-3 border-rose-800 pr-1.5">
                    رابعاً: ملخص الغياب المدرسي اليومي للطلاب
                  </h3>
                  {schoolStudentAbsences.length > 0 ? (
                    <div className="overflow-x-auto border border-slate-200 rounded">
                      <table className="w-full text-[9px] border-collapse text-right bg-white">
                        <thead>
                          <tr className="bg-slate-100 text-slate-800 font-extrabold border-b">
                            <th className="p-1.5 border-l">التاريخ</th>
                            <th className="p-1.5 border-l">الصف الدراسي</th>
                            <th className="p-1.5 border-l text-center">المقيد</th>
                            <th className="p-1.5 border-l text-center">الحاضر</th>
                            <th className="p-1.5 text-center">الغائب</th>
                          </tr>
                        </thead>
                        <tbody>
                          {schoolStudentAbsences.slice(0, 5).map(record => (
                            <tr key={record.id} className="border-b hover:bg-slate-50/50">
                              <td className="p-1.5 border-l font-mono font-bold text-slate-700">{record.date}</td>
                              <td className="p-1.5 border-l text-slate-850 font-bold" colSpan={record.records.length > 0 ? 1 : 4}>
                                {record.records?.[0]?.grade || 'مجمع'}
                              </td>
                              {record.records?.[0] && (
                                <>
                                  <td className="p-1.5 border-l text-center font-mono">{record.records[0].registered}</td>
                                  <td className="p-1.5 border-l text-center font-mono text-emerald-800 font-black">{record.records[0].present}</td>
                                  <td className="p-1.5 text-center font-mono text-rose-700 font-black">{record.records[0].absent}</td>
                                </>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-[10px] text-slate-400 italic">لا توجد سجلات غياب طلاب مسجلة قريباً.</p>
                  )}
                </div>
              </div>
            </div>
          </PrintableReport>
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// TAB 10: EXPORT DATA FOR ADMINISTRATION (تصدير البيانات للإدارة)
// ----------------------------------------------------
interface ExportSchoolDataTabProps {
  school: School;
  dbTick: number;
}

function ExportSchoolDataTab({ school, dbTick }: ExportSchoolDataTabProps) {
  const [exportStatus, setExportStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [fileName, setFileName] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [fileUUID, setFileUUID] = useState('');

  // Collect data stats
  const stats = useMemo(() => {
    const leadership = dbInstance.getLeadership().filter(l => l.schoolId === school.id);
    const staff = dbInstance.getStaff().filter(s => s.schoolId === school.id);
    const materialCounts = dbInstance.getMaterialCounts().filter(mc => mc.schoolId === school.id);
    const studentAbsences = dbInstance.getStudentAbsences().filter(sa => sa.schoolId === school.id);
    const teacherAbsences = dbInstance.getTeacherAbsences().filter(ta => ta.schoolId === school.id);
    const visitors = dbInstance.getVisitors().filter(v => v.schoolId === school.id);
    const nutrition = dbInstance.getNutritionRecords().filter(n => n.schoolId === school.id);
    const examNominations = dbInstance.getExamNominations().filter(en => en.schoolId === school.id);
    const examExcuses = dbInstance.getExamExcuses().filter(ee => ee.schoolId === school.id);

    return [
      { name: 'بيانات المدرسة والأنصبة', count: 1, status: 'مكتملة 🟢' },
      { name: 'بيانات القيادة المدرسية', count: leadership.length, status: leadership.length > 0 ? 'مكتملة 🟢' : 'غير مدخلة 🔴' },
      { name: 'بيانات العاملين (معلمين، إداريين...)', count: staff.length, status: staff.length > 0 ? 'مكتملة 🟢' : 'غير مدخلة 🔴' },
      { name: 'أعداد المعلمين والمواد والأنصبة', count: materialCounts.length, status: materialCounts.length > 0 ? 'مكتملة ومحتسبة 🟢' : 'غير مدخلة 🔴' },
      { name: 'غياب الطلاب اليومي', count: studentAbsences.length, status: studentAbsences.length > 0 ? 'مكتملة 🟢' : 'لا يوجد سجلات 🟡' },
      { name: 'غياب المعلمين والكوادر', count: teacherAbsences.length, status: teacherAbsences.length > 0 ? 'مكتملة 🟢' : 'لا يوجد سجلات 🟡' },
      { name: 'سجل الزوار والموجهين الميدانيين', count: visitors.length, status: visitors.length > 0 ? 'مكتملة 🟢' : 'لا يوجد سجلات 🟡' },
      { name: 'إحصاء التغذية المدرسية', count: nutrition.length, status: nutrition.length > 0 ? 'مكتملة 🟢' : 'لا يوجد سجلات 🟡' },
      { name: 'استمارة (1 سري) للمرشحين والاعتذارات', count: examNominations.length + examExcuses.length, status: (examNominations.length + examExcuses.length) > 0 ? 'جاهزة ومؤكدة 🟢' : 'لا يوجد مرشحين 🟡' },
    ];
  }, [school, dbTick]);

  const handleExport = () => {
    try {
      const leadership = dbInstance.getLeadership().filter(l => l.schoolId === school.id);
      const staff = dbInstance.getStaff().filter(s => s.schoolId === school.id);
      const materialCounts = dbInstance.getMaterialCounts().filter(mc => mc.schoolId === school.id);
      const studentAbsences = dbInstance.getStudentAbsences().filter(sa => sa.schoolId === school.id);
      const teacherAbsences = dbInstance.getTeacherAbsences().filter(ta => ta.schoolId === school.id);
      const visitors = dbInstance.getVisitors().filter(v => v.schoolId === school.id);
      const nutrition = dbInstance.getNutritionRecords().filter(n => n.schoolId === school.id);
      const examNominations = dbInstance.getExamNominations().filter(en => en.schoolId === school.id);
      const examExcuses = dbInstance.getExamExcuses().filter(ee => ee.schoolId === school.id);

      const payloadObj = {
        school,
        leadership,
        staff,
        materialCounts,
        studentAbsences,
        teacherAbsences,
        visitors,
        nutrition,
        examNominations,
        examExcuses
      };

      const uuidVal = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });

      const settings = dbInstance.getSettings();
      const payloadStr = JSON.stringify(payloadObj);
      const checksumVal = dbInstance.calculateChecksum(payloadStr);

      const exportObj = {
        metadata: {
          schoolId: school.id,
          schoolName: school.name,
          schoolCode: school.id,
          administrationName: settings.administrationName || 'إدارة أبو حماد التعليمية',
          stage: school.stage,
          exportDateTime: new Date().toISOString(),
          version: '1.0.0',
          fileId: uuidVal
        },
        payload: payloadStr,
        checksum: checksumVal
      };

      const finalStr = JSON.stringify(exportObj);
      const encoded = utf8ToBase64(finalStr);
      const fname = `School_${school.name.replace(/\s+/g, '_')}_${school.id}.abhm`;

      setGeneratedContent(encoded);
      setFileName(fname);
      setFileUUID(uuidVal);
      setExportStatus('success');

      // Trigger automatic download
      downloadFile(encoded, fname);
    } catch (e) {
      console.error(e);
      setExportStatus('error');
    }
  };

  const totalRecords = stats.reduce((acc, curr) => acc + curr.count, 0);

  // Sharing links
  const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(
    `السلام عليكم، مرفق ملف تصدير بيانات مدرسة: ${school.name}\nكود المدرسة: ${school.id}\nالرقم التسلسلي للملف: ${fileUUID}\nبتاريخ: ${new Date().toLocaleString('ar-EG')}\nبرجاء استيراده في لوحة التحكم الإدارية بالقسم.`
  )}`;

  const emailSubject = encodeURIComponent(`ملف تصدير بيانات مدرسة ${school.name} - كود ${school.id}`);
  const emailBody = encodeURIComponent(
    `السلام عليكم ورحمة الله وبركاته،\n\nمرفق طيه ملف بيانات مدرسة: ${school.name}\nكود المدرسة: ${school.id}\nالرقم التسلسلي للملف: ${fileUUID}\nتم تصديره بتاريخ: ${new Date().toLocaleString('ar-EG')}\n\nيرجى تحميل الملف المرفق واستيراده في لوحة التحكم الإدارية بقسم التنسيق.`
  );
  const emailUrl = `mailto:?subject=${emailSubject}&body=${emailBody}`;

  return (
    <div className="space-y-6 font-sans text-right animate-fadeIn" dir="rtl">
      <div className="bg-gradient-to-l from-indigo-900 via-slate-900 to-slate-900 border border-indigo-800/40 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl -translate-x-12 -translate-y-12" />
        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-600/20 text-emerald-400 rounded-xl border border-emerald-500/20">
              <Upload size={24} />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">مركز تصدير بيانات المدرسة للإدارة التعليمية</h2>
              <p className="text-xs text-slate-300">قم بتصدير وتأمين حزمة ملفات المدرسة بالكامل لإرسالها وتحديثها في الإدارة التعليمية بأبو حماد</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Statistics Pre-export Summary */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
          <h3 className="text-sm font-black text-slate-800 border-b border-slate-100 pb-3 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
            معاينة ملخص السجلات والبيانات الحالية قبل التصدير
          </h3>

          <div className="overflow-x-auto border border-slate-100 rounded-xl">
            <table className="w-full text-xs text-right border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-slate-750 font-black">
                  <th className="p-3">نوع السجل / البيان</th>
                  <th className="p-3 text-center">عدد السجلات</th>
                  <th className="p-3 text-left">حالة جاهزية البيانات</th>
                </tr>
              </thead>
              <tbody>
                {stats.map((item, i) => (
                  <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="p-3 font-bold text-slate-700">{item.name}</td>
                    <td className="p-3 text-center font-mono font-black text-slate-800">{item.count}</td>
                    <td className="p-3 text-left font-semibold">{item.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl flex justify-between items-center flex-wrap gap-2 text-xs font-bold text-slate-700">
            <span>إجمالي السجلات والكوادر الجاهزة للتجميع:</span>
            <span className="text-sm font-black text-indigo-700 bg-indigo-50 px-3 py-1 rounded-lg border border-indigo-100">
              {totalRecords} سجل
            </span>
          </div>

          <div className="pt-2">
            <button
              type="button"
              onClick={handleExport}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Upload size={16} />
              <span>توليد وتجميع ملف تصدير المدرسة المعتمد الموحد 📦</span>
            </button>
          </div>
        </div>

        {/* Export Results & Sharing Options */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
          <h3 className="text-sm font-black text-slate-800 border-b border-slate-100 pb-3 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
            حالة حزمة التصدير الحالية
          </h3>

          {exportStatus === 'idle' && (
            <div className="flex flex-col items-center justify-center p-8 text-center border border-dashed border-slate-200 rounded-2xl bg-slate-50/50 space-y-3">
              <Upload size={32} className="text-slate-350 animate-bounce" />
              <p className="text-xs font-bold text-slate-600">يرجى النقر على زر التصدير لتوليد الملف</p>
              <p className="text-[10px] text-slate-400">سيتم تجميع كافة السجلات في ملف بصيغة مشفرة معتمدة (.abhm)</p>
            </div>
          )}

          {exportStatus === 'error' && (
            <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-center text-rose-800 text-xs space-y-2">
              <p className="font-black">❌ حدث خطأ أثناء تجميع وتوليد ملف التصدير!</p>
              <p className="text-[10px] text-rose-600">يرجى التأكد من استكمال كافة الحقول والبيانات الأساسية للمدرسة والمحاولة مرة أخرى.</p>
            </div>
          )}

          {exportStatus === 'success' && (
            <div className="space-y-5">
              <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl text-center text-emerald-900 text-xs space-y-2">
                <p className="font-black">✅ تم توليد وتجهيز الملف وتحميله بنجاح!</p>
                <div className="p-3 bg-white border border-emerald-100 rounded-xl space-y-1 text-right font-mono text-[10px] text-slate-600">
                  <p className="break-all font-bold text-emerald-800"><span className="font-sans">اسم الملف: </span>{fileName}</p>
                  <p className="break-all"><span className="font-sans">المعرف الفريد (UUID): </span>{fileUUID}</p>
                </div>
              </div>

              <div className="space-y-3">
                <span className="block text-[11px] font-black text-slate-600">خيارات مشاركة وحفظ الملف:</span>
                
                {/* Save directly to computer */}
                <button
                  type="button"
                  onClick={() => downloadFile(generatedContent, fileName)}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Save size={14} />
                  <span>حفظ على الجهاز الكمبيوتر 💾</span>
                </button>

                {/* Save on USB drive instructions */}
                <button
                  type="button"
                  onClick={() => {
                    downloadFile(generatedContent, fileName);
                    alert('📁 تم إعادة تنزيل الملف لحفظه على الفلاشة.\nخطوة الحفظ على الفلاشة:\n1. قم بتركيب الفلاشة (USB Drive) بالكمبيوتر.\n2. انسخ الملف المحمل من مجلد التنزيلات والصقه بداخل الفلاشة لتسليمه لقسم التنسيق.');
                  }}
                  className="w-full py-2.5 bg-blue-50 text-blue-750 border border-blue-100 hover:bg-blue-100 text-xs font-bold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>📁 حفظ على فلاشة (USB Flash)</span>
                </button>

                {/* Share via WhatsApp Web */}
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer no-underline block text-center"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.262 2.268 3.502 5.282 3.502 8.484 0 6.657-5.338 11.997-11.95 11.997-2.005-.001-3.973-.502-5.724-1.454L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.625 1.449 5.4 0 9.794-4.4 9.795-9.8 0-2.615-1.017-5.074-2.864-6.923-1.848-1.848-4.308-2.865-6.924-2.865-5.4 0-9.794 4.4-9.797 9.8-.001 1.554.412 3.076 1.194 4.428l-.1.365-.968 3.536 3.623-.95.355.21z"/>
                  </svg>
                  <span>مشاركة عبر واتساب للإدارة 📱</span>
                </a>

                {/* Share via Email */}
                <a
                  href={emailUrl}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer no-underline block text-center"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                  </svg>
                  <span>مشاركة بالبريد الإلكتروني 📧</span>
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Convert UTF-8 to Base64 (Arabic characters safe)
function utf8ToBase64(str: string): string {
  return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (match, p1) => {
    return String.fromCharCode(parseInt(p1, 16));
  }));
}

// Convert Base64 to UTF-8
export function base64ToUtf8(str: string): string {
  return decodeURIComponent(Array.prototype.map.call(atob(str), (c) => {
    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
  }).join(''));
}

// File download helper
function downloadFile(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

