/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
// @ts-ignore
import brandLogo from '../assets/images/school_coordination_logo_1781360075640.jpg';

interface EducationalLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  glowing?: boolean;
  withText?: boolean;
  invertedText?: boolean;
}

export function EducationalLogo({ 
  size = 'md', 
  glowing = true, 
  withText = false,
  invertedText = false
}: EducationalLogoProps) {
  // Dimension mappings for the logo container to scale down elegantly
  const dims = {
    xs: 'w-10 h-10',
    sm: 'w-16 h-16',
    md: 'w-24 h-24',
    lg: 'w-36 h-36',
    xl: 'w-52 h-52',
  }[size];

  const textSizes = {
    xs: 'text-[9px]',
    sm: 'text-xs',
    md: 'text-sm md:text-base',
    lg: 'text-lg md:text-xl',
    xl: 'text-xl md:text-2xl',
  }[size];

  return (
    <div className="inline-flex flex-col items-center justify-center select-none text-center">
      {/* 
        High-fidelity 3D metallic dark blue background exactly matching the custom photo.
        Rounded wrapper with responsive scale.
      */}
      <div 
        className={`relative flex items-center justify-center rounded-2xl overflow-hidden border border-amber-500/20 transition-all duration-300 hover:scale-[1.03] ${dims} ${glowing ? 'animate-pulse-glow shadow-xl shadow-blue-950/40' : 'shadow-md'}`}
      >
        <img 
          src={brandLogo} 
          alt="لوجو محمد نجم - Mohamed Negm Logo" 
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover select-none pointer-events-none"
        />
      </div>
      
      {/* Classic gold typography match below the logo container */}
      {withText && (
        <div className="mt-3.5 text-center space-y-1">
          {/* Authentic Gold Gradient Text Effect */}
          <div className={`${textSizes} font-serif font-black tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-amber-600 via-amber-400 to-amber-700 drop-shadow-sm`}>
            مـحمـد نـجـم
          </div>
          <p className="text-[10px] md:text-sm font-serif font-black tracking-widest text-amber-500 uppercase">
            N e g m
          </p>
          <div className="w-18 h-[1.5px] bg-gradient-to-r from-transparent via-amber-500/50 to-transparent mx-auto" />
          <p className={`text-[9px] font-medium leading-relaxed ${invertedText ? 'text-blue-100/80' : 'text-slate-500'}`}>
            منصة التنسيق المدرسي وربط اليومية
          </p>
        </div>
      )}
    </div>
  );
}
