/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface PrintHeaderProps {
  title: string;
  subtitle?: string;
  isVisible?: boolean;
}

export function PrintHeader({ title, subtitle, isVisible = false }: PrintHeaderProps) {
  return (
    <div className={`${isVisible ? 'block' : 'hidden print:block'} border-b-4 border-slate-900 pb-4 mb-6 font-sans text-right`} dir="rtl" style={{ fontFamily: '"Cairo", "Inter", sans-serif' }}>
      <div className="flex justify-between items-center w-full">
        {/* Right: Official Hierarchy */}
        <div className="text-right space-y-1 shrink-0">
          <h2 className="text-sm font-black text-slate-950">وزارة التربية والتعليم والتعليم الفني</h2>
          <h3 className="text-xs font-bold text-slate-800">مديرية التربية والتعليم بالشرقية</h3>
          <h4 className="text-xs font-semibold text-slate-700">إدارة أبو حماد التعليمية</h4>
          <p className="text-[9px] text-slate-600 font-extrabold bg-slate-100 px-2 py-0.5 rounded-md inline-block border border-slate-200">قسم التنسيق العام</p>
        </div>

        {/* Center: Ministry of Education Logo (High-fidelity Golden Emblem) */}
        <div className="flex flex-col items-center justify-center text-center px-4 shrink-0">
          <svg className="w-14 h-14 drop-shadow-sm select-none" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Outer elegant double ring seal */}
            <circle cx="50" cy="50" r="46" stroke="#BF953F" strokeWidth="1.2" />
            <circle cx="50" cy="50" r="42" stroke="#BF953F" strokeWidth="0.5" strokeDasharray="2 2" />
            
            {/* Stylized Egyptian Eagle / Falcon of Quraish in Gold */}
            <path d="M50 22 L52.5 31 L61 32.5 L54.5 37.5 L56 46 L50 41 L44 46 L45.5 37.5 L39 32.5 L47.5 31 Z" fill="#BF953F" />
            
            {/* Central Shield with Egyptian Stripes */}
            <rect x="47.5" y="31.5" width="5" height="7" rx="0.5" fill="#FFFFFF" stroke="#8A661D" strokeWidth="0.5" />
            <line x1="48" y1="33" x2="52" y2="33" stroke="#D32F2F" strokeWidth="0.8" />
            <line x1="48" y1="35" x2="52" y2="35" stroke="#BF953F" strokeWidth="0.8" />
            <line x1="48" y1="37" x2="52" y2="37" stroke="#111111" strokeWidth="0.8" />

            {/* Book / Knowledge lines below eagle */}
            <path d="M38 56 Q50 52 62 56 M38 59 Q50 55 62 59" stroke="#BF953F" strokeWidth="0.8" fill="none" />
            <line x1="50" y1="48" x2="50" y2="55" stroke="#BF953F" strokeWidth="0.8" />

            {/* Ribbon / Banner */}
            <path d="M34 66 C42 64 58 64 66 66 L64 69.5 C56 67.5 44 67.5 36 69.5 Z" fill="#9C7A2E" />
            
            <path id="sealPathPrint" d="M18,50 A32,32 0 1,1 82,50" fill="none" stroke="transparent" />
            <text fill="#8A661D" className="text-[4.5px] font-sans font-bold">
              <textPath href="#sealPathPrint" startOffset="50%" textAnchor="middle">
                جمهورية مصر العربية - وزارة التربية والتعليم
              </textPath>
            </text>
          </svg>
          <span className="text-[8px] font-black tracking-wide text-slate-850 mt-1">جمهورية مصر العربية</span>
        </div>

        {/* Left: Validation / Print metadata badge */}
        <div className="text-center p-2 border border-slate-200 bg-slate-50 rounded-xl select-none print:bg-white print:border-slate-800 shrink-0">
          <span className="block text-[8px] text-[#2E7D32] bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-md font-black mb-1">عَلَم الإدارة والتميز</span>
          <span className="block font-black text-slate-900 text-[9px] tracking-wide">النسخة الرسمية المعتمدة</span>
          <span className="block text-[8px] text-slate-500 font-mono mt-1 font-bold">تاريخ الطباعة: {new Date().toLocaleDateString('ar-EG')}</span>
        </div>
      </div>
      
      <div className="mt-5 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white py-3 px-4 rounded-xl text-center shadow-xs">
        <h1 className="text-lg md:text-xl font-black tracking-wide leading-tight whitespace-pre-line">{title}</h1>
        {subtitle && <p className="text-[10px] md:text-xs text-slate-200 mt-1 font-bold">{subtitle}</p>}
      </div>
    </div>
  );
}

interface PrintFooterProps {
  isVisible?: boolean;
}

export function PrintFooter({ isVisible = false }: PrintFooterProps) {
  return (
    <div className={`${isVisible ? 'block' : 'hidden print:block'} border-t border-slate-300 pt-3 mt-8 font-sans text-right`} dir="rtl" style={{ fontFamily: '"Cairo", "Inter", sans-serif' }}>
      {/* Micro Footer Citation */}
      <div className="text-center text-[10px] text-slate-500 select-none flex justify-between items-center px-2">
        <span>منصة التنسيق العام اللامركزية - إدارة أبو حماد التعليمية</span>
        <div className="flex gap-4">
          <span>تاريخ التقرير: <span className="font-mono font-bold">{new Date().toLocaleDateString('ar-EG')}</span></span>
          <span>رقم الصفحة: <span className="font-mono font-bold">1</span></span>
        </div>
        <span>النسخة المطبوعة المستخرجة إلكترونياً</span>
      </div>
    </div>
  );
}

interface PrintableReportProps {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

export default function PrintableReport({ title, subtitle, children }: PrintableReportProps) {
  return (
    <div className="w-full bg-white p-6 max-w-4xl mx-auto shadow-sm rounded-lg border border-slate-100 print:shadow-none print:border-none print:p-0 font-sans text-right" dir="rtl" style={{ fontFamily: '"Cairo", "Inter", sans-serif' }}>
      {/* Printable Sheet Wrapper */}
      <div className="flex flex-col h-full justify-between">
        
        {/* Reusable Official Header */}
        <PrintHeader title={title} subtitle={subtitle} isVisible={true} />

        {/* Dynamic Content Body */}
        <div className="flex-grow my-4 min-h-[300px]">
          {children}
        </div>

        {/* Official Footer with Signature Blocks */}
        <div className="border-t-2 border-black pt-6 mt-10">
          <div className="grid grid-cols-3 gap-4 text-center">
            {/* Right Signature Block */}
            <div className="space-y-1">
              <p className="text-slate-500 text-xs font-bold">إعداد ومراجعة بالتنسيق</p>
              <h4 className="text-sm font-bold text-slate-950 mt-1">الأستاذ محمد نـجـم</h4>
              <p className="text-xs text-slate-700">مدير التنسيق العام</p>
              <div className="h-10 border-b border-dashed border-slate-300 w-32 mx-auto mt-2" />
            </div>

            {/* Middle Signature Block */}
            <div className="space-y-1">
              <p className="text-slate-500 text-xs font-bold">يعتمد،، وكلاء الإدارة</p>
              <h4 className="text-sm font-bold text-slate-950 mt-1">الأستاذ علاء المرجل</h4>
              <h4 className="text-sm font-bold text-slate-950">الأستاذ عبد المنعم شعلان</h4>
              <p className="text-xs text-slate-700">وكلاء الإدارة التعليمية</p>
              <div className="h-10 border-b border-dashed border-slate-300 w-32 mx-auto mt-2" />
            </div>

            {/* Left Signature Block */}
            <div className="space-y-1">
              <p className="text-slate-500 text-xs font-bold">اعتماد السلطة المختصة</p>
              <h4 className="text-sm font-bold text-slate-950 mt-1">الأستاذ محمد منصور العباسي</h4>
              <p className="text-xs text-slate-700 font-semibold">مدير عام الإدارة التعليمية</p>
              <div className="h-10 border-b border-dashed border-slate-300 w-32 mx-auto mt-2" />
            </div>
          </div>

          {/* Reusable Official Footer */}
          <PrintFooter isVisible={true} />
        </div>

      </div>
    </div>
  );
}
