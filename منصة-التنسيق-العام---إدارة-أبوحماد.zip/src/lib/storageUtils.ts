import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from './firebase';

/**
 * Reads a File object as Base64 Data URL.
 */
function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      resolve(reader.result as string);
    };
    reader.onerror = () => reject(new Error('FileReader failed'));
    reader.readAsDataURL(file);
  });
}

/**
 * Uploads a file to Firebase Storage.
 * Falls back to Base64 Data URL if offline or if storage fails, or if it times out
 * to avoid hanging/unresponsive "Uploading" spinners (جاري الرفع).
 */
export async function uploadNominationFile(
  file: File,
  schoolId: string,
  personName: string
): Promise<{ url: string; fallback: boolean }> {
  const fileExtension = file.name.split('.').pop() || 'dat';
  const timestamp = Date.now();
  const safeName = personName.replace(/\s+/g, '_').slice(0, 30);
  const storagePath = `nominations/${schoolId}/${safeName}_${timestamp}.${fileExtension}`;

  // Pre-generate Base64 so we can fall back to it immediately on timeout/failure
  let base64Url = '';
  try {
    base64Url = await readFileAsBase64(file);
  } catch (error) {
    console.error('Failed to parse file into base64:', error);
  }

  // Define the Firebase Storage upload utility
  const runUpload = async (): Promise<string> => {
    const storageRef = ref(storage, storagePath);
    const snapshot = await uploadBytes(storageRef, file);
    const downloadUrl = await getDownloadURL(snapshot.ref);
    return downloadUrl;
  };

  // Create a 1000ms timeout so we don't block the user's interface
  const timeoutLimit = 1000;
  const timeoutPromise = new Promise<string>((_, reject) => {
    setTimeout(() => {
      reject(new Error(`Storage operation timed out after ${timeoutLimit}ms`));
    }, timeoutLimit);
  });

  try {
    // Race the Firebase Storage upload against our fast 1-second timeout
    const downloadUrl = await Promise.race([runUpload(), timeoutPromise]);
    console.log('Successfully uploaded document to Firebase Storage:', downloadUrl);
    return { url: downloadUrl, fallback: false };
  } catch (error) {
    console.warn(
      'Firebase Storage connection timed out, is offline, or lacks permissions. Fast falling back to Base64:',
      error
    );
    // If we have a valid Base64 representation, use it. Otherwise, return an empty string to prevent crashing.
    return { url: base64Url || '', fallback: true };
  }
}
