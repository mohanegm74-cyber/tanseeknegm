/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { dbInstance } from './data/db';
import { School, SystemSettings } from './types';
import SchoolPrincipalPortal from './components/SchoolPrincipalPortal';
import CoordinationAdminPortal from './components/CoordinationAdminPortal';
import Footer from './components/Footer';
import { EducationalLogo } from './components/EducationalLogo';
import { 
  Building2, 
  Lock, 
  Search, 
  LogIn, 
  ArrowLeft, 
  Share2, 
  AlertCircle,
  RefreshCw,
  FolderLock,
  Home,
  LogOut
} from 'lucide-react';

export default function App() {
  const [dbTick, setDbTick] = useState(0);

  // Authentications states
  const [currentRole, setCurrentRole] = useState<'guest' | 'school' | 'admin'>('guest');
  const [activeSchoolId, setActiveSchoolId] = useState<string>('');
  const [activeSchoolPin, setActiveSchoolPin] = useState<string>('');

  // Credentials inputs
  const [adminUser, setAdminUser] = useState('');
  const [adminPass, setAdminPass] = useState('');

  // Selector controls
  const [schoolSearch, setSchoolSearch] = useState('');
  const [schoolsList, setSchoolsList] = useState<School[]>([]);
  const [selectedSchoolForLogin, setSelectedSchoolForLogin] = useState<School | null>(null);

  // Layout frames
  const [portalMode, setPortalMode] = useState<'select' | 'school_auth' | 'admin_auth'>('select');
  const [authError, setAuthError] = useState('');

  // Quota state
  const [quotaExceeded, setQuotaExceeded] = useState(false);

  // Connection & Sync status states
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [hasUnsynced, setHasUnsynced] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      dbInstance.syncAllUnsyncedToFirestore().catch(err => console.warn('Online auto-sync failed:', err));
    };
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const checkSync = () => {
      setHasUnsynced(dbInstance.hasUnsyncedChanges(activeSchoolId || undefined));
    };

    checkSync();
    const unsub = dbInstance.subscribe(checkSync);

    // Periodic check and auto-sync if online every 30 seconds
    const interval = setInterval(() => {
      if (navigator.onLine) {
        dbInstance.syncAllUnsyncedToFirestore().catch(err => console.warn('Periodic auto-sync failed:', err));
      }
    }, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
      unsub();
    };
  }, [activeSchoolId]);

  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).firestoreQuotaExceeded) {
      setQuotaExceeded(true);
    }
    const handleQuota = () => setQuotaExceeded(true);
    window.addEventListener('firestore-quota-exceeded', handleQuota);
    return () => {
      window.removeEventListener('firestore-quota-exceeded', handleQuota);
    };
  }, []);

  // Load database lists
  const refreshDatabaseList = () => {
    setSchoolsList(dbInstance.getSchools());
  };

  useEffect(() => {
    refreshDatabaseList();
    return dbInstance.subscribe(() => {
      refreshDatabaseList();
      setDbTick(prev => prev + 1);
    });
  }, []);

  // Filter school name list during input
  const filteredSchools = useMemo(() => {
    if (!schoolSearch.trim()) return schoolsList;
    const query = schoolSearch.toLowerCase();
    return schoolsList.filter(s => s.name.toLowerCase().includes(query));
  }, [schoolsList, schoolSearch]);

  // Handle Principal PIN Authentication
  const handlePrincipalLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    if (!selectedSchoolForLogin) return;

    if (activeSchoolPin === selectedSchoolForLogin.password) {
      setActiveSchoolId(selectedSchoolForLogin.id);
      setCurrentRole('school');
      setAuthError('');
    } else {
      setAuthError('عفواً الرقم السري المدخل غير صحيح للمدرسة المحددة.');
    }
  };

  // Handle Admin Credentials Authentication
  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    const sysSettings = dbInstance.getSettings();
    if (adminPass === sysSettings.coordinationAdminPass) {
      setCurrentRole('admin');
      setAuthError('');
    } else {
      setAuthError('خطأ في الرقم السري لمشرف التنسيق.');
    }
  };

  const handleLogout = () => {
    setCurrentRole('guest');
    setPortalMode('select');
    setSelectedSchoolForLogin(null);
    setActiveSchoolPin('');
    setAdminUser('');
    setAdminPass('');
    setAuthError('');
  };

  const handleWhatsAppShare = () => {
    const text = encodeURIComponent(
      `مرحباً، تفضل بزيارة منصة التنسيق العام بإدارة أبوحماد التعليمية الرقمية لإنجاز معاملات وقوى المدارس في الوقت الفعلي:\n${window.location.href}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  // Helper trigger to reset localStorage to defaults
  const handleResetSystemDB = () => {
    if (confirm('تنبيه هام جداً: هل ترغب في إعادة ضبط قاعدة البيانات السحابية إلى حالتها الأصلية ومسح كافة الكوادر الجديدة؟ لتسجيل الاختبار.')) {
      dbInstance.resetToDefaults();
      handleLogout();
      alert('تم استعادة قاعدة بيانات إدارة أبوحماد التعليمية الافتراضية بنجاح.');
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col justify-between font-sans text-[#212121]" dir="rtl">
      
      {/* Upper Status Ribbon Header */}
      <header className="bg-[#0D47A1] border-b-2 border-[#D4AF37] text-white select-none shrink-0 print:hidden shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center flex-wrap gap-2">
          
          <div className="flex items-center gap-3">
            {/* Interactive Logo Button at the top */}
            <button
              onClick={handleLogout}
              type="button"
              className="flex items-center justify-center p-0.5 rounded-full hover:scale-105 active:scale-95 transition-all focus:outline-none cursor-pointer"
              title="العودة للرئيسية والتسجيل"
            >
              <EducationalLogo size="xs" glowing={true} />
            </button>

            <div className="p-1 px-2.5 bg-white/20 border border-white/25 rounded-lg text-center text-[10px] font-black tracking-wide shrink-0 text-yellow-100">
              الموقع تحت التجريب
            </div>
            <div className="truncate">
              <h1 className="text-xs md:text-sm font-extrabold tracking-wide text-white">منصة التنسيق العام</h1>
              <p className="text-[10px] text-blue-100 font-bold">إدارة أبو حماد التعليمية</p>
            </div>
          </div>

          <div className="flex items-center gap-2 md:gap-3">
            {/* Sync Status Badge Indicator */}
            {!isOnline ? (
              <div className="flex items-center gap-1 px-2 py-1 bg-red-600 border border-red-500 rounded-xl text-[10px] md:text-xs font-black text-white shrink-0 shadow-sm animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-red-300 shrink-0" />
                <span>🔴 لا يوجد اتصال</span>
              </div>
            ) : hasUnsynced ? (
              <div className="flex items-center gap-1 px-2 py-1 bg-amber-500 border border-amber-400 rounded-xl text-[10px] md:text-xs font-black text-slate-900 shrink-0 shadow-sm animate-bounce" title="توجد تعديلات محفوظة محلياً على جهازك؛ يرجى الضغط على إرسال للإدارة لمزامنتها سحابياً">
                <span className="w-1.5 h-1.5 rounded-full bg-white shrink-0 animate-ping" />
                <span>🟡 جاري المزامنة محلياً</span>
              </div>
            ) : (
              <div className="flex items-center gap-1 px-2 py-1 bg-emerald-600 border border-emerald-500 rounded-xl text-[10px] md:text-xs font-black text-white shrink-0 shadow-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-350 shrink-0" />
                <span>🟢 متصل وتمت المزامنة</span>
              </div>
            )}

            {currentRole !== 'guest' && (
              <button
                onClick={handleLogout}
                type="button"
                className="px-3 py-1.5 bg-[#D32F2F] hover:bg-red-800 border border-red-500/20 rounded-xl text-[10px] md:text-xs font-black transition-all shadow-md flex items-center gap-1.5 cursor-pointer text-white active:scale-95 animate-fade-in"
                title="الخروج الفوري والعودة للشاشة الرئيسية"
              >
                <Home size={12} />
                <span>خروج وعودة للرئيسية</span>
              </button>
            )}

            <button
              onClick={handleWhatsAppShare}
              type="button"
              className="px-2.5 py-1.5 bg-[#2E7D32] hover:bg-green-800 rounded-xl text-[10px] font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer text-white active:scale-95"
              title="مشاركة المنصة على تطبيق الواتساب"
            >
              <Share2 size={12} />
              مشاركة واتساب
            </button>
            <button
              onClick={handleResetSystemDB}
              type="button"
              className="px-2 py-1.5 bg-white/20 hover:bg-white/30 border border-white/10 rounded-xl text-[10px] font-bold text-white transition flex items-center gap-1 cursor-pointer active:scale-95"
              title="إعادة تهيئة النظام لبيانات الاختبار"
            >
              <RefreshCw size={10} />
              تهيئة تجريبية
            </button>
          </div>

        </div>
      </header>

      {quotaExceeded && (
        <div className="bg-[#FFF3CD] border-b border-[#FFEBAA] text-[#856404] font-sans print:hidden shadow-sm transition-all duration-300">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2 text-xs md:text-sm font-extrabold text-[#856404]">
              <AlertCircle size={16} className="text-[#856404] shrink-0 animate-bounce" />
              <span>تنبيه: تم تجاوز حد الاستهلاك السحابي اليومي المجاني لقاعدة البيانات (Firebase Quota Limit Exceeded). تم تفعيل وضع حفظ البيانات المحلي الآمن (Offline Local Storage Mode) تلقائياً لضمان استمرار واستقرار عمل المنصة بنسبة 100%.</span>
            </div>
            <span className="px-2.5 py-1 bg-[#856404] text-[#FFF3CD] text-[10px] font-black rounded-lg uppercase tracking-wider shrink-0 animate-pulse">
              الوضع المحلي نشط 💾
            </span>
          </div>
        </div>
      )}

      {/* Primary Dynamic Stage Frame */}
      <main className="flex-grow flex items-center justify-center p-4 md:p-8">
        
        {/* Render guest entrance logins choice panels */}
        {currentRole === 'guest' ? (
          <div className="w-full max-w-lg mx-auto bg-white border border-slate-250 rounded-2xl shadow-2xl overflow-hidden animate-fade-in print:hidden select-none text-[#212121]">
            
            {/* Banner block brand with pulsing/glowing official logo */}
            <div className="bg-gradient-to-l from-[#0D47A1] via-[#1976D2] to-[#0D47A1] text-white p-6 md:p-8 text-center space-y-3 flex flex-col items-center justify-center border-b border-[#D4AF37]/50">
              <EducationalLogo size="lg" glowing={true} />
              <div className="space-y-1">
                <h2 className="text-2xl font-black font-sans tracking-tight leading-tight text-white">منصة التنسيق العام</h2>
                <p className="text-yellow-105 text-xs font-bold font-sans">إدارة أبو حماد التعليمية</p>
              </div>
            </div>

            <div className="p-6 md:p-8 bg-white">
              
              {portalMode === 'select' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="text-center pb-3 border-b border-slate-200">
                    <p className="text-xs font-black text-slate-700">الرجاء تحديد صلاحيتك المهنية لبدء الاستكشاف سحابياً</p>
                  </div>

                  {/* Dual options triggers */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* School option */}
                    <button
                      type="button"
                      onClick={() => setPortalMode('school_auth')}
                      className="group p-5 border border-slate-250 rounded-xl bg-slate-50 hover:bg-slate-100/50 hover:border-[#1976D2]/60 transition-all text-center space-y-2 cursor-pointer h-full flex flex-col justify-between shadow-md"
                    >
                      <Building2 className="w-10 h-10 mx-auto text-[#1976D2] transition group-hover:scale-110 group-hover:text-[#0D47A1]" />
                      <div className="space-y-1">
                        <h3 className="font-extrabold text-[#212121] text-sm">🏫 دخول مدير مدرسة</h3>
                        <p className="text-[10px] text-slate-500 leading-relaxed font-black">إدراج الطواقم المدرسية ونسب الغياب ووجبات التغذية</p>
                      </div>
                    </button>

                    {/* Admin option */}
                    <button
                      type="button"
                      onClick={() => setPortalMode('admin_auth')}
                      className="group p-5 border border-slate-250 rounded-xl bg-slate-50 hover:bg-slate-100/50 hover:border-[#1976D2]/60 transition-all text-center space-y-2 cursor-pointer h-full flex flex-col justify-between shadow-md"
                    >
                      <FolderLock className="w-10 h-10 mx-auto text-[#0D47A1] transition group-hover:scale-110 group-hover:text-[#1976D2]" />
                      <div className="space-y-1">
                        <h3 className="font-extrabold text-[#212121] text-sm">🏢 دخول مدير التنسيق</h3>
                        <p className="text-[10px] text-slate-500 leading-relaxed font-black">عرض العجز والزيادة بالإدارة وتخصيص المواد وطباعة المستندات</p>
                      </div>
                    </button>

                  </div>

                  <div className="pt-2 text-center text-[10px] text-slate-500 tracking-wide font-bold">
                    بوابة آمنة ومحمية وفق لوائح مديرية التربية والتعليم بالشرقية لإدارة الكوادر ٢٠٢٦
                  </div>
                </div>
              )}

              {/* SCHOOL AUTHENTICATION PORTLET */}
              {portalMode === 'school_auth' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-1.5 text-[#1565C0] cursor-pointer text-xs font-semibold pb-1.5 border-b border-slate-100" onClick={() => { setPortalMode('select'); setSelectedSchoolForLogin(null); setAuthError(''); }}>
                    <ArrowLeft size={14} />
                    <span>الرجوع واختيار صلاحية دخول أخرى</span>
                  </div>

                  {!selectedSchoolForLogin ? (
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">ابحث باسم المدرسة فورا:</label>
                        <div className="relative">
                          <input
                            type="text"
                            placeholder="اكتب هنا للبحث الفوري... (مثال: مدرسة السنجق)"
                            value={schoolSearch}
                            onChange={e => setSchoolSearch(e.target.value)}
                            className="w-full pl-4 pr-10 py-2.5 text-sm border border-slate-200 rounded-xl text-right focus:outline-none focus:ring-2 focus:ring-[#1565C0]/20 focus:border-[#1565C0] bg-white transition shadow-xs"
                          />
                          <span className="absolute right-3 top-3.5 text-slate-400"><Search size={16} /></span>
                        </div>
                      </div>

                      <div className="max-h-[180px] overflow-y-auto border border-slate-100 rounded-xl bg-slate-50/50 p-2 space-y-1">
                        {filteredSchools.length === 0 ? (
                          <div className="text-center p-4 text-slate-400 text-xs">لا يوجد مدارس مطابقة للاسم المدخل</div>
                        ) : (
                          filteredSchools.map(sch => (
                            <button
                              key={sch.id}
                              type="button"
                              onClick={() => setSelectedSchoolForLogin(sch)}
                              className="w-full text-right p-2.5 text-xs font-semibold hover:bg-[#1565C0] hover:text-white rounded-lg transition tracking-wide cursor-pointer flex justify-between items-center bg-white border border-slate-100/50 mb-1 last:mb-0 shadow-2xs hover:shadow-none"
                            >
                              <span>{sch.name}</span>
                              <span className="text-[9px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-bold group-hover:bg-[#1565C0]">
                                {sch.stage === 'primary' ? 'ابتدائي' : sch.stage === 'prep' ? 'إعدادي' : sch.stage === 'sec' ? 'ثانوي' : 'آخر'}
                              </span>
                            </button>
                          ))
                        )}
                      </div>
                      <p className="text-[10px] text-slate-400 text-center">انقر على المدرسة من القائمة بالأعلى لإدخال كود الأمان</p>
                    </div>
                  ) : (
                    /* Prompt PIN passcode login */
                    <form onSubmit={handlePrincipalLoginSubmit} className="space-y-4 animate-fade-in">
                      <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-3.5 text-center shadow-2xs animate-fade-in">
                        <span className="text-[9px] bg-[#1565C0] text-white font-bold rounded px-1.5 py-0.5">مدرسة محددة</span>
                        <h4 className="font-extrabold text-[#1565C0] mt-1.5 text-xs md:text-sm">{selectedSchoolForLogin.name}</h4>
                        <button type="button" onClick={() => setSelectedSchoolForLogin(null)} className="text-[10px] text-[#1565C0] hover:underline mt-1 font-bold">تغيير المدرسة</button>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">الرقم السري للمدرسة (PIN Entry) *</label>
                        <input
                          type="password"
                          placeholder="الرقم السري للمدرسة... (التجريبي: ١٠١، ١٠٢ إلخ)"
                          value={activeSchoolPin}
                          onChange={e => setActiveSchoolPin(e.target.value)}
                          className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl text-center tracking-widest font-bold focus:outline-none focus:ring-2 focus:ring-[#1565C0]/20 focus:border-[#1565C0] bg-white transition shadow-xs"
                        />
                      </div>

                      {authError && (
                        <div className="p-2.5 border border-rose-150 bg-rose-50 text-rose-600 text-xs font-bold rounded-xl flex items-center gap-1.5">
                          <AlertCircle size={14} className="shrink-0 animate-bounce" />
                          <span>{authError}</span>
                        </div>
                      )}

                      <button
                        type="submit"
                        className="w-full py-2.5 bg-gradient-to-r from-[#0D47A1] via-[#1565C0] to-[#1E88E5] hover:brightness-110 text-white text-xs font-black shadow-md shadow-blue-200/50 hover:shadow-lg hover:shadow-blue-300/40 transition-all rounded-xl flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                      >
                        <LogIn size={14} />
                        دخول بوابة مدير مدرسة
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* COORDINATION ADMIN AUTHENTICATION PORTLET */}
              {portalMode === 'admin_auth' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-1.5 text-slate-500 cursor-pointer text-xs font-semibold pb-1.5 border-b border-indigo-100" onClick={() => { setPortalMode('select'); setAuthError(''); }}>
                    <ArrowLeft size={14} />
                    <span>الرجوع واختيار صلاحية دخول أخرى</span>
                  </div>

                  <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-755 mb-1">الرقم السري للمشرف (Passcode) *</label>
                      <input
                        type="password"
                        placeholder="الرقم السري للمشرف... (التجريبي: 1234)"
                        value={adminPass}
                        onChange={e => setAdminPass(e.target.value)}
                        className="w-full px-3 py-2.5 text-sm border border-slate-200 text-center rounded-xl tracking-widest font-bold focus:outline-none focus:ring-2 focus:ring-[#1565C0]/20 focus:border-[#1565C0] bg-white transition shadow-xs"
                      />
                    </div>

                    {authError && (
                      <div className="p-2.5 border border-rose-150 bg-rose-50 text-rose-600 text-xs font-bold rounded-xl flex items-center gap-1.5">
                        <AlertCircle size={14} className="shrink-0 animate-bounce" />
                        <span>{authError}</span>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-gradient-to-r from-[#0D47A1] via-[#1565C0] to-[#1E88E5] hover:brightness-110 text-white text-xs font-black shadow-md shadow-blue-200/50 hover:shadow-lg hover:shadow-blue-300/40 transition-all rounded-xl flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                    >
                      <LogIn size={14} />
                      دخول بوابة التنسيق العام
                    </button>
                  </form>
                </div>
              )}

            </div>

          </div>
        ) : currentRole === 'school' ? (
          /* School principal portal view */
          <SchoolPrincipalPortal schoolId={activeSchoolId} onLogout={handleLogout} />
        ) : (
          /* Coordination General Admin portal */
          <CoordinationAdminPortal onLogout={handleLogout} />
        )}

      </main>

      {/* Official Footers on all screens */}
      <Footer showCredits={currentRole === 'guest'} />

    </div>
  );
}
